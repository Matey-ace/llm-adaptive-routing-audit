"""答案评分与指标计算。

原则：评分必须**程序可判定**，不依赖人工或 LLM 评审（自建集尤其如此）。
这样"任务成功率"才是可复现的客观量，也是回应"避免主观选择有利于本文方法的数据"的关键。

metric 类型：
  exact_match      字符串规范化后完全相等
  numeric_match    抽取"纯数值"后按容差比较（先从约定的最终答案位置提取）
  gsm8k_numeric   同 numeric_match 语义；专用于 GSM8K 官方"#### "后最终答案的约定
  math_equiv      MATH 解答：字符串范式 -> 结构化 -> sympy 符号/数值 三段判定
  contains         gold 是否作为子串出现在答案中（大小写与空白规范化）
  tool_trajectory  工具调用序列与 gold_trajectory 一致且终态答案正确（首批数据集不使用）

------------------------------------------------------------------------------
P1 修复要点（2026-10-13）
------------------------------------------------------------------------------
旧 `math_equiv` 会用 `extract_final_number`（取最后一个数）做数值比较，导致
  "2" vs "x+2"、"2/3" vs "5/3"、"2" vs "\\sqrt{2}"
三个假阳性（详见 `eval/extractors.py` 模块文档）。本版改为
`compare_answers`（eval/extractors.py）提供的规范化三判定：
    norm_equal -> set_equal / ordered_equal -> symbolic_equal / numeric_equal
只有**双方都是纯数值**时才启用数值比较，这是消除假阳性的关键。
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from tasks.dataset import Task
from eval.extractors import (extract_final_number, extract_boxed,
                             latex_normalize, normalize as _normalize,
                             extract_answer_span, canonical_text,
                             compare_answers, to_number,
                             _num_close,
                             SCORER_VERSION as _EXTRACTOR_VERSION)

# 评分口径版本（单一真源在 eval/extractors.py）：修改比较语义必须递增，
# 并同步更新 `paper/实验协议.md`。raw 日志会记录该版本以便事后追溯。
SCORER_VERSION = _EXTRACTOR_VERSION

# 数值比较容差：**仅绝对容差 1e-6，不使用相对容差**。
# 相对容差在大数上过宽（gold=3750000 与 3750001 的相对差仅 2.7e-7，会被误判相等），
# 这是负例控检在真实 GSM8K/MATH 数据上查出来的问题。详见 extractors._num_close。
NUM_ABS_TOL = 1e-6


def normalize(text: Any) -> str:
    if text is None:
        return ""
    s = str(text).strip().lower()
    s = re.sub(r"[\s,，。.；;：:、]+", "", s)
    s = s.replace("，", "").replace("。", "")
    return s


def extract_number(text: str) -> Optional[float]:
    """向后兼容：取最后一个数值（委托给 extractors.extract_final_number）。"""
    return extract_final_number(text)


def numeric_value(text: str) -> Tuple[Optional[float], str]:
    """取候选答案的**数值**，返回 (数值, 来源)。

    来源用于记录口径：
      "boxed" / "marker" / "last_line" / "whole"：来自 `extract_answer_span`；
      "fallback_last_number"：**无显式标记时**退回"最后一个数"的启发式
        （GSM8K 习惯写法），会在 detailed 结果的 reason 里显式记录，便于人工抽查。
    """
    span, src = extract_answer_span(text)
    v = to_number(span)
    if v is not None:
        return v, src
    v2 = extract_final_number(text)
    if v2 is not None:
        return v2, "fallback_last_number"
    return None, src


def _numeric_equal(got: str, want: str, tol: float = NUM_ABS_TOL) -> bool:
    g, _ = numeric_value(got)
    w, _ = numeric_value(want)
    if g is None or w is None:
        return False
    return _num_close(g, w, abs_=tol)


def math_equal(gold: str, answer: str) -> Tuple[bool, bool, str]:
    """MATH 等价判定委托给 `compare_answers`（详见 eval/extractors.py）。"""
    return compare_answers(str(gold), str(answer))


def _math_equiv(gold: str, answer: str, tol: float = NUM_ABS_TOL) -> bool:
    """向后兼容的布尔接口。**不再**使用"最后一个数"作为答案值。"""
    ok, _nr, _reason = math_equal(gold, answer)
    return ok


def score_answer(task: Task, answer: str) -> bool:
    metric = task.metric
    if metric == "exact_match":
        return normalize(answer) == normalize(task.gold)
    if metric in ("numeric_match", "gsm8k_numeric"):
        return _numeric_equal(answer, str(task.gold))
    if metric == "math_equiv":
        return _math_equiv(str(task.gold), answer)
    if metric == "contains":
        return normalize(task.gold) in normalize(answer)
    if metric == "tool_trajectory":
        # 说明：该 metric 需要**实际工具调用序列**才能比对，而 score_answer 只收到
        # 最终答案字符串，无法在此重建序列。真正的轨迹比对由 runner 在记录
        # Trajectory.steps 后调用 `score_tool_trajectory` 完成；此处仅做终态答案判定，
        # 供首批不使用该 metric 的数据集保持兼容。
        return normalize(task.gold) in normalize(answer)
    return False


def score_answer_detailed(task: Task, answer: str) -> Tuple[bool, bool, str]:
    """带复核标记与原因码，供评分自测与争议留存使用。

    返回 (correct, needs_review, reason)：
    - needs_review=True 表示**无法自动判定**，必须写入争议清单人工复核，
      而不是默认判错或默认判对（P1 要求：提取失败 / 明确错误 / 需复核三分）。
    - reason 取值见 `compare_answers`；numeric 类的兜底来源记为
      "fallback_last_number" 或 "numeric_unparseable"。
    """
    metric = task.metric
    if metric in ("numeric_match", "gsm8k_numeric"):
        g, gsrc = numeric_value(answer)
        w, wsrc = numeric_value(str(task.gold))
        if g is None or w is None:
            return False, True, "numeric_unparseable"
        ok = _num_close(g, w, abs_=NUM_ABS_TOL)
        reason = "numeric_equal" if ok else "numeric_diff"
        if "fallback" in (gsrc, wsrc):
            reason += "+fallback_last_number"
        return ok, False, reason
    if metric == "math_equiv":
        if str(answer).strip() == "":
            return False, True, "empty_answer"
        return compare_answers(str(task.gold), str(answer))
    # 其余 metric 直接委托
    return score_answer(task, answer), False, "ok"


# ---------------------------------------------------------------------- 汇总
def summarize_runs(rows: List[Dict]) -> Dict[str, Dict]:
    """把逐任务结果汇总为 策略 × 难度 的均值表。

    分层口径：**一律使用任务的客观难度锚点 difficulty**（来自数据集原始标注），
    不使用 selected_level。原因是 selected_level 是本文方法的判定结果，
    若用它给 adaptive 分层而其他策略用锚点分层，两者的层级定义就不一致，
    得到的"自适应更省"可能是分层口径造成的假象。

    selected_level 与锚点的一致性单独作为指标统计（见 _aggregate 的 judge_agreement），
    用于衡量复杂度判定本身的质量。
    """
    buckets: Dict[str, Dict[str, List[Dict]]] = {}
    for r in rows:
        strategy = r["strategy"]
        level = r.get("difficulty") or "all"
        buckets.setdefault(strategy, {}).setdefault(level, []).append(r)

    out: Dict[str, Dict] = {}
    for strategy, by_level in buckets.items():
        out[strategy] = {}
        for level, items in by_level.items():
            out[strategy][level] = _aggregate(items)
    return out


def _aggregate(items: List[Dict]) -> Dict:
    n = len(items)
    acc = sum(1 for i in items if i.get("success")) / n if n else 0.0
    total_tokens = [i["meter_summary"]["total_tokens"] for i in items]
    # 延迟口径：用"各次 API 调用延迟之和"，它不受并发排队影响，是论文中可辩护的指标。
    # 墙钟时间（extra.wall_time_ms）含排队等待，只作为辅助参考单独列出。
    api_latency = [i["meter_summary"]["total_latency_ms"] for i in items]
    wall_time = [i["extra"].get("wall_time_ms", 0.0) for i in items]
    calls = [i["meter_summary"]["n_calls"] for i in items]

    # 复杂度判定与客观锚点的一致性（仅对有 selected_level 的策略有意义）
    judged = [i for i in items if i.get("selected_level")]
    agree = (sum(1 for i in judged if i["selected_level"] == i["difficulty"]) / len(judged)
             if judged else None)

    return {
        "n": n,
        "accuracy": round(acc, 4),
        "avg_total_tokens": round(sum(total_tokens) / n, 1) if n else 0.0,
        "avg_prompt_tokens": round(
            sum(i["meter_summary"]["prompt_tokens"] for i in items) / n, 1) if n else 0.0,
        "avg_completion_tokens": round(
            sum(i["meter_summary"]["completion_tokens"] for i in items) / n, 1) if n else 0.0,
        "avg_api_latency_ms": round(sum(api_latency) / n, 1) if n else 0.0,
        "avg_wall_time_ms": round(sum(wall_time) / n, 1) if n else 0.0,
        "avg_llm_calls": round(sum(calls) / n, 2) if n else 0.0,
        "avg_reflections": round(sum(i.get("n_reflections", 0) for i in items) / n, 2) if n else 0.0,
        "avg_replans": round(sum(i.get("n_replans", 0) for i in items) / n, 2) if n else 0.0,
        "avg_tool_calls": round(sum(i.get("n_tool_calls", 0) for i in items) / n, 2) if n else 0.0,
        "avg_cost_usd": round(
            sum(i["meter_summary"]["total_cost_usd"] for i in items) / n, 8) if n else 0.0,
        "avg_cost_cny": round(
            sum(i["meter_summary"]["total_cost_cny"] for i in items) / n, 6) if n else 0.0,
        "judge_agreement": round(agree, 4) if agree is not None else None,
        "path_distribution": _path_distribution(items),
    }


def _path_distribution(items: List[Dict]) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for i in items:
        p = i.get("selected_path")
        if p:
            out[p] = out.get(p, 0) + 1
    return out


def pareto_frontier(points: List[Dict], x_key: str = "avg_total_tokens",
                    y_key: str = "accuracy") -> List[Dict]:
    """返回帕累托最优点（x 越小越好，y 越大越好）。"""
    frontier: List[Dict] = []
    for p in sorted(points, key=lambda d: (d[x_key], -d[y_key])):
        if not any(f[x_key] <= p[x_key] and f[y_key] >= p[y_key] for f in frontier):
            frontier.append(p)
    return frontier
