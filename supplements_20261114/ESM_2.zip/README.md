# Audit archive and offline reconstruction

Article: Quality and Resource Tradeoffs in Adaptive Routing for LLM Mathematical Reasoning

Author: Mai Ye

School of Artificial Intelligence, Guangdong Industry Polytechnic University, Foshan, China

Corresponding email: 2025233201343@stumail.gdipu.edu.cn

Version: 5 November 2026 human-audit manuscript, author approved. Public code and annotation ledger: https://github.com/Matey-ace/sncs-adaptive-routing-audit . Author-owned software is MIT; author-owned annotation compilation and adjudication text are GPL-3.0-only. Journal submission is on hold at the author's request.

Use Python 3.13 with requirements.txt installed before disconnecting. From this directory run:

    python reproduce.py --mode verify --output ../verification_run
    python reproduce.py --mode analysis --output ../analysis_run
    python reproduce.py --mode rescore --output ../rescore_run

Each output must be new and outside the archive. Every process disables socket connections before study modules are imported. No collection controller is launched. Baseline computations, 57,400 stored-answer rescoring, de-identified rating agreement, exact member linkage and both audit-score versions remain separate. The archive reconstructs stored evidence, not fresh model responses or missing provider billing.

data/population.json defines 51,007 physical original records with seven designated replacements, yielding 51,000 formal originals, plus 4,000 main and 2,400 repeat follow-up runs. Follow-up problems were previously examined. Original repeats retain 100 task clusters per dataset; follow-up repeats retain 300. Repeated runs do not become independent problems.

data/human_review holds the 1,216 de-identified task-answer opinions, 87 author adjudications, exact crosswalks and source disclosures. Original-reference and reference-answer-sensitive scores are reconstructed in a new output directory. Rater A's rationale assistance and B's partly AI-assisted checking are disclosed; agreement does not authenticate independence or correctness. Three unresolved materials remain unknown. The reference-answer sensitivity changes no original benchmark file.

The baseline original eleven manuscript tables are preserved in expected/manuscript_tables.json. Three additional audit tables are rebuilt from the review records and trajectory-derived statistics, then compared with expected/audit_tables.json. Counts are exact, floats use absolute tolerance 1e-10, and displayed cells match exactly. MANIFEST.json hashes every payload file. PROVENANCE.json and data/human_review/provenance.json distinguish original and de-identified derivatives.

Raw rater ZIP/RAR returns, real names, contact details and identity/order mappings are excluded. The archive contains answer labels and reference evidence and is separate from blinded rater packets. See NOTICE.md for source-specific rights and the separate scope of the public code and annotation repository.
