"""同预算基线（complexity 模块 B6，阶段 D 必做，提前实现）。

策略名 `vote_k`：对 easy/medium 等任务，用 k 次独立采样（异 seed + 异 repeat_id 绕过缓存）
生成 k 个答案，再按"归一化答案多数表决、平票取首次"选出一个最终答案。

- k ∈ {2, 3, 4} 即预算档位；每次采样用 temperature>0 + 不同 seed，使结果具多样性，
  且通过 repeat_id 绕过同一缓存（与 A1 的 repeat_id 机制联动）。
- 开销 = k 次 solve 全额计入总指标（revised 计划 5.5：同预算基线须如实计入）。
- 这是"固定次数独立作答 + 预先指定选择规则"的基线，用于和 adaptive 的质量—成本权衡对照。

设计要点（P1 修复）：
- 投票键**不得**使用"最后一个数"作为答案值（旧实现 `num:round(x,4)`），否则
  "x+2" 与 "2"、"2/3" 与 "5/3" 会被归为一票，凭空制造多数票；
  现统一走 `eval.extractors.vote_key`（纯数值 / 符号调用 / 结构化 / 无法解析四类）。
- 无法候选解析者**不合并**（键带采样序号），避免把互不相干的答案凑成一票。
- 平票规则：取**首次出现**者；是否发生平票写入 `traj.extra["vote_tie"]` 以便事后审计。
"""

from __future__ import annotations

import time
from collections import Counter
from typing import List, Optional, Tuple

from agents.base import AgentBase, Step, Trajectory
from tasks.agent_view import AgentView

try:
    from eval.extractors import vote_key as _vote_key_core
except Exception:  # noqa: BLE001
    _vote_key_core = None


def _vote_key(answer: str, index: int = 0) -> str:
    """多数表决用的归一化键（详见 `eval.extractors.vote_key`）。

    四类：num:<纯数值> / sym:<符号表达式> / struct:<结构化串> / raw#<i>:<原串>。
    """
    if _vote_key_core is not None:
        try:
            return _vote_key_core(answer, fallback_index=index)
        except Exception:  # noqa: BLE001
            pass
    # 兜底（不应发生）：按去空白小写串，且强制带序号以避免异常路径下的错误合并
    import re as _re
    return f"raw#{index}:" + _re.sub(r"\s+", "", str(answer).strip().lower())


def _parse_answer(content: str) -> str:
    content = content.strip()
    if content.startswith("ANSWER:"):
        return content[len("ANSWER:"):].strip()
    if content.startswith("FINAL:"):
        return content[len("FINAL:"):].strip()
    return content


class MajorityVoteAgent(AgentBase):
    strategy_name = "vote_k"

    def __init__(self, *args, k: int = 3, vote_temperature: float = 0.7,
                 base_seed: int = 42, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.k = max(1, int(k))
        self.vote_temperature = vote_temperature
        self.base_seed = base_seed

    def run(self, av: AgentView) -> Trajectory:
        meter = self.meter
        started = time.perf_counter()
        traj = Trajectory(task_id=av.task_id, strategy=self.strategy_name,
                          final_answer="")
        self.last_budget_block = None

        saved_rid = self.client.repeat_id
        answers: List[str] = []
        for i in range(self.k):
            if not self.budget_ok()[0]:
                break
            # 异 repeat_id：绕过同题 k 次采样之间的缓存污染
            self.client.repeat_id = f"{saved_rid}_v{i}" if saved_rid else f"v{i}"
            solve_msgs = self.build_messages(av, "solve")
            t0 = time.perf_counter()
            reply = self.client.chat(
                solve_msgs, purpose="solve",
                decoding_override={"temperature": self.vote_temperature,
                                   "seed": self.base_seed + i},
            )
            content = reply.content.strip()
            traj.steps.append(Step(kind="solve", prompt=solve_msgs[1]["content"],
                                   response=content,
                                   latency_ms=(time.perf_counter() - t0) * 1000))
            answers.append(_parse_answer(content))

        # 恢复 repeat_id，避免影响后续任务
        self.client.repeat_id = saved_rid

        majority = self._majority(answers)
        keys = [_vote_key(a, i) for i, a in enumerate(answers)]
        counts = Counter(keys)
        top = counts.most_common()
        traj.extra["votes"] = answers
        traj.extra["k"] = self.k
        traj.extra["completed_votes"] = len(answers)
        traj.extra["vote_counts"] = dict(counts)
        # 平票审计：第一名的票数出现多次即视为平票（<k 时取首次的规则已生效）
        traj.extra["vote_tie"] = len(top) > 1 and top[0][1] == top[1][1]
        traj.extra["vote_tie_groups"] = [c for _k, c in top if c == top[0][1]] if top else []
        return self._finish(av, majority, traj, started, meter)

    @staticmethod
    def _majority(answers: List[str]) -> str:
        if not answers:
            return ""
        # 按归一化键多数表决；平票取首次出现者（口径见模块文档）
        keys = [_vote_key(a, i) for i, a in enumerate(answers)]
        counts = Counter(keys)
        first_idx = {k: min(i for i, x in enumerate(keys) if x == k)
                     for k in set(keys)}
        best = max(counts, key=lambda k: (counts[k], -first_idx[k]))
        return answers[keys.index(best)]

    # 便捷构造（runner / 测试用）
    @classmethod
    def build(cls, client, k: int = 3, **kwargs) -> "MajorityVoteAgent":
        return cls(client, k=k, **kwargs)
