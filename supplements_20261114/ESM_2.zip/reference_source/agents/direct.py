"""Baseline 1：Direct Agent —— 无规划、无反思。

对应论文中的"完全不开启"基线，用于衡量 Planning 与 Reflection 的边际贡献。
"""

from __future__ import annotations

from agents.base import AgentBase, Step, Trajectory, parse_json_loose
from llm_proxy.usage import UsageMeter
from tasks.agent_view import AgentView


class DirectAgent(AgentBase):
    strategy_name = "direct"

    def run(self, av: AgentView) -> Trajectory:
        import time
        meter = self.meter
        started = time.perf_counter()
        traj = Trajectory(task_id=av.task_id, strategy=self.strategy_name,
                          final_answer="")
        self.last_budget_block = None
        if not self.budget_ok()[0]:
            return self._finish(av, "", traj, started, meter)

        if av.tools_allowed:
            answer, n_tools, stop_reason = self.run_tool_loop(av)
            traj.n_tool_calls = n_tools
            traj.stop_reason = stop_reason
        else:
            t0 = time.perf_counter()
            reply = self.client.chat(self.build_messages(av, "solve"), purpose="solve")
            traj.steps.append(Step(kind="solve", prompt=self.build_messages(av, "solve")[1]["content"],
                                   response=reply.content,
                                   latency_ms=(time.perf_counter() - t0) * 1000))
            answer = reply.content.strip()
            if answer.startswith("ANSWER:"):
                answer = answer[len("ANSWER:"):].strip()
            traj.stop_reason = "direct_single_shot"

        return self._finish(av, answer, traj, started, meter)
