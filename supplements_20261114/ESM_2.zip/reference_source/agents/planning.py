"""Baseline 2：Fixed Planning Agent —— 始终规划，从不反思。

对应"始终开启 Planning"基线。
"""

from __future__ import annotations

from agents.base import AgentBase, Step, Trajectory
from llm_proxy.usage import UsageMeter
from tasks.agent_view import AgentView


class PlanningAgent(AgentBase):
    strategy_name = "planning"

    def run(self, av: AgentView) -> Trajectory:
        import time
        meter = self.meter
        started = time.perf_counter()
        traj = Trajectory(task_id=av.task_id, strategy=self.strategy_name,
                          final_answer="")
        self.last_budget_block = None
        if not self.budget_ok()[0]:
            return self._finish(av, "", traj, started, meter)

        # 步骤 1：生成计划
        plan_msgs = self.build_messages(av, "plan")
        t0 = time.perf_counter()
        plan_reply = self.client.chat(plan_msgs, purpose="plan")
        plan_text = plan_reply.content.strip()
        traj.steps.append(Step(kind="plan", prompt=plan_msgs[1]["content"],
                               response=plan_text,
                               latency_ms=(time.perf_counter() - t0) * 1000))
        history = f"计划：\n{plan_text}"
        if not self.budget_ok()[0]:
            return self._finish(av, "", traj, started, meter)

        # 步骤 2：按计划执行（工具任务走工具循环，否则直接求解）
        if av.tools_allowed:
            answer, n_tools, stop_reason = self.run_tool_loop(av)
            traj.n_tool_calls = n_tools
            traj.stop_reason = stop_reason
        else:
            solve_msgs = self.build_messages(av, "solve", history=history)
            t0 = time.perf_counter()
            reply = self.client.chat(solve_msgs, purpose="solve")
            traj.steps.append(Step(kind="solve", prompt=solve_msgs[1]["content"],
                                   response=reply.content,
                                   latency_ms=(time.perf_counter() - t0) * 1000))
            answer = reply.content.strip()
            if answer.startswith("ANSWER:"):
                answer = answer[len("ANSWER:"):].strip()
            traj.stop_reason = "planned_single_shot"

        return self._finish(av, answer, traj, started, meter)
