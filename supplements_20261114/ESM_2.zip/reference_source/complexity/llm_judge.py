"""LLM 复杂度判定器（complexity 模块 B3）。

从 agents/adaptive.py 迁入 judge 逻辑，并修复"把 hard 全判成 medium"的缺陷：

缺陷根因：原 prompt 只给语义描述，模型倾向把中等长度任务都归为 medium，
hard 区分度不足（见 README 已知问题 2）。

修复三招（修订计划 B3）：
  ① 要求模型**先数推理步数再定级**，把"步数"作为可操作的硬判据；
  ② 每个难度附 **2 个来自 calibration 的锚点示例**（离线构造，不泄漏测试任务元数据）；
  ③ 严格的 JSON schema，字段含 level / confidence / reasoning_steps / reason。

成本：判定调用照常走 client.chat(purpose="judge")，计入总指标（修订计划 5.5）。
判定 prompt 的 few-shot 示例来自 calibration（离线），**仅含示例题面与难度标签，
绝不包含待判定任务的 gold / split / 真实答案**。

P3 补充（2026-10-13）：
- 判定调用现在**完整留痕**：真实 prompt、latency、本次调用的 token/费用增量、
  所用锚点示例 task_id 都写进返回值，最终落入 Trajectory 的 `Step.detail`，
  使"judge 到底花了多少、用了哪些示例"可事后审计（实验协议第 6 节要求判定开销如实计入）。
- 示例 ID 记录的目的：明确 judge prompt 允许引用 calibration 锚点示例，
  但**不得**泄漏待判定任务的标签；留下 ID 便于事后逐条核对。

与 mock provider 兼容：user 文本同时含 "level" + "复杂度" 以触发 mock 启发式判定；
待判定任务用唯一标记 "待判定任务："，few-shot 用 "示例任务：" 避免误匹配。
"""

from __future__ import annotations

import json
import re
import time
from typing import Dict, List, Optional, Tuple

from tasks.dataset import Task

_VALID_LEVELS = ("easy", "medium", "hard")


def _base_meta(user_text: str, example_ids: List[str], client,
               latency_ms: float, usage) -> Dict:
    """构造 judge 调用的统一审计元信息（P3）。"""
    return {
        "prompt": user_text,
        "latency_ms": round(latency_ms, 2),
        "usage": usage,
        "example_ids": list(example_ids),
        "model": getattr(client, "model", None),
    }
_SYSTEM = (
    "你是任务复杂度判定器。给定一道任务的题面，判定其复杂度等级。\n"
    "判定流程（必须遵循）：\n"
    "1. 先估算完成该任务所需的**推理步数**（单步=1；2~3 步；4 步及以上）。\n"
    "2. 再按下列标准定级：\n"
    "   - easy：单步即可完成（简单事实问答、单步计算、单步信息抽取），推理步数≈1。\n"
    "   - medium：需要 2~3 步推理或简单工具调用。\n"
    "   - hard：需要 4 步以上推理、多工具协作、代码调试、证明或长链条信息整合。\n"
    "3. 只输出一个 JSON 对象，不要输出任何其他文字。\n"
    '严格 schema：{"level": "easy|medium|hard", "confidence": 0~1, '
    '"reasoning_steps": 整数, "reason": "简短理由"}'
)


def _example_block(tasks: List[Task], per_level: int = 2) -> tuple[str, List[str]]:
    """从 calibration 任务中为每个难度抽至多 per_level 个示例。

    返回 (示例文本, 所用示例的 task_id 列表)。ID 列表会被记录到 judge 调用的详情里，
    以便事后核对"哪些 calibration 样本参与了判定尺度的定义"。
    示例只含**题面与难度标签**，不含 gold / split / source 等元数据。
    """
    if not tasks:
        return "", []
    buckets: Dict[str, List[Task]] = {"easy": [], "medium": [], "hard": []}
    used_ids: List[str] = []
    for t in tasks:
        if t.difficulty in buckets and len(buckets[t.difficulty]) < per_level:
            buckets[t.difficulty].append(t)
    lines = ["\n参考锚点示例（题面 => 难度，仅用于统一判定尺度）："]
    for lvl in _VALID_LEVELS:
        for t in buckets[lvl]:
            snippet = re.sub(r"\s+", " ", t.prompt)[:120]
            lines.append(f"示例任务：{snippet} => 难度：{lvl}")
            used_ids.append(t.task_id)
    return "\n".join(lines), used_ids


class LLMJudge:
    def __init__(self, calibration_tasks: Optional[List[Task]] = None,
                 per_level: int = 2, max_tokens: int = 160) -> None:
        self.calibration_tasks = calibration_tasks or []
        self.per_level = per_level
        self.max_tokens = max_tokens

    def example_ids(self) -> List[str]:
        """按当前 per_level 实际选中的 calibration 锚点示例 task_id（确定性）。"""
        self.build_messages("")  # 复用同一选择逻辑，保证与实际判定时一致
        return list(getattr(self, "_last_example_ids", []))

    def build_messages(self, prompt: str) -> List[dict]:
        ex, used_ids = _example_block(self.calibration_tasks, self.per_level)
        self._last_example_ids = used_ids
        user = (
            "【复杂度判定】请按上面的流程先数推理步数、再定级。\n"
            f"{ex}\n\n"
            "注意：上面的示例只用于统一尺度，不要照搬其难度。\n"
            "下面是真正需要你判定的任务。\n"
            f"待判定任务：\n{prompt}"
        )
        return [{"role": "system", "content": _SYSTEM},
                {"role": "user", "content": user}]

    # ------------------------------------------------------------------ 用量快照
    @staticmethod
    def _usage_snapshot(client) -> Optional[Dict[str, float]]:
        """读取当前累计用量快照（用于计算单次判定的增量），不可读则返回 None。"""
        try:
            s = client.meter.summary()
            return {k: float(s.get(k, 0) or 0)
                    for k in ("n_calls", "total_tokens", "prompt_tokens",
                              "completion_tokens", "total_latency_ms",
                              "total_cost_usd", "total_cost_cny")}
        except Exception:  # noqa: BLE001
            return None

    @staticmethod
    def _usage_delta(before: Optional[Dict[str, float]], after: Optional[Dict[str, float]]):
        if before is None or after is None:
            return None
        return {k: round(after[k] - before[k], 6) for k in before}

    def judge(self, client, prompt: str) -> Dict:
        """调用 LLM 判定，返回结构化结果。

        返回字段：level, confidence, reasoning_steps, reason, raw, ok
        以及 P3 新增的可审计字段：
          prompt（送入 judge 的 user 文本）、latency_ms、usage（本次调用增量）、
          example_ids（所用 calibration 锚点示例 ID）、model

        ok=False 表示解析失败或等级非法，此时 level 回退为 "medium"（保守默认）。
        """
        msgs = self.build_messages(prompt)
        user_text = msgs[-1]["content"]
        example_ids = list(getattr(self, "_last_example_ids", []))
        started = time.perf_counter()
        before = self._usage_snapshot(client)
        try:
            reply = client.chat(msgs, purpose="judge",
                               max_tokens=self.max_tokens,
                               decoding_override={"temperature": 0.0})
            raw = reply.content.strip()
        except Exception as exc:  # noqa: BLE001 - 判定失败必须回退，不能中断主流程
            meta = _base_meta(user_text, example_ids, client,
                              (time.perf_counter() - started) * 1000,
                              self._usage_delta(before, self._usage_snapshot(client)))
            return {"level": "medium", "confidence": 0.0,
                    "reasoning_steps": 0, "reason": f"judge 调用异常：{exc}",
                    "raw": "", "ok": False, **meta}

        meta = _base_meta(user_text, example_ids, client,
                          (time.perf_counter() - started) * 1000,
                          self._usage_delta(before, self._usage_snapshot(client)))

        parsed = self._parse(raw)
        if not parsed.get("ok"):
            return {"level": "medium", "confidence": 0.0,
                    "reasoning_steps": 0, "reason": "JSON 解析失败或等级非法",
                    "raw": raw, "ok": False, **meta}
        return {
            "level": parsed["level"],
            "confidence": float(parsed.get("confidence", 0.0)),
            "reasoning_steps": int(parsed.get("reasoning_steps", 0) or 0),
            "reason": str(parsed.get("reason", "")),
            "raw": raw, "ok": True, **meta,
        }

    @staticmethod
    def _parse(text: str) -> Dict:
        m = re.search(r"\{.*\}", text, re.S)
        if not m:
            return {"ok": False}
        try:
            obj = json.loads(m.group(0))
        except Exception:  # noqa: BLE001
            return {"ok": False}
        level = obj.get("level")
        if level not in _VALID_LEVELS:
            return {"ok": False}
        obj["ok"] = True
        return obj
