"""混合路由（complexity 模块 B4，C3 方案）。

C3 混合策略：
  - score < t_low          → easy   → 走 direct 路径（规则低区，零判定成本）
  - score > t_high         → hard   → 走 plan_reflect 路径（规则高区，零判定成本）
  - t_low <= score <= t_high → 灰区  → 调用 LLM judge 定级（计入 judge 成本）

容错：
  - judge 不可用（未注入 / 调用异常 / 返回非法等级）→ 回退到规则分级，
    默认 medium，method 标记为 "rule_fallback"，保证主流程不中断。
  - direct 路径在 Agent 层若出现格式失败，由 agents/adaptive.py 负责升级 planning
    （沿用既有 escalation 逻辑）。
  - **未拟合（P3）**：默认 `unfitted_policy="error"`，直接抛 RuleScorerNotFittedError。
    旧行为是静默返回 0 分→全部判 easy，属于方向错误的静默降级，现已禁止。
    确需降级时须**显式**传 `unfitted_policy="all_gray"`，此时分数取灰区中部，
    method 标记为 "rule_default"，决策可被事后检索出来。

t_low / t_high **只在 calibration 上拟合**（由 RuleScorer.grid_search 负责），
此处仅消费冻结后的阈值。路由决策与判定开销都会落入 Trajectory 与 UsageMeter。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

from complexity.llm_judge import LLMJudge
from complexity.rule_scorer import RuleScorer, RuleScorerNotFittedError

# 未拟合时的预设退路。选 all_gray 时使用的分数位置（落在常见阈值区间中部）
UNFITTED_GRAY_SCORE = 0.5


@dataclass
class RouteDecision:
    level: str                 # easy / medium / hard
    method: str                # rule_low / rule_high / judge / rule_fallback / rule_default
    score: float               # 规则分数 [0,1]
    judge_info: Optional[Dict] = None
    unfitted: bool = False     # True 表示本次走的是未拟合退路（须在报告里单列）


class C3Router:
    """C3 混合路由。

    unfitted_policy:
      "error"     （默认）未拟合即抛错，杜绝静默降级；
      "all_gray"  未拟合时把分数置于灰区中部，交给 judge 或默认 medium，
                  并置 `RouteDecision.unfitted=True` 以便检索。
    """

    def __init__(self, rule_scorer: RuleScorer, judge: Optional[LLMJudge] = None,
                 t_low: Optional[float] = None, t_high: Optional[float] = None,
                 unfitted_policy: str = "error", mode: str = "hybrid") -> None:
        if mode not in ('hybrid', 'rule_only', 'all_judge', 'fixed_easy', 'fixed_medium', 'fixed_hard'):
            raise ValueError(f'Unknown router mode: {mode}')
        self.mode = mode
        if unfitted_policy not in ("error", "all_gray"):
            raise ValueError(f"unsupported unfitted_policy: {unfitted_policy}")
        self.rule = rule_scorer
        self._judge = judge
        self.unfitted_policy = unfitted_policy
        if t_low is not None:
            self.rule.t_low = t_low
        if t_high is not None:
            self.rule.t_high = t_high

    def route(self, client, prompt: str, source: Optional[str] = None) -> RouteDecision:
        if self.mode.startswith('fixed_'):
            return RouteDecision(level=self.mode.removeprefix('fixed_'), method=self.mode, score=0.)
        try:
            score = self.rule.score_from_prompt(prompt, source)
            unfitted = False
        except RuleScorerNotFittedError:
            if self.unfitted_policy != "all_gray":
                raise
            # 明示的降级：置灰区中部，交由 judge / 默认 medium，并留下 unfitted 标记
            score = UNFITTED_GRAY_SCORE
            return RouteDecision(level="medium", method="rule_default",
                                 score=score, unfitted=True)

        if self.mode == 'rule_only':
            level = 'easy' if score < self.rule.t_low else 'hard' if score > self.rule.t_high else 'medium'
            return RouteDecision(level=level, method='rule_only', score=score, unfitted=unfitted)
        if self.mode != 'all_judge' and score < self.rule.t_low:
            return RouteDecision(level="easy", method="rule_low", score=score,
                                 unfitted=unfitted)
        if self.mode != 'all_judge' and score > self.rule.t_high:
            return RouteDecision(level="hard", method="rule_high", score=score,
                                 unfitted=unfitted)
        # 灰区：调用 LLM judge
        if self.judge is None:
            return RouteDecision(level="medium", method="rule_default", score=score,
                                 unfitted=unfitted)
        info = self.judge.judge(client, prompt)
        if not info.get("ok"):
            return RouteDecision(level="medium", method="rule_fallback",
                                score=score, judge_info=info, unfitted=unfitted)
        return RouteDecision(level=info["level"], method="judge",
                            score=score, judge_info=info, unfitted=unfitted)

    @property
    def judge(self) -> Optional[LLMJudge]:
        return self._judge

    @judge.setter
    def judge(self, value: Optional[LLMJudge]) -> None:
        self._judge = value

    # 便捷构造：用 calibration 任务拟合规则打分器并寻优阈值
    @classmethod
    def from_calibration(cls, calibration_tasks, judge: Optional[LLMJudge] = None,
                         use_extended: bool = False,
                         override_features: Optional[list] = None) -> "C3Router":
        rs = RuleScorer(use_extended=use_extended, override=override_features)
        rs.fit(calibration_tasks)
        rs.grid_search(calibration_tasks)
        return cls(rs, judge=judge)
