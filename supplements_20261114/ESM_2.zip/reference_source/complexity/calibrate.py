"""标定流程（complexity 模块 B5）。

流程：拟合 → LOO-CV → dev 泛化检查 → 产出报告。

- 规则打分器阈值**只在 calibration 上 grid search + LOO-CV** 选定；
  dev 仅用于泛化检查，不参与调参（实验协议第 5.3 节）。
- 若提供 judge_client，则额外在 calibration / dev 上跑 LLM judge 混淆矩阵
  （判定调用计费，仅限 Pilot / 真实阶段）；不提供时该部分标记为"待 API"。
- 低估 / 高估比率直接给出；其造成的**具体质量损失与成本增加**需结合策略运行结果，
  本模块只报告比率并给出**示意性**成本浪费估计（明确标注为估算，非实测）。
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Dict, List, Optional

from complexity.llm_judge import LLMJudge
from complexity.rule_scorer import RuleScorer, confusion_matrix, macro_f1
from tasks.dataset import Task

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPORT_DIR = os.path.join(PROJECT_ROOT, "results", "complexity")


# 示意性开销假设（仅用于"高估成本浪费"的粗略量级说明，投稿前须按实测替换）
_NOMINAL_OVERHEAD_TOKENS = 400  # plan_reflect 相对 direct 的示意性额外 token


def _judge_confusion(judge: LLMJudge, client, tasks: List[Task]):
    y_true = [t.difficulty for t in tasks]
    y_pred = [judge.judge(client, t.prompt)["level"] for t in tasks]
    cm = confusion_matrix(y_true, y_pred)
    return {"macro_f1": macro_f1(cm), "accuracy": sum(
        1 for t, p in zip(y_true, y_pred) if t == p) / len(y_true), "confusion": cm}


def run_calibration(calibration_tasks: List[Task], dev_tasks: List[Task],
                    config: Optional[Dict] = None,
                    judge_client=None,
                    out_prefix: str = "calibration") -> Dict:
    config = config or {}
    rs = RuleScorer(
        use_extended=config.get("use_extended", False),
        override=config.get("features"),
    )
    rs.fit(calibration_tasks)
    t_low, t_high = rs.grid_search(calibration_tasks)
    # P3：两种 CV 口径分开报告，不可互相顶替
    stability = rs.check_normalization_stability(calibration_tasks)   # 只逐折重算归一化
    loo = rs.loo_cv(calibration_tasks)                                # 逐折重拟合+重选阈值
    cal_eval = rs.eval_confusion(calibration_tasks)
    dev_eval = rs.eval_confusion(dev_tasks)
    cal_mis = rs.misestimation_rates(calibration_tasks)
    dev_mis = rs.misestimation_rates(dev_tasks)

    report: Dict = {
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "selected_features": rs.selected,
        "use_dataset_prior": "dataset_prior" in rs.selected,
        "thresholds": {"t_low": t_low, "t_high": t_high},
        "calibration": {
            "n": len(calibration_tasks),
            "macro_f1": cal_eval["macro_f1"],
            "accuracy": cal_eval["accuracy"],
            "confusion": cal_eval["confusion"],
            "loo_cv": {"macro_f1": loo.get("macro_f1"), "accuracy": loo.get("accuracy"),
                       "thresholds_mean": loo.get("thresholds_mean"),
                       "thresholds_stable": loo.get("thresholds_stable"),
                       "note": loo.get("note")},
            "normalization_stability": {
                "macro_f1": stability["macro_f1"], "accuracy": stability["accuracy"],
                "note": stability["note"]},
            "misestimation": cal_mis,
        },
        "dev": {
            "n": len(dev_tasks),
            "macro_f1": dev_eval["macro_f1"],
            "accuracy": dev_eval["accuracy"],
            "confusion": dev_eval["confusion"],
            "misestimation": dev_mis,
        },
    }

    # 示意性高估成本浪费（仅说明量级，非实测）
    over_n = dev_mis["over"]
    report["dev"]["illustrative_overhead_tokens"] = over_n * _NOMINAL_OVERHEAD_TOKENS

    # LLM judge 评估（需 API）
    if judge_client is not None:
        judge = LLMJudge(calibration_tasks=calibration_tasks,
                         per_level=config.get("judge_examples_per_level", 2))
        cal_j = _judge_confusion(judge, judge_client, calibration_tasks)
        dev_j = _judge_confusion(judge, judge_client, dev_tasks)
        report["judge"] = {"calibration": cal_j, "dev": dev_j}
    else:
        report["judge"] = {
            "status": "pending_api",
            "note": "LLM judge 混淆矩阵需在 Pilot / 真实阶段提供 judge_client 后评估（判定调用计费）。",
        }

    _write_reports(report, out_prefix)
    return report


def _write_reports(report: Dict, out_prefix: str) -> None:
    os.makedirs(REPORT_DIR, exist_ok=True)
    json_path = os.path.join(REPORT_DIR, f"{out_prefix}_report.json")
    md_path = os.path.join(REPORT_DIR, f"{out_prefix}_report.md")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(_render_md(report))
    print(f"  [calibrate] 报告已写出：{json_path}\n              {md_path}")


def _render_md(r: Dict) -> str:
    def cm_table(cm):
        head = "| 真\\预测 | easy | medium | hard |\n|---|---:|---:|---:|\n"
        rows = ""
        for t in ("easy", "medium", "hard"):
            rows += f"| {t} | " + " | ".join(str(cm[t][p]) for p in ("easy", "medium", "hard")) + " |\n"
        return head + rows

    lines = [
        "# 复杂度判定标定报告",
        "",
        f"- 生成时间：{r['generated_at']}",
        f"- 选定特征（v1 等权）：{r['selected_features']}",
        f"- 是否启用数据集先验：{r['use_dataset_prior']}（若为 True，须在正文单列其收益）",
        f"- 冻结阈值：t_low={r['thresholds']['t_low']}，t_high={r['thresholds']['t_high']}",
        "",
        "## 一、Calibration（仅用于拟合与 CV）",
        f"- 样本数：{r['calibration']['n']}",
        f"- 拟合 Macro-F1：{r['calibration']['macro_f1']:.4f}，准确率：{r['calibration']['accuracy']:.4f}",
        f"- **逐折 LOO-CV**（每折重拟合归一化 + 重选阈值）Macro-F1："
        f"{(r['calibration']['loo_cv']['macro_f1'] if r['calibration']['loo_cv']['macro_f1'] is not None else 0):.4f}，"
        f"均值阈值 t_low={r['calibration']['loo_cv']['thresholds_mean']['t_low']}，"
        f"t_high={r['calibration']['loo_cv']['thresholds_mean']['t_high']}"
        f"（各折是否一致：{'是' if r['calibration']['loo_cv']['thresholds_stable'] else '否'}）",
        f"- 归一化稳定性检查（阈值固定、逐折重算归一化）Macro-F1："
        f"{r['calibration']['normalization_stability']['macro_f1']:.4f} —— 只说明区间估计是否脆弱，"
        f"**不可**当作泛化性能",
        f"- 低估率：{r['calibration']['misestimation']['under_rate']:.3f}；"
        f"高估率：{r['calibration']['misestimation']['over_rate']:.3f}",
        "",
        "混淆矩阵（行=锚点真值，列=规则预测）：",
        cm_table(r["calibration"]["confusion"]),
        "",
        "## 二、Dev（仅泛化检查，未调参）",
        f"- 样本数：{r['dev']['n']}",
        f"- Macro-F1：{r['dev']['macro_f1']:.4f}，准确率：{r['dev']['accuracy']:.4f}",
        f"- 低估率：{r['dev']['misestimation']['under_rate']:.3f}；"
        f"高估率：{r['dev']['misestimation']['over_rate']:.3f}",
        f"- 示意性高估成本浪费（{_NOMINAL_OVERHEAD_TOKENS} token/题 × 高估数）："
        f"{r['dev']['illustrative_overhead_tokens']} token",
        "",
        "混淆矩阵：",
        cm_table(r["dev"]["confusion"]),
        "",
        "## 三、LLM Judge",
    ]
    j = r["judge"]
    if j.get("status") == "pending_api":
        lines.append(f"- 状态：{j['note']}")
    else:
        lines.append(f"- Calibration Macro-F1：{j['calibration']['macro_f1']:.4f}")
        lines.append(f"- Dev Macro-F1：{j['dev']['macro_f1']:.4f}")
        lines.append("")
        lines.append("Dev 混淆矩阵：")
        lines.append(cm_table(j["dev"]["confusion"]))
    lines.append("")
    lines.append("## 四、说明与局限")
    lines.append("- 规则打分仅用 prompt 表层特征，零 LLM 成本；阈值只在 calibration 选定。")
    lines.append("- 低估（把 hard 判低）可能在 hard 任务上损失质量；高估（把 easy 判高）"
                 "浪费 plan_reflect 开销；具体影响须结合四策略实测。")
    lines.append("- 若启用数据集先验，需单列去掉该特征后的结果，检查是否主要靠数据集身份路由。")
    return "\n".join(lines)


def _split_by(tasks, split_name: str):
    """按 Task.split 字段筛选，保证三层划分互斥（实验协议第 5.3 节）。"""
    return [t for t in tasks if t.split == split_name]


if __name__ == "__main__":
    import sys
    sys.path.insert(0, PROJECT_ROOT)
    from tasks.loaders import load_tasks

    # GSM8K：calibration / dev 均来自官方 train 且互斥
    gsm = load_tasks({"source": "gsm8k",
                      "splits": {"calibration": 200, "dev": 100, "test": 0}})
    run_calibration(_split_by(gsm, "calibration"), _split_by(gsm, "dev"),
                    config={"use_extended": False}, out_prefix="gsm8k_rule")

    # MATH：同上，subject 分布由三层抽样保持比例
    mth = load_tasks({"source": "math",
                      "splits": {"calibration": 200, "dev": 100, "test": 0}})
    run_calibration(_split_by(mth, "calibration"), _split_by(mth, "dev"),
                    config={"use_extended": False}, out_prefix="math_rule")
