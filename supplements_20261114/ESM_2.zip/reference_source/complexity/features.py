"""复杂度判定特征池（complexity 模块 B1）。

设计原则（见 paper/实验协议.md 第 4、5.5 节与 paper/difficulty_protocol.md）：
- 所有特征**仅从任务 prompt 文本派生**，绝不读取 gold / difficulty / split /
  source 之外的任何隐藏评测元数据；`source`（数据集身份）特征默认关闭，需显式
  开启 `use_dataset_prior` 并单独报告其收益（修订计划 5.5 的硬性要求）。
- 9 维候选池仅用于离线分析与可选加权；v1 规则打分**只用 4–6 维等权线性分**，
  避免在小标定集（约 400 条）上过拟合 9 维权重。
- 特征尺度差异大，规则打分前统一做 min–max 归一化（见 rule_scorer.py）。

本文件是纯函数 + 轻量容器，不依赖 LLM、不依赖评测元数据对象，便于单测与复现。
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

# ----------------------------------------------------------------- 9 维候选池
# 名称 -> 人类可读说明（用于协议文档与报告，不进入模型）
FEATURE_POOL: Dict[str, str] = {
    "prompt_length": "prompt 字符数",
    "num_sentences": "句数（按中英文句末标点切分）",
    "num_numbers": "数字个数（含小数与负数）",
    "number_density": "数字密度 = num_numbers / max(prompt_length, 1)",
    "keyword_count": "多步/证明/调试类关键词命中数",
    "math_symbol_count": "数学符号计数（$, \\, =, <, >, ^, ≤, ≥, ±, ×, ÷, √, 集合/求和等）",
    "is_calculation": "是否计算题（启发式：含数值+求解类动词）",
    "arith_op_count": "算术运算符计数（+ - × * / ÷，暗示多步运算）",
    "dataset_prior": "数据集身份先验（gsm8k=0 / math=1；默认关闭）",
}

# v1 默认启用的 4 维：最稳健的表层特征，均有明确的在线可得性
V1_DEFAULT_FEATURES: List[str] = [
    "prompt_length",
    "num_numbers",
    "math_symbol_count",
    "keyword_count",
]

# 可扩展为 6 维（含计算题启发式与算术运算符计数）
V1_EXTENDED_FEATURES: List[str] = V1_DEFAULT_FEATURES + [
    "is_calculation",
    "arith_op_count",
]

# 多步 / 证明 / 调试类关键词（用于 keyword_count 与 is_calculation 的判定）
_MULTISTEP_KW = [
    "并且", "同时", "多步", "先", "再", "然后", "接着", "最后", "分别", "依次",
    "证明", "推导", "调试", "比较", "整合", "调用", "代码", "其中", "此外", "以及",
    "step", "prove", "derive", "debug", "compare", "integrate",
]
_CALC_KW = [
    "计算", "算出", "求", "求值", "多少", "一共", "剩余", "总共", "等于", "结果",
    "calculate", "compute", "find", "evaluate", "how many", "how much", "total",
]
_MATH_SYMBOLS = re.compile(
    r"[\$€£¥\\=<>^√±×÷∞∑∏∫∈∉⊆⊂∀∃≤≥≠≡∂∇·]"
)
_SENT_SPLIT = re.compile(r"[。.!?！？；;\n]+")
_NUM_RE = re.compile(r"-?\d+(?:\.\d+)?")
_ARITH_RE = re.compile(r"[+\-×*/÷]")


def compute_features(prompt: str, source: Optional[str] = None) -> Dict[str, float]:
    """从单个 prompt 派生全部 9 维特征（纯表层，无隐藏信息）。

    source：仅用于 `dataset_prior` 特征（默认不启用）。传入 None 或任意非
    "math" 字符串时 dataset_prior=0.0；"math" 时为 1.0。
    """
    if not prompt:
        prompt = ""
    length = len(prompt)
    sentences = [s for s in _SENT_SPLIT.split(prompt) if s.strip()]
    nums = _NUM_RE.findall(prompt)
    num_numbers = len(nums)
    kw_hits = sum(1 for kw in _MULTISTEP_KW if kw in prompt)
    sym_count = len(_MATH_SYMBOLS.findall(prompt))
    arith_ops = len(_ARITH_RE.findall(prompt))
    is_calc = 1.0 if (num_numbers >= 1 and any(kw in prompt for kw in _CALC_KW)) else 0.0
    dataset_prior = 1.0 if (source or "").lower() == "math" else 0.0

    return {
        "prompt_length": float(length),
        "num_sentences": float(max(len(sentences), 1)),
        "num_numbers": float(num_numbers),
        "number_density": float(num_numbers) / max(length, 1),
        "keyword_count": float(kw_hits),
        "math_symbol_count": float(sym_count),
        "is_calculation": is_calc,
        "arith_op_count": float(arith_ops),
        "dataset_prior": dataset_prior,
    }


@dataclass
class FeatureStats:
    """一组任务上各选定特征的 min / max（用于 min–max 归一化）。"""
    selected: List[str] = field(default_factory=list)
    mins: Dict[str, float] = field(default_factory=dict)
    maxs: Dict[str, float] = field(default_factory=dict)

    def normalize(self, feats: Dict[str, float]) -> Dict[str, float]:
        out: Dict[str, float] = {}
        for name in self.selected:
            lo = self.mins.get(name, 0.0)
            hi = self.maxs.get(name, 0.0)
            span = hi - lo
            v = feats.get(name, 0.0)
            out[name] = 0.0 if span <= 0 else min(1.0, max(0.0, (v - lo) / span))
        return out


def fit_feature_stats(prompts: List[str], selected: List[str],
                      sources: Optional[List[Optional[str]]] = None) -> FeatureStats:
    """在给定 prompt 集合上计算每个选定特征的 min / max。"""
    sources = sources or [None] * len(prompts)
    stats = FeatureStats(selected=list(selected))
    for name in selected:
        vals = [compute_features(p, s).get(name, 0.0)
                for p, s in zip(prompts, sources)]
        stats.mins[name] = min(vals) if vals else 0.0
        stats.maxs[name] = max(vals) if vals else 0.0
    return stats


def equal_weight_score(normalized: Dict[str, float], selected: List[str]) -> float:
    """等权线性分：选定特征归一化后取算术平均，落在 [0, 1]。

    这是 v1 的唯一打分方式——明确拒绝在小标定集上拟合 9 维加权系数，
    避免过拟合（修订计划 5.5 / 实验协议第 5.3 节）。
    """
    if not selected:
        return 0.0
    return sum(normalized.get(n, 0.0) for n in selected) / len(selected)


def select_v1_features(use_extended: bool = False,
                       override: Optional[List[str]] = None) -> List[str]:
    """返回 v1 启用的特征子集。

    - override：显式指定（必须全部属于 FEATURE_POOL）。
    - use_extended=True：使用 6 维（默认 4 维）。
    - 注意：dataset_prior 不在 v1 默认集合内；若需启用须显式 override
      且必须在报告中单列其收益（修订计划 5.5）。
    """
    if override is not None:
        for n in override:
            if n not in FEATURE_POOL:
                raise ValueError(f"未知特征：{n}；可选：{list(FEATURE_POOL)}")
        return list(override)
    return list(V1_EXTENDED_FEATURES) if use_extended else list(V1_DEFAULT_FEATURES)
