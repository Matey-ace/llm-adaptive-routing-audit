"""Versioned dev-only regrading; raw responses and historical vote choices stay intact."""
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from eval.metrics import SCORER_VERSION
from runner.run_experiment import load_config, select_evaluation_tasks
from runner.scoring import score_final_answer
from tasks.loaders import load_tasks


def main():
    tasks = {}
    rows = []
    sources = {}
    for source in ("gsm8k", "math"):
        cfg = load_config(ROOT / f"configs/exp/pilot_{source}.yaml")
        tasks.update({t.task_id: t for t in select_evaluation_tasks(load_tasks(cfg["tasks"]), cfg)})
        runs = [f"pilot_{source}_20261013_s3b"]
        if source == "gsm8k":
            runs.insert(0, "pilot_gsm8k_20261013_s3a")
        for run in runs:
            path = ROOT / f"results/raw/{run}.jsonl"
            sources[run] = hashlib.sha256(path.read_bytes()).hexdigest()
            for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
                row = json.loads(line)
                if row.get("error"):
                    continue
                assert tasks[row["task_id"]].split == "dev"
                old = {k: row[k] for k in ("success", "needs_review", "score_reason", "scorer_version")}
                new = score_final_answer(tasks[row["task_id"]], row["final_answer"])
                rows.append({"task_id": row["task_id"], "strategy": row["strategy"],
                    "source": source, "source_run": run, "source_line": line_number,
                    "old": old, "new": new, "final_answer": row["final_answer"]})
    assert len(rows) == 400 and len({(r["task_id"], r["strategy"]) for r in rows}) == 400
    changed = [r for r in rows if (r["old"]["success"], r["old"]["needs_review"]) !=
                                 (r["new"]["success"], r["new"]["needs_review"])]
    report = {"scorer_version": SCORER_VERSION, "scope": "dev_only",
        "raw_sha256": sources, "n": len(rows), "changed_n": len(changed),
        "old_needs_review": sum(r["old"]["needs_review"] for r in rows),
        "new_needs_review": sum(r["new"]["needs_review"] for r in rows),
        "historical_vote_selection_retained": True, "changed": changed, "scores": rows}
    path = ROOT / f"results/aggregated/pilot_rescore_{SCORER_VERSION}.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("n", "changed_n", "old_needs_review", "new_needs_review")}, indent=2))


if __name__ == "__main__":
    main()
