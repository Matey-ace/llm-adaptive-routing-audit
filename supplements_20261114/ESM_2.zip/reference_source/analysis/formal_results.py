"""Complete frozen-run paired summary; refuses incomplete or mismatched records."""
import argparse
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'.runtime/statistics'))
from analysis.paired_summary import quality_bounds, paired_cost, outcome
from analysis.paired_wilcoxon import signed_rank
from analysis.paired_binary_secondary import binary_secondary
from analysis.freeze_contract import object_sha256, source_snapshot


def pairs_for(rows,a,b):
    def group(strategy):
        group = {}
        for row in rows:
            if row['strategy'] != strategy:
                continue
            key = (row['task_id'],row['repeat_id'])
            if key in group:
                raise ValueError('Duplicate task/strategy/repeat record')
            group[key] = row
        return group
    left,right = group(a),group(b)
    if not left or left.keys() != right.keys():
        raise ValueError('Incomplete matched strategies')
    return [(left[k],right[k]) for k in sorted(left)]


def complete_tokens(row):
    if row.get('failed_attempts') or row.get('error'):
        return None
    return row['meter_summary']['total_tokens']


def complete_cost(row):
    if row.get('failed_attempts') or row.get('error'):
        return None
    return row['meter_summary']['total_cost_usd']


def api_latency(row):
    audit = row.get('request_audit_summary')
    return audit['observed_api_latency_ms'] if audit and audit['failed_latency_complete'] else None


def recorded_attempts(row):
    audit = row.get('request_audit_summary')
    return audit['recorded_request_attempts'] if audit else None


def summarize_pair(pairs, primary=True):
    result = {}
    if primary:
        result['quality'] = quality_bounds(pairs)
        result['binary_secondary'] = binary_secondary(pairs)
    else:
        # Supplemental repeats use task-cluster descriptive uncertainty bounds.
        def lo_a(row):
            value = outcome(row)
            return 0 if value is None else value
        def hi_a(row):
            value = outcome(row)
            return 1 if value is None else value
        low_pairs = [(dict(a,_q=lo_a(a)),dict(b,_q=hi_a(b))) for a,b in pairs]
        high_pairs = [(dict(a,_q=hi_a(a)),dict(b,_q=lo_a(b))) for a,b in pairs]
        result['quality'] = {'low_assignment':paired_cost(low_pairs,lambda r:r['_q']),
                             'high_assignment':paired_cost(high_pairs,lambda r:r['_q']),
                             'scope':'Supplemental task-cluster percentile summaries; not primary NI'}
    result['costs'] = {name:{'paired_summary':paired_cost(pairs,getter),
                            'secondary_signed_rank':signed_rank(pairs,getter)}
                       for name,getter in [('complete_tokens',complete_tokens),('complete_nominal_usd',complete_cost),
                                           ('observed_api_latency_ms',api_latency),('recorded_request_attempts',recorded_attempts)]}
    return result


def read_frozen_case(run_id,freeze):
    frozen_path = ROOT/freeze
    raw_freeze = frozen_path.read_bytes()
    frozen = json.loads(raw_freeze)
    if frozen.get('status') != 'frozen_s6':
        raise ValueError('Analysis requires an actual frozen S6 packet')
    case = frozen['runs'][run_id]
    manifest = json.loads((ROOT/f'results/raw/{run_id}.manifest.json').read_text(encoding='utf-8'))
    spec = manifest['spec']
    if hashlib.sha256(json.dumps(spec,sort_keys=True).encode()).hexdigest() != manifest['spec_sha256']:
        raise ValueError('Run manifest content/hash mismatch')
    if spec.get('freeze_sha256') != hashlib.sha256(raw_freeze).hexdigest():
        raise ValueError('Run does not reference this frozen packet')
    rows = [json.loads(line) for line in (ROOT/f'results/raw/{run_id}.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
    cfg = spec['config']
    settings = {k:spec[k] for k in ('base_config','provider_config','router_sha256')}
    if object_sha256(cfg) != case['config_sha256'] or object_sha256(settings) != case['runtime_sha256']:
        raise ValueError('Manifest configuration differs from frozen case')
    if set(spec['task_ids']) != set(case['task_fingerprints']) or len(spec['task_ids']) != len(case['task_fingerprints']):
        raise ValueError('Manifest task population differs from frozen case')
    if spec['repeat_ids'] != [f'r{i}' for i in range(case['repeats'])]:
        raise ValueError('Manifest repeats differ from frozen case')
    expected = {(s,t,r) for s in cfg['strategies'] for t in spec['task_ids'] for r in spec['repeat_ids']}
    keys = [(r['strategy'],r['task_id'],r['repeat_id']) for r in rows]
    if len(keys) != len(expected) or set(keys) != expected:
        raise ValueError('Require every frozen strategy/task/repeat exactly once')
    if any(r['source'] != case['source'] or r['split'] != 'test' or r['scorer_version'] != frozen['scorer_version'] for r in rows):
        raise ValueError('Record source/split/scorer mismatch')
    if source_snapshot() != frozen['source_sha256']:
        raise ValueError('Analysis source changed since S6')
    return frozen,case,spec,rows


def main(run_id,freeze):
    frozen,case,spec,rows = read_frozen_case(run_id,freeze)
    cfg=spec['config']
    a,b = ('adaptive','vote_k') if case['kind'].startswith('budget') else ('adaptive','plan_reflect')
    comparison={'a':a,'b':b}
    comparison_rows=rows
    if case['kind'].startswith('ablation_'):
        ref_id=case['comparison_run']
        _,ref_case,ref_spec,ref_rows=read_frozen_case(ref_id,freeze)
        if ref_case['source'] != case['source'] or ref_spec['config']['model'] != cfg['model']:
            raise ValueError('Ablation reference source/model mismatch')
        a,b='adaptive_variant','adaptive_primary'
        comparison_rows=[dict(r,strategy=a) for r in rows]+[dict(r,strategy=b) for r in ref_rows if r['strategy']=='adaptive']
        comparison={'a':a,'b':b,'reference_run':ref_id,'scope':'Secondary ablation; fresh stochastic routing/service responses, not exact route replay'}
    report = {'run_id':run_id,'source':case['source'],'kind':case['kind'],'records':len(rows),
              'comparison':comparison,'paired':summarize_pair(pairs_for(comparison_rows,a,b),len(spec['repeat_ids'])==1),
              'failures':{s:{'n':sum(r['strategy']==s for r in rows),
                             'empty':sum(r['strategy']==s and not r['final_answer'].strip() for r in rows),
                             'execution_errors':sum(r['strategy']==s and bool(r.get('error')) for r in rows),
                             'nonempty_unknown':sum(r['strategy']==s and bool(r['final_answer'].strip()) and outcome(r) is None for r in rows),
                             'budget_truncated':sum(r['strategy']==s and r.get('extra',{}).get('truncated_by_budget',False) for r in rows),
                             'stops':dict(Counter(r.get('stop_reason') for r in rows if r['strategy']==s))}
                          for s in cfg['strategies']},
              'cost_scope':'Nominal successful usage, not invoice. Missing failed billing is unknown; no case deletion or zero filling.',
              'budget_scope':'Equal available ceilings do not imply equal realized calls/tokens/costs. Report all records.'}
    path = ROOT/f'results/aggregated/{run_id}_paired.json'
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Complete paired summary saved: {path}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-id',required=True)
    parser.add_argument('--freeze',default='results/verify/s6_freeze_20261014.json')
    args = parser.parse_args()
    main(args.run_id,args.freeze)
