"""Complete candidate run audit against its predeclared dev manifest."""
import json
import argparse
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from analysis.pilot_diagnostics import read_rows, reflect_transition
from complexity.artifact import load_artifact, router_from_artifact
from complexity.rule_scorer import confusion_matrix, macro_f1
from runner.run_experiment import load_config, select_evaluation_tasks
from tasks.loaders import load_tasks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--selected-stopper', action='store_true')
    parser.add_argument('--corrected', action='store_true')
    args = parser.parse_args()
    selected_pair = args.selected_stopper or args.corrected
    prefix = 'selected_stopper' if selected_pair else 'router_candidate'
    suffix = 's5g' if selected_pair else 's5e'
    config_suffix = 's5'
    if args.corrected:
        suffix, config_suffix = 's5i', 's5i'
    data, sha = load_artifact(ROOT / 'results/complexity/router_candidate_s5_20261014.json')
    router = router_from_artifact(data, judge_max_tokens=4096)
    all_rows, tasks, datasets = [], {}, {}
    for source in ('gsm8k', 'math'):
        cfg = load_config(ROOT / f'configs/exp/{prefix}_{source}_{config_suffix}.yaml')
        selected = select_evaluation_tasks(load_tasks(cfg['tasks']), cfg)
        tasks.update({t.task_id: t for t in selected})
        rows = read_rows(ROOT / f'results/raw/{prefix}_{source}_20261014_{suffix}.jsonl')
        assert len(rows) == 40 and {r['task_id'] for r in rows} == {t.task_id for t in selected}, 'Wait for complete run'
        baseline = [r for r in read_rows(ROOT / f'results/raw/pilot_{source}_20261014_s5d.jsonl') if r['strategy'] == 'adaptive']
        assert all(r['split'] == 'dev' and r['strategy'] == 'adaptive' and r['router_sha256'] == sha for r in rows)
        for r in rows:
            if r.get('error'):
                continue
            score = router.rule.score_from_prompt(tasks[r['task_id']].prompt)
            method = r['extra']['route_method']
            expected = 'rule_low' if score < .05 else 'rule_high' if score > .15 else 'gray'
            assert method == expected or expected == 'gray' and method in ('judge', 'rule_fallback')
            assert abs(score - r['extra']['rule_score']) <= .000051
            assert all(not a['cached'] and a['response_envelope'] for a in r['call_audit'])
            if selected_pair and not args.corrected:
                assert r['meter_summary']['n_calls'] <= 8 and r['n_reflections'] <= 1 and r['n_replans'] == 0
                if r['n_reflections']:
                    assert r['extra']['first_round_answer'] == r['final_answer']
            if args.corrected:
                assert r['meter_summary']['n_calls'] <= 8 and r['n_reflections'] <= 4
                assert r['prompt_version'] == 'zh-v3'
                previous_reflection = None
                for step in r['steps']:
                    if step['kind'] == 'reflect':
                        previous_reflection = step['response'].strip()
                    if step['kind'] == 'replan':
                        assert previous_reflection is not None and previous_reflection in step['prompt']
        normal = [r for r in rows if not r.get('error')]
        confusion = confusion_matrix([r['difficulty'] for r in normal], [r['selected_level'] for r in normal])
        datasets[source] = {'n': len(rows), 'errors': len(rows)-len(normal),
            'correct': sum(r['success'] for r in rows), 'needs_review': sum(r['needs_review'] for r in rows),
            'empty': sum(not r['final_answer'].strip() for r in rows),
            'records_with_length': sum(any(a['finish_reason'] == 'length' for a in r.get('call_audit', [])) for r in rows),
            'route_methods': dict(Counter(r['extra']['route_method'] for r in normal)),
            'selected_paths': dict(Counter(r['selected_path'] for r in normal)),
            'escalations': sum('escalated_from' in r['extra'] for r in normal),
            'confusion': confusion, 'hybrid_macro_f1_vs_anchor': macro_f1(confusion),
            'calls': sum(r['meter_summary']['n_calls'] for r in rows),
            'nominal_usd': sum(r['meter_summary']['total_cost_usd'] for r in rows),
            'original_router_s5d_adaptive': {'correct': sum(r['success'] for r in baseline),
                'needs_review': sum(r['needs_review'] for r in baseline),
                'nominal_usd': sum(r['meter_summary']['total_cost_usd'] for r in baseline)}}
        all_rows.extend(rows)
    report = {'stage': f'S5_{suffix}_not_test_not_freeze', 'candidate_sha256': sha,
              'records': len(all_rows), 'datasets': datasets,
              'reflection': reflect_transition([r for r in all_rows if r.get('n_reflections', 0)], tasks),
              'limitations': ['Fresh dev runs, not deterministic matched replay.',
                             'Accuracy does not refit the already calibration-selected thresholds.',
                             'Rule/hybrid classification and actual solve benefit are separate measures.',
                             'Nominal cost is not invoice; invalid outputs and parser reviews retained.']}
    output_name = 'selected_pair_diagnostics_20261014' if selected_pair else 'router_candidate_diagnostics_20261014'
    if args.corrected:
        output_name += '_s5i'
    (ROOT / f'results/aggregated/{output_name}.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
