"""Validate and summarize S5c dev runs, without changing historical outputs."""
import json
import argparse
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from analysis.pilot_diagnostics import read_rows, reflect_transition
from runner.run_experiment import load_config, select_evaluation_tasks
from tasks.loaders import load_tasks
from eval.metrics import SCORER_VERSION


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=('s5c', 's5d'), default='s5c')
    args = parser.parse_args()
    run_suffix = '20261013_s5c' if args.stage == 's5c' else '20261014_s5d'
    config_suffix = 's5' if args.stage == 's5c' else 's5d'
    cap = 2048 if args.stage == 's5c' else 4096
    output_suffix = '20261014' if args.stage == 's5c' else '20261014_s5d'
    rows, tasks = [], {}
    for source in ('gsm8k', 'math'):
        cfg = load_config(ROOT / f'configs/exp/pilot_{source}_{config_suffix}.yaml')
        selected = select_evaluation_tasks(load_tasks(cfg['tasks']), cfg)
        tasks.update({t.task_id: t for t in selected})
        group = read_rows(ROOT / f'results/raw/pilot_{source}_{run_suffix}.jsonl')
        expected = {(t.task_id, s) for t in selected for s in
                    ('direct', 'planning', 'plan_reflect', 'adaptive', 'vote_k')}
        successful = [r for r in group if not r.get('error')]
        assert len(successful) == len(expected) == 200, 'Run incomplete; wait for terminal state'
        assert {(r['task_id'], r['strategy']) for r in successful} == expected
        rows.extend(group)
    assert all(r['split'] == 'dev' and r['scorer_version'] == SCORER_VERSION for r in rows)
    normal = [r for r in rows if not r.get('error')]
    for r in normal:
        assert len(r['call_audit']) == r['meter_summary']['n_calls']
        assert all(not a['cached'] and a['response_envelope'] for a in r['call_audit'])
        assert all(a['decoding']['max_tokens'] == cap for a in r['call_audit'])
    groups = {}
    for source in ('gsm8k', 'math'):
        groups[source] = {}
        for strategy in ('direct', 'planning', 'plan_reflect', 'adaptive', 'vote_k'):
            g = [r for r in normal if r['source'] == source and r['strategy'] == strategy]
            audits = [a for r in g for a in r['call_audit']]
            groups[source][strategy] = {
                'n': len(g), 'correct': sum(r['success'] for r in g),
                'needs_review': sum(r['needs_review'] for r in g),
                'empty_final': sum(not r['final_answer'].strip() for r in g),
                'records_with_length': sum(any(a['finish_reason'] == 'length' for a in r['call_audit']) for r in g),
                'finish_reasons': dict(Counter(a['finish_reason'] for a in audits)),
                'calls': len(audits), 'tokens': sum(r['meter_summary']['total_tokens'] for r in g),
                'nominal_usd': sum(r['meter_summary']['total_cost_usd'] for r in g),
                'stops': dict(Counter(r.get('stop_reason') or 'not_applicable' for r in g))}
    report = {'stage': f'S5_{args.stage}_not_final_freeze', 'output_cap': cap, 'scorer_version': SCORER_VERSION,
              'task_n': len(tasks), 'normal_records': len(normal),
              'error_records': sum(bool(r.get('error')) for r in rows),
              'successful_uncached_calls': sum(r['meter_summary']['n_calls'] for r in normal),
              'nominal_usd': sum(r['meter_summary']['total_cost_usd'] for r in rows),
              'cost_note': 'List-price estimate, not invoice; failed-request billing unmeasured.',
              'datasets': groups,
              'reflection': {s: reflect_transition([r for r in normal if r['strategy'] == s and r['n_reflections'] > 0], tasks)
                             for s in ('plan_reflect', 'adaptive')},
              'adaptive_routes': {source: dict(Counter(r['extra'].get('route_method') for r in normal
                                    if r['source'] == source and r['strategy'] == 'adaptive')) for source in ('gsm8k', 'math')},
              'review': [{'task_id': r['task_id'], 'strategy': r['strategy'], 'reason': r['score_reason'],
                         'answer': r['final_answer'], 'gold': tasks[r['task_id']].gold}
                        for r in normal if r['needs_review']],
              'length_calls': [{'task_id': r['task_id'], 'strategy': r['strategy'], 'purpose': a['purpose'],
                                'content_empty': not a['content'].strip()}
                               for r in normal for a in r['call_audit'] if a['finish_reason'] == 'length'],
              'limitations': ['Dev exploratory results; no formal-test or noninferiority claim.',
                              'No shared total-call budget in these runs.',
                              f'{cap} remains provisional when full-sample truncations occur.',
                              'Router is the original S2 artifact; grid audit candidate not applied.']}
    report['output_validity_pass'] = not report['error_records'] and not report['length_calls'] and all(r['final_answer'].strip() for r in normal)
    dest = ROOT / f'results/aggregated/pilot_s5_diagnostics_{output_suffix}.json'
    dest.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    lines = [f'# S5 {args.stage} 完整 dev 复验诊断', '', f'80 题×五策略，全部为新调用；输出档位 {cap}，正式 test 尚未开始。', '',
             '| 数据集 | 策略 | 自动判对 | 待复核 | 空答案 | 出现 length 的记录 | 调用 | 标价估算 USD |',
             '|---|---|---:|---:|---:|---:|---:|---:|']
    for source, strategies in groups.items():
        for s, v in strategies.items():
            lines.append(f"| {source} | {s} | {v['correct']}/{v['n']} | {v['needs_review']} | {v['empty_final']} | {v['records_with_length']} | {v['calls']} | {v['nominal_usd']:.6f} |")
    lines += ['', f"成功新调用 {report['successful_uncached_calls']} 次；标价估算 USD {report['nominal_usd']:.6f}，不是实际账单。",
              '', f'逐调用响应信封、结束原因、{cap} 上限和样本唯一性均已核对。',
              '输出截断、空答案及评分争议单列；正确性、格式有效性与停止原因分别报告。',
              '原路由、无共享总调用预算；本轮用于诊断，不据此声称 S6 冻结通过或非劣效成立。',
              '', '反思转移、待复核答案和截断调用入口见同名 JSON。']
    (ROOT / f'paper/Pilot复验诊断_{output_suffix}.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({k: report[k] for k in ('normal_records', 'successful_uncached_calls', 'nominal_usd', 'datasets')}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
