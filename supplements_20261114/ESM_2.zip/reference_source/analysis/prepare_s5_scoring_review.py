"""Prepare an auditable review proposal; never changes scores or raw files."""
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
report = json.loads((ROOT / 'results/aggregated/pilot_s5_diagnostics_20261014.json').read_text(encoding='utf-8'))
raw_paths = [ROOT / f'results/raw/pilot_{s}_20261013_s5c.jsonl' for s in ('gsm8k', 'math')]
raw = [json.loads(line) for p in raw_paths for line in p.read_text(encoding='utf-8').splitlines()]
by_key = {(r['task_id'], r['strategy']): r for r in raw if not r.get('error')}
proposals = []
for item in report['review']:
    row = by_key[item['task_id'], item['strategy']]
    proposal = dict(item)
    proposal.update({'original_success': row['success'], 'original_needs_review': row['needs_review'],
                     'original_score_reason': row['score_reason'], 'status': 'AI_review_proposal_not_human_adjudication'})
    if not row['final_answer'].strip():
        proposal.update({'classification': 'empty_final_output', 'proposed_success': False,
                        'basis': 'No final answer was emitted; preserve separate truncation/invalid-output accounting.'})
    else:
        assert item['task_id'] == 'math_geometry_dev_0036' and row['final_answer'] == '180°'
        # Verify the actual Asymptote edge cycle's seven Euclidean tip angles.
        points = {name: (math.cos(k * 2 * math.pi / 7), math.sin(k * 2 * math.pi / 7))
                  for name, k in {'A':4, 'B':3, 'C':2, 'D':1, 'E':5, 'F':6, 'G':7}.items()}
        cycle = 'ACGEBDF'
        angles = []
        for i, vertex in enumerate(cycle):
            center = points[vertex]
            a, b = points[cycle[i-1]], points[cycle[(i+1) % 7]]
            u, v = (a[0]-center[0], a[1]-center[1]), (b[0]-center[0], b[1]-center[1])
            cosine = (u[0]*v[0]+u[1]*v[1]) / (math.hypot(*u)*math.hypot(*v))
            angles.append(math.degrees(math.acos(max(-1., min(1., cosine)))))
        assert math.isclose(sum(angles), 540., abs_tol=1e-8)
        proposal.update({'classification': 'different_angle_value', 'proposed_success': False,
                        'basis': 'Actual edge cycle A-C-G-E-B-D-F has seven equal tip angles 540/7 degrees; total 540 degrees, distinct from 180 degrees.',
                        'geometry_check': {'tip_angles_degrees': angles, 'sum_degrees': sum(angles)},
                        'task_prompt': next(a['messages'][1]['content'] for a in row['call_audit'] if a['purpose'] == 'plan')})
    proposals.append(proposal)
assert len(proposals) == 27
out = {'stage': 'S4_review_proposals_only', 'proposals_n': 27, 'empty_n': 26,
       'nonempty_n': 1, 'raw_unchanged': True, 'human_approved': False,
       'raw_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in raw_paths},
       'proposals': proposals}
(ROOT / 'results/aggregated/s5_scoring_review_proposals_20261014.json').write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')
lines = ['# S5c 评分待复核提案', '', '本文件由 AI 整理，不是作者/人工裁定。原始评分、响应和 needs_review 标记不改。', '',
         '27 条待复核：26 条未发出最终答案，建议质量计为失败并独立报告空输出/截断；1 条输出180°，与该题540°不同。', '',
         '非空争议的独立核查：依据原题 Asymptote 的 A-C-G-E-B-D-F 连线，逐点以相邻两条边夹角计算，七个尖角各540/7度，总和540度。这里核对的是实际边连接，避免把不同连线的七角星当作同一图形。', '',
         '| 任务 ID | 策略 | 原原因 | 建议分类 |', '|---|---|---|---|']
for p in proposals:
    lines.append(f"| {p['task_id']} | {p['strategy']} | {p['original_score_reason']} | {p['classification']} |")
lines += ['', '完整原答题、参考值、独立几何计算与源文件SHA256见同名JSON；如作者批准，应新增裁定侧表并保留原评分。',
          '该核查不修改评分器，不使用 test，不把结果回馈给生成/路由/投票过程。']
(ROOT / 'paper/S5c评分复核提案_20261014.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(json.dumps({k: out[k] for k in ('proposals_n', 'empty_n', 'nonempty_n', 'human_approved')}))
