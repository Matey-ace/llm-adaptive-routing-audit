"""查看任意一次 run 的汇总与协议遵循情况。

用法：
    python analysis/show_run.py                 # 自动取最新一次 run
    python analysis/show_run.py intern_probe    # 按 raw 文件名前缀筛选
    python analysis/show_run.py --steps         # 额外打印每步原始 response
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)


def load_rows(prefix: str | None) -> tuple[str, list]:
    os.chdir(PROJECT_ROOT)
    pattern = f"results/raw/{prefix}*.jsonl" if prefix else "results/raw/*.jsonl"
    files = sorted(glob.glob(pattern))
    if not files:
        raise SystemExit(f"未找到匹配的原始日志: {pattern}")
    raw = files[-1]
    rows = [json.loads(l) for l in open(raw, encoding="utf-8")]
    return raw, rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("prefix", nargs="?", default=None)
    ap.add_argument("--steps", action="store_true", help="打印每步原始 response")
    args = ap.parse_args()

    raw, rows = load_rows(args.prefix)
    print(f"原始文件: {raw}")
    print(f"记录数: {len(rows)} | 失败: {sum(1 for r in rows if r.get('error'))}")
    print()

    if args.steps:
        print("========== 每步原始 response ==========")
        for r in rows:
            print("-" * 76)
            print(f"[{r['strategy']}] {r['task_id']} ({r['difficulty']}) "
                  f"success={r['success']} answer={str(r['final_answer'])[:40]!r}")
            for s in r.get("steps", []):
                print(f"   {s['kind']:9s} {s['latency_ms']:7.0f}ms  "
                      f"{str(s.get('response', ''))[:180]!r}")
        print()

    print("========== 汇总（按客观难度锚点分层）==========")
    agg_file = os.path.join("results", "aggregated",
                            os.path.basename(raw).replace(".jsonl", ".json"))
    if not os.path.exists(agg_file):
        raise SystemExit(f"未找到汇总文件: {agg_file}，请先运行 runner")
    d = json.load(open(agg_file, encoding="utf-8"))

    hdr = (f"{'策略':16s}{'层级':8s}{'n':>4s}{'准确率':>8s}{'总token':>10s}"
           f"{'API延迟ms':>10s}{'调用':>6s}{'反思':>6s}{'成本$':>10s}{'判定一致':>9s}")
    print(hdr)
    for s in ["direct", "planning", "plan_reflect", "adaptive"]:
        if s not in d:
            continue
        for lvl in ["easy", "medium", "hard"]:
            if lvl not in d[s]:
                continue
            a = d[s][lvl]
            ja = a["judge_agreement"]
            print(f"{s:16s}{lvl:8s}{a['n']:>4d}{a['accuracy']:>8.3f}"
                  f"{a['avg_total_tokens']:>10.1f}{a['avg_api_latency_ms']:>10.0f}"
                  f"{a['avg_llm_calls']:>6.2f}{a['avg_reflections']:>6.2f}"
                  f"{a['avg_cost_usd']:>10.6f}"
                  f"{(f'{ja:.2f}' if ja is not None else '-'):>9s}")

    print()
    print("========== adaptive 路径分布与判定一致率 ==========")
    if "adaptive" in d:
        for lvl in ["easy", "medium", "hard"]:
            if lvl in d["adaptive"]:
                a = d["adaptive"][lvl]
                print(f"  {lvl:7s}: 路径 {a['path_distribution']}  "
                      f"判定一致率 {a['judge_agreement']}")


if __name__ == "__main__":
    main()
