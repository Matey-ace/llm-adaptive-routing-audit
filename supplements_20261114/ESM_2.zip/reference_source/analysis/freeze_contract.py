"""S6 contract validation before real benchmark-test model requests."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def object_sha256(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()


def source_snapshot():
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for folder in ('agents', 'complexity', 'eval', 'llm_proxy', 'runner', 'tasks', 'analysis')
            for p in sorted((ROOT / folder).rglob('*.py'))}


def project_path(path):
    result = (ROOT / path).resolve()
    if not result.is_relative_to(ROOT):
        raise ValueError('Freeze artifact path must stay inside project')
    return result


def verify_test_freeze(cfg, tasks, run_id, repeats, limit, base_config, provider_config, router_sha256):
    """Return frozen packet hash, or None for mock/dev/synthetic fixtures.

    This is a reproducibility gate, not an author-signature or statistical
    success certificate. It must be called before run manifest/request creation.
    """
    if cfg.get('provider', 'mock') == 'mock' or not any(t.split == 'test' and t.source in ('gsm8k', 'math') for t in tasks):
        return None
    if cfg.get('phase') != 'formal_test' or not cfg.get('freeze_artifact'):
        raise ValueError('Real benchmark test requires an explicit S6 freeze artifact')
    if limit is not None or cfg.get('resume_success_from'):
        raise ValueError('Frozen test disallows limit overrides and borrowing prior run outputs')
    if not tasks or any(t.split != 'test' for t in tasks) or len({t.source for t in tasks}) != 1:
        raise ValueError('Frozen case requires one benchmark source and only test tasks')
    raw = project_path(cfg['freeze_artifact']).read_bytes()
    frozen = json.loads(raw)
    required = ('primary_comparison', 'statistics', 'repeat_policy', 'test_members', 'runs', 'source_sha256', 'artifacts')
    if frozen.get('schema_version') != 1 or frozen.get('status') != 'frozen_s6' or any(k not in frozen for k in required):
        raise ValueError('S6 packet is incomplete or not frozen')
    if frozen.get('delta') != .03 or frozen.get('test_counts') != {'gsm8k': 1000, 'math': 1000}:
        raise ValueError('S6 packet does not match author-selected margin/sample counts')
    if frozen.get('score_validation_splits') != ['calibration', 'dev'] or frozen.get('historical_test_gold_exposure') is not True:
        raise ValueError('Scorer split policy or historical exposure disclosure missing')
    from eval.metrics import SCORER_VERSION
    if frozen.get('scorer_version') != SCORER_VERSION or frozen.get('trajectory_schema_version') != '2026-10-14.2':
        raise ValueError('Scorer/trajectory version differs from S6')
    if frozen['primary_comparison'] != {'a': 'adaptive', 'b': 'plan_reflect', 'quality_and_cost_same_pair': True}:
        raise ValueError('Primary comparison must identify the same quality/cost comparator')
    stats = frozen['statistics']
    if (stats.get('quality_interval') != 'paired_discordant_CP_union_bound' or stats.get('confidence') != .95
            or stats.get('unknown_policy') != 'conservative_bounds' or stats.get('quality_variant') != 'stratified_union_bound'):
        raise ValueError('Primary interval/uncertainty policy is not the validated S6 method')
    if float(os.environ.get('INTERN_AI_REQUEST_INTERVAL_S','0')) != frozen.get('request_interval_s'):
        raise ValueError('Request pacing differs from frozen runtime policy')
    if frozen['repeat_policy'].get('unit') != 'task' or frozen['repeat_policy'].get('primary_repeats') != 1:
        raise ValueError('Primary independent tasks and supplemental clustering not specified')
    if any(len(frozen['test_members'].get(s, {})) != 1000 for s in ('gsm8k', 'math')):
        raise ValueError('S6 full test member cardinality differs')
    if any(len(set(frozen['test_members'][s].values())) != 1000 for s in ('gsm8k', 'math')):
        raise ValueError('Duplicate task fingerprints in frozen test pool')
    if source_snapshot() != frozen['source_sha256']:
        raise ValueError('Experiment or analysis source changed after S6 freeze')
    for path, expected in frozen['artifacts'].items():
        if hashlib.sha256(project_path(path).read_bytes()).hexdigest() != expected:
            raise ValueError(f'Frozen artifact changed: {path}')
    case = frozen['runs'].get(run_id)
    if not case:
        raise ValueError('Run ID is not predeclared in S6')
    if object_sha256(cfg) != case.get('config_sha256'):
        raise ValueError('Experiment config changed after S6')
    settings = {'base_config': base_config, 'provider_config': provider_config, 'router_sha256': router_sha256}
    if object_sha256(settings) != case.get('runtime_sha256') or repeats != case.get('repeats'):
        raise ValueError('Resolved runtime settings/repeats differ from S6')
    from tasks.loaders._manifest import row_key
    actual = {t.task_id: row_key(t) for t in tasks}
    source = tasks[0].source
    if len(actual) != len(tasks) or actual != case.get('task_fingerprints') or case.get('source') != source:
        raise ValueError('Selected test members differ from frozen case')
    if any(frozen['test_members'][source].get(i) != h for i, h in actual.items()):
        raise ValueError('Case includes a member outside the author-selected test pool')
    if case.get('role') == 'primary' and len(tasks) != 1000:
        raise ValueError('Primary test case must use all 1000 source tasks')
    if case.get('role') == 'primary' and repeats != 1:
        raise ValueError('Primary interval supports one binary outcome per task')
    return hashlib.sha256(raw).hexdigest()
