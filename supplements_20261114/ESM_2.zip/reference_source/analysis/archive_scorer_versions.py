"""Recover the prior source only when its bytes match the recorded S3 hash."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
current = (ROOT / "eval/extractors.py").read_text(encoding="utf-8")
old = current.replace("2026-10-13.2", "2026-10-13.1")
old = old.replace('    s = s.replace("−", "-").replace("π", r"\\pi")\n', '')
block = r'''    # A numeric Unicode radicand has a known endpoint. Leave √2x and √2^2
    # unresolved instead of guessing the extent of the radical.
    s = re.sub(r"√(\d+(?:\.\d+)?)(?=$|[)/,+\-*])",
               lambda m: r"\sqrt{" + m.group(1) + "}", s)
'''
assert block in old
old = old.replace(block, "")
expected = json.loads((ROOT / "results/verify/s3_source_sha256_20261013.json").read_text(encoding="utf-8-sig"))["eval\\extractors.py"]
directory = ROOT / "results/verify/scorer_sources"
directory.mkdir(exist_ok=True)
found = False
for candidate in (old.encode("utf-8"), old.replace("\n", "\r\n").encode("utf-8")):
    if hashlib.sha256(candidate).hexdigest() == expected:
        (directory / "extractors_2026-10-13.1.py").write_bytes(candidate)
        found = True
        break
assert found, "Prior source reconstruction did not match; do not claim archival parity"
(directory / "extractors_2026-10-13.2.py").write_bytes((ROOT / "eval/extractors.py").read_bytes())
print("Both scorer sources archived; prior bytes match the S3 source hash.")
