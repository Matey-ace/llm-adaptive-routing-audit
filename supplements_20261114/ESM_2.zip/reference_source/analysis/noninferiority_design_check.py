"""Prospective paired-binary precision check; no test data or model calls."""
import json
import math
from pathlib import Path
from statistics import NormalDist

ROOT = Path(__file__).resolve().parents[1]
DELTA = .03
normal = NormalDist()
z = normal.inv_cdf(.975)  # Two-sided 95% lower endpoint specified in protocol.
target_z = normal.inv_cdf(.8)
rows = []
for q in (.01, .03, .05, .10, .20, .30):
    for n in (200, 300, 500):
        se = math.sqrt(q / n)
        rows.append({'disagreement_probability': q, 'n_independent_tasks': n,
                     'approx_95_halfwidth_at_true_difference_zero': z * se,
                     'approx_power_at_true_difference_zero': normal.cdf(DELTA / se - z),
                     'approx_n_for_80percent_power_at_true_difference_zero': math.ceil(q * ((z + target_z) / DELTA) ** 2)})
report = {'status': 'prospective_approximation_not_final_power_or_freeze', 'delta': DELTA,
          'confidence': .95, 'assumed_true_accuracy_difference': 0,
          'derivation': 'D=A-B in {-1,0,1}; E[D^2]=q; Var(D)=q-Delta^2. At Delta=0, SE=sqrt(q/n). NI lower endpoint Dbar-z(.975)*SE > -delta.',
          'source_of_q': 'Hypothetical sensitivity grid, not fitted to formal test.',
          'formula_power': 'Phi(delta*sqrt(n/q)-z(.975))',
          'formula_n': 'ceil(q*(z(.975)+z(.8))^2/delta^2)',
          'rows': rows,
          'limits': ['Normal approximation with known hypothetical q; final protocol uses paired bootstrap.',
                     'Small n or sparse disagreements require dedicated simulation/exact interval assessment.',
                     'A real quality deficit reduces power; this assumes true difference zero.',
                     'Repeated calls do not add independent tasks; clustering remains required.',
                     'n=500 is illustrative; do not pool datasets into one primary accuracy result.',
                     'No formal-test answers or gold were used.']}
(ROOT / 'results/verify/noninferiority_design_check_20261014.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
lines = ['# δ=3 个百分点的配对样本量预检查', '',
         '这是 S6 冻结前的前瞻敏感性计算，不是正式功效认证或实验结论。未使用 test 答案、标签或结果。', '',
         '设同题正确性差 D=A−B，取值 −1/0/1；q 为两策略正确性不一致的概率。则 Var(D)=q−Δ²。假定真实差值 Δ=0，标准误为 √(q/n)。协议规定配对差值双侧 95% 区间下界大于 −0.03；正态近似功效为 Φ(0.03√(n/q)−1.960)。', '',
         '| 假设不一致率 q | MATH n=200 近似功效 | GSM8K n=300 近似功效 | 达到 80% 的近似独立题数 |',
         '|---|---:|---:|---:|']
for q in (.01, .03, .05, .10, .20, .30):
    g = [r for r in rows if r['disagreement_probability'] == q]
    lines.append(f"| {q:.0%} | {g[0]['approx_power_at_true_difference_zero']:.1%} | {g[1]['approx_power_at_true_difference_zero']:.1%} | {g[0]['approx_n_for_80percent_power_at_true_difference_zero']} |")
lines += ['', '当前 200/300 题在不一致率达到 5% 或以上时，近似功效低于 80%；这不证明实际功效必然不足，实际不一致率与真实差值未知。真实准确率若已下降，非劣效更难成立。',
          '重复实验应按题聚类，不把同题多次作答折算成新增独立题数；两个数据集分别报告，不将 n=500 当作单一主指标。',
          '冻结前需明确保留当前规模并如实报告区间精度，或在看 test 前扩大独立样本并核查抽样/费用。δ 保持作者已定的 0.03。',
          '该推导是已知假设 q 的正态近似；正式配对 bootstrap 检验仍应通过边界零假设和稀疏不一致场景的模拟验收，不以本表替代。']
(ROOT / 'paper/非劣效样本量预检查_20261014.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(json.dumps(rows[:9], indent=2))
