"""Synthetic heterogeneous stratum check; no benchmark gold or API calls."""
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / '.runtime/statistics'))
import numpy as np
from scipy import __version__ as scipy_version
from scipy.stats import beta
from analysis.paired_exact_interval import clopper_pearson


def main():
    plan = {'seed': 20261016, 'trials_each': 3000, 'confidence': .95,
            'margin': .03, 'real_api_calls': 0, 'benchmark_gold_used': False,
            'strata_sizes': {'gsm8k': [354,480,166], 'math': [259,218,523]},
            'discordance_profiles': [[.03,.03,.03],[.05,.05,.05],[.1,.1,.1],[.03,.1,.2]],
            'true_differences': [0.,-.03], 'method': 'stratified_CP_union_bound',
            'assumptions': 'IID outcomes within difficulty strata; sampled design mixture; no repeated task clusters'}
    path = ROOT / 'results/verify/stratified_interval_simulation_20261014.plan.json'
    if path.exists():
        assert json.loads(path.read_text(encoding='utf-8')) == plan
    else:
        path.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding='utf-8')
    tail = .05 / 12
    numerical_checks = []
    for n in (166,218,354,523):
        for k in (0,1,7,n//2,n-1,n):
            lo, hi = clopper_pearson(k,n,tail)
            slo = 0. if k == 0 else float(beta.ppf(tail,k,n-k+1))
            shi = 1. if k == n else float(beta.ppf(1-tail,k+1,n-k))
            error = max(abs(lo-slo),abs(hi-shi))
            assert error < 1e-10
            numerical_checks.append({'n': n, 'k': k, 'max_error': error})
    rng = np.random.default_rng(plan['seed'])
    scenarios = []
    for source, sizes in plan['strata_sizes'].items():
        for qs in plan['discordance_profiles']:
            for difference in plan['true_differences']:
                lower = np.zeros(plan['trials_each'])
                upper = np.zeros(plan['trials_each'])
                for n,q in zip(sizes,qs):
                    counts = rng.multinomial(n,[(q+difference)/2,(q-difference)/2,1-q],size=plan['trials_each'])
                    plus,minus = counts[:,0],counts[:,1]
                    def bound(k):
                        lo = np.where(k == 0,0.,beta.ppf(tail,k,n-k+1))
                        hi = np.where(k == n,1.,beta.ppf(1-tail,k+1,n-k))
                        return lo,hi
                    lp,up = bound(plus)
                    lm,um = bound(minus)
                    lower += n/sum(sizes)*(lp-um)
                    upper += n/sum(sizes)*(up-lm)
                coverage = float(np.mean((lower <= difference)&(upper >= difference)))
                reject = float(np.mean(lower > -.03))
                scenarios.append({'source':source,'n':sum(sizes),'discordance_by_stratum':qs,
                                  'true_difference':difference,'coverage':coverage,
                                  'noninferiority_rate':reject,
                                  'ni_mc_standard_error':float(np.sqrt(reject*(1-reject)/plan['trials_each'])),
                                  'mean_interval_width':float(np.mean(upper-lower))})
    output = {'plan':plan,'versions':{'numpy':np.__version__,'scipy':scipy_version},
              'numerical_cross_checks':numerical_checks,'scenarios':scenarios,
              'limitation':'Synthetic checks support implementation, not assumptions on real benchmark/service outcomes or a universal power guarantee.'}
    (ROOT / 'results/aggregated/stratified_interval_simulation_20261014.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'cross_checks':len(numerical_checks),'scenarios':scenarios},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
