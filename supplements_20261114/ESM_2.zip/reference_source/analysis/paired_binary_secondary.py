"""Secondary paired binary statistics; do not delete unknown outcomes."""
import math
from analysis.paired_summary import outcome


def binary_secondary(pairs):
    from scipy.stats import binomtest
    pairs = list(pairs)
    seen = set()
    for a,b in pairs:
        if a['task_id'] != b['task_id'] or a.get('repeat_id') != b.get('repeat_id') or a['task_id'] in seen:
            raise ValueError('One matched primary repeat per task required')
        seen.add(a['task_id'])
    if not pairs:
        raise ValueError('Empty paired sample')
    values = [(outcome(a),outcome(b)) for a,b in pairs]
    unknown = sum(x is None or y is None for x,y in values)
    if unknown:
        return {'available':False,'n_tasks':len(values),'unknown_pairs':unknown,
                'reason':'Unknown scores retained in primary bounds; no complete-case significance claim'}
    plus = sum(x>y for x,y in values)
    minus = sum(x<y for x,y in values)
    pa = sum(x for x,_ in values)/len(values)
    pb = sum(y for _,y in values)/len(values)
    return {'available':True,'n_tasks':len(values),'discordant_a_only':plus,'discordant_b_only':minus,
            'mcnemar_exact_pvalue':float(binomtest(plus,plus+minus,.5,alternative='two-sided').pvalue) if plus+minus else 1.,
            'cohens_h_a_minus_b':2*math.asin(math.sqrt(pa))-2*math.asin(math.sqrt(pb)),
            'scope':'Secondary marginal equality/standardized effect; not the quality noninferiority test'}
