"""Synthetic power and boundary audit of paired percentile-bootstrap design."""
import json
import math
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SEED, TRIALS, BOOTSTRAPS, DELTA = 20261014, 1500, 2000, .03
plan = {'seed': SEED, 'trials_per_scenario': TRIALS, 'bootstraps_per_trial': BOOTSTRAPS,
        'n_candidates': [200, 300], 'q_candidates': [.03, .05, .1, .2],
        'true_differences': [0., -DELTA], 'delta': DELTA,
        'method': 'paired task resampling; percentile 2.5% lower endpoint; strict lower > -delta',
        'purpose': 'Prospective synthetic audit, not formal test or configuration selection on test'}
dest = ROOT / 'results/verify/noninferiority_bootstrap_simulation_20261014.plan.json'
if dest.exists():
    assert json.loads(dest.read_text(encoding='utf-8')) == plan
else:
    dest.write_text(json.dumps(plan, indent=2), encoding='utf-8')
rng = np.random.default_rng(SEED)
results = []
for n in plan['n_candidates']:
    for q in plan['q_candidates']:
        for diff in plan['true_differences']:
            probabilities = [(q + diff) / 2, (q - diff) / 2, 1 - q]
            samples = rng.multinomial(n, probabilities, size=TRIALS)
            rejected = 0
            for counts in samples:
                # For D in {-1,0,1}, multinomial resampling exactly represents
                # drawing n paired tasks with replacement from the observed set.
                draws = rng.multinomial(n, counts / n, size=BOOTSTRAPS)
                differences = (draws[:, 0] - draws[:, 1]) / n
                lower = float(np.quantile(differences, .025, method='linear'))
                rejected += lower > -DELTA
            rate = rejected / TRIALS
            results.append({'n': n, 'q': q, 'true_difference': diff,
                            'measure': 'power' if diff == 0 else 'boundary_type_I_rejection',
                            'rate': rate, 'mc_standard_error': math.sqrt(rate * (1 - rate) / TRIALS)})
            print(json.dumps(results[-1]), flush=True)
report = {'plan': plan, 'results': results,
          'limitations': ['Synthetic independent binary task differences, no test data.',
                         'Only one-run-per-task scenario; clustered repeated-run audit remains pending.',
                         'Monte Carlo rates have sampling uncertainty; no guarantee for unseen q or true differences.',
                         'No primary comparison, sample size or test configuration frozen by this audit.']}
(ROOT / 'results/verify/noninferiority_bootstrap_simulation_20261014.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
lines = ['# 配对 bootstrap 非劣效设计的合成验收', '',
         f'固定种子 {SEED}，每场景 {TRIALS} 次模拟、每次 {BOOTSTRAPS} 次配对重采样。所有数据为模拟，未使用正式 test。', '',
         'D 为同题两策略正确性差，q 为不一致率。考察真实差值 0（功效）与 −0.03（零假设边界拒绝率）。判定使用双侧 95% percentile 区间下界严格大于 −0.03。', '',
         '| 独立题数 | q | 真实差值为 0 的功效 | 零假设边界拒绝率 | 边界率 MC 标准误 |',
         '|---:|---:|---:|---:|---:|']
for n in plan['n_candidates']:
    for q in plan['q_candidates']:
        g = [r for r in results if r['n'] == n and r['q'] == q]
        lines.append(f"| {n} | {q:.0%} | {g[0]['rate']:.1%} | {g[1]['rate']:.1%} | {g[1]['mc_standard_error']:.3f} |")
lines += ['', '该模拟验证一个明确的 percentile-bootstrap 实现选择；不等同于最终统计代码验收，不覆盖同题多次重复的聚类设计。',
          '离散端点、稀疏不一致与有限 bootstrap 次数都会影响拒绝率；报告全部场景，不按最有利场景选择样本量。',
          '当前样本规模的精度限制与 δ=.03 同时保留，S6 冻结仍需确定主比较、独立题数与最终统计实现。']
(ROOT / 'paper/配对bootstrap合成验收_20261014.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
