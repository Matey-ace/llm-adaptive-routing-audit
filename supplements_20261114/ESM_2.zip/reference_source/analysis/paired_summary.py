"""Pre-test paired analysis primitives. No gold access or model requests.

Unknown nonempty scores are bounded, never silently adjudicated. Cost
resampling uses whole tasks and preserves paired runs and difficulty strata.
"""
import math
import random
from collections import defaultdict
from analysis.paired_exact_interval import paired_difference_interval


def outcome(row):
    if row.get('error') or not str(row.get('final_answer', '')).strip():
        return 0
    if row.get('needs_review') or row.get('success') is None:
        return None
    return int(bool(row['success']))


def quality_bounds(pairs, delta=.03, confidence=.95):
    """Weighted stratum CP bounds; only a single primary repeat per task.

    The union bound allocates alpha across every nonempty difficulty stratum.
    Weights are observed sample proportions, defining the sampled design
    mixture. Coverage needs IID conditional Bernoulli outcomes per stratum;
    benchmark sampling and service drift do not establish that assumption.
    """
    pairs = list(pairs)
    groups = defaultdict(list)
    seen = set()
    for a, b in pairs:
        if a.get('source') != b.get('source'):
            raise ValueError('Source mismatch')
        if a['task_id'] != b['task_id'] or a.get('repeat_id', 0) != b.get('repeat_id', 0):
            raise ValueError('Unpaired task/repeat')
        if a['task_id'] in seen:
            raise ValueError('Primary quality analysis permits one repeat per task')
        seen.add(a['task_id'])
        if a.get('difficulty') != b.get('difficulty'):
            raise ValueError('Difficulty mismatch')
        groups[a.get('difficulty', 'unspecified')].append((outcome(a), outcome(b)))
    if not groups:
        raise ValueError('Empty paired sample')
    n = len(seen)
    if len({a.get('source') for a, _ in pairs}) > 1:
        raise ValueError('Report benchmark sources separately')
    levels = len(groups)
    lower = upper = point_lower = point_upper = 0.
    strata = {}
    for level, values in groups.items():
        low = [(0 if x is None else x, 1 if y is None else y) for x, y in values]
        high = [(1 if x is None else x, 0 if y is None else y) for x, y in values]
        def interval(v):
            return paired_difference_interval(sum(x > y for x, y in v), sum(x < y for x, y in v),
                                              len(v), 1 - (1 - confidence) / levels)
        lo, hi = interval(low), interval(high)
        weight = len(values) / n
        lower += weight * lo['lower']
        upper += weight * hi['upper']
        point_lower += weight * lo['difference']
        point_upper += weight * hi['difference']
        strata[level] = {'n': len(values), 'weight': weight, 'low_assignment': lo, 'high_assignment': hi}
    return {'n_tasks': n, 'difference_bounds': [point_lower, point_upper], 'confidence_interval': [lower, upper],
            'noninferiority': lower > -delta, 'delta': delta, 'confidence': confidence,
            'method': 'paired_discordant_CP_union_bound', 'variant': 'stratified_union_bound',
            'uncertain_pairs': sum(x is None or y is None for v in groups.values() for x, y in v),
            'strata': strata, 'assumption': 'IID paired outcomes conditional on difficulty; sampled design weights; one primary repeat'}


def paired_cost(pairs, getter, draws=2000, seed=20261014):
    """Task-cluster mean A-B bootstrap; matched repeats averaged within task.

    Returns descriptive percentile bounds, not the primary quality NI test.
    Missing costs make the full paired metric unavailable, never zero-filled.
    """
    if draws < 100:
        raise ValueError('At least 100 descriptive bootstrap draws')
    pairs = list(pairs)
    if len({a.get('source') for a, _ in pairs}) > 1:
        raise ValueError('Report benchmark sources separately')
    groups = defaultdict(list)
    seen = set()
    for a, b in pairs:
        if a.get('source') != b.get('source'):
            raise ValueError('Source mismatch')
        key = (a['task_id'], a.get('repeat_id', 0))
        if key != (b['task_id'], b.get('repeat_id', 0)) or key in seen:
            raise ValueError('Unpaired/duplicate task repeat')
        seen.add(key)
        if a.get('difficulty') != b.get('difficulty'):
            raise ValueError('Difficulty mismatch')
        x, y = getter(a), getter(b)
        if x is None or y is None or not math.isfinite(x) or not math.isfinite(y):
            return {'available': False, 'reason': 'Missing/nonfinite paired cost; no zero imputation'}
        groups[(a.get('difficulty', 'unspecified'), a['task_id'])].append((x, y))
    strata = defaultdict(list)
    for (level, _), runs in groups.items():
        strata[level].append((sum(x for x, _ in runs) / len(runs), sum(y for _, y in runs) / len(runs)))
    n = len(groups)
    if not n:
        raise ValueError('Empty paired cost sample')
    mean_a = sum(x for v in strata.values() for x, _ in v) / n
    mean_b = sum(y for v in strata.values() for _, y in v) / n
    differences = [x - y for v in strata.values() for x, y in v]
    rng = random.Random(seed)
    samples = sorted(sum(sum(x-y for x, y in (rng.choice(v) for _ in v)) for v in strata.values()) / n for _ in range(draws))
    return {'available': True, 'n_tasks': n, 'n_paired_runs': len(seen), 'mean_a': mean_a, 'mean_b': mean_b,
            'difference_a_minus_b': mean_a - mean_b,
            'relative_saving': None if mean_b == 0 else 1 - mean_a / mean_b,
            'descriptive_percentile95': [samples[int(.025 * (draws-1))], samples[int(.975 * (draws-1))]],
            'paired_sign_effect': (sum(d > 0 for d in differences) - sum(d < 0 for d in differences)) / n,
            'draws': draws, 'seed': seed, 'unit': 'task_cluster', 'stratified': True}
