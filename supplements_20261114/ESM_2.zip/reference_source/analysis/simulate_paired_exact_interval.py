"""Synthetic audit of the conservative paired-discordant candidate interval."""
import json
import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from analysis.paired_exact_interval import paired_difference_interval

plan = {'seed': 20261015, 'trials_per_scenario': 3000,
        'n_candidates': [200, 300, 1000], 'q_candidates': [.03, .05, .1, .2],
        'true_differences': [0., -.03], 'delta': .03,
        'confidence': .95, 'method': 'paired_discordant_CP_union_bound',
        'status': 'candidate_not_adopted', 'data': 'Synthetic independent paired differences only'}
dest = ROOT / 'results/verify/paired_exact_simulation_20261014.plan.json'
if dest.exists():
    assert json.loads(dest.read_text(encoding='utf-8')) == plan
else:
    dest.write_text(json.dumps(plan, indent=2), encoding='utf-8')
rng = np.random.default_rng(plan['seed'])
rows = []
for n in plan['n_candidates']:
    for q in plan['q_candidates']:
        for diff in plan['true_differences']:
            counts = rng.multinomial(n, [(q + diff) / 2, (q - diff) / 2, 1 - q], size=plan['trials_per_scenario'])
            rejected = sum(paired_difference_interval(int(plus), int(minus), n)['lower'] > -.03 for plus, minus, _ in counts)
            rate = rejected / len(counts)
            row = {'n': n, 'q': q, 'true_difference': diff, 'rate': rate,
                   'measure': 'power' if diff == 0 else 'boundary_type_I_rejection',
                   'mc_standard_error': math.sqrt(rate * (1-rate) / len(counts))}
            rows.append(row)
            print(json.dumps(row), flush=True)
(ROOT / 'results/verify/paired_exact_simulation_20261014.json').write_text(json.dumps({'plan': plan, 'results': rows}, indent=2), encoding='utf-8')
lines = ['# 保守配对区间候选的合成模拟', '', '方法为不一致计数的 Clopper–Pearson 联合界；尚未采用为正式主检验。', '',
         '每场景 3000 次模拟，固定种子 20261015，不使用 test。重复题聚类不在本轮范围。', '',
         '| 独立题数 | q | Δ=0 时功效 | Δ=−.03 时边界拒绝率 |',
         '|---:|---:|---:|---:|']
for n in plan['n_candidates']:
    for q in plan['q_candidates']:
        g = [r for r in rows if r['n'] == n and r['q'] == q]
        lines.append(f"| {n} | {q:.0%} | {g[0]['rate']:.1%} | {g[1]['rate']:.1%} |")
lines += ['', '有限样本覆盖的依据为尾概率及联合界推导；模拟只是特定场景的数值检查，不替代证明。',
          '与 percentile-bootstrap 旧模拟不是同一随机样本上的成对方法比较；分别展示，不宣称已作配对优劣检验。',
          '1000 题也可能达不到 80% 功效；不反向放宽 δ，最终独立题数和主检验仍需冻结。']
(ROOT / 'paper/保守配对区间合成模拟_20261014.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
