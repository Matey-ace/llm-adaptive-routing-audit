"""Zero-API reproduction of S4 post-reflection usage freshness."""
import argparse
import hashlib
import json
import runpy
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--after-fix', action='store_true')
args = parser.parse_args()
scope = runpy.run_path(str(ROOT / 'tests/test_budget_stop_refresh.py'))
cases = []
for name, params in [('calls', {'max_calls': 3, 'max_tokens': 10**9}), ('tokens', {'max_calls': 100, 'max_tokens': 60})]:
    client = scope['Client']()
    result = scope['PlanReflectAgent'](client, stopper=scope['BudgetStopper'](**params),
        hard_cap=scope['HardCapStopper'](max_calls=8)).run(scope['AgentView']('t', 'q', ()))
    cases.append({'threshold': name, 'params': params, 'calls': client.calls,
                  'total_tokens': client.meter.total_tokens, 'stop_reason': result.stop_reason,
                  'pass': client.calls == ['plan', 'solve', 'reflect']})
report = {'real_api_calls': 0, 'cases': cases,
          'source_sha256': hashlib.sha256((ROOT / 'agents/plan_reflect.py').read_bytes()).hexdigest()}
tag = 'after_fix' if args.after_fix else 'before_fix'
(ROOT / f'results/verify/s4_latest_usage_{tag}_20261014.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
raise SystemExit(0 if all(c['pass'] for c in cases) else 1)
