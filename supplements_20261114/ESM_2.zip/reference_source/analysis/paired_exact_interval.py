"""Conservative paired binary risk-difference interval, one outcome per task.

For discordant probabilities p+ and p-, Delta=p+-p-. Each count has a
Binomial(n,p) marginal, even though the two counts are dependent. Four
one-sided Clopper-Pearson bounds at alpha/4, combined by the union bound,
give a two-sided interval with at least 1-alpha coverage under IID task
outcomes (or IID conditional outcomes within separately bounded strata). This does not
assume independence of A and B. Repeated task clusters are not supported.
"""
import math
from functools import lru_cache


@lru_cache(maxsize=128)
def _log_combinations(n):
    return tuple(math.lgamma(n + 1) - math.lgamma(i + 1) - math.lgamma(n - i + 1) for i in range(n + 1))


def _binomial_probability(n, p, first, last):
    if first > last:
        return 0.
    if p == 0:
        return float(first == 0)
    if p == 1:
        return float(last == n)
    combinations = _log_combinations(n)
    lp, lq = math.log(p), math.log1p(-p)
    logs = [combinations[i] + i * lp + (n - i) * lq for i in range(first, last + 1)]
    maximum = max(logs)
    return min(1., math.exp(maximum) * math.fsum(math.exp(x - maximum) for x in logs))


@lru_cache(maxsize=4096)
def clopper_pearson(k, n, tail=.025):
    if not isinstance(k, int) or not isinstance(n, int) or n < 1 or not 0 <= k <= n or not 0 < tail < .5:
        raise ValueError('Require integer 0<=k<=n, n>=1 and 0<tail<0.5')
    lower, upper = 0., 1.
    if k:
        lo, hi = 0., 1.
        for _ in range(60):
            mid = (lo + hi) / 2
            if _binomial_probability(n, mid, k, n) >= tail:
                hi = mid
            else:
                lo = mid
        lower = (lo + hi) / 2
    if k < n:
        lo, hi = 0., 1.
        for _ in range(60):
            mid = (lo + hi) / 2
            if _binomial_probability(n, mid, 0, k) > tail:
                lo = mid
            else:
                hi = mid
        upper = (lo + hi) / 2
    return lower, upper


def paired_difference_interval(plus, minus, n, confidence=.95):
    if not isinstance(plus, int) or not isinstance(minus, int) or plus < 0 or minus < 0 or plus + minus > n or not 0 < confidence < 1:
        raise ValueError('Invalid paired counts or confidence')
    tail = (1 - confidence) / 4
    lp, up = clopper_pearson(plus, n, tail)
    lm, um = clopper_pearson(minus, n, tail)
    return {'difference': (plus - minus) / n, 'lower': lp - um, 'upper': up - lm,
            'confidence_at_least': confidence, 'tail_each_marginal': tail,
            'method': 'paired_discordant_CP_union_bound', 'n_independent_tasks': n,
            'scope': 'IID paired binary task outcomes; one outcome per strategy per task; no repeated clusters'}
