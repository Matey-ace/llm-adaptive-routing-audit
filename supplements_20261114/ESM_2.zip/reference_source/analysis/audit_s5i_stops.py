"""Keep S5i raw immutable; derive executed replans from recorded steps."""
import json
from collections import Counter
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
groups = {}
for source in ('gsm8k','math'):
    rows = [json.loads(s) for s in (ROOT/f'results/raw/selected_stopper_{source}_20261014_s5i.jsonl').read_text(encoding='utf-8').splitlines()]
    assert len(rows) == 40
    differences = [{'task_id':r['task_id'],'raw_n_replans':r['n_replans'],
                    'executed_replan_steps':sum(s['kind']=='replan' for s in r['steps'])}
                   for r in rows if r['n_replans'] != sum(s['kind']=='replan' for s in r['steps'])]
    groups[source] = {'n':40,'stops':dict(Counter(r['stop_reason'] for r in rows)),
                      'failed_attempts':sum(len(r['failed_attempts']) for r in rows),
                      'actual_replan_steps':sum(s['kind']=='replan' for r in rows for s in r['steps']),
                      'blocked_replan_counter_differences':differences,
                      'unknown_final_ids':[r['task_id'] for r in rows if r['needs_review']]}
report = {'datasets':groups,'raw_unchanged':True,
          'scope':'Request-budget repair has no failed-attempt path to alter in these 80 records. Blocked replan counts are derived separately; do not claim raw attempted counters were completed replans.',
          'selection':'S2(.05,streak2) fixed before this full validation; no new parameter selection.'}
(ROOT/'results/aggregated/s5i_stop_audit_20261014.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
