"""Deterministic S4 diagnostics from Pilot raw logs; no model calls."""
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from runner.run_experiment import load_config, select_evaluation_tasks
from runner.scoring import score_final_answer
from complexity.rule_scorer import confusion_matrix
from tasks.loaders import load_tasks
from agents.base import parse_verdict, parse_confidence
from eval.metrics import SCORER_VERSION


def read_rows(path):
    return [json.loads(s) for s in path.read_text(encoding="utf-8").splitlines() if s.strip()]


def rate(n, d):
    return n / d if d else None


def reflect_transition(rows, tasks):
    counts = Counter()
    pending = []
    for row in rows:
        first = row.get("extra", {}).get("first_round_answer")
        if first is None:
            solves = [s for s in row["steps"] if s["kind"] == "solve"]
            first = solves[0]["response"] if solves else ""
        before = score_final_answer(tasks[row["task_id"]], first)
        if before["needs_review"] or row["needs_review"]:
            pending.append(row["task_id"])
            continue
        counts[(bool(before["success"]), bool(row["success"]))] += 1
    cc, cw = counts[(True, True)], counts[(True, False)]
    wc, ww = counts[(False, True)], counts[(False, False)]
    defined_n = cc + cw + wc + ww
    return {"reflection_tasks": len(rows), "scorable_n": defined_n,
            "correct_correct": cc, "correct_wrong": cw,
            "wrong_correct": wc, "wrong_wrong": ww,
            "flip_rate": rate(cw, cc + cw), "correction_rate": rate(wc, wc + ww),
            "flip_share_all_reflection_tasks": rate(cw, len(rows)),
            "correction_share_all_reflection_tasks": rate(wc, len(rows)),
            "net_correct_count_change": wc - cw, "needs_review_ids": pending}


def main():
    tasks = {}
    rows = []
    for source in ("gsm8k", "math"):
        cfg = load_config(ROOT / f"configs/exp/pilot_{source}.yaml")
        tasks.update({t.task_id: t for t in select_evaluation_tasks(load_tasks(cfg["tasks"]), cfg)})
        attempts = []
        if source == "gsm8k":
            attempts.extend(read_rows(ROOT / "results/raw/pilot_gsm8k_20261013_s3a.jsonl"))
        attempts.extend(read_rows(ROOT / f"results/raw/pilot_{source}_20261013_s3b.jsonl"))
        effective = {}
        for row in attempts:
            if row.get("error"):
                continue
            key = (row["task_id"], row["strategy"])
            assert key not in effective, "Successful task re-run unexpectedly"
            effective[key] = row
        rows.extend(effective.values())
    assert len(rows) == 400 and len(tasks) == 80
    assert len({(r["task_id"], r["strategy"], r["repeat_id"]) for r in rows}) == 400
    assert all(r.get("split") == "dev" for r in rows)
    if any(r["scorer_version"] != SCORER_VERSION for r in rows):
        raise ValueError("Historical scoring version differs; use analysis/rescore_pilot.py instead of mixing versions")
    judge_rows = read_rows(ROOT / "results/raw/pilot_judge_20261013_s3b.jsonl")
    assert len(judge_rows) == 80 and len({r["task_id"] for r in judge_rows}) == 80
    summary = {}
    cap_suspects = []
    for row in rows:
        usage = row.get("usage_records", [])
        if any(u["completion_tokens"] == 1024 for u in usage):
            cap_suspects.append({"task_id": row["task_id"], "strategy": row["strategy"]})
    audit = []
    for source in ("gsm8k", "math"):
        by_strategy = {}
        for strategy in ("direct", "planning", "plan_reflect", "adaptive", "vote_k"):
            group = [r for r in rows if r.get("source") == source and r["strategy"] == strategy]
            errors = [r for r in group if r.get("error")]
            reviews = [r for r in group if r.get("needs_review")]
            by_strategy[strategy] = {"n": len(group), "correct": sum(bool(r["success"]) for r in group),
                "needs_review": len(reviews), "errors": len(errors),
                "tokens": sum(r["meter_summary"]["total_tokens"] for r in group),
                "nominal_usd": sum(r["meter_summary"]["total_cost_usd"] for r in group),
                "uncached_successful_calls": sum(r["meter_summary"]["n_uncached_calls"] for r in group),
                "stops": dict(Counter(r.get("stop_reason") or "not_applicable" for r in group))}
            for r in group:
                if r["success"] and not r.get("error"):
                    continue
                audit.append({"task_id": r["task_id"], "strategy": strategy,
                    "reason": r.get("score_reason"), "answer": r["final_answer"], "error": r.get("error"),
                    "needs_review": r.get("needs_review"), "gold": tasks[r["task_id"]].gold})
        adaptive = [r for r in rows if r.get("source") == source and r["strategy"] == "adaptive"]
        js = [r for r in judge_rows if r["source"] == source]
        valid = [r for r in js if r["judge"].get("ok")]
        summary[source] = {"strategies": by_strategy,
            "route_methods": dict(Counter(r["extra"].get("route_method") for r in adaptive)),
            "selected_paths": dict(Counter(r["selected_path"] for r in adaptive)),
            "all_judge_valid_n": len(valid), "all_judge_failed_n": len(js) - len(valid),
            "all_judge_failed_by_anchor": dict(Counter(r["difficulty"] for r in js if not r["judge"].get("ok"))),
            "all_judge_confusion": confusion_matrix([r["difficulty"] for r in valid],
                                                      [r["judge"]["level"] for r in valid]),
            "adaptive_confusion": confusion_matrix([r["difficulty"] for r in adaptive],
                                                      [r["selected_level"] for r in adaptive])}
        order = {"easy": 0, "medium": 1, "hard": 2}
        low = [r for r in adaptive if order[r["selected_level"]] < order[r["difficulty"]]]
        summary[source]["underestimated_routing"] = {"n": len(low),
            "adaptive_correct": sum(r["success"] for r in low),
            "planning_correct_same_tasks": sum(r["success"] for r in rows
                if r["strategy"] == "planning" and r["task_id"] in {x["task_id"] for x in low})}
        refl_steps = [s for r in rows if r["source"] == source for s in r["steps"] if s["kind"] == "reflect"]
        summary[source]["reflection_format"] = {"reflect_steps": len(refl_steps),
            "malformed_verdict": sum(parse_verdict(s["response"]) == "MALFORMED" for s in refl_steps),
            "missing_confidence": sum(not parse_confidence(s["response"])[1] for s in refl_steps)}
    reflection = {}
    for strategy in ("plan_reflect", "adaptive"):
        reflection[strategy] = reflect_transition(
            [r for r in rows if r["strategy"] == strategy and r["n_reflections"] > 0], tasks)
    # Deterministic review list: disagreements and every reflection change.
    grouped = defaultdict(list)
    for r in rows:
        grouped[r["task_id"]].append(r)
    disagreement_ids = [tid for tid, group in grouped.items() if len({r["success"] for r in group}) > 1]
    calls = sum(r["meter_summary"]["n_calls"] for r in rows)
    cost = sum(r["meter_summary"]["total_cost_usd"] for r in rows)
    judge_cost = sum(r["meter_summary"]["total_cost_usd"] for r in judge_rows)
    prior_rows = read_rows(ROOT / "results/raw/pilot_gsm8k_20261013_s3a.jsonl")
    probe = json.loads((ROOT / "results/verify/s3_output_limit_probe_20261013.json").read_text(encoding="utf-8"))
    probe_usage = probe["response"]["usage"]
    probe_cost = probe_usage["prompt_tokens"] / 1e6 + probe_usage["completion_tokens"] * 4 / 1e6
    report = {"stage": "pilot_dev_not_independent_test", "strategy_records": len(rows),
              "task_n": len(tasks), "all_judge_records": len(judge_rows),
              "strategy_successful_calls": calls, "strategy_nominal_usd": cost,
              "strategy_uncached_successful_calls": sum(r["meter_summary"]["n_uncached_calls"] for r in rows),
              "independent_judge_nominal_usd": judge_cost,
              "historical_failed_task_records": sum(bool(r.get("error")) for r in prior_rows),
              "successful_records_with_retries": sum(bool(r.get("failed_attempts")) for r in rows),
              "recorded_retry_failures": sum(len(r.get("failed_attempts", [])) for r in rows),
              "output_probe_nominal_usd": probe_cost,
              "output_probe": {"task_id": probe["task_id"], "usage": probe_usage,
                               "finish_reason": probe["response"]["choices"][0]["finish_reason"]},
              "cost_note": "List-price estimate, not invoice; provider cached-input discounts and failed-attempt billing are not measured.",
              "datasets": summary, "reflection": reflection, "needs_review": audit,
              "output_cap_suspects": cap_suspects,
              "human_review_disagreement_ids": disagreement_ids,
              "limitations": ["k=3 is a fixed-count comparator, budget matching awaits S5/S6.",
                  "Seed accepted by endpoint; deterministic sampling is not established.",
                  "Adaptive reflection first answer recovered from saved solve step when extra is absent.",
                  "finish_reason is absent in strategy raw logs; output-cap suspects require inspection.",
                  "All-judge is a classification diagnostic, not a full all-judge solving ablation."]}
    dest = ROOT / "results/aggregated/pilot_diagnostics_20261013.json"
    dest.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = ["# S3–S4 Pilot 数据诊断", "", "仅为 dev 探索结果，正式 test 尚未运行。",
        "", "| 数据集 | 策略 | 自动判对/总样本 | 待复核 | token | 名义费用 USD |",
        "|---|---|---:|---:|---:|---:|"]
    for source, info in summary.items():
        for s, v in info["strategies"].items():
            lines.append(f"| {source} | {s} | {v['correct']}/{v['n']} | {v['needs_review']} | {v['tokens']} | {v['nominal_usd']:.6f} |")
    lines += ["", f"策略调用名义费用 ${cost:.6f}；独立 judge 诊断 ${judge_cost:.6f}。",
        "费用按端点单价估算，平台缓存折扣及失败调用账单未测量，人民币汇率仍为假设值。",
        "", "## 判定器、输出与停止诊断", "",
        "- 独立 judge 有效返回：GSM8K " + str(summary["gsm8k"]["all_judge_valid_n"]) +
        "/40，MATH " + str(summary["math"]["all_judge_valid_n"]) + "/40；解析失败单列，不把回退 medium 当作有效 judge 标签。",
        "- 灰区回退：GSM8K " + str(summary["gsm8k"]["route_methods"].get("rule_fallback", 0)) +
        " 条，MATH " + str(summary["math"]["route_methods"].get("rule_fallback", 0)) + " 条。",
        "- 新版逐调用日志中有 " + str(len(cap_suspects)) + " 条策略记录出现单次输出 1024 token；旧记录缺少逐调用明细，此数并非完整截断计数。",
        "- MATH 反思步骤中 VERDICT/CONFIDENCE 缺失各 " + str(summary["math"]["reflection_format"]["malformed_verdict"]) + " 次。",
        "- 首轮 11 条调用失败保留；后续 3 条成功记录包含 4 次失败重试。费用估算不包含未返回用量的失败及中断请求。",
        "- 额外单题复测名义费用 $" + f"{probe_cost:.6f}" + "，仅作诊断，不替换原结果。",
        "", "## 反思前首轮求解到最终答案转移", "",
        "null 表示分母为零而未定义。待复核条目不参与已判定转移计数，另列 ID。"]
    for strategy, info in reflection.items():
        lines.append(f"- {strategy}：{json.dumps(info, ensure_ascii=False)}")
    lines += ["", "## 人工复核入口", "", f"自动未判对或异常记录：{len(audit)}，需逐条核查评分争议。",
        "策略判对结果存在差异的任务 ID（逐条核对原始输出）：", "", ", ".join(disagreement_ids),
        "", "## 后续", "", "依据混淆矩阵、反思转移与费用诊断开展 S5 有限选择。",
        "k=3 尚非同预算匹配；全 judge 仅为分类诊断，解题消融在 D 阶段。",
        "判定矩阵、路由覆盖、停止分布和完整复核条目见同名 JSON。"]
    (ROOT / "paper/Pilot诊断_20261013.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("strategy_records", "task_n", "all_judge_records",
        "strategy_successful_calls", "strategy_nominal_usd", "independent_judge_nominal_usd")}, indent=2))


if __name__ == "__main__":
    main()
