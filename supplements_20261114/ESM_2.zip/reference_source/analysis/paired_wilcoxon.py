"""Secondary task-level signed-rank report, not the quality NI test.

Policy fixed before test: difference A-B rounded to nine decimal places;
drop exact zeros, two-sided asymptotic p-value, no continuity correction.
IID symmetric-difference assumptions must be stated. Sign effect is a
separate direction statistic, not an independent-samples Cliff's delta.
"""
import math
from collections import defaultdict


def signed_rank(pairs, getter):
    from scipy import __version__ as scipy_version
    from scipy.stats import wilcoxon
    pairs = list(pairs)
    if not pairs or len({a.get('source') for a, _ in pairs}) != 1:
        raise ValueError('Require nonempty pairs from one benchmark')
    groups = defaultdict(list)
    seen = set()
    for a, b in pairs:
        key = (a['task_id'], a.get('repeat_id', 0))
        if key != (b['task_id'], b.get('repeat_id', 0)) or key in seen or a.get('source') != b.get('source'):
            raise ValueError('Unpaired/duplicate task repeat')
        seen.add(key)
        x, y = getter(a), getter(b)
        if x is None or y is None or not math.isfinite(x) or not math.isfinite(y):
            return {'available': False, 'reason': 'Missing/nonfinite paired cost; no zero imputation'}
        groups[a['task_id']].append(x-y)
    differences = [round(sum(v)/len(v), 9) for v in groups.values()]
    nonzero = sum(d != 0 for d in differences)
    output = {'available': True, 'n_tasks': len(groups), 'n_runs': len(seen), 'nonzero_tasks': nonzero,
              'zero_method': 'wilcox', 'alternative': 'two-sided', 'method': 'asymptotic',
              'continuity_correction': False, 'difference_round_decimals': 9, 'scipy_version': scipy_version,
              'paired_sign_effect': (sum(d > 0 for d in differences)-sum(d < 0 for d in differences))/len(groups),
              'scope': 'Secondary descriptive test; IID symmetric task differences assumed; repeats averaged within task; no quality NI claim'}
    if not nonzero:
        output.update(statistic=0., pvalue=None, degenerate_all_zero=True)
    else:
        result = wilcoxon(differences, zero_method='wilcox', correction=False,
                          alternative='two-sided', method='asymptotic', nan_policy='raise')
        output.update(statistic=float(result.statistic), pvalue=float(result.pvalue), degenerate_all_zero=False)
    return output
