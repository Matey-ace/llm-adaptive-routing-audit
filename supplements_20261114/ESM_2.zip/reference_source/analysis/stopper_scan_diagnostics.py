"""Summarize all predeclared stopper arms and apply the saved selection rule."""
import json
import argparse
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN_ID = 'pilot_stopper_scan_20261014_s5f'
parser = argparse.ArgumentParser()
parser.add_argument('--run-id', default=RUN_ID)
args = parser.parse_args()
RUN_ID = args.run_id
if not RUN_ID.replace('_', '').isalnum():
    raise ValueError('Invalid run-id')
suffix = '' if RUN_ID == 'pilot_stopper_scan_20261014_s5f' else '_' + RUN_ID.rsplit('_', 1)[-1]
plan = json.loads((ROOT / f'results/raw/{RUN_ID}.plan.json').read_text(encoding='utf-8'))
rows = [json.loads(line) for line in (ROOT / f'results/raw/{RUN_ID}.jsonl').read_text(encoding='utf-8').splitlines()]
expected = {(c['id'], m['task_id']) for c in plan['candidates'] for m in plan['members']}
assert len(rows) == 60 and {(r['candidate'], r['task_id']) for r in rows} == expected, 'Wait for complete 60-combination run'
assert all(r['split'] == 'dev' and r['strategy'] == 'plan_reflect' for r in rows)
groups = {}
for candidate in plan['candidates']:
    name = candidate['id']
    g = [r for r in rows if r['candidate'] == name]
    assert all(r['meter_summary']['n_calls'] <= 8 for r in g)
    assert all(not a['cached'] for r in g for a in r.get('call_audit', []))
    groups[name] = {'n': len(g), 'correct_lower': sum(r['success'] for r in g),
                   'uncertain_nonempty': sum(r['needs_review'] and bool(r['final_answer'].strip()) for r in g),
                   'empty_failures': sum(not r['final_answer'].strip() for r in g),
                   'execution_errors': sum(bool(r.get('error')) for r in g),
                   'nominal_usd': sum(r['meter_summary']['total_cost_usd'] for r in g),
                   'calls': sum(r['meter_summary']['n_calls'] for r in g),
                   'stops': dict(Counter(r.get('stop_reason') for r in g)),
                   'datasets': {s: {'n': sum(r['source'] == s for r in g),
                                     'correct': sum(r['success'] for r in g if r['source'] == s)}
                                for s in ('gsm8k', 'math')}}
reference = groups[plan['reference']]
upper = reference['correct_lower'] + reference['uncertain_nonempty']
for name, g in groups.items():
    g['eligible'] = not g['execution_errors'] and (name == plan['reference'] or g['correct_lower'] >= upper - .03 * g['n'])
eligible = [c['id'] for c in plan['candidates'] if groups[c['id']]['eligible']]
selected = min(eligible, key=lambda name: groups[name]['nominal_usd']) if eligible else None
report = {'stage': 'S5_finite_dev_choice_not_independent_test', 'groups': groups,
          'selected_candidate': selected, 'plan_reference': plan['reference'],
          'selection_rule_applied_without_test': True,
          'limitations': ['12 balanced exploratory dev tasks; no noninferiority/benefit claim.',
                         'Fresh calls are stochastic; no deterministic paired replay claim.',
                         'Shared budget is logical calls; failed physical retries are separately logged.',
                         'Empty/failed outputs included, nonempty parser reviews treated as uncertain.',
                         'A selected stopper still needs full chosen-router validation before final S6 freeze.']}
(ROOT / f'results/aggregated/stopper_scan_diagnostics_20261014{suffix}.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
lines = ['# 有限停止工作点比较', '', '仅12道预先分层选定dev题，每候选新调用；不是独立test或非劣效证据。', '',
         '| 候选 | 自动确认正确下界 | 非空解析争议 | 空/失败 | 逻辑调用 | 标价估算USD | 满足预定选择条件 |',
         '|---|---:|---:|---:|---:|---:|---|']
for name, g in groups.items():
    lines.append(f"| {name} | {g['correct_lower']}/{g['n']} | {g['uncertain_nonempty']} | {g['empty_failures']} | {g['calls']} | {g['nominal_usd']:.6f} | {g['eligible']} |")
lines += ['', f'按调用前保存规则选出的候选：{selected}。',
          '选择以S1上限2为参考，非空解析争议进入参考质量上界；空输出按作者要求计失败。其他候选确认正确下界满足参考上界减3个百分点后，取费用最小者。',
          '小样本离散性、服务端随机性和分层样本构成影响选择；不能把开发集选择解释成总体质量保持或最优停止机制。完整停止分布与分数据集结果见JSON。']
(ROOT / f'paper/停止工作点有限比较_20261014{suffix}.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
