"""Post-test paired sensitivity analyses; never imports a collector or alters inputs."""
from pathlib import Path
from functools import lru_cache
from collections import defaultdict, Counter
import hashlib
import json
import math
import platform
import sys
import numpy as np
import scipy
from scipy.stats import beta, binomtest
from statistics import NormalDist

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/verify/sncs_p0_20261020'
CASES=['formal_gsm8k_primary_20261014','formal_math_primary_20261014',
       'formal_gsm8k_qwen_20261014','formal_math_qwen_20261014']


def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')


def wilson(k,n):
    p=np.asarray(k)/n;z=NormalDist().inv_cdf(.975);den=1+z*z/n
    center=(p+z*z/(2*n))/den
    radius=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return center-radius,center+radius


def newcombe10(e,f,g,h):
    e,f,g,h=[np.asarray(v,dtype=float) for v in [e,f,g,h]]
    n=e+f+g+h
    if np.any(n<=0):raise ValueError('nonempty table required')
    pa,pb=(e+f)/n,(e+g)/n
    la,ua=wilson(e+f,n);lb,ub=wilson(e+g,n)
    numerator=e*h-f*g
    numerator=np.where(numerator>0,np.maximum(numerator-n/2,0),numerator)
    denominator=np.sqrt((e+f)*(g+h)*(e+g)*(f+h))
    corr=np.divide(numerator,denominator,out=np.zeros_like(numerator),where=denominator>0)
    lo=pa-pb-np.sqrt(np.maximum(0,(pa-la)**2+(ub-pb)**2-2*corr*(pa-la)*(ub-pb)))
    hi=pa-pb+np.sqrt(np.maximum(0,(ua-pa)**2+(pb-lb)**2-2*corr*(ua-pa)*(pb-lb)))
    return lo,hi


@lru_cache(maxsize=64)
def cp_lookup(n,H):
    tail=.05/(4*H);k=np.arange(n+1)
    low=np.zeros(n+1);high=np.ones(n+1)
    low[1:]=beta.ppf(tail,k[1:],n-k[1:]+1)
    high[:-1]=beta.ppf(1-tail,k[:-1]+1,n-k[:-1])
    return low,high


def outcome(r):
    if r['error'] or not r['answer'].strip():return 0
    if r['needs_review'] or r['success'] is None:return None
    return int(bool(r['success']))


def counts(pairs,policy):
    table=Counter()
    for a,b in pairs:
        x,y=outcome(a),outcome(b)
        if policy=='known' and (x is None or y is None):continue
        if policy=='low':x,y=0 if x is None else x,1 if y is None else y
        else:x,y=0 if x is None else x,0 if y is None else y
        table[(x,y)]+=1
    return [table[(1,1)],table[(1,0)],table[(0,1)],table[(0,0)]]


def cp_envelope(pairs):
    by=defaultdict(list)
    for a,b in pairs:by[a['difficulty']].append((a,b))
    n=len(pairs)
    if n==0:return None
    low=high=pl=pu=0.
    for sub in by.values():
        ns=len(sub);lower,upper=cp_lookup(ns,len(by));poslo=neglo=poshi=neghi=0
        for a,b in sub:
            x,y=outcome(a),outcome(b)
            xl,yl=0 if x is None else x,1 if y is None else y
            xh,yh=1 if x is None else x,0 if y is None else y
            poslo+=xl>yl;neglo+=xl<yl;poshi+=xh>yh;neghi+=xh<yh
        low+=ns/n*(lower[poslo]-upper[neglo]);high+=ns/n*(upper[poshi]-lower[neghi])
        pl+=(poslo-neglo)/n;pu+=(poshi-neghi)/n
    return {'n':n,'difference_bounds':[pl,pu],'confidence_interval':[float(low),float(high)],
            'lower_gt_minus_003':bool(low>-.03),'unknown_pairs':sum(outcome(a) is None or outcome(b) is None for a,b in pairs),
            'strata':{k:len(v) for k,v in by.items()}}


def score_summary(pairs,policy):
    e,f,g,h=counts(pairs,policy);n=e+f+g+h
    if not n:return {'n':0}
    lo,hi=newcombe10(e,f,g,h)
    return {'n':n,'table':{'both_correct':e,'a_only':f,'b_only':g,'neither_correct':h},
            'difference':(f-g)/n,'newcombe10_95':[float(lo),float(hi)],
            'post_test_lower_gt_minus_003':bool(lo>-.03),
            'mcnemar_exact_zero_difference_p':float(binomtest(f,f+g,.5).pvalue) if f+g else 1.}


def validate_method():
    # Original article Table III, method 10; e,f,g,h notation as printed.
    examples=[([36,12,2,0],[.0569,.3404]),([20,12,2,16],[.0562,.3292]),
              ([35,14,0,1],[.1461,.4175]),([2,98,0,0],[.9178,.9945]),
              ([27,0,0,27],[-.0351,.0351]),([54,0,0,0],[-.0664,.0664])]
    checks=[]
    for table,expected in examples:
        actual=[float(x) for x in newcombe10(*table)]
        assert max(abs(a-b) for a,b in zip(actual,expected))<.000051,(table,actual,expected)
        flipped=newcombe10(table[0],table[2],table[1],table[3])
        assert np.allclose(flipped,[-actual[1],-actual[0]],atol=1e-12)
        checks.append({'counts':table,'published_4dp':expected,'computed':actual})
    # Check boundaries, negative association, and positive/negative differences.
    for t in [[0,0,0,20],[20,0,0,0],[0,20,0,0],[0,0,20,0],[0,4,5,0]]:
        lo,hi=newcombe10(*t);assert -1-1e-12<=lo<=hi<=1+1e-12
    return checks


def load_primary():
    idxpath=ROOT/'results/verify/service_lineage_closure_20261019/record_to_execution_setting.json'
    ledgerpath=ROOT/'results/verify/author_adjudication_20261019/overlay_ledger.json'
    index=read(idxpath)
    selected=[r for r in index if r['run_id'] in CASES and r['strategy'] in ['adaptive','plan_reflect']]
    assert len(selected)==8000
    want=defaultdict(dict)
    for r in selected:
        assert r['line'] not in want[r['path']]
        want[r['path']][r['line']]=r
    inputs={str(p.relative_to(ROOT)):sha(p) for p in [idxpath,ledgerpath,ROOT/'analysis/paired_summary.py',ROOT/'analysis/paired_exact_interval.py']}
    rows=[]
    for path,locs in want.items():
        p=ROOT/path;p.resolve().relative_to(ROOT.resolve());inputs[path]=sha(p)
        with p.open(encoding='utf-8-sig') as stream:
            for line_no,line in enumerate(stream,1):
                if line_no not in locs:continue
                raw=json.loads(line);meta=locs[line_no]
                assert (raw['task_id'],raw['strategy'],str(raw['repeat_id']))==(meta['task_id'],meta['strategy'],str(meta['repeat_id']))
                row={k:meta[k] for k in ['run_id','task_id','strategy','repeat_id','setting_id']}
                row.update({'difficulty':raw['difficulty'],'source':raw['source'],'answer':str(raw.get('final_answer','')),
                            'success':raw.get('success'),'needs_review':bool(raw.get('needs_review')),'error':bool(raw.get('error'))})
                row['frozen_outcome']=outcome(row);row['adjudicated_outcome']=row['frozen_outcome'];rows.append(row)
    assert len(rows)==8000
    overlays={(r['run_id'],r['strategy'],r['task_id'],str(r['repeat_id']),r['answer_sha256']):r for r in read(ledgerpath)['entries']}
    for r in rows:
        key=(r['run_id'],r['strategy'],r['task_id'],str(r['repeat_id']),hashlib.sha256(r['answer'].encode()).hexdigest())
        if key in overlays:
            entry=overlays[key];assert r['frozen_outcome']==entry['frozen_outcome']
            r['adjudicated_outcome']=entry['author_outcome']
    return rows,inputs


def observed(rows):
    result=[]
    for rid in CASES:
        groups=defaultdict(dict)
        for r in rows:
            if r['run_id']==rid:groups[(r['task_id'],str(r['repeat_id']))][r['strategy']]=r
        assert len(groups)==1000 and all(set(v)=={'adaptive','plan_reflect'} for v in groups.values())
        reference=read(ROOT/f'results/author_adjudicated_20261019/{rid}.json')
        for scoring in ['frozen','adjudicated']:
            pairs=[]
            for arms in groups.values():
                ab=[]
                for key in ['adaptive','plan_reflect']:
                    r=dict(arms[key]);v=r[f'{scoring}_outcome'];r['success']=v;r['needs_review']=v is None;ab.append(r)
                pairs.append(tuple(ab))
            full=cp_envelope(pairs)
            archived=reference['original_quality' if scoring=='frozen' else 'quality']
            assert np.allclose(full['difference_bounds'],archived['difference_bounds'],atol=1e-12)
            assert np.allclose(full['confidence_interval'],archived['confidence_interval'],atol=1e-10)
            assert full['unknown_pairs']==archived['uncertain_pairs']
            completed=[(a,b) for a,b in pairs if not a['error'] and not b['error'] and a['answer'].strip() and b['answer'].strip()]
            zeros=[]
            for a,b in pairs:
                aa,bb=dict(a),dict(b)
                for z in [aa,bb]:
                    z['success']=0 if outcome(z) is None else outcome(z);z['needs_review']=False
                zeros.append((aa,bb))
            result.append({'run_id':rid,'scoring':scoring,'primary_reproduced':full,
                           'full_unknown_zero_cp':cp_envelope(zeros),
                           'full_unknown_zero_score':score_summary(pairs,'zero'),
                           'known_labels_score':score_summary(pairs,'known'),
                           'complete_execution_cp':cp_envelope(completed),
                           'complete_execution_known_score':score_summary(completed,'known'),
                           'complete_execution_excluded_pairs':1000-len(completed)})
    return result


def simulations():
    rng=np.random.default_rng(20261020);draws=5000;results=[]
    for dataset,ns in [('gsm8k',[354,480,166]),('math',[259,218,523])]:
        for q in [.05,.10,.20]:
            for delta in [0.,-.03]:
                pa,pb=.8+delta,.8
                truth=[(pa+pb-q)/2,(q+delta)/2,(q-delta)/2,1-(pa+pb+q)/2]
                assert min(truth)>=0 and abs(sum(truth)-1)<1e-12
                for u in [0.,.02,.05]:
                    masks=[(1-u)**2,u*(1-u),u*(1-u),u*u]
                    prob=np.outer(truth,masks).ravel()
                    lower=np.zeros(draws);upper=np.zeros(draws)
                    pooled=np.zeros((draws,16),dtype=int)
                    lowplus=[];lowminus=[];highplus=[];highminus=[]
                    for a,b in [(1,1),(1,0),(0,1),(0,0)]:
                        for ma,mb in [(False,False),(True,False),(False,True),(True,True)]:
                            al,bl=0 if ma else a,1 if mb else b
                            ah,bh=1 if ma else a,0 if mb else b
                            lowplus.append(al>bl);lowminus.append(al<bl);highplus.append(ah>bh);highminus.append(ah<bh)
                    for n in ns:
                        sample=rng.multinomial(n,prob,size=draws);pooled+=sample
                        l,h=cp_lookup(n,3)
                        lower+=n/1000*(l[sample[:,lowplus].sum(axis=1)]-h[sample[:,lowminus].sum(axis=1)])
                        upper+=n/1000*(h[sample[:,highplus].sum(axis=1)]-l[sample[:,highminus].sum(axis=1)])
                    l,h=cp_lookup(1000,1)
                    unlo=l[pooled[:,lowplus].sum(axis=1)]-h[pooled[:,lowminus].sum(axis=1)]
                    unhi=h[pooled[:,highplus].sum(axis=1)]-l[pooled[:,highminus].sum(axis=1)]
                    oracle=pooled.reshape(draws,4,4).sum(axis=2)
                    nlo,nhi=newcombe10(*oracle.T)
                    for method,lo,hi in [('frozen_stratified_cp',lower,upper),('unstratified_cp',unlo,unhi),('oracle_complete_label_newcombe10',nlo,nhi)]:
                        reject=int((lo>-.03).sum());mc=wilson(reject,draws)
                        results.append({'dataset':dataset,'n':1000,'reference_accuracy':pb,'latent_difference':delta,
                                        'discordance_probability':q,'unknown_probability_per_arm':u,'draws':draws,'method':method,
                                        'lower_gt_minus_003_frequency':reject/draws,'monte_carlo_wilson95':[float(x) for x in mc],
                                        'mean_interval_width':float(np.mean(hi-lo)),'coverage_frequency':float(np.mean((lo<=delta)&(hi>=delta)))})
    return results


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    checks=validate_method();dump(OUT/'method_validation.json',{'source':'Newcombe 1998 Table III, method 10','published_examples':checks})
    rows,inputs=load_primary();dump(OUT/'primary_minimal_rows_internal.json',rows)
    results=observed(rows);dump(OUT/'paired_sensitivity.json',results)
    sim=simulations();dump(OUT/'design_simulation.json',{'seed':20261020,'analysis_role':'hypothetical design sensitivity, not observed power','scenarios':sim})
    assert all(sha(ROOT/p)==expected for p,expected in inputs.items())
    dump(OUT/'statistics_validation.json',{'input_sha256':inputs,'original_primary_comparisons_reproduced':8,
        'primary_rows':8000,'paired_population_per_comparison':1000,'published_method_examples_checked':6,
        'simulation_conditions':36,'simulation_method_rows':108,'draws_per_condition':5000,
        'runtime':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,
        'new_model_calls':0,'new_human_ratings':0,'frozen_inputs_unchanged':True})
    print(json.dumps([{k:r[k] for k in ['run_id','scoring','complete_execution_excluded_pairs','full_unknown_zero_score','known_labels_score','complete_execution_cp']} for r in results],ensure_ascii=True,indent=2))


if __name__=='__main__':main()
