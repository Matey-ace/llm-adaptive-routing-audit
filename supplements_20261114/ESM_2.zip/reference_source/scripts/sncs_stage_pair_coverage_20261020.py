"""Post-test descriptive coverage; reads archived lineage indexes only."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'results/verify/service_lineage_closure_20261019'
OUT = ROOT / 'results/verify/sncs_stage_pair_coverage_20261020'


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    inputs = [BASE / 'record_to_execution_setting.json', BASE / 'execution_settings.json']
    hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
    settings = {r['setting_id']: r for r in load(inputs[1])}
    groups = defaultdict(lambda: defaultdict(dict))
    for row in load(inputs[0]):
        rid = row['run_id']
        if rid not in {f'formal_{d}_{k}_20261014' for d in ['gsm8k', 'math'] for k in ['primary', 'qwen']}:
            continue
        if row['strategy'] not in ['adaptive', 'plan_reflect']:
            continue
        key = (row['task_id'], str(row['repeat_id']))
        assert row['strategy'] not in groups[rid][key], (rid, key)
        assert row['setting_id'] in settings
        groups[rid][key][row['strategy']] = row['setting_id']
    report = []
    for rid, pairs in sorted(groups.items()):
        counts = Counter()
        same_setting = 0
        for key, arms in pairs.items():
            assert set(arms) == {'adaptive', 'plan_reflect'}, (rid, key)
            a, b = settings[arms['adaptive']], settings[arms['plan_reflect']]
            sa, sb = (a['provider'], a['epoch']), (b['provider'], b['epoch'])
            assert a['model'] == b['model']
            counts[(sa, sb)] += 1
            same_setting += arms['adaptive'] == arms['plan_reflect']
        assert len(pairs) == 1000
        report.append({'run_id': rid, 'model': a['model'], 'pairs': len(pairs),
                       'same_provider_epoch': sum(n for (a, b), n in counts.items() if a == b),
                       'same_execution_setting': same_setting,
                       'stage_cross_counts': [{'adaptive': list(a), 'plan_reflect': list(b), 'n': n}
                                              for (a, b), n in sorted(counts.items())]})
    assert len(report) == 4
    assert hashes == {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'coverage.json').write_text(json.dumps({'analysis_role': 'post-test descriptive coverage',
        'inputs_sha256': hashes, 'comparisons': report}, ensure_ascii=False, indent=2), encoding='utf-8')
    lines = ['# SNCS主比较服务阶段配对覆盖', '', '日期：2026-10-20。测试后描述性分析，原主比较和统计判据保留。', '',
             '| 主比较批次 | 配对N | 相同provider/epoch | 相同执行签名 |', '| --- | --- | --- | --- |']
    for r in report:
        lines.append(f"| {r['run_id']} | {r['pairs']} | {r['same_provider_epoch']} | {r['same_execution_setting']} |")
    lines += ['', '相同阶段或执行签名不等于同一时刻、相同上游权重或服务状态。全部配对数保持1000；完整阶段交叉表与输入哈希见results/verify/sncs_stage_pair_coverage_20261020/coverage.json。', '',
              '该检查只衡量已记录执行条件的匹配覆盖，不计算质量效应；没有删除跨阶段配对或替换冻结主总体。']
    (ROOT / 'paper/SNCS主比较阶段配对覆盖_20261020.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
