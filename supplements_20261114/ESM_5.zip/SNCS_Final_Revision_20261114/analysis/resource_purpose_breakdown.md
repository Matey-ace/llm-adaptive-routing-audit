# Complete purpose-level resource accounting

All rows are sums over recorded response events; no reasoning-token double counting.

| Dataset | Arm | Purpose | Requests | Prompt tokens | Completion tokens | Total tokens |
| --- | --- | --- | --- | --- | --- | --- |
| GSM8K | Adaptive | judge | 166 | 96866 | 59952 | 156818 |
| GSM8K | Adaptive | plan | 169 | 42634 | 31080 | 73714 |
| GSM8K | Adaptive | reflect | 53 | 21242 | 22188 | 43430 |
| GSM8K | Adaptive | solve | 200 | 62883 | 18245 | 81128 |
| GSM8K | ASC-Beta-8 | baseline_solve | 939 | 223995 | 155182 | 379177 |
| GSM8K | Direct | solve | 200 | 47734 | 26452 | 74186 |
| GSM8K | Plan+Reflect | plan | 200 | 49534 | 38966 | 88500 |
| GSM8K | Plan+Reflect | reflect | 200 | 74234 | 63308 | 137542 |
| GSM8K | Plan+Reflect | solve | 200 | 65098 | 18844 | 83942 |
| GSM8K | Planning | plan | 200 | 49534 | 35414 | 84948 |
| GSM8K | Planning | solve | 200 | 64916 | 20961 | 85877 |
| MATH | Adaptive | judge | 111 | 63101 | 52582 | 115683 |
| MATH | Adaptive | plan | 140 | 38980 | 37970 | 76950 |
| MATH | Adaptive | reflect | 78 | 37342 | 74765 | 112107 |
| MATH | Adaptive | replan | 1 | 500 | 435 | 935 |
| MATH | Adaptive | solve | 201 | 65421 | 77608 | 143029 |
| MATH | ASC-Beta-8 | baseline_solve | 855 | 215658 | 491667 | 707325 |
| MATH | Direct | solve | 200 | 49761 | 90599 | 140360 |
| MATH | Plan+Reflect | plan | 200 | 51561 | 50442 | 102003 |
| MATH | Plan+Reflect | reflect | 206 | 83998 | 111414 | 195412 |
| MATH | Plan+Reflect | replan | 6 | 3380 | 3164 | 6544 |
| MATH | Plan+Reflect | solve | 206 | 74252 | 88707 | 162959 |
| MATH | Planning | plan | 200 | 51561 | 46631 | 98192 |
| MATH | Planning | solve | 200 | 69588 | 77542 | 147130 |
