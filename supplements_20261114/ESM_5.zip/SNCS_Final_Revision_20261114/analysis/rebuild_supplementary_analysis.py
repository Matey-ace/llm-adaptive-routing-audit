"""Independent, read-only reanalysis; writes only beside this script.

Run: python rebuild_supplementary_analysis.py
Requires numpy/scipy. No experiment package import, network, or model call.
Original results and returned human decisions are never modified.
"""
from pathlib import Path
from collections import Counter, defaultdict
from hashlib import sha256
from datetime import datetime, timezone
import json, os, socket, zipfile
import numpy as np
import scipy
from scipy.stats import beta, binomtest

HERE = Path(__file__).resolve().parent
WORK = HERE.parent.parent
ORIGINAL = WORK / 'SNCS_FiveArm_Runner_20261111'
RUN = ORIGINAL / 'runs/selfhosted_main_conc_20261113'
PREP = WORK / 'SNCS_Experiment_Preparation_20261110'
ARMS = ['direct','planning','plan_reflect','adaptive_legacy','asc_beta_8']
SOURCES = ['gsm8k','math']
EXCLUDED3 = ['new_gsm8k_main_test_row_01035','new_gsm8k_main_test_row_01042','new_gsm8k_main_test_row_00649']
EXCLUDED4 = EXCLUDED3 + ['new_gsm8k_main_test_row_00100']
EXCLUDED5 = EXCLUDED4 + ['new_gsm8k_main_test_row_00675']

def no_network(*a, **kw): raise RuntimeError('Offline analysis: network disabled')
socket.create_connection = no_network

def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def jsonl(p): return [json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s.strip()]
def write(name, obj):
    p = HERE / name
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def digest(p): return sha256(p.read_bytes()).hexdigest()

def paired(pairs):
    n = len(pairs)
    b = sum(a and not z for a,z in pairs)
    c = sum(z and not a for a,z in pairs)
    a = sum(x and z for x,z in pairs)
    d = n-a-b-c
    tail = .05/4
    lo = lambda k: 0. if k == 0 else float(beta.ppf(tail,k,n-k+1))
    hi = lambda k: 1. if k == n else float(beta.ppf(1-tail,k+1,n-k))
    return {'n':n,'both_correct':a,'a_only_correct_b':b,'b_only_correct_c':c,'both_incorrect':d,
            'difference':(b-c)/n,'lower':lo(b)-hi(c),'upper':hi(b)-lo(c),
            'exact_mcnemar_p':float(binomtest(min(b,c),b+c,.5).pvalue) if b+c else 1.}

def main():
    input_paths = [RUN/'results.jsonl',RUN/'journal.jsonl',RUN/'scores_v1.jsonl',
        RUN/'review/human_scores_score_sheet.jsonl', RUN/'review/human_scores_score_sheet_contextual_math.jsonl',
        PREP/'draft/main_five_arm_queue_2000.jsonl',PREP/'draft/generation_prompt_only_420.jsonl',
        ORIGINAL/'evidence/seal_snapshot.json',ORIGINAL/'evidence/seal_snapshot_v2.json']
    before = {str(p):digest(p) for p in input_paths}
    rows = jsonl(input_paths[0]); events = jsonl(input_paths[1]); metadata = events[0]
    lookup = {r['run_id']:r for r in rows}
    assert len(lookup)==len(rows)==2000
    queue = jsonl(input_paths[5])
    assert set(lookup)=={q['run_id'] for q in queue}
    responses = [e for e in events if e['event']=='response_received']
    intents = [e for e in events if e['event']=='dispatch_intent_durable']
    settlements = [e for e in events if e['event']=='usage_settled']
    assert len(responses)==len(intents)==len(settlements)==5331
    assert len({e['request_id'] for e in responses})==5331
    scored = {}
    for name,p in zip(['automatic','human_strict','human_contextual'],input_paths[2:5]):
        rr = jsonl(p)
        scored[name] = {(r['task_id'],r['strategy']):(r.get('score') or r)['decision'] for r in rr}
        assert len(scored[name])==2000
    by_task = {s:sorted({r['task_id'] for r in rows if r['source']==s}) for s in SOURCES}
    assert all(len(v)==200 for v in by_task.values())
    main_stats = {}; sensitivity = {}
    arm_table = []
    for scoring,lk in scored.items():
        main_stats[scoring] = {'global_counts':dict(Counter(lk.values())),'primary':{}}
        sensitivity[scoring] = {}
        for source,tids in by_task.items():
            pairs = [(lk[t,'adaptive_legacy']=='correct',lk[t,'plan_reflect']=='correct')
                     for t in tids if lk[t,'adaptive_legacy']!='unknown' and lk[t,'plan_reflect']!='unknown']
            main_stats[scoring]['primary'][source] = paired(pairs)|{'planned_n':len(tids),'omitted_pairs':len(tids)-len(pairs)}
            for arm in ARMS:
                c = Counter(lk[t,arm] for t in tids)
                arm_table.append({'source':source,'arm':arm,'scoring':scoring,'planned_n':len(tids),
                    'correct':c['correct'],'incorrect':c['incorrect'],'unknown':c['unknown'],
                    'correct_over_planned':c['correct']/len(tids),
                    'accuracy_known':c['correct']/(c['correct']+c['incorrect'])})
            if source=='gsm8k':
                for title,excluded in [('exclude_original_three',EXCLUDED3),('exclude_four',EXCLUDED4),('exclude_five',EXCLUDED5)]:
                    kept = [t for t in tids if t not in excluded]
                    pp = [(lk[t,'adaptive_legacy']=='correct',lk[t,'plan_reflect']=='correct') for t in kept
                          if lk[t,'adaptive_legacy']!='unknown' and lk[t,'plan_reflect']!='unknown']
                    sensitivity[scoring][title] = paired(pp)|{'planned_n':len(kept),'excluded':excluded,'post_hoc':True}
            if source=='math':
                # Sensitivity only. Preserves original unknown decisions in main analysis.
                empty_ids = {r['task_id'] for r in rows if not r['outcome']['final_answer'].strip()}
                pp = [(lk[t,'adaptive_legacy']=='correct',lk[t,'plan_reflect']=='correct') for t in tids
                      if all(lk[t,arm]!='unknown' or (t in empty_ids and not next(r['outcome']['final_answer'].strip()
                          for r in rows if r['task_id']==t and r['strategy']==arm))
                          for arm in ['adaptive_legacy','plan_reflect'])]
                sensitivity[scoring]['empty_final_as_incorrect_full_math_200'] = paired(pp)|{
                    'planned_n':200,'post_hoc':True,'policy':'Only empty final answer is assigned 0; other unknowns remain omitted; no returned human label changed.'}
    resource = []
    trajectory = {rid:{'calls':0,'prompt_tokens':0,'completion_tokens':0,'total_tokens':0} for rid in lookup}
    for e in responses:
        d = trajectory[e['run_id']]
        d['calls']+=1;d['prompt_tokens']+=e['prompt_tokens'];d['completion_tokens']+=e['completion_tokens']
        d['total_tokens']+=e['prompt_tokens']+e['completion_tokens']
    purpose = defaultdict(lambda:{'calls':0,'prompt_tokens':0,'completion_tokens':0,'total_tokens':0})
    for e in responses:
        r = lookup[e['run_id']]; d = purpose[(r['source'],r['strategy'],e['purpose'])]
        d['calls']+=1;d['prompt_tokens']+=e['prompt_tokens'];d['completion_tokens']+=e['completion_tokens']
        d['total_tokens']+=e['prompt_tokens']+e['completion_tokens']
    for source in SOURCES:
        for arm in ARMS:
            group = [trajectory[r['run_id']] for r in rows if r['source']==source and r['strategy']==arm]
            totals = {k:sum(d[k] for d in group) for k in group[0]}
            resource.append({'source':source,'arm':arm,'n':len(group),'total':totals,
                             'mean_per_question':{k:v/len(group) for k,v in totals.items()}})
    # Whole-question resampling retains within-question method pairing.
    # This resource interval realization is exploratory, not a quality decision rule.
    resource_pairs = {}
    for source,tids in by_task.items():
        rng = np.random.default_rng(20261111)
        draws = rng.integers(0,len(tids),size=(2000,len(tids)))
        resource_pairs[source] = {}
        bykey = {(r['task_id'],r['strategy']):trajectory[r['run_id']] for r in rows}
        for metric in ['calls','prompt_tokens','completion_tokens','total_tokens']:
            x = np.array([bykey[t,'adaptive_legacy'][metric] for t in tids],dtype=float)
            y = np.array([bykey[t,'plan_reflect'][metric] for t in tids],dtype=float)
            delta = x-y
            sample_delta = delta[draws].mean(axis=1)
            ratio = x[draws].sum(axis=1)/y[draws].sum(axis=1)
            resource_pairs[source][metric] = {'adaptive_total':int(x.sum()),'plan_reflect_total':int(y.sum()),
                'adaptive_mean':float(x.mean()),'plan_reflect_mean':float(y.mean()),
                'mean_difference':float(delta.mean()),'ratio_of_totals':float(x.sum()/y.sum()),
                'relative_change':float(x.sum()/y.sum()-1),
                'paired_bootstrap_percentile_95_mean_difference':[float(v) for v in np.quantile(sample_delta,[.025,.975])],
                'paired_bootstrap_percentile_95_ratio':[float(v) for v in np.quantile(ratio,[.025,.975])]}
    length_calls = [e for e in responses if e['finish_reason']=='length']
    empty = [r for r in rows if not r['outcome']['final_answer'].strip()]
    truncation = {'calls':len(length_calls),'trajectories':len({e['run_id'] for e in length_calls}),
        'calls_fraction':len(length_calls)/len(responses),'trajectory_fraction':len({e['run_id'] for e in length_calls})/len(rows),
        'call_details':[{'run_id':e['run_id'],'request_id':e['request_id'],'purpose':e['purpose'],
                         'completion_tokens':e['completion_tokens'],'empty_content':not e['content'].strip()} for e in length_calls],
        'empty_final_answers':[{'task_id':r['task_id'],'arm':r['strategy'],'run_id':r['run_id'],
                               'stop_reason':r['outcome']['stop_reason']} for r in empty]}
    assert truncation['calls']==11 and truncation['trajectories']==8 and len(empty)==1
    finished = next(e['ts_utc'] for e in reversed(events) if e['event']=='run_finished')
    drift = []
    for rel,old_hash in metadata['code_fingerprint'].items():
        p = ORIGINAL/'src/sncs_fivearm'/rel
        now = digest(p)
        if now!=old_hash:drift.append({'relative_path':rel,'run_start_sha256':old_hash,'current_sha256':now})
    # Search accessible local Python copies by filename, and archive members, for
    # the four old hashes. Bound search to relevant project snapshots/packages.
    targets = {d['run_start_sha256']:d['relative_path'] for d in drift}
    filenames = {Path(v).name for v in targets.values()}
    roots = [WORK/'.snapshots',ORIGINAL,PREP,WORK/'SNCS_Agent_Handoff_20261111',
             WORK/'SNCS_Independent_Recheck_20261114',WORK/'SNCS_Autonomous_Audit_20261109']
    examined = []; matches = []; search_errors = []
    for root in roots:
        if not root.exists():continue
        def walk_error(err):search_errors.append(str(err))
        for parent,dirs,files in os.walk(root,onerror=walk_error):
            dirs[:] = [d for d in dirs if d not in ['__pycache__','.git','node_modules']]
            for name in files:
                if name not in filenames:continue
                p = Path(parent)/name
                try:
                    h=digest(p);examined.append(str(p))
                    if h in targets:matches.append({'path':str(p),'historical_relative_path':targets[h],'sha256':h})
                except OSError as ex:search_errors.append(str(ex))
    archives = [p for p in WORK.glob('SNCS*.zip')]
    archives += list((ORIGINAL/'reports').glob('*.zip'))+list((ORIGINAL/'evidence/review_return_20261114').glob('*.zip'))
    archives += list((WORK/'SNCS_Autonomous_Audit_20261109').glob('*.zip'))
    for archive in archives:
        try:
            with zipfile.ZipFile(archive) as z:
                for name in z.namelist():
                    if Path(name).name not in filenames:continue
                    examined.append(str(archive)+'!'+name);h=sha256(z.read(name)).hexdigest()
                    if h in targets:matches.append({'path':str(archive)+'!'+name,'historical_relative_path':targets[h],'sha256':h})
        except (OSError,zipfile.BadZipFile) as ex:search_errors.append(str(ex))
    seals={p.name:load(p)['sealed_utc'] for p in input_paths[7:9]}
    provenance = {'run_started_utc':metadata['started_utc'],'run_finished_utc':finished,'seal_times_utc':seals,
        'seal_interpretation':'Both cited seals postdate completion; they establish post-run consistency, not a pre-data freeze.',
        'source_differences':drift,'historical_search':{'roots':[str(r) for r in roots],
            'archive_paths':[str(p) for p in archives],'examined':examined,'matches':matches,'errors':search_errors,
            'limit':'Bounded local search, not every byte or remote history. No historical source invented from hashes.'},
        'source_attribution':'Main interval method and primary comparison appear in earlier handoff, but current seal alone is not timestamp proof of pre-run implementation.',
        'registry_runstart_matches_current':metadata['code_fingerprint']['registry.py']==digest(ORIGINAL/'src/sncs_fivearm/registry.py'),
        'router_artifact_path':str(WORK/'results/complexity/router_candidate_s5_20261014.json'),
        'router_sha256':digest(WORK/'results/complexity/router_candidate_s5_20261014.json'),
        'published_new_run_weights_independently_verified':False}
    prompts={r['task_id']:r['prompt'] for r in jsonl(input_paths[6])}
    disputes=[]
    explanations={EXCLUDED4[-1]:{'title':'Doorbell wording/reference-key inconsistency',
        'analysis':'The phrase “10 times more than” does not unambiguously mean add 10. 20+25+10*60=705 under a tenfold reading; 20+25+11*60=765 under a literal 10-times-more increment reading. The reference 175 uses 60+10=70, discarding “times”. This is a wording/key dispute, not a new human adjudication.',
        'reference_key':'175','reasonable_readings':['705','765']},
        EXCLUDED5[-1]:{'title':'Shelter comparative wording ambiguity',
        'analysis':'“Twice as many more dogs than when he left” can be read as total twice the original count (24 minus 3 =21), or 24 additional dogs (12+24-3=33). The reference adopts 33. Record ambiguity without replacing the returned human labels.',
        'reference_key':'33','reasonable_readings':['21','33']}}
    for tid,explanation in explanations.items():
        disputes.append({'task_id':tid,'source':'gsm8k','prompt':prompts[tid],**explanation,
            'origin':'AI-assisted post-run audit; not an independent human adjudication',
            'human_labels_unchanged':True,'answers':[{'arm':r['strategy'],'answer':r['outcome']['final_answer'],
                'human_strict':scored['human_strict'][tid,r['strategy']],
                'human_contextual':scored['human_contextual'][tid,r['strategy']]} for r in rows if r['task_id']==tid]})
    qbalance = {s:{arm:dict(Counter(q['execution_position'] for q in queue if q['source']==s and q['strategy']==arm)) for arm in ARMS} for s in SOURCES}
    assert all(set(c.values())=={40} for d in qbalance.values() for c in d.values())
    counts = {'result_rows':len(rows),'tasks':len({r['task_id'] for r in rows}),'dispatch_intents':len(intents),
        'responses':len(responses),'usage_settlements':len(settlements),
        'prompt_tokens':sum(e['prompt_tokens'] for e in responses),'completion_tokens':sum(e['completion_tokens'] for e in responses),
        'total_tokens':sum(e['prompt_tokens']+e['completion_tokens'] for e in responses),
        'requests_without_message_snapshot':sum('messages' not in e for e in intents),
        'outcome_dispatch_count_mismatches':[{'run_id':r['run_id'],'journal':trajectory[r['run_id']]['calls'],
            'outcome':r['outcome']['dispatches']} for r in rows if trajectory[r['run_id']]['calls']!=r['outcome']['dispatches']]}
    assert counts['prompt_tokens']==1603773 and counts['completion_tokens']==1694118
    result={'status':'INDEPENDENT_OFFLINE_REANALYSIS_COMPLETE','created_utc':datetime.now(timezone.utc).isoformat(),
        'versions':{'numpy':np.__version__,'scipy':scipy.__version__},'source_hashes':before,
        'integrity':counts,'primary_comparison':'adaptive_legacy minus plan_reflect',
        'quality_interval':'95% paired discordant Clopper-Pearson union bound; alpha/4 per tail; no cross-dataset multiplicity correction',
        'quality':main_stats,'three_scoring_arm_tables':arm_table,'sensitivity':sensitivity,
        'resources':resource,'resource_purpose':[{'source':s,'arm':a,'purpose':p,**d} for (s,a,p),d in sorted(purpose.items())],
        'paired_resource_analysis':resource_pairs,
        'resource_bootstrap':{'draws':2000,'seed':20261111,'unit':'whole question within dataset, preserving arm pairing',
            'interval':'percentile 95%; exploratory realized analysis; no multiple-comparison adjustment','monetary_cost_inference':False},
        'truncation':truncation,'provenance':provenance,'queue_position_balance':qbalance,
        'human_review':'Author confirmed two independent human reviewers, a separate adjudicator, and consent to anonymous record publication. No human labels are altered in this analysis.'}
    assert all(digest(p)==before[str(p)] for p in input_paths)
    write('supplementary_reanalysis.json',result)
    write('posthoc_dispute_register.json',{'status':'AI_RAISED_DISPUTES_NOT_NEW_HUMAN_DECISIONS','items':disputes})
    write('provenance_reconciliation.json',provenance)
    write('input_integrity.json',{'original_inputs_unchanged':True,'sha256':before,'network_or_model_calls':0})
    render_fragments(result)
    print(json.dumps({'counts':counts,'primary':main_stats,'resource_comparison':resource_pairs,
        'historical_hash_matches':matches,'source_differences':drift},ensure_ascii=False,indent=2))

def mdtable(header, rows):
    return '\n'.join(['| '+' | '.join(header)+' |','| '+' | '.join(['---']*len(header))+' |']+
                     ['| '+' | '.join(map(str,r))+' |' for r in rows])

def render_fragments(j):
    labels={'automatic':'Automatic','human_strict':'Human strict','human_contextual':'Human contextual'}
    arm_names={'direct':'Direct','planning':'Planning','plan_reflect':'Plan+Reflect','adaptive_legacy':'Adaptive','asc_beta_8':'ASC-Beta-8'}
    primary=[]
    for label,d in j['quality'].items():
        for source,v in d['primary'].items():
            primary.append([labels[label],source.upper(),v['planned_n'],v['n'],
                v['a_only_correct_b'],v['b_only_correct_c'],f"{100*v['difference']:+.3f}",
                f"[{100*v['lower']:+.3f}, {100*v['upper']:+.3f}]",f"{v['exact_mcnemar_p']:.3f}"])
    quality=mdtable(['Scoring','Dataset','Planned','Known pairs','b','c','Difference (pp)','95% interval (pp)','McNemar p'],primary)
    arms=[]
    for d in j['three_scoring_arm_tables']:
        arms.append([labels[d['scoring']],d['source'].upper(),arm_names[d['arm']],d['correct'],d['incorrect'],d['unknown']])
    resources=[]
    for d in j['resources']:
        t=d['total'];m=d['mean_per_question']
        resources.append([d['source'].upper(),arm_names[d['arm']],t['calls'],f"{m['calls']:.3f}",
            t['prompt_tokens'],t['completion_tokens'],t['total_tokens'],f"{m['total_tokens']:.2f}"])
    sensitivity=[]
    for label,d in j['sensitivity'].items():
        for title,v in d.items():
            sensitivity.append([labels[label],title.replace('_',' '),v['planned_n'],v['n'],
                f"{100*v['difference']:+.3f}",f"[{100*v['lower']:+.3f}, {100*v['upper']:+.3f}]"])
    boots=[]
    for source,d in j['paired_resource_analysis'].items():
        for metric,v in d.items():
            lo,hi=v['paired_bootstrap_percentile_95_mean_difference']
            boots.append([source.upper(),metric,f"{v['mean_difference']:+.3f}",f"[{lo:+.3f}, {hi:+.3f}]",f"{100*v['relative_change']:+.2f}%"])
    methods='''### 3.9 Analysis of the new five-arm screening experiment

The primary method contrast was Adaptive minus Plan+Reflect within each dataset, with the question as the paired unit. The original automatic three-category scoring analysis is retained. In this revision, we present the returned strict human scores as the principal presentation and show automatic and contextual-human results alongside them; adoption of the human-strict presentation is a revision-stage choice, not a prospectively registered primary scoring endpoint. The human assessment covered all 2,000 trajectories. The author confirms two independent human reviewers and a separate adjudicator, with consent to anonymous use of their scoring records. Counts of answer texts exposing method-like features describe incomplete blinding, not the number of rated trajectories. Strict scores measure agreement under the documented reference-key rules; contextual scores allow documented mathematical and task-context equivalences. Neither guarantees an error-free benchmark key.

For binary known pairs, let b denote questions correct only for Adaptive and c those correct only for Plan+Reflect. We estimate (b−c)/N and form a conservative 95% interval by subtracting Clopper–Pearson bounds on b/N and c/N, using tail probability 0.0125 for each of the four tails. Exact McNemar p-values are descriptive tests of equality, not evidence of equivalence or noninferiority. Intervals are per dataset; no cross-dataset multiplicity-adjusted confirmatory claim is made. Unknown labels remain unknown, and the planned and complete-pair denominators are both reported. Human-strict MATH has one omitted pair because the Plan+Reflect final answer is empty. A separately labeled, post-hoc operational-failure sensitivity assigns that empty final answer an incorrect outcome and restores all 200 MATH pairs, without overwriting the returned score.

We retain the original three-item GSM8K exclusion analysis and add nested four-item and five-item exclusions as post-hoc sensitivities. The fourth item is the doorbell wording/key dispute (00100); the fifth is the shelter comparative-wording ambiguity (00675). These two new concerns were raised during AI-assisted audit, not newly adjudicated by a human reviewer. All five methods are removed together for each excluded question. The original human labels and all-question results remain intact, and these exclusions do not constitute a resampling plan or a claim that the remaining keys are error-free.

Resource accounting sums every response-bearing request over the complete question workflow, including judging, planning, reflection, replanning, solving, and baseline sampling. We report request counts, prompt tokens, and completion tokens separately, with totals and means. Reasoning tokens already included in completion_tokens are not added again. A resource bootstrap resamples 200 whole questions with replacement within each dataset while preserving paired method observations (2,000 draws; NumPy default_rng seed 20261111), producing exploratory percentile intervals on mean differences and ratios of totals. This realized resource analysis is descriptive and does not establish monetary savings: the local gateway has no verified billing record, and its zero local tariff is only a placeholder. We distinguish transport/workflow exceptions, length-limited calls, and empty final answers.

### 4.5 New-problem five-arm design and execution provenance

The screening experiment used 200 GSM8K and 200 MATH official-test questions selected from the remaining project pool after archived-use and lexical/template overlap screening. Project-level novelty does not establish model-pretraining novelty. MATH includes algebra (50), prealgebra (38), intermediate algebra (34), precalculus (22), counting and probability (21), number theory (20), and geometry (15); it is not an algebra-only experiment. Twenty separate training questions were used for preflight. The 100 reserved calibration questions were not queued for this main run. The five arms were Direct, Planning, Plan+Reflect, Adaptive with the retained legacy router, and ASC-Beta-8. Each method was run once per question. The question sample is a screening pilot, not a powered confirmatory noninferiority study.

Within each dataset/sampling stratum, a ten-sequence Williams arrangement (five cyclic sequences and their reversals) balances method position and first-order adjacency. With seed 20261110, SHA-256-derived stratum seeds shuffle arm-label assignments, sequence assignments, and questions; a global generator shuffles question blocks. Each arm occupies each of the five positions 40 times per dataset. The five methods remain sequential within a question block; 12 blocks execute concurrently, so service time is not completely randomized across individual requests.

Plan+Reflect retained S1 stopping with max_rounds=2. Adaptive retained S2(delta=0.05, streak=2), with a hybrid router built from the existing October 14 artifact, SHA-256 3178631cb9426c1620b608eadff1b5109e24184c9954836e1af15ae0641573ea, without refitting on the new screening pool. The artifact originated as an earlier calibration-grid candidate; the new registry explicitly adopts and fingerprint-checks that file for this experiment. ASC-Beta-8 uses the published top-two Beta stopping mechanism: for the leading and second-most-frequent valid categories with counts a and b, stop when Pr[Beta(a+1,b+1)>1/2]≥0.95, subject to at most eight actual sequential requests. Invalid outputs consume attempts but do not vote; ties at the cap select the earliest observed valid category. Repeated samples use separate conversations without previous candidates. This is an implementation of an existing comparator, not a newly proposed stopping algorithm.

All arms used the author-specified local gateway at GATEWAY_REDACTED, whose responses report deepseek-v4.1-flash, with thinking enabled, reasoning_effort=high, top_p=1, and temperature and seed omitted. The model/weight identity is an author-reported deployment mapping, not independently authenticated. The per-trajectory ceiling was eight requests. Solve, baseline_solve, and tool calls had a 16,384-token ceiling; judge, plan, reflect, and replan calls had 4,096. This shared request ceiling is not an equal total-token budget, and all adaptive control overhead is included in resource accounting. The single main service window was November 13, 2026, 15:05:22–15:40:58 UTC (November 13, 23:05:22–23:40:58 China time).

The available seal snapshots were created at 17:12:33 and 17:25:18 UTC, after the main window. They document post-run consistency rather than a verified pre-data freeze. The run-start journal records code hashes; current cli.py, evaluation/analysis.py, evaluation/stats.py, and journal.py differ from those hashes. A bounded local search did not recover the matching old file contents, so an exact historical source diff is unavailable. The registry and strategy code fingerprints match the run-start records. We retain the earlier design/handoff as planning evidence while acknowledging that it does not reconstruct the missing four historical sources. Current numerical results have been recalculated independently from immutable raw outputs and returned scores. Actual request bodies were not durably captured in the legacy journal, which limits per-request parameter verification.
'''
    result='''### 5.12 Results of the new five-arm screening experiment

The run produced all 2,000 planned trajectories on 400 questions, with 5,331 unique dispatch intents, responses, and usage settlements. The recorded token totals were 1,603,773 prompt and 1,694,118 completion tokens (3,297,891 combined). No transport/workflow exception was recorded, but this does not mean that every output completed normally: 11 calls in eight trajectories ended with finish_reason=length (0.206% of calls; 0.4% of trajectories), and one Plan+Reflect MATH trajectory had an empty final answer. That trajectory remains unknown in the returned human scores and is included as incorrect only in the explicitly labeled operational-failure sensitivity.

Table 18. Per-arm results under the three retained scoring views. Each row has 200 planned trajectories; C/I/U denote correct, incorrect, and unknown. Human-strict counts describe reference-key scoring and must not be read as an independently corrected mathematical truth set.

'''+mdtable(['Scoring','Dataset','Arm','C','I','U'],arms)+'''

Table 19. Paired Adaptive minus Plan+Reflect quality comparisons. Differences and intervals are percentage points; b and c are discordant counts. The principal revision presentation uses strict human scores; automatic scoring is retained rather than replaced.

'''+quality+'''

Under strict human scoring, the estimated differences were −0.500 percentage points for GSM8K and −0.503 for the 199 complete MATH pairs. All quality intervals cross zero. Contextual GSM8K yields a zero difference. These observations support neither a quality advantage nor equivalence; the strict-human lower bounds also remain below the illustrative −3-percentage-point noninferiority margin. The marked reduction in unknown scores after human review reflects scoring/parser coverage as well as answer equivalence, and is not an improvement in the model outputs themselves.

Table 20. Whole-workflow resource use. Completion usage includes reasoning where returned by the service. Arithmetic totals of prompt and completion tokens are a transparent volume measure, not a verified currency cost. Means use all 200 questions, including the empty-answer trajectory.

'''+mdtable(['Dataset','Arm','Requests','Requests/question','Prompt tokens','Completion tokens','Total tokens','Total tokens/question'],resources)+'''

Adaptive used 2.0% fewer requests than Plan+Reflect on GSM8K (588 versus 600), while using 14.55% more combined tokens (355,090 versus 309,984). Thus request counts and token volume move in opposite directions on this dataset. On MATH, Adaptive used 14.08% fewer requests (531 versus 618) and 3.90% fewer combined tokens (448,704 versus 466,918). The paired resource bootstrap interval for the GSM8K total-token mean difference was +109.36 to +340.25 tokens/question, whereas the MATH interval was −255.90 to +91.24 and includes zero. Only the MATH request-count interval excludes zero among these two request-count comparisons. These are exploratory within-window results, not evidence of a general monetary saving or stable performance across deployment windows.

Table 21. Post-hoc question-exclusion and empty-final sensitivities. Exclusions preserve the original labels and remove each affected question across all five arms. The automatic empty-final row still omits other unknown pairs; only the human rows restore all 200 MATH pairs.

'''+mdtable(['Scoring','Sensitivity','Planned','Known pairs','Difference (pp)','95% interval (pp)'],sensitivity)+'''

The new doorbell dispute concerns the wording “10 times more than” against a reference calculation that adds 10; 705 follows a tenfold reading, whereas the reference 175 follows an additive reading. The shelter item admits differing readings of “twice as many more,” yielding 21 or 33. We register these as audit concerns, not new human judgments. The four- and five-item GSM8K exclusions leave the substantive Adaptive–Plan+Reflect interpretation unchanged: strict scores retain one discordant pair, contextual scores retain one discordance in each direction, and all intervals cross zero. Both Adaptive and Plan+Reflect had the same submitted answer on each of the two newly flagged questions, so their paired difference is not directly driven by a disagreement on those questions; comparisons involving Direct, Planning, or ASC may be more sensitive. Excluding suspect items does not validate every remaining answer key. Treating the empty MATH final answer as incorrect gives b=c=1 over 200 questions, a zero difference with interval [−3.142, +3.142] percentage points; superiority, equivalence, and confirmatory noninferiority remain unsupported.

Table 22. Exploratory paired resource bootstrap, Adaptive minus Plan+Reflect. Mean differences use requests/question or tokens/question, depending on metric. Relative changes are ratios of observed aggregate totals; intervals are percentile intervals on paired mean differences, with no multiplicity adjustment.

'''+mdtable(['Dataset','Metric','Mean difference','95% bootstrap interval','Observed relative change'],boots)+'''

This additional experiment supplies a new-problem, multi-comparator execution check rather than proof of a new routing algorithm. Its limits include one service window, one reported model deployment, incomplete output-format blinding, a nearly saturated human-scored accuracy regime, finite-sample uncertainty, reference-key disputes, post-run analysis/source provenance gaps, and absent verified billing. Request reductions alone are not sufficient to claim overall cost efficiency.
'''
    (HERE/'new_methods.md').write_text(methods,encoding='utf-8')
    (HERE/'new_results.md').write_text(result,encoding='utf-8')
    purpose_rows=[[d['source'].upper(),arm_names[d['arm']],d['purpose'],d['calls'],d['prompt_tokens'],d['completion_tokens'],d['total_tokens']] for d in j['resource_purpose']]
    (HERE/'resource_purpose_breakdown.md').write_text('# Complete purpose-level resource accounting\n\nAll rows are sums over recorded response events; no reasoning-token double counting.\n\n'+mdtable(['Dataset','Arm','Purpose','Requests','Prompt tokens','Completion tokens','Total tokens'],purpose_rows)+'\n',encoding='utf-8')

if __name__=='__main__':main()
