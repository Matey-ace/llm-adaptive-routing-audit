"""Read-only manuscript checks against raw-derived evidence and historical tables."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, re
from scipy.stats import beta

BASE=Path(__file__).resolve().parent.parent
PAPER=BASE/'SNCS_Revised_Manuscript.md'
OLD=BASE.parent/'SNCS_Autonomous_Audit_20261109'
text=PAPER.read_text(encoding='utf-8')
original=(OLD/'SNCS_Revised_Manuscript.md').read_text(encoding='utf-8')
j=json.loads((BASE/'analysis/supplementary_reanalysis.json').read_text(encoding='utf-8'))

def tables(t):
    return {int(n):[line.strip() for line in content.strip().splitlines()]
        for n,content in re.findall(r'\*\*Table (\d+)\*\*[^\n]*\n\n((?:\|[^\n]*\n)+)',t)}

a,b=tables(original),tables(text)
historical={str(k):a.get(k)==b.get(k) for k in range(1,18)}
assert all(historical.values())
armnames={'direct':'Direct','planning':'Planning','plan_reflect':'Plan+Reflect','adaptive_legacy':'Adaptive','asc_beta_8':'ASC-Beta-8'}
labels={'automatic':'Automatic','human_strict':'Human strict','human_contextual':'Human contextual'}
quality_checks=[]
for label,d in j['quality'].items():
    for source,q in d['primary'].items():
        line='| '+' | '.join([labels[label],source.upper(),str(q['n']),f"{q['difference']*100:+.3f}",f"[{q['lower']*100:+.3f}, {q['upper']*100:+.3f}]"])+' |'
        assert line in b[19],line
        quality_checks.append({'label':label,'source':source,'matched_table19':True})
for q in j['three_scoring_arm_tables']:
    line='| '+' | '.join([labels[q['scoring']],q['source'].upper(),armnames[q['arm']],str(q['correct']),str(q['incorrect']),str(q['unknown'])])+' |'
    assert line in b[18],line
for q in j['resources']:
    line='| '+' | '.join([q['source'].upper(),armnames[q['arm']],f"{q['mean_per_question']['calls']:.3f}",str(q['total']['total_tokens']),f"{q['mean_per_question']['total_tokens']:.2f}"])+' |'
    assert line in b[20],line

# Independent reconstruction of archived baseline CP endpoints, directly from
# stratum counts, without importing the original interval implementation.
legacy=json.loads((OLD/'evidence/one_label_perturbation_sensitivity.json').read_text(encoding='utf-8'))
cp_checks=[]
for source,d in legacy.items():
    for label,p in d.items():
        q=p['baseline'];h=len(q['strata']);n=q['n'];alpha=q['alpha'];tail=alpha/(4*h)
        def lower(k,m):return 0. if k==0 else float(beta.ppf(tail,k,m-k+1))
        def upper(k,m):return 1. if k==m else float(beta.ppf(1-tail,k+1,m-k))
        lo=hi=0.
        for stratum,pairs in q['strata'].items():
            # First assignment unfavorable; second favorable to Adaptive.
            bad,good=pairs;m=bad['n'];w=m/n
            lo+=w*(lower(bad['positive'],m)-upper(bad['negative'],m))
            hi+=w*(upper(good['positive'],m)-lower(good['negative'],m))
        expected=q['confidence_interval']
        assert abs(lo-expected[0])<1e-11 and abs(hi-expected[1])<1e-11
        cp_checks.append({'dataset':source,'score':label,'recomputed_interval':[lo,hi],
            'matches_archived_baseline':True,'passes_lower_gt_minus_003':lo>-.03})
out={'checked_utc':datetime.now(timezone.utc).isoformat(),'manuscript_sha256':sha256(PAPER.read_bytes()).hexdigest(),
     'historical_tables_1_through_17_identical':historical,'new_table18_rows_matched':30,
     'new_table19_rows_matched':quality_checks,'new_table20_resource_rows_matched':10,
     'legacy_followup_cp_reconstructed_from_stratum_counts':cp_checks,
     'scope':'AI-assisted computational review; source-data and model authentication are separate limitations.'}
(BASE/'analysis/manuscript_statistical_verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
