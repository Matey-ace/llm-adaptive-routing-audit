### 5.12 Results of the new five-arm screening experiment

The run produced all 2,000 planned trajectories on 400 questions, with 5,331 unique dispatch intents, responses, and usage settlements. The recorded token totals were 1,603,773 prompt and 1,694,118 completion tokens (3,297,891 combined). No transport/workflow exception was recorded, but this does not mean that every output completed normally: 11 calls in eight trajectories ended with finish_reason=length (0.206% of calls; 0.4% of trajectories), and one Plan+Reflect MATH trajectory had an empty final answer. That trajectory remains unknown in the returned human scores and is included as incorrect only in the explicitly labeled operational-failure sensitivity.

Table 18. Per-arm results under the three retained scoring views. Each row has 200 planned trajectories; C/I/U denote correct, incorrect, and unknown. Human-strict counts describe reference-key scoring and must not be read as an independently corrected mathematical truth set.

| Scoring | Dataset | Arm | C | I | U |
| --- | --- | --- | --- | --- | --- |
| Automatic | GSM8K | Direct | 165 | 30 | 5 |
| Automatic | GSM8K | Planning | 160 | 23 | 17 |
| Automatic | GSM8K | Plan+Reflect | 168 | 23 | 9 |
| Automatic | GSM8K | Adaptive | 166 | 28 | 6 |
| Automatic | GSM8K | ASC-Beta-8 | 164 | 34 | 2 |
| Automatic | MATH | Direct | 185 | 4 | 11 |
| Automatic | MATH | Planning | 185 | 2 | 13 |
| Automatic | MATH | Plan+Reflect | 187 | 2 | 11 |
| Automatic | MATH | Adaptive | 185 | 2 | 13 |
| Automatic | MATH | ASC-Beta-8 | 189 | 3 | 8 |
| Human strict | GSM8K | Direct | 191 | 9 | 0 |
| Human strict | GSM8K | Planning | 191 | 9 | 0 |
| Human strict | GSM8K | Plan+Reflect | 193 | 7 | 0 |
| Human strict | GSM8K | Adaptive | 192 | 8 | 0 |
| Human strict | GSM8K | ASC-Beta-8 | 190 | 10 | 0 |
| Human strict | MATH | Direct | 199 | 1 | 0 |
| Human strict | MATH | Planning | 199 | 1 | 0 |
| Human strict | MATH | Plan+Reflect | 199 | 0 | 1 |
| Human strict | MATH | Adaptive | 199 | 1 | 0 |
| Human strict | MATH | ASC-Beta-8 | 200 | 0 | 0 |
| Human contextual | GSM8K | Direct | 197 | 3 | 0 |
| Human contextual | GSM8K | Planning | 198 | 2 | 0 |
| Human contextual | GSM8K | Plan+Reflect | 199 | 1 | 0 |
| Human contextual | GSM8K | Adaptive | 199 | 1 | 0 |
| Human contextual | GSM8K | ASC-Beta-8 | 196 | 4 | 0 |
| Human contextual | MATH | Direct | 199 | 1 | 0 |
| Human contextual | MATH | Planning | 199 | 1 | 0 |
| Human contextual | MATH | Plan+Reflect | 199 | 0 | 1 |
| Human contextual | MATH | Adaptive | 199 | 1 | 0 |
| Human contextual | MATH | ASC-Beta-8 | 200 | 0 | 0 |

Table 19. Paired Adaptive minus Plan+Reflect quality comparisons. Differences and intervals are percentage points; b and c are discordant counts. The principal revision presentation uses strict human scores; automatic scoring is retained rather than replaced.

| Scoring | Dataset | Planned | Known pairs | b | c | Difference (pp) | 95% interval (pp) | McNemar p |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Automatic | GSM8K | 200 | 188 | 7 | 10 | -1.596 | [-8.915, +5.817] | 0.629 |
| Automatic | MATH | 200 | 184 | 0 | 1 | -0.543 | [-3.418, +2.347] | 1.000 |
| Human strict | GSM8K | 200 | 200 | 0 | 1 | -0.500 | [-3.148, +2.161] | 1.000 |
| Human strict | MATH | 200 | 199 | 0 | 1 | -0.503 | [-3.163, +2.172] | 1.000 |
| Human contextual | GSM8K | 200 | 200 | 1 | 1 | +0.000 | [-3.142, +3.142] | 1.000 |
| Human contextual | MATH | 200 | 199 | 0 | 1 | -0.503 | [-3.163, +2.172] | 1.000 |

Under strict human scoring, the estimated differences were −0.500 percentage points for GSM8K and −0.503 for the 199 complete MATH pairs. All quality intervals cross zero. Contextual GSM8K yields a zero difference. These observations support neither a quality advantage nor equivalence; the strict-human lower bounds also remain below the illustrative −3-percentage-point noninferiority margin. The marked reduction in unknown scores after human review reflects scoring/parser coverage as well as answer equivalence, and is not an improvement in the model outputs themselves.

Table 20. Whole-workflow resource use. Completion usage includes reasoning where returned by the service. Arithmetic totals of prompt and completion tokens are a transparent volume measure, not a verified currency cost. Means use all 200 questions, including the empty-answer trajectory.

| Dataset | Arm | Requests | Requests/question | Prompt tokens | Completion tokens | Total tokens | Total tokens/question |
| --- | --- | --- | --- | --- | --- | --- | --- |
| GSM8K | Direct | 200 | 1.000 | 47734 | 26452 | 74186 | 370.93 |
| GSM8K | Planning | 400 | 2.000 | 114450 | 56375 | 170825 | 854.12 |
| GSM8K | Plan+Reflect | 600 | 3.000 | 188866 | 121118 | 309984 | 1549.92 |
| GSM8K | Adaptive | 588 | 2.940 | 223625 | 131465 | 355090 | 1775.45 |
| GSM8K | ASC-Beta-8 | 939 | 4.695 | 223995 | 155182 | 379177 | 1895.88 |
| MATH | Direct | 200 | 1.000 | 49761 | 90599 | 140360 | 701.80 |
| MATH | Planning | 400 | 2.000 | 121149 | 124173 | 245322 | 1226.61 |
| MATH | Plan+Reflect | 618 | 3.090 | 213191 | 253727 | 466918 | 2334.59 |
| MATH | Adaptive | 531 | 2.655 | 205344 | 243360 | 448704 | 2243.52 |
| MATH | ASC-Beta-8 | 855 | 4.275 | 215658 | 491667 | 707325 | 3536.62 |

Adaptive used 2.0% fewer requests than Plan+Reflect on GSM8K (588 versus 600), while using 14.55% more combined tokens (355,090 versus 309,984). Thus request counts and token volume move in opposite directions on this dataset. On MATH, Adaptive used 14.08% fewer requests (531 versus 618) and 3.90% fewer combined tokens (448,704 versus 466,918). The paired resource bootstrap interval for the GSM8K total-token mean difference was +109.36 to +340.25 tokens/question, whereas the MATH interval was −255.90 to +91.24 and includes zero. Only the MATH request-count interval excludes zero among these two request-count comparisons. These are exploratory within-window results, not evidence of a general monetary saving or stable performance across deployment windows.

Table 21. Post-hoc question-exclusion and empty-final sensitivities. Exclusions preserve the original labels and remove each affected question across all five arms. The automatic empty-final row still omits other unknown pairs; only the human rows restore all 200 MATH pairs.

| Scoring | Sensitivity | Planned | Known pairs | Difference (pp) | 95% interval (pp) |
| --- | --- | --- | --- | --- | --- |
| Automatic | exclude original three | 197 | 185 | -1.622 | [-9.055, +5.908] |
| Automatic | exclude four | 196 | 184 | -1.630 | [-9.103, +5.939] |
| Automatic | exclude five | 195 | 183 | -1.639 | [-9.151, +5.970] |
| Automatic | empty final as incorrect full math 200 | 200 | 185 | +0.000 | [-3.393, +3.393] |
| Human strict | exclude original three | 197 | 197 | -0.508 | [-3.195, +2.193] |
| Human strict | exclude four | 196 | 196 | -0.510 | [-3.211, +2.205] |
| Human strict | exclude five | 195 | 195 | -0.513 | [-3.227, +2.216] |
| Human strict | empty final as incorrect full math 200 | 200 | 200 | +0.000 | [-3.142, +3.142] |
| Human contextual | exclude original three | 197 | 197 | +0.000 | [-3.189, +3.189] |
| Human contextual | exclude four | 196 | 196 | +0.000 | [-3.205, +3.205] |
| Human contextual | exclude five | 195 | 195 | +0.000 | [-3.221, +3.221] |
| Human contextual | empty final as incorrect full math 200 | 200 | 200 | +0.000 | [-3.142, +3.142] |

The new doorbell dispute concerns the wording “10 times more than” against a reference calculation that adds 10; 705 follows a tenfold reading, whereas the reference 175 follows an additive reading. The shelter item admits differing readings of “twice as many more,” yielding 21 or 33. We register these as audit concerns, not new human judgments. The four- and five-item GSM8K exclusions leave the substantive Adaptive–Plan+Reflect interpretation unchanged: strict scores retain one discordant pair, contextual scores retain one discordance in each direction, and all intervals cross zero. Both Adaptive and Plan+Reflect had the same submitted answer on each of the two newly flagged questions, so their paired difference is not directly driven by a disagreement on those questions; comparisons involving Direct, Planning, or ASC may be more sensitive. Excluding suspect items does not validate every remaining answer key. Treating the empty MATH final answer as incorrect gives b=c=1 over 200 questions, a zero difference with interval [−3.142, +3.142] percentage points; superiority, equivalence, and confirmatory noninferiority remain unsupported.

Table 22. Exploratory paired resource bootstrap, Adaptive minus Plan+Reflect. Mean differences use requests/question or tokens/question, depending on metric. Relative changes are ratios of observed aggregate totals; intervals are percentile intervals on paired mean differences, with no multiplicity adjustment.

| Dataset | Metric | Mean difference | 95% bootstrap interval | Observed relative change |
| --- | --- | --- | --- | --- |
| GSM8K | calls | -0.060 | [-0.170, +0.050] | -2.00% |
| GSM8K | prompt_tokens | +173.795 | [+127.799, +219.738] | +18.40% |
| GSM8K | completion_tokens | +51.735 | [-41.996, +145.159] | +8.54% |
| GSM8K | total_tokens | +225.530 | [+109.357, +340.254] | +14.55% |
| MATH | calls | -0.435 | [-0.590, -0.270] | -14.08% |
| MATH | prompt_tokens | -39.235 | [-113.495, +40.768] | -3.68% |
| MATH | completion_tokens | -51.835 | [-162.642, +77.416] | -4.09% |
| MATH | total_tokens | -91.070 | [-255.901, +91.244] | -3.90% |

This additional experiment supplies a new-problem, multi-comparator execution check rather than proof of a new routing algorithm. Its limits include one service window, one reported model deployment, incomplete output-format blinding, a nearly saturated human-scored accuracy regime, finite-sample uncertainty, reference-key disputes, post-run analysis/source provenance gaps, and absent verified billing. Request reductions alone are not sufficient to claim overall cost efficiency.
