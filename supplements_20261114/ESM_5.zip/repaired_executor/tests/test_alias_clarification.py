"""2026-11-13 别名消歧（BigChat → dsv4-flash）守卫测试。

纪律：语义澄清 ≠ 模型选定 ≠ 支出批准。
必须证明：合同草案仍未批准、launch 字段仍空、CLI 仍拒绝派发、付费调用仍为 0。
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

from sncs_fivearm.contracts import Contract, draft_contract


def _cli(args, cwd=None):
    env = dict(os.environ)
    env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
    return subprocess.run(
        [sys.executable, "-B", "-X", "utf8", "-m", "sncs_fivearm.cli"] + args,
        capture_output=True, text=True, encoding="utf-8", timeout=300, env=env, cwd=cwd)


def test_alias_file_is_consistent(runner_root):
    p = runner_root / "configs" / "model_alias_clarification.json"
    assert p.is_file()
    d = json.loads(p.read_text(encoding="utf-8-sig"))
    assert d["status"].startswith("ALIAS_DISAMBIGUATED")
    assert d["paid_calls_added"] == 0
    assert d["clarification"]["author_correction"] == "笔误，指 dsv4-flash"
    assert d["clarification"]["service_family"] == "DeepSeek V4 Flash"
    assert d["clarification"]["qwen_candidate_status"].startswith("已排除")
    names = {a["name"] for a in d["alias_map"]}
    assert {"dsv4-flash", "deepseek-v4-flash", "deepseek-v4-flash-0731",
            "deepseek-v4.1-flash", "deepseek-flash"} <= names
    official = next(a for a in d["alias_map"] if a["name"] == "deepseek-flash")
    assert official["is_api_model_id"] is True
    shorthand = next(a for a in d["alias_map"] if a["name"] == "dsv4-flash")
    assert shorthand["is_api_model_id"] is False


def test_alias_evidence_matches_archived_pricing_doc(prep_dir):
    """官方价目页原文点名 deepseek-flash，并说明旧名已下线。"""
    text = (prep_dir / "evidence" / "official_sources" / "pricing_cn.txt").read_text(
        encoding="utf-8")
    assert "模型名请使用" in text
    assert "deepseek-flash" in text
    assert "deepseek-v4-flash" in text
    assert "DeepSeek-V4.1-Flash-1017" in text
    assert "已下线" in text


def test_draft_contract_records_clarification_but_stays_locked(tmp_path):
    raw = draft_contract()
    assert raw["model_clarification"]["service_family"] == "DeepSeek V4 Flash"
    assert "dsv4-flash" in raw["model_clarification"]["author_quote"]
    assert raw["approval"]["approved"] is False
    assert raw["provider"]["model_id"] is None
    assert raw["provider"]["base_url"] is None
    assert raw["budget"]["total_micro"] is None
    assert raw["tariff"]["currency"] is None
    assert any("端点" in x for x in raw["decisions_pending"])

    p = tmp_path / "draft.json"
    p.write_text(json.dumps(raw, ensure_ascii=False), encoding="utf-8")
    c = Contract.load(p, approvals_dir=tmp_path / "no_approvals")
    assert c.approved is False
    assert c.live_ready is False
    assert c.get("provider.model_id") is None


def test_clarification_does_not_unlock_live_run(tmp_path):
    raw = draft_contract()
    p = tmp_path / "draft.json"
    p.write_text(json.dumps(raw, ensure_ascii=False), encoding="utf-8")
    done = _cli(["run", "--phase", "preflight", "--contract", str(p)])
    assert done.returncode == 3
    assert "未派发" in done.stdout
    assert "configs/approvals" in done.stdout


def test_no_paid_calls_after_clarification(runner_root):
    """澄清只改文档与配置；没有任何 run 目录被新增、没有 usage_settled 事件。"""
    runs = runner_root / "runs"
    paid_like = []
    for j in runs.rglob("journal.jsonl"):
        for line in j.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            e = json.loads(line)
            if e.get("event") == "run_started" and e.get("execution_mode") == "live":
                paid_like.append(str(j))
    assert paid_like == [], f"澄清后出现真实 run: {paid_like}"
    smoke = json.loads((runner_root / "evidence" / "gateway_smoke_receipt.json")
                       .read_text(encoding="utf-8-sig"))
    assert smoke["purpose"] == "SMOKE_ONLY_NOT_EXPERIMENTAL_DATA"
    assert smoke["paid_calls"] == 0


def test_proposed_contract_is_filled_but_still_locked(runner_root, tmp_path):
    """具体合同提案：参数已填、批准门仍关、CLI 仍拒绝派发。"""
    p = runner_root / "configs" / "execution_contract_PROPOSED_v1.json"
    assert p.is_file()
    raw = json.loads(p.read_text(encoding="utf-8-sig"))
    assert raw["status"].startswith("PROPOSED_FOR_AUTHOR_REVIEW")
    assert raw["provider"]["model_id"] == "deepseek-flash"
    assert raw["provider"]["base_url"] == "https://api.deepseek.com"
    assert raw["provider"]["thinking"]["reasoning_effort"] == "max"
    assert raw["tariff"]["input_uncached_micro_per_million"] == 2_000_000
    assert raw["budget"]["total_micro"] == 100_000_000
    assert raw["approval"]["approved"] is False

    c = Contract.load(p, approvals_dir=runner_root / "configs" / "approvals")
    assert c.approved is False
    assert c.live_ready is False
    assert any("批准" in x for x in c.problems)

    done = _cli(["run", "--phase", "preflight", "--contract", str(p)])
    assert done.returncode == 3
    assert "未派发" in done.stdout

    receipt = json.loads((runner_root / "evidence" / "proposed_contract_receipt.json")
                         .read_text(encoding="utf-8-sig"))
    assert receipt["live_ready"] is False
    assert receipt["paid_calls"] == 0
