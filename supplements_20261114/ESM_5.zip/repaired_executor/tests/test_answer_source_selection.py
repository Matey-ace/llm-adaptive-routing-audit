"""答案记录必须取「最后一次求解类派发」，不能取 reflect/replan。

真实数据复现（2026-11-13，本机网关 deepseek-v4.1-flash）：
plan_reflect 的调用链是 plan → solve → reflect，最后一条响应是反思正文
（"REFLECT: ... VERDICT: PASS"）。若用它去解析答案，会得到
`unclassifiable_output`，把正确答案 475 判成无效。

本测试用合成 provider 精确复现该链路，并断言修复后 plan_reflect / adaptive
都能拿到有效答案键。
"""

from __future__ import annotations

import pytest

from sncs_fivearm.budget import Ledger
from sncs_fivearm.dispatcher import Dispatcher
from sncs_fivearm.inputs import TaskPrompt, sha256_text
from sncs_fivearm.journal import Journal
from sncs_fivearm.providers import PurposeSyntheticProvider, SyntheticAction
from sncs_fivearm.registry import FiveArmRegistry
from sncs_fivearm.simulation_runner import ownerless_contract


def _task(text="A shop earns 5*20 + 10*30 + 15*5. Report the total.") -> TaskPrompt:
    return TaskPrompt(task_id="T", prompt=text, prompt_sha256=sha256_text(text))


def _run(tmp_path, strategy, purpose_script, task=None):
    c = ownerless_contract()
    j = Journal(tmp_path / "j.jsonl")
    led = Ledger(currency="CNY", total_cap_micro=100_000_000,
                 phase_caps_micro={"preflight": 100_000_000, "main": 0},
                 price_in_micro_per_million=2_000_000,
                 price_out_micro_per_million=8_000_000)
    provider = PurposeSyntheticProvider(purpose_script)
    d = Dispatcher(journal=j, ledger=led, provider=provider, contract=c,
                   output_ceiling=c.output_ceiling, sampling=c.sampling(),
                   input_bound_method=c.input_bound_method)
    reg = FiveArmRegistry(dispatcher=d, contract=c, verify_router=False)
    return reg.run_trajectory(strategy=strategy, task=task or _task(),
                              run_id="R", phase="preflight")


def test_plan_reflect_answer_ignores_trailing_reflection(tmp_path):
    """最后一条是 reflect，答案仍须来自 solve。"""
    out = _run(tmp_path, "plan_reflect", {
        "plan": [SyntheticAction.text("PLAN: 1. multiply 2. add")],
        "solve": [SyntheticAction.text("ANSWER: 475")],
        "reflect": [SyntheticAction.text(
            "REFLECT: 5*20=100, 10*30=300, 15*5=75, total 475. Correct.\n"
            "CONFIDENCE: 1.0\nVERDICT: PASS")],
    })
    assert out.final_answer == "475"
    assert out.answer_record["valid"] is True, out.answer_record
    assert out.answer_record["key"] == "num:475/1"


def test_adaptive_reflect_path_answer_ignores_trailing_reflection(tmp_path):
    """adaptive 走 plan_reflect 子路径时同样不能取 reflect 正文。"""
    task = _task("A shop sells pens for 3 dollars and notebooks for 7 dollars. "
                 "A customer buys 4 pens and 9 notebooks. Report the total cost in dollars and cents.")
    out = _run(tmp_path, "adaptive_legacy", {
        "judge": [SyntheticAction.text(
            '{"level": "medium", "confidence": 0.7, "reasoning_steps": 2, "reason": "ok"}')],
        "plan": [SyntheticAction.text("PLAN: 1. multiply 2. add")],
        "solve": [SyntheticAction.text("ANSWER: 75")],
        "reflect": [SyntheticAction.text(
            "REFLECT: 12+63=75, correct.\nCONFIDENCE: 0.95\nVERDICT: PASS")],
    }, task=task)
    assert out.answer_record["valid"] is True, out.answer_record
    assert out.answer_record["key"] == "num:75/1"


def test_truncated_solve_still_detected_after_purpose_filter(tmp_path):
    """按 purpose 过滤后，截断标记仍须来自 solve 而非 reflect。"""
    out = _run(tmp_path, "plan_reflect", {
        "plan": [SyntheticAction.text("PLAN: 1. compute")],
        "solve": [SyntheticAction.truncated("partial reasoning without answer")],
        "reflect": [SyntheticAction.text(
            "REFLECT: looks incomplete\nCONFIDENCE: 0.2\nVERDICT: REVISE")],
        "replan": [SyntheticAction.text("PLAN: retry")],
    })
    assert out.answer_record["valid"] is False
    assert out.answer_record["reason"] == "truncated_without_final_marker"


def test_direct_and_asc_unaffected(tmp_path):
    direct = _run(tmp_path, "direct", {"solve": [SyntheticAction.text("ANSWER: 7")]})
    assert direct.answer_record["key"] == "num:7/1"
    asc = _run(tmp_path, "asc_beta_8",
               {"baseline_solve": [SyntheticAction.text("ANSWER: 7")] * 8})
    assert asc.answer_record["valid"] is True
    assert asc.answer_record["key"] == "num:7/1"
