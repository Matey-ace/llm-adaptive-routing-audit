"""人工评审回传的还原与一致性测试。"""

from __future__ import annotations

import csv
import json
from collections import Counter

import pytest


def test_human_scores_restored_to_arms(runner_root):
    run = runner_root / "runs" / "selfhosted_main_conc_20261113"
    p = run / "review" / "human_vs_auto.json"
    if not p.is_file():
        pytest.skip("人工评审尚未回传")
    d = json.loads(p.read_text(encoding="utf-8"))
    for label, v in d["labels"].items():
        assert v["n"] == 2000, label
        assert set(v["by_arm"]) == {"direct", "planning", "plan_reflect",
                                    "adaptive_legacy", "asc_beta_8"}
        total = sum(sum(c.values()) for c in v["by_arm"].values())
        assert total == 2000


def test_human_agreement_in_reasonable_range(runner_root):
    run = runner_root / "runs" / "selfhosted_main_conc_20261113"
    p = run / "review" / "human_vs_auto.json"
    if not p.is_file():
        pytest.skip("人工评审尚未回传")
    d = json.loads(p.read_text(encoding="utf-8"))
    for label, v in d["labels"].items():
        rate = v["agreement"]["rate"]
        assert 0.0 <= rate <= 1.0, (label, rate)
        assert v["agreement"]["agree"] + v["agreement"]["disagree"] == v["n"]


def test_human_primary_interval_is_valid(runner_root):
    """Validate interval structure without constraining the scientific conclusion."""
    run = runner_root / "runs" / "selfhosted_main_conc_20261113"
    p = run / "review" / "human_vs_auto.json"
    if not p.is_file():
        pytest.skip("人工评审尚未回传")
    d = json.loads(p.read_text(encoding="utf-8"))
    for label, v in d["labels"].items():
        for src in ("gsm8k", "math"):
            pr = v["primary"][src]["primary"]
            assert -1 <= pr["difference"] <= 1, (label, src, pr["difference"])
            assert -1 <= pr["lower"] <= pr["difference"] <= pr["upper"] <= 1, (label, src, pr["lower"], pr["upper"])


def test_strict_and_contextual_are_distinct(runner_root):
    run = runner_root / "runs" / "selfhosted_main_conc_20261113"
    p = run / "review" / "human_vs_auto.json"
    if not p.is_file():
        pytest.skip("人工评审尚未回传")
    d = json.loads(p.read_text(encoding="utf-8"))
    if len(d["labels"]) < 2:
        pytest.skip("只有一套口径")
    decisions = [tuple(sorted(v["decisions"].items())) for v in d["labels"].values()]
    assert all(sum(v["decisions"].values()) == v["n"] for v in d["labels"].values())


def test_adjudication_covers_all_disagreements(runner_root):
    run = runner_root / "runs" / "selfhosted_main_conc_20261113"
    p = run / "review" / "human_vs_auto.json"
    if not p.is_file():
        pytest.skip("人工评审尚未回传")
    d = json.loads(p.read_text(encoding="utf-8"))
    labels = list(d["labels"])
    if len(labels) < 2:
        pytest.skip("只有一套口径")
    a = {r["blind_id"]: r["decision"] for r in _jsonl(
        run / "review" / f"human_scores_{labels[0].replace('.csv','')}.jsonl")}
    b = {r["blind_id"]: r["decision"] for r in _jsonl(
        run / "review" / f"human_scores_{labels[1].replace('.csv','')}.jsonl")}
    diffs = {k for k in a if a[k] != b[k]}
    assert set(a) == set(b)
    assert diffs <= set(a)


def test_human_status_matrix_exists_and_matches(runner_root):
    """人工口径的状态矩阵必须存在，且 unknown 数与人工评分一致。"""
    run = runner_root / "runs" / "selfhosted_main_conc_20261113"
    p = run / "review" / "human_score_sheet_status_matrix_summary.json"
    if not p.is_file():
        pytest.skip("人工状态矩阵未生成")
    s = json.loads(p.read_text(encoding="utf-8"))
    assert s["n_rows"] == 2000
    assert s["overall"].get("unknown") == 1
    assert sum(s["overall"].values()) == 2000


def test_auto_and_human_matrices_use_same_denominator(runner_root):
    run = runner_root / "runs" / "selfhosted_main_conc_20261113"
    a = run / "status_matrix_summary.json"
    h = run / "review" / "human_score_sheet_status_matrix_summary.json"
    if not (a.is_file() and h.is_file()):
        pytest.skip("缺状态矩阵")
    sa = json.loads(a.read_text(encoding="utf-8"))
    sh = json.loads(h.read_text(encoding="utf-8"))
    assert sa["n_rows"] == sh["n_rows"] == 2000


def _jsonl(path):
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines()
            if l.strip()]
