"""评分、统计、盲评、分析（工作包 F 与 E 第 13–14 项）。"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from sncs_fivearm.evaluation import ANALYSIS_PLAN_VERSION, SCORE_SCHEMA_VERSION
from sncs_fivearm.evaluation.analysis import (accuracy_by_arm, build_report,
                                              markdown_table, plan_task_ids)
from sncs_fivearm.evaluation.blind import build_blind_package
from sncs_fivearm.evaluation.gold import GoldItem, gsm8k_gold, math_gold
from sncs_fivearm.evaluation.scoring import (COMPARATOR_VERSION, score_one,
                                             score_run)
from sncs_fivearm.evaluation.stats import (StatsError, build_lookup,
                                           clopper_pearson, compare_arms,
                                           mcnemar_exact,
                                           paired_difference_interval)


# ---------------------------------------------------------------- gold 解析
def test_gsm8k_gold_extracts_after_hash():
    assert gsm8k_gold("reasoning here\n#### 1,234") == "1,234"


def test_math_gold_extracts_boxed():
    assert math_gold("blah \\boxed{\\frac{3}{4}} end") == "\\frac{3}{4}"


def test_math_gold_nested_boxed():
    assert math_gold("x \\boxed{\\sqrt{\\frac{1}{2}}}") == "\\sqrt{\\frac{1}{2}}"


# ---------------------------------------------------------------- 三分评分
def _gold(text, source="gsm8k"):
    metric = "gsm8k_numeric" if source == "gsm8k" else "math_equiv"
    return GoldItem(task_id="T", source=source, gold_text=text, metric=metric)


def test_correct_incorrect_unknown_are_three_way():
    assert score_one(task_id="T", run_id="R", strategy="direct",
                     final_answer="ANSWER: 42", gold=_gold("42")).decision == "correct"
    assert score_one(task_id="T", run_id="R", strategy="direct",
                     final_answer="ANSWER: 41", gold=_gold("42")).decision == "incorrect"
    assert score_one(task_id="T", run_id="R", strategy="direct",
                     final_answer="", gold=_gold("42")).decision == "unknown"


def test_empty_answer_is_unknown_not_incorrect():
    r = score_one(task_id="T", run_id="R", strategy="asc_beta_8",
                  final_answer="", gold=_gold("42"))
    assert r.decision == "unknown"
    assert r.needs_review is True
    assert r.value is None


def test_equivalent_representation_scores_correct():
    assert score_one(task_id="T", run_id="R", strategy="direct",
                     final_answer="ANSWER: 0.5",
                     gold=_gold("1/2", "math")).decision == "correct"


def test_unparseable_gold_is_unknown():
    """gold 无法归入任何类键（超长短语/散文）→ unknown，而不是判错。"""
    r = score_one(task_id="T", run_id="R", strategy="direct",
                  final_answer="ANSWER: 42",
                  gold=_gold("the reasoning above shows a long chain of steps that "
                             "cannot be reduced to a single comparable value, and "
                             "therefore the reference answer is not a key at all"))
    assert r.decision == "unknown"
    assert r.reason == "gold_unclassifiable"


def test_short_literal_gold_uses_text_key():
    """短字面答案（如 yes）走 text 键，不因为不是数字就判 unknown。"""
    r = score_one(task_id="T", run_id="R", strategy="direct",
                  final_answer="ANSWER: yes",
                  gold=_gold("yes", "math"))
    assert r.decision == "correct"
    assert r.gold_key.startswith("text:")


# ---------------------------------------------------------------- 恒等性（政策漏洞守卫）
@pytest.mark.parametrize("answer", [
    "42",
    "3/4",
    "\\frac{\\pi^2}{8}",
    "\\left[ \\frac{\\pi^2}{8}, \\frac{5 \\pi^2}{4} \\right]",
    "\\begin{pmatrix} 0 & -15 \\\\ -2 & -4 \\end{pmatrix}",
    "y = \\frac{1}{2} x + 2",
    "x + 2",
    "(1, 2)",
    "\\{1,2,3\\}",
    "-12x -3",
    "\\$150",
    "991",
])
def test_identity_scoring_accepts_every_real_answer_shape(answer):
    """把 gold 原样当预测：必须 correct。否则说明该类真实答案无法归类。"""
    r = score_one(task_id="T", run_id="R", strategy="direct",
                  final_answer="ANSWER: " + answer,
                  gold=_gold(answer, "math"))
    assert r.decision == "correct", (answer, r.decision, r.reason)


def test_structured_answers_get_struct_key():
    from sncs_fivearm.answers import answer_key, struct_key
    for s in ("\\left[ a, b \\right]", "y = 2x + 1", "(1, 2)",
              "\\begin{pmatrix} 1 & 2 \\end{pmatrix}"):
        key, kind = answer_key(s)
        assert kind == "structured", (s, kind)
        assert key.startswith("struct:")


def test_prose_still_unclassifiable_after_struct_key():
    """加了 struct 键之后，散文仍不得被当成答案类别。"""
    from sncs_fivearm.answers import answer_key
    assert answer_key("not a key at all")[0] is None


def test_score_versions_are_stamped():
    r = score_one(task_id="T", run_id="R", strategy="direct",
                  final_answer="ANSWER: 1", gold=_gold("1"))
    assert r.comparator_version == COMPARATOR_VERSION
    assert r.score_schema_version == SCORE_SCHEMA_VERSION


def test_score_run_refuses_to_overwrite(tmp_path):
    results = tmp_path / "results.jsonl"
    results.write_text(json.dumps({
        "run_id": "R", "task_id": "T", "source": "gsm8k", "strategy": "direct",
        "outcome": {"final_answer": "ANSWER: 42"},
    }) + "\n", encoding="utf-8")
    out = tmp_path / "scores_v1.jsonl"
    gold = {"T": _gold("42")}
    score_run(results_path=results, gold=gold, out_path=out, source_sha256="x")
    with pytest.raises(FileExistsError):
        score_run(results_path=results, gold=gold, out_path=out, source_sha256="x")


# ---------------------------------------------------------------- 统计
def test_clopper_pearson_bounds():
    lo, hi = clopper_pearson(0, 10)
    assert lo == 0.0 and 0.2 < hi < 0.35
    lo, hi = clopper_pearson(10, 10)
    assert hi == 1.0 and 0.65 < lo < 0.80


def test_paired_interval_is_not_two_independent_intervals():
    ci = paired_difference_interval(10, 2, 200)
    assert ci["method"] == "paired_discordant_clopper_pearson_union_bound"
    assert ci["difference"] == pytest.approx(8 / 200)
    assert ci["lower"] < ci["difference"] < ci["upper"]


def test_mcnemar_exact_symmetric_and_known():
    assert mcnemar_exact(0, 0) == 1.0
    assert mcnemar_exact(5, 5) == pytest.approx(1.0)
    assert mcnemar_exact(10, 0) == pytest.approx(2 * 0.5 ** 10)


def _scored(rows):
    return [{"task_id": t, "strategy": a, "source": "gsm8k",
             "score": {"decision": d}} for t, a, d in rows]


def test_compare_arms_paired_table():
    scored = _scored([
        ("t1", "adaptive_legacy", "correct"), ("t1", "plan_reflect", "incorrect"),
        ("t2", "adaptive_legacy", "incorrect"), ("t2", "plan_reflect", "correct"),
        ("t3", "adaptive_legacy", "correct"), ("t3", "plan_reflect", "correct"),
    ])
    lookup = build_lookup(scored)
    r = compare_arms(lookup=lookup, source="gsm8k", task_ids=["t1", "t2", "t3"],
                     arm_a="adaptive_legacy", arm_b="plan_reflect")
    assert r["paired_table"] == {"both_correct": 1, "a_only": 1,
                                 "b_only": 1, "neither_correct": 0}
    assert r["n_known_pairs"] == 3
    assert r["primary"]["difference"] == pytest.approx(0.0)


def test_compare_arms_reports_no_complete_pairs_explicitly():
    scored = _scored([
        ("t1", "adaptive_legacy", "unknown"), ("t1", "plan_reflect", "unknown"),
    ])
    lookup = build_lookup(scored)
    r = compare_arms(lookup=lookup, source="gsm8k", task_ids=["t1"],
                     arm_a="adaptive_legacy", arm_b="plan_reflect")
    assert r["status"] == "NO_COMPLETE_PAIRS"
    assert r["primary"] is None
    assert "note" in r


def test_identification_bounds_for_unknown():
    scored = _scored([
        ("t1", "adaptive_legacy", "correct"), ("t1", "plan_reflect", "unknown"),
    ])
    lookup = build_lookup(scored)
    r = compare_arms(lookup=lookup, source="gsm8k", task_ids=["t1"],
                     arm_a="adaptive_legacy", arm_b="plan_reflect")
    ib = r["identification_bounds"]
    assert ib["lower"] == pytest.approx(0.0)   # 1 - 1
    assert ib["upper"] == pytest.approx(1.0)   # 1 - 0
    assert ib["unknown_or_missing_pairs"] == 1


def test_all_unknown_does_not_fabricate_numbers():
    scored = _scored([(f"t{i}", "adaptive_legacy", "unknown") for i in range(5)]
                     + [(f"t{i}", "plan_reflect", "unknown") for i in range(5)])
    lookup = build_lookup(scored)
    ids = [f"t{i}" for i in range(5)]
    r = compare_arms(lookup=lookup, source="gsm8k", task_ids=ids,
                     arm_a="adaptive_legacy", arm_b="plan_reflect")
    assert r["status"] == "NO_COMPLETE_PAIRS"
    assert r["denominators"]["a_unknown"] == 5
    assert r["denominators"]["a_scorable"] == 0


def test_accuracy_by_arm_separates_not_started():
    scored = _scored([("t1", "direct", "correct")])
    acc = accuracy_by_arm(scored, ["t1", "t2"], "direct")
    assert acc["n_planned"] == 2 and acc["n_scored"] == 1
    assert acc["not_started"] == 1
    assert acc["accuracy_pessimistic"] == pytest.approx(0.5)
    assert acc["accuracy_optimistic"] == pytest.approx(1.0)


def test_invalid_ci_arguments_rejected():
    with pytest.raises(StatsError):
        paired_difference_interval(5, 5, 3)
    with pytest.raises(StatsError):
        clopper_pearson(3, 2)


# ---------------------------------------------------------------- 盲评
def test_blind_package_hides_method_identity():
    results = [
        {"run_id": f"R{i}", "task_id": f"t{i}", "strategy": s,
         "execution_position": i + 1, "source": "gsm8k",
         "outcome": {"final_answer": f"ANSWER: {i}",
                     "answer_record": {"valid": True}}}
        for i, s in enumerate(["direct", "planning", "plan_reflect",
                               "adaptive_legacy", "asc_beta_8"])
    ]
    prompts = {f"t{i}": type("P", (), {"prompt": f"Question {i}"})()
               for i in range(5)}
    pkg = build_blind_package(results_rows=results, prompts=prompts, seed=7)
    for row in pkg["public_rows"]:
        assert set(row) == {"blind_id", "task_id", "source", "prompt", "submitted_answer"}
        assert "strategy" not in row
        assert "run_id" not in row
    assert len(pkg["mapping"]) == 5
    assert pkg["manifest"]["hidden_fields"]
    assert "limitation" in str(pkg["manifest"]).lower() or \
        "limitation" in pkg["manifest"]


# ---------------------------------------------------------------- 分析
def test_report_and_markdown_generate(tmp_path):
    scored = _scored([
        ("t1", "adaptive_legacy", "correct"), ("t1", "plan_reflect", "incorrect"),
        ("t1", "direct", "correct"), ("t1", "planning", "incorrect"),
        ("t1", "asc_beta_8", "correct"),
    ])
    queue = [{"phase": "preflight", "source": "gsm8k", "task_id": "t1"}]
    results = [{"strategy": s, "task_id": "t1", "outcome": {"dispatches": 1,
                                                            "steps": []}}
               for s in ("direct", "planning", "plan_reflect",
                         "adaptive_legacy", "asc_beta_8")]
    rep = build_report(scored_rows=scored, results_rows=results,
                       queue_rows=queue, phase="preflight")
    assert "gsm8k" in rep["sources"]
    md = markdown_table(rep)
    assert "adaptive_legacy" in md and "主要对比" in md
    assert rep["plan_version"] == ANALYSIS_PLAN_VERSION


def test_plan_task_ids_preserves_queue_order():
    q = [{"phase": "main", "source": "gsm8k", "task_id": "b"},
         {"phase": "main", "source": "gsm8k", "task_id": "a"},
         {"phase": "main", "source": "math", "task_id": "c"}]
    assert plan_task_ids(q, "main", "gsm8k") == ["b", "a"]
    assert plan_task_ids(q, "main", "math") == ["c"]
