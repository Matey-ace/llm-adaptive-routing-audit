"""信息隔离：生成路径不得接触 gold 或评分模块。

用 AST 静态扫描 + 运行时守卫两条独立证据：

1. 静态：生成路径的源码里不得出现 `evaluation.gold` / `evaluation.scoring` 的导入，
   也不得出现 `gold` 字段访问（字面字符串 `"gold"` 在允许清单之外）。
2. 运行时：在导入生成模块后，`evaluation.gold` 不在 `sys.modules` 里
   （证明它没有被间接拉入）。
"""

from __future__ import annotations

import ast
import subprocess
import sys
from pathlib import Path

import pytest

GENERATION_PACKAGE_PARTS = (
    "registry.py", "dispatcher.py", "runner.py", "inputs.py", "budget.py",
    "journal.py", "contracts.py", "providers/__init__.py", "answers/__init__.py",
    "answers/asc.py", "simulation_runner.py", "system.py",
)

FORBIDDEN_MODULES = ("evaluation.gold", "evaluation.scoring", "evaluation.blind",
                     "evaluation.analysis", "evaluation.stats")

# 允许出现 "gold" 字面的位置：说明性文档串与"拒绝 gold"的字段清单
ALLOWED_GOLD_LITERAL_FILES = {"inputs.py", "answers/__init__.py"}


def _package_root() -> Path:
    return Path(__file__).resolve().parents[1] / "src" / "sncs_fivearm"


def _py_files():
    root = _package_root()
    for p in sorted(root.rglob("*.py")):
        if "legacy_root" in p.parts or "__pycache__" in p.parts:
            continue
        yield p


def test_generation_modules_do_not_import_gold_or_scoring():
    offenders = []
    for p in _py_files():
        tree = ast.parse(p.read_text(encoding="utf-8"), filename=str(p))
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                for bad in FORBIDDEN_MODULES:
                    if node.module == bad or node.module.startswith(bad + "."):
                        offenders.append((p.name, node.lineno, node.module))
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    for bad in FORBIDDEN_MODULES:
                        if alias.name == bad or alias.name.startswith(bad + "."):
                            offenders.append((p.name, node.lineno, alias.name))
    # evaluation 包内部引用彼此是允许的；生成路径不允许
    offenders = [o for o in offenders
                 if not o[0].startswith("evaluation")]
    # 从 evaluation 包外引用 evaluation.* 的只允许出现在 cli.py（命令分派）里
    offenders = [o for o in offenders if o[0] != "cli.py"]
    assert not offenders, f"生成路径出现了 gold/评分导入: {offenders}"


def test_no_gold_field_access_in_generation_paths():
    problems = []
    root = _package_root()
    for rel in GENERATION_PACKAGE_PARTS:
        p = root / rel
        if not p.is_file():
            continue
        text = p.read_text(encoding="utf-8")
        if rel.replace("\\", "/") in ALLOWED_GOLD_LITERAL_FILES:
            continue
        if '"gold"' in text or "'gold'" in text:
            problems.append(rel)
    assert not problems, f"这些生成模块出现了 gold 字段字面量: {problems}"


def test_importing_runner_does_not_pull_gold_module():
    code = (
        "import sys\n"
        "sys.path.insert(0, r'{src}')\n"
        "import sncs_fivearm.runner\n"
        "import sncs_fivearm.registry\n"
        "import sncs_fivearm.dispatcher\n"
        "import sncs_fivearm.inputs\n"
        "bad = [m for m in sys.modules if m.startswith('sncs_fivearm.evaluation.gold')"
        " or m.startswith('sncs_fivearm.evaluation.scoring')]\n"
        "assert not bad, bad\n"
        "print('OK')\n"
    ).format(src=(_package_root().parents[0]))
    done = subprocess.run([sys.executable, "-B", "-X", "utf8", "-c", code],
                          capture_output=True, text=True, encoding="utf-8", timeout=120)
    assert done.returncode == 0, done.stdout + done.stderr


def test_prompt_store_carries_no_scoring_fields(prep_dir):
    import json
    allowed = {"task_id", "prompt", "prompt_sha256"}
    rows = [json.loads(s) for s in
            (prep_dir / "draft" / "generation_prompt_only_420.jsonl")
            .read_text(encoding="utf-8").splitlines() if s.strip()]
    assert all(set(r) == allowed for r in rows)


def test_queue_rows_have_no_scoring_fields(prep_dir):
    import json
    forbidden = {"gold", "answer", "success", "score", "labels",
                 "reference_answer", "prompt"}
    for name in ("preflight_five_arm_queue_100.jsonl", "main_five_arm_queue_2000.jsonl"):
        rows = [json.loads(s) for s in
                (prep_dir / "draft" / name).read_text(encoding="utf-8").splitlines()
                if s.strip()]
        assert not any(forbidden.intersection(r) for r in rows), name


def test_agent_view_has_only_three_fields(legacy):
    av = legacy.agent_view.AgentView(task_id="T", prompt="P")
    assert set(av.__dict__) == {"task_id", "prompt", "tools_allowed"}
    with pytest.raises(Exception):
        av.task_id = "changed"  # frozen dataclass


def test_gold_bearing_task_cannot_be_passed_to_agent_view(legacy):
    """AgentView 不接收 gold；含 gold 的 Task 必须先剥离。"""
    Task = legacy.tasks_dataset.Task
    t = Task(task_id="T", task_type="math", difficulty="hard",
             difficulty_anchor={}, prompt="P", gold="42", metric="gsm8k_numeric")
    views = legacy.agent_view.to_agent_view(t)
    assert not hasattr(views, "gold")
    assert views.prompt == "P"
