"""共享 pytest 夹具。

纪律：
* 所有测试默认**离线**：使用合成 provider，不发任何网络请求。
* 测试写到 tmp_path，不污染 runs/ 与 evidence/。
* 真实输入（准备包）只读；不接受写入。
"""

from __future__ import annotations

import sys
import os
from pathlib import Path

import pytest

RUNNER_ROOT = Path(__file__).resolve().parents[1]
SRC = RUNNER_ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

WORKSPACE = RUNNER_ROOT.parent
WORKSPACE = Path(os.environ.get("SNCS_WORKSPACE_ROOT", WORKSPACE))
PREP_DIR = WORKSPACE / "SNCS_Experiment_Preparation_20261110"


@pytest.fixture(scope="session")
def runner_root() -> Path:
    return Path(os.environ.get("SNCS_ARCHIVE_FIXTURES", RUNNER_ROOT))


@pytest.fixture(scope="session")
def prep_dir() -> Path:
    if not PREP_DIR.is_dir():
        pytest.skip(f"准备包不可用: {PREP_DIR}")
    return PREP_DIR


@pytest.fixture(scope="session")
def workspace() -> Path:
    return WORKSPACE


@pytest.fixture()
def legacy():
    from sncs_fivearm.runtime import load_legacy
    return load_legacy()


@pytest.fixture()
def offline_contract():
    from sncs_fivearm.simulation_runner import ownerless_contract
    return ownerless_contract()
