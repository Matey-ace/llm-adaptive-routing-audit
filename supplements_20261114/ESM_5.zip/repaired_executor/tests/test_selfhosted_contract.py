"""自部署 DS 4.1 正式实验合同与守卫测试。

纪律：
* 必须走本机端点，不发外部付费；
* `author_execution_approval` 记录作者原话；
* 版本一致性是**作者声明**，不是独立认证；
* 费用结论被显式禁用；
* 主筛查队列 2000 条、400 题、五臂齐全。
"""

from __future__ import annotations

import json

import pytest

from sncs_fivearm.contracts import Contract
from sncs_fivearm.inputs import ARMS, build_bundle, select_phase


PREP = None  # 由 fixture 注入


def test_selfhosted_contract_is_ready_and_locked(runner_root):
    p = runner_root / "configs" / "execution_contract_SELFHOSTED_v2.json"
    assert p.is_file()
    c = Contract.load(p, approvals_dir=runner_root / "configs" / "approvals")
    assert c.mode == "local_gateway"
    assert c.live_ready is True, c.problems
    assert c.get("provider.base_url") == "http://127.0.0.1:8787"
    assert c.get("provider.model_id") == "deepseek-v4.1-flash"
    assert c.get("provider.thinking.reasoning_effort") == "high"
    assert c.get("phase_scope") == ["preflight", "main"]
    assert c.get("budget.cost_conclusion_allowed") is False
    assert c.get("tariff.source.provider_validated") is False


def test_author_quote_is_recorded(runner_root):
    d = json.loads((runner_root / "configs" / "execution_contract_SELFHOSTED_v2.json")
                   .read_text(encoding="utf-8-sig"))
    quote = d["author_execution_approval"]["quote"]
    assert "可以开始实验" in quote
    assert "学校机房" in quote
    assert "DS 4.1" in quote
    assert d["local_gateway_authorization"]["quote"] == quote
    assert d["local_gateway_authorization"]["external_billing"] is False
    assert d["approval"]["note"] and "不参与门限" in d["approval"]["note"]


def test_version_consistency_is_declared_not_verified(runner_root):
    d = json.loads((runner_root / "configs" / "execution_contract_SELFHOSTED_v2.json")
                   .read_text(encoding="utf-8-sig"))
    claims = d["deployment_claims"]
    assert claims["source"] == "author_statement_not_independently_verified"
    assert any("版本一致" in c for c in claims["claims"])
    assert any("权重文件" in c or "逐字节" in c
               for c in claims["what_project_cannot_verify"])
    assert "据作者说明" in claims["mitigation"] or "同一端点" in claims["mitigation"]


def test_protocol_record_exists(runner_root):
    text = (runner_root / "protocol" / "Selfhosted_Experiment_Record.md").read_text(
        encoding="utf-8")
    assert "不是" in text and "实验免费" in text
    assert "不得" in text and "成本为 0" in text
    assert "作者声明" in text


def test_main_queue_is_2000_with_five_arms(prep_dir):
    bundle = build_bundle(
        phase="main",
        manifest_path=prep_dir / "manifests_v2" / "main_tasks_400.json",
        prompt_store_path=prep_dir / "draft" / "generation_prompt_only_420.jsonl",
        queue_path=prep_dir / "draft" / "main_five_arm_queue_2000.jsonl",
        prep_dir=prep_dir)
    q = select_phase(bundle.queue, "main")
    assert len(q) == 2000
    assert len({r.task_id for r in q}) == 400
    assert {r.strategy for r in q} == set(ARMS)
    assert [r.sequence for r in q] == list(range(1, 2001))


def test_live_external_contract_still_requires_approval(tmp_path):
    """对照：live 模式不能借自部署合同绕过外部批准。"""
    from sncs_fivearm.contracts import draft_contract
    raw = draft_contract()
    raw["execution_mode"] = "live"
    p = tmp_path / "c.json"
    p.write_text(json.dumps(raw, ensure_ascii=False), encoding="utf-8")
    c = Contract.load(p, approvals_dir=tmp_path / "approvals")
    assert c.live_ready is False
