"""答案解析与 ASC 机制测试（工作包 C 的全部枚举项）。"""

from __future__ import annotations

from fractions import Fraction

import pytest

from sncs_fivearm.answers import (AnswerRecord, POLICY_VERSION, alias_of,
                                  answer_key, keys_equivalent,
                                  number_key, parse_answer_attempt, text_key)
from sncs_fivearm.answers.asc import (AscRunner, MAX_ATTEMPTS, STOP_CAP,
                                      STOP_THRESHOLD, AscOutcome,
                                      sequential_confidence, should_stop_now,
                                      final_answer_text)
from sncs_fivearm.answers.asc_beta_core import (summarize_attempts,
                                               top_two_confidence)


# ---------------------------------------------------------------- ASC 数学
def test_three_same_not_enough_four_stops():
    assert top_two_confidence(3) == Fraction(15, 16) < Fraction(95, 100)
    assert top_two_confidence(4) == Fraction(31, 32) > Fraction(95, 100)


def test_second_most_frequent_changes_posterior():
    # a=3, b=1 → 13/16 = 0.8125 < 0.95，不应停止
    assert top_two_confidence(3, 1) == Fraction(13, 16)
    assert float(top_two_confidence(3, 1)) < 0.95


def test_third_category_does_not_merge_into_b():
    # ['7','8','7','9','7'] → a=3, b=1（8 与 9 各 1，取第二高频 = 1）
    r = sequential_confidence(["num:7/1", "num:8/1", "num:7/1", "num:9/1", "num:7/1"])
    assert r[-1] == pytest.approx(float(top_two_confidence(3, 1)), abs=1e-12)


def test_invalid_consumes_attempt_but_votes_not():
    keys = [None, None, None, None, "num:7/1", "num:7/1", "num:7/1", "num:7/1"]
    r = summarize_attempts(keys)
    assert r["attempts"] == 8
    assert r["stop_reason"] == "asc_beta_threshold"
    assert sum(1 for h in r["history"] if h["valid"]) == 4


def test_all_invalid_is_explicit_failure():
    r = summarize_attempts([None] * 12)
    assert r["attempts"] == 8
    assert r["selected_key"] is None
    assert r["stop_reason"] == "attempt_cap"


def test_persistent_tie_uses_cap_and_earliest():
    r = summarize_attempts(["7", "8"] * 4)
    assert r["attempts"] == 8
    assert r["selected_key"] == "7"
    assert r["posterior_top_two"] == 0.5


def test_ninth_item_never_consumed():
    def gen():
        for i in range(8):
            yield str(i % 2)
        raise AssertionError("第 9 项被消费")

    r = summarize_attempts(gen())
    assert r["attempts"] == 8


# ---------------------------------------------------------------- ASC runner
def _rec(text: str, finish: str = "stop") -> AnswerRecord:
    return parse_answer_attempt(text, finish_reason=finish)


def test_runner_early_stop_skips_remaining():
    draws = []

    def draw(i):
        draws.append(i)
        return _rec("ANSWER: 4")

    out = AscRunner().run(draw)
    assert out.attempts == 4
    assert out.stop_reason == STOP_THRESHOLD
    assert len(draws) == 4
    assert out.early_stop_skipped_attempts == MAX_ATTEMPTS - 4


def test_runner_cap_never_requests_ninth():
    calls = {"n": 0}

    def draw(i):
        calls["n"] += 1
        return _rec(f"ANSWER: {i}")

    out = AscRunner().run(draw)
    assert out.attempts == 8
    assert calls["n"] == 8
    assert out.stop_reason == STOP_CAP


def test_runner_blocked_stops_without_drawing():
    draws = []

    def draw(i):
        draws.append(i)
        return _rec("ANSWER: 1")

    def blocked(i):
        return "budget_stop" if i >= 3 else None

    out = AscRunner().run(draw, blocked=blocked)
    assert out.attempts == 2
    assert out.stop_reason == "budget_stop"
    assert len(draws) == 2


def test_runner_records_selected_raw_span():
    seq = ["ANSWER: 3/4", "ANSWER: 0.75", "ANSWER: 0.75", "ANSWER: 3/4"]

    def draw(i):
        return _rec(seq[i - 1])

    out = AscRunner().run(draw)
    assert out.stop_reason == STOP_THRESHOLD
    # 原始片段必须保留（不是规范化字符串）
    assert out.selected_raw_span in ("3/4", "0.75")
    assert out.selected_key is not None
    assert out.selected_key.startswith("num:")


def test_final_answer_text_preserves_original():
    seq = ["ANSWER: 1/2", "ANSWER: 0.5", "ANSWER: 0.5", "ANSWER: 0.5"]

    def draw(i):
        return _rec(seq[i - 1])

    runner = AscRunner()
    out = runner.run(draw)
    txt = final_answer_text(out, runner.attempts)
    assert txt in ("1/2", "0.5")


# ---------------------------------------------------------------- 提取政策
def test_same_value_different_representation_same_key():
    keys = {number_key(s) for s in ("0.5", "1/2", "0.50", "\\frac{1}{2}", ".5")}
    assert len(keys) == 1
    assert keys.pop() == "num:1/2"


def test_thousands_separator_and_sign():
    assert number_key("1,234") == number_key("1234")
    assert number_key("-12.5") == number_key("-12.5")
    assert number_key("-12.5") != number_key("12.5")


def test_different_values_are_not_merged():
    assert number_key("2") != number_key("x+2")
    assert number_key("2/3") != number_key("5/3")
    assert number_key("2") != number_key("\\sqrt{2}")


def test_symbolic_key_keeps_variables():
    assert answer_key("2x")[0] == answer_key("x*2")[0]
    assert answer_key("x+2")[0] != answer_key("2")[0]


def test_empty_and_truncated_are_invalid():
    assert parse_answer_attempt("").valid is False
    assert parse_answer_attempt("", finish_reason="length").reason == "empty_content"
    r = parse_answer_attempt("partial reasoning only", finish_reason="length")
    assert r.valid is False
    assert r.reason == "truncated_without_final_marker"


def test_truncated_with_marker_is_valid():
    r = parse_answer_attempt("...thinking...\nANSWER: 42", finish_reason="length")
    assert r.valid is True
    assert r.key == "num:42/1"


def test_nested_boxed():
    r = parse_answer_attempt(r"so \boxed{\frac{3}{4}} is the answer")
    assert r.valid is True
    assert r.key == "num:3/4"


def test_conflicting_markers_flagged():
    r = parse_answer_attempt("ANSWER: 1\nmore\nANSWER: 2")
    assert r.valid is True
    assert r.conflicting_markers is True
    assert r.key == "num:2/1"


def test_whole_text_answer_requires_short_literal():
    long_prose = "The answer requires careful consideration " * 30
    assert parse_answer_attempt(long_prose).valid is False


def test_gold_free_policy_version_stamped():
    r = parse_answer_attempt("ANSWER: 7")
    assert r.policy_version == POLICY_VERSION


def test_keys_equivalent_is_strict():
    assert keys_equivalent("num:1/2", "num:1/2") is True
    assert keys_equivalent("num:1/2", "num:2/4") is False  # 键在生成时已规范化
    assert keys_equivalent(None, None) is False
