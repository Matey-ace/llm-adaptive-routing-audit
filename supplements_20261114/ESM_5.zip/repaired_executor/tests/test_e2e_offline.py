"""端到端离线验收：12 个场景 + 真实队列小样本 + 崩溃恢复。

覆盖工作包 E 的第 2、3、4、5、9、10、12 项，并给出可复现证据文件。
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from sncs_fivearm.inputs import build_bundle, select_phase
from sncs_fivearm.journal import Journal, resume_plan


@pytest.fixture(scope="module")
def suite_receipt(tmp_path_factory):
    from sncs_fivearm.simulation_runner import run_scenario_suite
    out = tmp_path_factory.mktemp("scenarios")
    ev = tmp_path_factory.mktemp("evidence")
    return run_scenario_suite(suite_path=None, out_dir=out, evidence_dir=ev)


def test_scenario_suite_passes(suite_receipt):
    assert suite_receipt["status"] == "PASS", [
        (c["scenario_id"], [k for k in c["checks"] if not k["passed"]])
        for c in suite_receipt["checks"] if not c["passed"]]
    assert suite_receipt["scenarios"] >= 12
    assert suite_receipt["network_calls"] == 0
    assert suite_receipt["live_calls"] == 0


@pytest.mark.parametrize("scenario_id", [
    "asc_early_stop", "asc_cap", "asc_all_invalid", "identical_answers",
    "second_place", "truncated", "missing_usage", "transport_failures",
    "plan_reflect_cap", "adaptive_judge", "budget_stop", "conflicting_markers",
])
def test_each_scenario_passed(suite_receipt, scenario_id):
    row = next(c for c in suite_receipt["checks"] if c["scenario_id"] == scenario_id)
    failed = [c["name"] for c in row["checks"] if not c["passed"]]
    assert row["passed"], f"{scenario_id} 未通过的检查: {failed}"


# ---------------------------------------------------------------- 真实队列小样本
def test_real_queue_small_sample_offline(tmp_path, prep_dir):
    """用真实预检队列的前 2 题（10 条轨迹）跑离线模拟，证明五臂都经过 dispatcher。"""
    from sncs_fivearm.providers import PurposeSyntheticProvider, SyntheticAction
    from sncs_fivearm.runner import RunConfig, Runner
    from sncs_fivearm.simulation_runner import ownerless_contract

    bundle = build_bundle(
        phase="preflight",
        manifest_path=prep_dir / "manifests_v2" / "preflight_tasks_20.json",
        prompt_store_path=prep_dir / "draft" / "generation_prompt_only_420.jsonl",
        queue_path=prep_dir / "draft" / "preflight_five_arm_queue_100.jsonl",
        prep_dir=prep_dir)
    queue = select_phase(bundle.queue, "preflight")[:10]
    assert len(queue) == 10
    assert len({r.task_id for r in queue}) == 2

    purpose = {
        "judge": [SyntheticAction.text(
            '{"level": "medium", "confidence": 0.7, "reasoning_steps": 2, "reason": "ok"}')],
        "plan": [SyntheticAction.text("PLAN:\n1. step")],
        "solve": [SyntheticAction.text("ANSWER: 42")],
        "baseline_solve": [SyntheticAction.text("ANSWER: 42")],
        "reflect": [SyntheticAction.text(
            "REFLECT:\n- fine\nCONFIDENCE: 0.9\nVERDICT: PASS")],
        "replan": [SyntheticAction.text("PLAN:\n1. retry")],
    }
    provider = PurposeSyntheticProvider(purpose)
    cfg = RunConfig(run_id="offline_realqueue", phase="preflight",
                    contract=ownerless_contract(), bundle=bundle, queue=queue,
                    purpose="offline_simulation", notes="real queue, synthetic provider")
    summary = Runner(config=cfg, provider=provider, runs_root=tmp_path,
                     package_root=Path(__file__).resolve().parents[1] / "src" / "sncs_fivearm"
                     ).execute()

    assert summary.completed == 10, summary.as_dict()
    assert summary.failed == 0
    assert summary.known_charge_micro > 0

    journal = Journal(tmp_path / "offline_realqueue" / "journal.jsonl")
    events = journal.read_all()
    intents = [e for e in events if e["event"] == "dispatch_intent_durable"]
    assert intents, "必须有派发记录"
    # 每个臂至少出现一次
    strategies = {r.strategy for r in queue}
    assert strategies == {"direct", "planning", "plan_reflect",
                          "adaptive_legacy", "asc_beta_8"}
    # 所有派发都有对应的预留与结算/未决
    reservations = {e["request_id"] for e in events
                    if e["event"] == "reservation_created"}
    settled = {e["request_id"] for e in events if e["event"] == "usage_settled"}
    unresolved = {e["request_id"] for e in events
                  if e["event"] == "reconciliation_required"}
    assert reservations == settled | unresolved
    # 每条轨迹都不超过 8 次
    counts = {}
    for e in intents:
        counts[e["run_id"]] = counts.get(e["run_id"], 0) + 1
    assert all(v <= 8 for v in counts.values()), counts


def test_all_five_arms_dispatch_through_shared_path(tmp_path, prep_dir):
    """五臂的每一次派发都能在共享 journal 中找到（无旁路）。"""
    from sncs_fivearm.providers import PurposeSyntheticProvider, SyntheticAction
    from sncs_fivearm.runner import RunConfig, Runner
    from sncs_fivearm.simulation_runner import ownerless_contract

    bundle = build_bundle(
        phase="preflight",
        manifest_path=prep_dir / "manifests_v2" / "preflight_tasks_20.json",
        prompt_store_path=prep_dir / "draft" / "generation_prompt_only_420.jsonl",
        queue_path=prep_dir / "draft" / "preflight_five_arm_queue_100.jsonl",
        prep_dir=prep_dir)
    queue = select_phase(bundle.queue, "preflight")[:5]
    purpose = {
        "judge": [SyntheticAction.text(
            '{"level": "medium", "confidence": 0.7, "reasoning_steps": 2, "reason": "ok"}')],
        "plan": [SyntheticAction.text("PLAN:\n1. step")],
        "solve": [SyntheticAction.text("ANSWER: 7")],
        "baseline_solve": [SyntheticAction.text("ANSWER: 7")],
        "reflect": [SyntheticAction.text(
            "REFLECT:\n- fine\nCONFIDENCE: 0.9\nVERDICT: PASS")],
        "replan": [SyntheticAction.text("PLAN:\n1. retry")],
    }
    provider = PurposeSyntheticProvider(purpose)
    cfg = RunConfig(run_id="offline_arms", phase="preflight",
                    contract=ownerless_contract(), bundle=bundle, queue=queue,
                    purpose="offline_simulation")
    Runner(config=cfg, provider=provider, runs_root=tmp_path,
           package_root=Path(__file__).resolve().parents[1] / "src" / "sncs_fivearm"
           ).execute()

    events = Journal(tmp_path / "offline_arms" / "journal.jsonl").read_all()
    per_strategy = {}
    for row in queue:
        rid_prefix = row.run_id
        n = sum(1 for e in events
                if e["event"] == "dispatch_intent_durable"
                and str(e.get("run_id")) == rid_prefix)
        per_strategy[row.strategy] = per_strategy.get(row.strategy, 0) + n
    for arm in ("direct", "planning", "plan_reflect", "adaptive_legacy", "asc_beta_8"):
        assert per_strategy.get(arm, 0) >= 1, f"{arm} 没有派发记录"

    # provider 只被经过 dispatcher 调用
    assert len(provider.calls) == sum(1 for e in events
                                      if e["event"] == "dispatch_intent_durable")


# ---------------------------------------------------------------- 崩溃恢复
def test_resume_after_partial_run_does_not_redispatch(tmp_path, prep_dir):
    from sncs_fivearm.providers import PurposeSyntheticProvider, SyntheticAction
    from sncs_fivearm.runner import RunConfig, Runner
    from sncs_fivearm.simulation_runner import ownerless_contract

    bundle = build_bundle(
        phase="preflight",
        manifest_path=prep_dir / "manifests_v2" / "preflight_tasks_20.json",
        prompt_store_path=prep_dir / "draft" / "generation_prompt_only_420.jsonl",
        queue_path=prep_dir / "draft" / "preflight_five_arm_queue_100.jsonl",
        prep_dir=prep_dir)
    queue = select_phase(bundle.queue, "preflight")[:10]
    purpose = {
        "plan": [SyntheticAction.text("PLAN:\n1. step")],
        "solve": [SyntheticAction.text("ANSWER: 7")],
        "baseline_solve": [SyntheticAction.text("ANSWER: 7")],
        "reflect": [SyntheticAction.text(
            "REFLECT:\n- fine\nCONFIDENCE: 0.9\nVERDICT: PASS")],
        "replan": [SyntheticAction.text("PLAN:\n1. retry")],
    }
    provider = PurposeSyntheticProvider(purpose)
    cfg = RunConfig(run_id="offline_resume", phase="preflight",
                    contract=ownerless_contract(), bundle=bundle, queue=queue,
                    purpose="offline_simulation")
    root = Path(__file__).resolve().parents[1] / "src" / "sncs_fivearm"
    Runner(config=cfg, provider=provider, runs_root=tmp_path, package_root=root).execute()
    first_calls = len(provider.calls)
    journal = Journal(tmp_path / "offline_resume" / "journal.jsonl")
    before = len([e for e in journal.read_all()
                  if e["event"] in ("completed", "failed")])

    # 同一 run 再跑一次：不得重发任何已完成轨迹
    provider2 = PurposeSyntheticProvider(purpose)
    Runner(config=cfg, provider=provider2, runs_root=tmp_path, package_root=root).execute()
    assert provider2.calls == [], "已完成轨迹不得重发"
    after = len([e for e in Journal(tmp_path / "offline_resume" / "journal.jsonl").read_all()
                 if e["event"] in ("completed", "failed")])
    assert after == before, "终态数不应增加"


def test_resume_quarantines_orphan_dispatch(tmp_path, prep_dir):
    """人为注入"已派发但无终态"的轨迹：恢复时必须隔离，不得重发。"""
    from sncs_fivearm.runner import RunConfig, Runner
    from sncs_fivearm.providers import PurposeSyntheticProvider, SyntheticAction
    from sncs_fivearm.simulation_runner import ownerless_contract

    bundle = build_bundle(
        phase="preflight",
        manifest_path=prep_dir / "manifests_v2" / "preflight_tasks_20.json",
        prompt_store_path=prep_dir / "draft" / "generation_prompt_only_420.jsonl",
        queue_path=prep_dir / "draft" / "preflight_five_arm_queue_100.jsonl",
        prep_dir=prep_dir)
    queue = select_phase(bundle.queue, "preflight")[:5]
    run_dir = tmp_path / "offline_orphan"
    run_dir.mkdir()
    j = Journal(run_dir / "journal.jsonl")
    cfg = RunConfig(run_id="offline_orphan", phase="preflight",
                    contract=ownerless_contract(), bundle=bundle, queue=queue,
                    purpose="offline_simulation")
    # 用 Runner 自己生成元信息，保证恢复核对能通过（不手写近似值）
    from sncs_fivearm.runner import Runner as _R
    probe = _R(config=cfg, provider=PurposeSyntheticProvider({}), runs_root=tmp_path,
               package_root=Path(__file__).resolve().parents[1] / "src" / "sncs_fivearm")
    j.append("run_started", **probe._run_meta())
    # 注入：第 1 条轨迹已派发但无响应
    j.append("claim", run_id=queue[0].run_id)
    j.append("reservation_created", request_id=queue[0].run_id + "#d1",
             run_id=queue[0].run_id, phase="preflight", bound_micro=1000)
    j.append("dispatch_intent_durable", request_id=queue[0].run_id + "#d1",
             run_id=queue[0].run_id)

    provider = PurposeSyntheticProvider({
        "solve": [SyntheticAction.text("ANSWER: 7")],
        "baseline_solve": [SyntheticAction.text("ANSWER: 7")],
        "plan": [SyntheticAction.text("PLAN:\n1. x")],
        "reflect": [SyntheticAction.text(
            "REFLECT:\n- ok\nCONFIDENCE: 0.9\nVERDICT: PASS")],
        "replan": [SyntheticAction.text("PLAN: retry")],
    })
    Runner(config=cfg, provider=provider,
           runs_root=tmp_path,
           package_root=Path(__file__).resolve().parents[1] / "src" / "sncs_fivearm"
           ).execute()

    # 那条轨迹没有被重发
    redispatched = [c for c in provider.calls if c.run_id == queue[0].run_id]
    assert redispatched == [], "孤儿轨迹不得重发"
    states = [e for e in Journal(run_dir / "journal.jsonl").read_all()
              if e["event"] == "reconciliation_required"]
    assert any(e.get("reason") == "orphan_dispatch_no_terminal_state" for e in states)


def test_resume_rejects_changed_contract(tmp_path, prep_dir):
    from sncs_fivearm.errors import RunLocked
    from sncs_fivearm.providers import PurposeSyntheticProvider, SyntheticAction
    from sncs_fivearm.runner import RunConfig, Runner
    from sncs_fivearm.simulation_runner import ownerless_contract

    bundle = build_bundle(
        phase="preflight",
        manifest_path=prep_dir / "manifests_v2" / "preflight_tasks_20.json",
        prompt_store_path=prep_dir / "draft" / "generation_prompt_only_420.jsonl",
        queue_path=prep_dir / "draft" / "preflight_five_arm_queue_100.jsonl",
        prep_dir=prep_dir)
    queue = select_phase(bundle.queue, "preflight")[:5]
    purpose = {"solve": [SyntheticAction.text("ANSWER: 1")],
               "baseline_solve": [SyntheticAction.text("ANSWER: 1")],
               "plan": [SyntheticAction.text("PLAN: x")],
               "reflect": [SyntheticAction.text(
                   "REFLECT:\n- ok\nCONFIDENCE: 0.9\nVERDICT: PASS")],
               "replan": [SyntheticAction.text("PLAN: y")]}
    root = Path(__file__).resolve().parents[1] / "src" / "sncs_fivearm"
    cfg = RunConfig(run_id="offline_changed", phase="preflight",
                    contract=ownerless_contract(), bundle=bundle, queue=queue,
                    purpose="offline_simulation")
    Runner(config=cfg, provider=PurposeSyntheticProvider(purpose),
           runs_root=tmp_path, package_root=root).execute()

    other = ownerless_contract(budget={"currency": "CNY", "total_micro": 1,
                                       "preflight_micro": 1, "main_micro": 0,
                                       "unknown_usage_policy": "x",
                                       "stop_before_dispatch_when_insufficient": True,
                                       "topup_without_approval": False})
    cfg2 = RunConfig(run_id="offline_changed", phase="preflight",
                     contract=other, bundle=bundle, queue=queue,
                     purpose="offline_simulation")
    with pytest.raises(RunLocked):
        Runner(config=cfg2, provider=PurposeSyntheticProvider(purpose),
               runs_root=tmp_path, package_root=root).execute()
