"""CLI 行为：离线命令不联网；live 入口在未批准时拒绝派发。"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from sncs_fivearm import cli
from sncs_fivearm.contracts import draft_contract


def _run_cli(args, cwd=None):
    """在子进程里跑 CLI，避免污染当前进程的 sys.modules。"""
    env = dict(os.environ)
    env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
    env.pop("EXAMPLE_KEY", None)
    return subprocess.run([sys.executable, "-B", "-X", "utf8", "-m", "sncs_fivearm.cli"] + args,
                          capture_output=True, text=True, encoding="utf-8", timeout=300,
                          env=env, cwd=cwd)


def test_doctor_reports_ok():
    done = _run_cli(["doctor", "--offline"])
    assert done.returncode == 0, done.stdout + done.stderr
    payload = json.loads(done.stdout)
    assert payload["status"] == "OK"
    assert payload["live_calls_made"] == 0
    assert payload["network_calls"] == 0
    assert payload["input_fingerprints_ok"] is True
    assert payload["legacy_manifest_match"] is True


def test_validate_inputs_locks_2100():
    done = _run_cli(["validate-inputs"])
    assert done.returncode == 0, done.stdout + done.stderr
    payload = json.loads(done.stdout)
    assert payload["status"] == "OK"
    assert payload["merged"]["n_queue_rows"] == 2100
    assert payload["merged"]["n_distinct_tasks"] == 420
    assert payload["phases"]["main"]["n_queue"] == 2000
    assert payload["phases"]["preflight"]["n_queue"] == 100


def test_run_live_without_approval_refuses(tmp_path):
    draft = draft_contract()
    p = tmp_path / "draft.json"
    p.write_text(json.dumps(draft, ensure_ascii=False), encoding="utf-8")
    done = _run_cli(["run", "--phase", "preflight", "--contract", str(p)])
    assert done.returncode == 3, done.stdout + done.stderr
    assert "未派发" in done.stdout
    assert "configs/approvals" in done.stdout


def test_run_refuses_even_if_credentials_present(tmp_path):
    """凭证存在但合同未批准：仍然不派发（第 12 项）。"""
    draft = draft_contract()
    draft["provider"]["api_key_env"] = "EXAMPLE_KEY"
    p = tmp_path / "draft.json"
    p.write_text(json.dumps(draft, ensure_ascii=False), encoding="utf-8")
    env = dict(os.environ)
    env["EXAMPLE_KEY"] = "sk-should-never-be-used"
    env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
    done = subprocess.run(
        [sys.executable, "-B", "-X", "utf8", "-m", "sncs_fivearm.cli",
         "run", "--phase", "preflight", "--contract", str(p)],
        capture_output=True, text=True, encoding="utf-8", timeout=300, env=env)
    assert done.returncode == 3
    assert "未派发" in done.stdout


def test_offline_run_and_status_and_export(tmp_path):
    """离线 run → status → export 全链路（不联网）。"""
    from sncs_fivearm.simulation_runner import ownerless_contract
    import sncs_fivearm.cli as cli_mod

    contract = ownerless_contract()
    cpath = tmp_path / "offline_contract.json"
    cpath.write_text(json.dumps(contract.raw, ensure_ascii=False), encoding="utf-8")

    saved = (cli_mod.RUNS_DIR, cli_mod.REPORTS_DIR)
    cli_mod.RUNS_DIR = tmp_path / "runs"
    cli_mod.REPORTS_DIR = tmp_path / "reports"
    try:
        ns = type("NS", (), {})()
        ns.phase = "preflight"
        ns.contract = str(cpath)
        ns.mode = "offline"
        ns.run_id = "cli_offline"
        ns.limit = 5
        assert cli_mod.cmd_run(ns) == 0

        run_dir = tmp_path / "runs" / "cli_offline"
        assert (run_dir / "journal.jsonl").is_file()
        assert (run_dir / "results.jsonl").is_file()

        st = type("ST", (), {})()
        st.run = "cli_offline"
        assert cli_mod.cmd_status(st) == 0

        ex = type("EX", (), {})()
        ex.run = "cli_offline"
        assert cli_mod.cmd_export(ex) == 0

        ledger_path = tmp_path / "reports" / "cli_offline_ledger.json"
        assert ledger_path.is_file()
        ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
        assert ledger["currency"] == "CNY"
        assert ledger["dispatches_total"] > 0
    finally:
        cli_mod.RUNS_DIR, cli_mod.REPORTS_DIR = saved


def test_seal_reports_consistency(runner_root):
    from sncs_fivearm.seal import seal_snapshot
    out = seal_snapshot(contract_path=None, runner_root=runner_root,
                        prep_dir=runner_root.parent / "SNCS_Experiment_Preparation_20261110",
                        out_path=Path(os.environ.get("TEMP", ".")) / "seal_test.json")
    assert out["status"] in ("SEALED_CONSISTENT", "SEALED_WITH_PROBLEMS")
    assert out["contract_mode"] == "draft"


def test_reconcile_without_evidence_does_not_guess(tmp_path):
    from sncs_fivearm.reconcile import reconcile_run
    run_dir = tmp_path / "r"
    run_dir.mkdir()
    from sncs_fivearm.journal import Journal
    j = Journal(run_dir / "journal.jsonl")
    j.append("reconciliation_required", run_id="x", phase="preflight",
             request_id="q1", exposure_micro=1000, reason="usage_missing")
    out = reconcile_run(run_id="r", runs_root=tmp_path, evidence=None)
    assert out["status"] == "EVIDENCE_REQUIRED"
    assert out["pending_requests"] == 1


def test_reconcile_with_evidence_updates_ledger(tmp_path):
    from sncs_fivearm.reconcile import reconcile_run
    from sncs_fivearm.journal import Journal
    run_dir = tmp_path / "r"
    run_dir.mkdir()
    j = Journal(run_dir / "journal.jsonl")
    j.append("reconciliation_required", run_id="x", phase="preflight",
             request_id="q1", exposure_micro=1000, reason="usage_missing")
    ev = tmp_path / "bill.json"
    ev.write_text(json.dumps({"items": [{"request_id": "q1", "billed_micro": 800,
                                         "note": "console export"}]}),
                  encoding="utf-8")
    out = reconcile_run(run_id="r", runs_root=tmp_path, evidence=ev)
    assert out["status"] == "RECONCILED"
    assert out["total_reconciled_micro"] == 800
