"""工作包 E 第 1 项：输入锁定与完整性。

覆盖：
  * 420 题 / 2,100 轨迹 / 五臂成员 / 顺序 / 题文哈希完整一致
  * 备用 100 题零入队
  * 生成入口只接受三字段，gold 字段被拒
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from sncs_fivearm.errors import ForbiddenFieldError, InputIntegrityError
from sncs_fivearm.inputs import (ARMS, LOCKED_SHA256, build_bundle,
                                 build_merged_bundle, load_prompt_store,
                                 load_queue, select_phase, sha256_file,
                                 verify_arm_membership)


def test_locked_fingerprints_match_handoff_index(prep_dir):
    for rel, expected in LOCKED_SHA256.items():
        p = prep_dir / rel
        assert p.is_file(), f"缺少 {rel}"
        assert sha256_file(p) == expected, f"{rel} 哈希不符"


def test_prompt_store_is_three_fields_with_exact_hashes(prep_dir):
    prompts = load_prompt_store(prep_dir / "draft" / "generation_prompt_only_420.jsonl")
    assert len(prompts) == 420
    for p in prompts.values():
        assert p.task_id and p.prompt and len(p.prompt_sha256) == 64


def test_merged_queue_is_2100_with_five_arms(prep_dir):
    bundle = build_merged_bundle(prep_dir=prep_dir)
    assert len(bundle.queue) == 2100
    assert len({r.run_id for r in bundle.queue}) == 2100
    assert len({r.task_id for r in bundle.queue}) == 420
    assert {r.strategy for r in bundle.queue} == set(ARMS)
    assert [r.sequence for r in bundle.queue] == list(range(1, 2101))
    # 预检在前、主筛查在后
    assert all(r.phase == "preflight" for r in bundle.queue[:100])
    assert all(r.phase == "main" for r in bundle.queue[100:])
    # 每连续 5 行同题且五臂齐全
    for phase in ("preflight", "main"):
        verify_arm_membership(select_phase(bundle.queue, phase))


def test_preflight_and_main_bundles(prep_dir):
    pre = build_bundle(phase="preflight",
                       manifest_path=prep_dir / "manifests_v2" / "preflight_tasks_20.json",
                       prompt_store_path=prep_dir / "draft" / "generation_prompt_only_420.jsonl",
                       queue_path=prep_dir / "draft" / "preflight_five_arm_queue_100.jsonl",
                       prep_dir=prep_dir)
    assert len(pre.manifest) == 20 and len(pre.queue) == 100
    assert len(pre.task_ids_in_queue) == 20

    main = build_bundle(phase="main",
                        manifest_path=prep_dir / "manifests_v2" / "main_tasks_400.json",
                        prompt_store_path=prep_dir / "draft" / "generation_prompt_only_420.jsonl",
                        queue_path=prep_dir / "draft" / "main_five_arm_queue_2000.jsonl",
                        prep_dir=prep_dir)
    assert len(main.manifest) == 400 and len(main.queue) == 2000
    assert len(main.task_ids_in_queue) == 400

    # 阶段互斥
    assert not ({r.task_id for r in pre.queue} & {r.task_id for r in main.queue})


def test_calibration_reserve_never_queued(prep_dir):
    bundle = build_merged_bundle(prep_dir=prep_dir)
    calibration = json.loads(
        (prep_dir / "manifests_v2" / "calibration_tasks_100.json").read_text(encoding="utf-8-sig"))
    cal_ids = {str(r["task_id"]) for r in calibration}
    assert len(cal_ids) == 100
    assert not (cal_ids & {r.task_id for r in bundle.queue})


def test_gold_fields_rejected_in_prompt_store(tmp_path, prep_dir):
    src = (prep_dir / "draft" / "generation_prompt_only_420.jsonl").read_text(encoding="utf-8")
    first, rest = src.split("\n", 1)
    row = json.loads(first)
    row["gold"] = "42"
    bad = tmp_path / "bad_store.jsonl"
    bad.write_text(json.dumps(row, ensure_ascii=False) + "\n" + rest, encoding="utf-8")
    with pytest.raises(ForbiddenFieldError):
        load_prompt_store(bad)


def test_prompt_hash_mismatch_rejected(tmp_path, prep_dir):
    src = (prep_dir / "draft" / "generation_prompt_only_420.jsonl").read_text(encoding="utf-8")
    first, rest = src.split("\n", 1)
    row = json.loads(first)
    row["prompt"] = row["prompt"] + " tampered"
    bad = tmp_path / "tampered.jsonl"
    bad.write_text(json.dumps(row, ensure_ascii=False) + "\n" + rest, encoding="utf-8")
    with pytest.raises(InputIntegrityError):
        load_prompt_store(bad)


def test_queue_rejects_prompt_body(tmp_path, prep_dir):
    q = (prep_dir / "draft" / "preflight_five_arm_queue_100.jsonl").read_text(encoding="utf-8")
    lines = q.splitlines()
    row = json.loads(lines[0])
    row["prompt"] = "leaked"
    lines[0] = json.dumps(row, ensure_ascii=False)
    bad = tmp_path / "bad_queue.jsonl"
    bad.write_text("\n".join(lines) + "\n", encoding="utf-8")
    with pytest.raises(InputIntegrityError):
        load_queue(bad, phase="preflight")


def test_queue_rejects_duplicate_run_id(tmp_path, prep_dir):
    q = (prep_dir / "draft" / "preflight_five_arm_queue_100.jsonl").read_text(encoding="utf-8")
    lines = q.splitlines()
    bad = tmp_path / "dup.jsonl"
    bad.write_text("\n".join(lines[:5] + lines[:95]) + "\n", encoding="utf-8")
    with pytest.raises(InputIntegrityError):
        load_queue(bad, phase="preflight")


def test_position_and_strategy_balance(prep_dir):
    """顺序平衡：每源每臂每位置出现 40 次（主）/ 2 次（预检）。"""
    from collections import Counter

    for phase, per in (("main", 40), ("preflight", 2)):
        queue = load_queue(
            prep_dir / "draft" / f"{phase}_five_arm_queue_"
            f"{2000 if phase == 'main' else 100}.jsonl", phase=phase)
        cells: Counter = Counter()
        for r in queue:
            cells[(r.source, r.strategy, r.execution_position)] += 1
        assert len(cells) == 2 * 5 * 5, f"{phase} 位置格数"
        assert set(cells.values()) == {per}, f"{phase} 位置格不均衡: {set(cells.values())}"
