"""P1–P6 新增产物的回归测试。

覆盖：
  * journal 资源账目与 summary 对账；
  * 配对 cluster bootstrap 的确定性与边界；
  * 状态矩阵分母完整、unknown 与评分一致；
  * 服务窗口漂移检查；
  * 盲评包字段与隐私边界；
  * run_finished 不被误判为轨迹终态。
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from sncs_fivearm.evaluation.resources import (assert_totals_match_summary,
                                               load_calls, per_arm, per_purpose,
                                               totals, usage_coverage)
from sncs_fivearm.evaluation.service_window import build_window
from sncs_fivearm.evaluation.stats import paired_cluster_bootstrap
from sncs_fivearm.evaluation.status_matrix import (build_matrix, summarise,
                                                   unknown_cases)
from sncs_fivearm.journal import Journal, derive_trajectory_states

RUN_ID = "selfhosted_main_conc_20261113"


def _run_dir(runner_root: Path) -> Path:
    d = runner_root / "runs" / RUN_ID
    if not d.is_dir():
        pytest.skip(f"缺主 run: {d}")
    return d


# ---------------------------------------------------------------- P1 资源账目
def test_resource_totals_match_summary(runner_root):
    d = _run_dir(runner_root)
    calls = load_calls(d / "journal.jsonl")
    summary = json.loads((d / "summary.json").read_text(encoding="utf-8"))
    result = assert_totals_match_summary(calls, summary)
    assert result["ok"] is True
    t = result["totals"]
    assert t["dispatches"] == 5331
    assert t["responses"] == 5331
    assert t["unresolved"] == 0
    assert t["prompt_tokens"] == 1_603_773
    assert t["completion_tokens"] == 1_694_118


def test_per_purpose_sums_to_total(runner_root):
    calls = load_calls(_run_dir(runner_root) / "journal.jsonl")
    by = per_purpose(calls)
    assert sum(v["dispatches"] for v in by.values()) == 5331
    assert set(by) == {"solve", "baseline_solve", "plan", "reflect", "judge", "replan"}


def test_usage_coverage_is_complete(runner_root):
    calls = load_calls(_run_dir(runner_root) / "journal.jsonl")
    cov = usage_coverage(calls)
    assert cov["coverage"] == 1.0
    assert cov["missing_usage"] == 0


def test_per_arm_covers_all_five(runner_root):
    d = _run_dir(runner_root)
    calls = load_calls(d / "journal.jsonl")
    from sncs_fivearm.inputs import build_bundle, select_phase
    prep = runner_root.parent / "SNCS_Experiment_Preparation_20261110"
    bundle = build_bundle(
        phase="main",
        manifest_path=prep / "manifests_v2" / "main_tasks_400.json",
        prompt_store_path=prep / "draft" / "generation_prompt_only_420.jsonl",
        queue_path=prep / "draft" / "main_five_arm_queue_2000.jsonl",
        prep_dir=prep)
    queue = [r.__dict__ for r in select_phase(bundle.queue, "main")]
    from sncs_fivearm.evaluation.resources import run_to_arm
    by = per_arm(calls, run_to_arm(queue))
    assert set(by) == {"direct", "planning", "plan_reflect",
                       "adaptive_legacy", "asc_beta_8"}
    assert sum(v["dispatches"] for v in by.values()) == 5331


# ---------------------------------------------------------------- P2 bootstrap
def test_paired_bootstrap_deterministic_and_paired():
    tr = {"t1": {"A": {"dispatches": 3}, "B": {"dispatches": 1}},
          "t2": {"A": {"dispatches": 2}, "B": {"dispatches": 2}},
          "t3": {"A": {"dispatches": 1}, "B": {"dispatches": 3}}}
    r1 = paired_cluster_bootstrap(task_resources=tr, task_ids=["t1", "t2", "t3"],
                                  arm_a="A", arm_b="B", metric="dispatches",
                                  draws=300, seed=11)
    r2 = paired_cluster_bootstrap(task_resources=tr, task_ids=["t1", "t2", "t3"],
                                  arm_a="A", arm_b="B", metric="dispatches",
                                  draws=300, seed=11)
    assert r1["observed_mean_difference"] == 0.0
    assert r1["bootstrap_95"] == r2["bootstrap_95"]
    assert r1["n_tasks"] == 3


def test_paired_bootstrap_skips_incomplete_pairs():
    tr = {"t1": {"A": {"dispatches": 3}}, "t2": {"A": {"dispatches": 1},
                                                 "B": {"dispatches": 1}},
          "t3": {"A": {"dispatches": 2}, "B": {"dispatches": 2}}}
    r = paired_cluster_bootstrap(task_resources=tr, task_ids=["t1", "t2", "t3"],
                                 arm_a="A", arm_b="B", metric="dispatches")
    assert r["n_tasks"] == 2  # t1 缺 B，不插补


def test_paired_bootstrap_insufficient():
    r = paired_cluster_bootstrap(task_resources={"t1": {"A": {"dispatches": 1},
                                                        "B": {"dispatches": 1}}},
                                 task_ids=["t1"], arm_a="A", arm_b="B")
    assert r["status"] == "INSUFFICIENT_TASKS"


def test_paired_bootstrap_rejects_unknown_metric():
    from sncs_fivearm.evaluation.stats import StatsError
    with pytest.raises(StatsError):
        paired_cluster_bootstrap(task_resources={}, task_ids=[], arm_a="A",
                                 arm_b="B", metric="wall_time")


# ---------------------------------------------------------------- P3 状态矩阵
def test_status_matrix_denominator_complete(runner_root):
    d = _run_dir(runner_root)
    from sncs_fivearm.inputs import build_bundle, select_phase
    prep = runner_root.parent / "SNCS_Experiment_Preparation_20261110"
    bundle = build_bundle(
        phase="main",
        manifest_path=prep / "manifests_v2" / "main_tasks_400.json",
        prompt_store_path=prep / "draft" / "generation_prompt_only_420.jsonl",
        queue_path=prep / "draft" / "main_five_arm_queue_2000.jsonl",
        prep_dir=prep)
    queue = [r.__dict__ for r in select_phase(bundle.queue, "main")]
    rows = build_matrix(queue_rows=queue,
                        results_rows=_jsonl(d / "results.jsonl"),
                        scored_rows=_jsonl(d / "scores_v1.jsonl"),
                        journal_events=Journal(d / "journal.jsonl").read_all())
    assert len(rows) == 2000
    s = summarise(rows)
    assert s["n_rows"] == 2000
    assert s["overall"].get("scored_correct") == 1754
    assert s["overall"].get("scored_incorrect") == 151
    assert s["overall"].get("unknown") == 95
    assert sum(s["overall"].values()) == 2000


def test_unknown_cases_match_scores(runner_root):
    d = _run_dir(runner_root)
    rows = [json.loads(l) for l in (d / "status_matrix.jsonl")
            .read_text(encoding="utf-8").splitlines() if l.strip()]
    scored = _jsonl(d / "scores_v1.jsonl")
    u = unknown_cases(rows, scored)
    assert len(u) == 95
    assert all(x["reason"] for x in u)


# ---------------------------------------------------------------- P6 服务窗口
def test_service_window_checks(runner_root):
    d = _run_dir(runner_root)
    events = Journal(d / "journal.jsonl").read_all()
    w = build_window(journal_events=events)
    assert w["dispatches"] == 5331
    assert w["model_reported"] == {"deepseek-v4.1-flash": 5331}
    assert w["dispatches_per_minute"]["peak"] <= 480
    assert w["status"] == "PASS"


def test_run_finished_not_counted_as_trajectory(runner_root):
    d = _run_dir(runner_root)
    states = derive_trajectory_states(Journal(d / "journal.jsonl").read_all())
    assert len(states) == 2000
    assert all(s.state == "completed" for s in states.values())


# ---------------------------------------------------------------- P5 盲评包
def test_blind_package_fields(runner_root):
    d = _run_dir(runner_root) / "blind"
    if not (d / "blind_items.jsonl").is_file():
        pytest.skip("盲评包未生成")
    items = [json.loads(l) for l in (d / "blind_items.jsonl")
             .read_text(encoding="utf-8").splitlines() if l.strip()]
    assert len(items) == 2000
    assert all(set(r) == {"blind_id", "task_id", "source", "prompt",
                          "submitted_answer"} for r in items)
    ids = [r["blind_id"] for r in items]
    assert len(set(ids)) == 2000
    mapping = json.loads((d / "blind_mapping_PRIVATE.json").read_text(encoding="utf-8"))
    assert len(mapping) == 2000
    manifest = json.loads((d / "blind_manifest.json").read_text(encoding="utf-8"))
    assert "blinding_limitation" in manifest
    assert "strategy" in manifest["hidden_fields"]


def _jsonl(path: Path):
    if not path.is_file():
        return []
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines()
            if l.strip()]
