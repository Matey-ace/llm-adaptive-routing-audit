"""共享 dispatcher、8 次门、预算门、响应保全、合同批准门。

覆盖工作包 E 第 2、3、6、7、8、12 项。
"""

from __future__ import annotations

import json

import pytest

from sncs_fivearm.budget import Ledger
from sncs_fivearm.contracts import Contract, ContractError, draft_contract, sha256_json
from sncs_fivearm.dispatcher import Dispatcher, LegacyBridgeClient
from sncs_fivearm.errors import (BudgetBlocked, ContractNotApproved,
                                 DispatchLimitReached, TransportError)
from sncs_fivearm.journal import Journal
from sncs_fivearm.providers import SyntheticAction, SyntheticProvider


def _ledger(total=100_000_000, pre=100_000_000):
    return Ledger(currency="CNY", total_cap_micro=total,
                  phase_caps_micro={"preflight": pre, "main": 0},
                  price_in_micro_per_million=2_000_000,
                  price_out_micro_per_million=8_000_000)


def _contract(**over):
    from sncs_fivearm.simulation_runner import ownerless_contract
    return ownerless_contract(**over)


def _dispatcher(tmp_path, *, provider, contract=None, ledger=None):
    c = contract or _contract()
    j = Journal(tmp_path / "j.jsonl")
    return Dispatcher(journal=j, ledger=ledger or _ledger(), provider=provider,
                      contract=c, output_ceiling=c.output_ceiling,
                      sampling=c.sampling(),
                      input_bound_method=c.input_bound_method)


MSGS = [{"role": "system", "content": "s"}, {"role": "user", "content": "u"}]


def test_dispatch_happy_path_records_everything(tmp_path):
    provider = SyntheticProvider({"R": [SyntheticAction.text("ANSWER: 5", pt=120, ct=30)]})
    d = _dispatcher(tmp_path, provider=provider)
    rec = d.dispatch(run_id="R", phase="preflight", purpose="solve",
                     messages=MSGS, max_tokens=100)
    assert rec.dispatched is True
    assert rec.settled == "settled"
    assert rec.prompt_tokens == 120 and rec.completion_tokens == 30
    assert rec.actual_micro == 120 * 2 + 30 * 8
    events = [e["event"] for e in Journal(tmp_path / "j.jsonl").read_all()]
    assert events == ["reservation_created", "dispatch_intent_durable",
                      "response_received", "usage_settled"]


def test_dispatch_cap_is_eight_and_ninth_never_sent(tmp_path):
    provider = SyntheticProvider({"R": [SyntheticAction.text(f"ANSWER: {i}", pt=10, ct=10) for i in range(1, 20)]})
    d = _dispatcher(tmp_path, provider=provider)
    for i in range(8):
        d.dispatch(run_id="R", phase="preflight", purpose="solve",
                   messages=MSGS, max_tokens=64)
    assert len(provider.calls) == 8
    with pytest.raises(DispatchLimitReached):
        d.dispatch(run_id="R", phase="preflight", purpose="solve",
                   messages=MSGS, max_tokens=64)
    assert len(provider.calls) == 8, "第 9 次不得实际发出"
    assert d.remaining("R") == 0


def test_budget_block_does_not_dispatch(tmp_path):
    provider = SyntheticProvider({"R": [SyntheticAction.text("ANSWER: 1")]})
    tight = Ledger(currency="CNY", total_cap_micro=10,
                   phase_caps_micro={"preflight": 10, "main": 0},
                   price_in_micro_per_million=2_000_000,
                   price_out_micro_per_million=8_000_000)
    d = _dispatcher(tmp_path, provider=provider, ledger=tight)
    with pytest.raises(BudgetBlocked):
        d.dispatch(run_id="R", phase="preflight", purpose="solve",
                   messages=MSGS, max_tokens=64)
    assert provider.calls == []
    events = [e["event"] for e in Journal(tmp_path / "j.jsonl").read_all()]
    assert events == ["budget_blocked"]
    assert "dispatch_intent_durable" not in events


def test_budget_block_records_not_dispatched_flag(tmp_path):
    provider = SyntheticProvider({"R": [SyntheticAction.text("ANSWER: 1")]})
    tight = Ledger(currency="CNY", total_cap_micro=10,
                   phase_caps_micro={"preflight": 10, "main": 0},
                   price_in_micro_per_million=2_000_000,
                   price_out_micro_per_million=8_000_000)
    d = _dispatcher(tmp_path, provider=provider, ledger=tight)
    with pytest.raises(BudgetBlocked):
        d.dispatch(run_id="R", phase="preflight", purpose="solve",
                   messages=MSGS, max_tokens=64)
    blocked = [e for e in Journal(tmp_path / "j.jsonl").read_all()
               if e["event"] == "budget_blocked"]
    assert blocked[0]["dispatched"] is False


def test_exact_accounting_with_preset_values(tmp_path):
    """请求/输出账目与预设合成值精确一致（整数 micro，无浮点漂移）。"""
    provider = SyntheticProvider({
        "R": [SyntheticAction.text("ANSWER: 1", pt=1000, ct=250)]
    })
    d = _dispatcher(tmp_path, provider=provider)
    rec = d.dispatch(run_id="R", phase="preflight", purpose="judge",
                     messages=MSGS, max_tokens=4096)
    expected = 1000 * 2 + 250 * 8
    assert rec.actual_micro == expected
    settled = [e for e in Journal(tmp_path / "j.jsonl").read_all()
               if e["event"] == "usage_settled"][0]
    assert settled["actual_micro"] == expected
    assert settled["prompt_tokens"] == 1000
    assert settled["completion_tokens"] == 250


def test_currency_is_not_mixed(tmp_path):
    from sncs_fivearm.budget import CurrencyMismatch
    with pytest.raises(CurrencyMismatch):
        Ledger(currency="USD", total_cap_micro=1,
               phase_caps_micro={"preflight": 1, "main": 0},
               price_in_micro_per_million=1, price_out_micro_per_million=1)


def test_missing_usage_keeps_content_and_exposure(tmp_path):
    provider = SyntheticProvider({
        "R": [SyntheticAction.missing_usage("ANSWER: 42")]
    })
    d = _dispatcher(tmp_path, provider=provider)
    rec = d.dispatch(run_id="R", phase="preflight", purpose="solve",
                     messages=MSGS, max_tokens=64)
    assert rec.settled == "reconciliation_required"
    assert "42" in rec.content
    assert rec.envelope, "envelope 必须被保全"
    assert d.ledger.unresolved_exposure_micro > 0
    assert d.ledger.known_charge_micro == 0


def test_empty_and_malformed_outputs_are_preserved(tmp_path):
    provider = SyntheticProvider({
        "R1": [SyntheticAction.empty()],
        "R2": [SyntheticAction.text("garbage without protocol")],
    })
    d = _dispatcher(tmp_path, provider=provider)
    a = d.dispatch(run_id="R1", phase="preflight", purpose="solve",
                   messages=MSGS, max_tokens=64)
    b = d.dispatch(run_id="R2", phase="preflight", purpose="solve",
                   messages=MSGS, max_tokens=64)
    assert a.content == "" and a.settled == "settled"
    assert b.content == "garbage without protocol"


def test_http_error_may_have_billed_keeps_exposure(tmp_path):
    provider = SyntheticProvider({
        "R": [SyntheticAction.error("HTTP 502", may_have_billed=True, status_code=502)]
    })
    d = _dispatcher(tmp_path, provider=provider)
    rec = d.dispatch(run_id="R", phase="preflight", purpose="solve",
                     messages=MSGS, max_tokens=64)
    assert rec.settled == "reconciliation_required"
    assert rec.error and "502" in rec.error
    assert d.ledger.unresolved_exposure_micro > 0


def test_http_error_not_billed_releases(tmp_path):
    provider = SyntheticProvider({
        "R": [SyntheticAction.error("HTTP 400", may_have_billed=False, status_code=400)]
    })
    d = _dispatcher(tmp_path, provider=provider)
    rec = d.dispatch(run_id="R", phase="preflight", purpose="solve",
                     messages=MSGS, max_tokens=64)
    assert rec.settled == "released"
    assert d.ledger.unresolved_exposure_micro == 0
    assert d.ledger.reserved_micro == 0


def test_timeout_is_treated_as_may_have_billed(tmp_path):
    provider = SyntheticProvider({
        "R": [SyntheticAction.error("Read timed out", may_have_billed=True)]
    })
    d = _dispatcher(tmp_path, provider=provider)
    rec = d.dispatch(run_id="R", phase="preflight", purpose="solve",
                     messages=MSGS, max_tokens=64)
    assert rec.settled == "reconciliation_required"
    journal = [e for e in Journal(tmp_path / "j.jsonl").read_all()
               if e["event"] == "failed"]
    assert journal[0]["may_have_billed"] is True


def test_no_automatic_retry_on_unknown_dispatch(tmp_path):
    provider = SyntheticProvider({
        "R": [SyntheticAction.error("reset", may_have_billed=True),
              SyntheticAction.text("ANSWER: 1")]
    })
    d = _dispatcher(tmp_path, provider=provider)
    d.dispatch(run_id="R", phase="preflight", purpose="solve",
               messages=MSGS, max_tokens=64)
    assert len(provider.calls) == 1, "未知派发不得自动重试"


def test_output_token_ceiling_enforced(tmp_path):
    provider = SyntheticProvider({"R": [SyntheticAction.text("ANSWER: 1")]})
    contract = _contract()
    contract.raw["limits"]["per_call_output_token_ceiling"] = 256
    d = _dispatcher(tmp_path, provider=provider, contract=contract)
    d.dispatch(run_id="R", phase="preflight", purpose="solve",
               messages=MSGS, max_tokens=999_999)
    assert provider.calls[0].max_tokens == 256


def test_bridge_client_blocks_sampling_override(tmp_path):
    provider = SyntheticProvider({"R": [SyntheticAction.text("ANSWER: 1")]})
    d = _dispatcher(tmp_path, provider=provider)
    bridge = LegacyBridgeClient(d, role_limits={"default": 4096, "solve": 4096},
                               model_name="m")
    bridge.bind(run_id="R", phase="preflight")
    bridge.chat(MSGS, purpose="solve",
                decoding_override={"temperature": 1.5, "top_p": 0.1})
    assert bridge.override_violations, "采样覆盖必须被记录"
    assert provider.calls[0].sampling["temperature"] == 0.0


def test_bridge_role_limit_cannot_exceed_ceiling(tmp_path):
    provider = SyntheticProvider({"R": [SyntheticAction.text("ANSWER: 1")]})
    contract = _contract()
    contract.raw["limits"]["per_call_output_token_ceiling"] = 512
    d = _dispatcher(tmp_path, provider=provider, contract=contract)
    bridge = LegacyBridgeClient(d, role_limits={"default": 999_999, "solve": 999_999},
                               model_name="m")
    bridge.bind(run_id="R", phase="preflight")
    bridge.chat(MSGS, purpose="solve", max_tokens=999_999)
    assert provider.calls[0].max_tokens == 512


# ---------------------------------------------------------------- 合同门
def _write(tmp_path, raw) -> Contract:
    p = tmp_path / "contract.json"
    p.write_text(json.dumps(raw, ensure_ascii=False), encoding="utf-8")
    return p


def test_draft_contract_is_never_ready(tmp_path):
    raw = draft_contract()
    p = _write(tmp_path, raw)
    c = Contract.load(p, approvals_dir=tmp_path / "approvals")
    assert c.mode == "live"
    assert c.approved is False
    assert c.live_ready is False
    assert any("批准" in x or "provider.name" in x for x in c.problems)
    with pytest.raises(ContractNotApproved):
        c.require_live_ready()


def test_self_declared_approval_without_record_is_rejected(tmp_path):
    raw = draft_contract()
    raw["approval"] = {"approved": True, "approval_reference": "FAKE",
                       "approved_utc": "2026-11-11T00:00:00Z"}
    p = _write(tmp_path, raw)
    c = Contract.load(p, approvals_dir=tmp_path / "approvals")
    assert c.approved is False, "没有 approvals/*.json 时必须视为未批准"
    assert c.live_ready is False


def test_author_record_unlocks_only_matching_fields(tmp_path):
    raw = draft_contract()
    _fill_live(raw, total_micro=100_000_000, preflight=10_000_000, main=90_000_000)
    raw["approval"] = {"approved": True, "approval_reference": "A1",
                       "approved_utc": "2026-11-11T00:00:00Z"}
    p = _write(tmp_path, raw)
    approvals = tmp_path / "approvals"
    approvals.mkdir()
    (approvals / "A1.json").write_text(json.dumps({
        "approval_id": "A1", "recorded_by": "author", "approved": True,
        "quote": "批准预检 10 元、总额 100 元，模型 X",
        "approved_utc": "2026-11-11T00:00:00Z",
        "model_id": raw["provider"]["model_id"],
        "currency": "CNY", "total_micro": 100_000_000,
        "phases": ["preflight"],
    }), encoding="utf-8")
    c = Contract.load(p, approvals_dir=approvals)
    assert c.approved is True
    assert c.live_ready is True, c.problems


def test_approval_with_wrong_amount_blocks(tmp_path):
    raw = draft_contract()
    _fill_live(raw, total_micro=100_000_000, preflight=10_000_000, main=90_000_000)
    raw["approval"] = {"approved": True, "approval_reference": "A2",
                       "approved_utc": "2026-11-11T00:00:00Z"}
    p = _write(tmp_path, raw)
    approvals = tmp_path / "approvals"
    approvals.mkdir()
    (approvals / "A2.json").write_text(json.dumps({
        "approval_id": "A2", "recorded_by": "author", "approved": True,
        "quote": "批准 50 元", "model_id": raw["provider"]["model_id"],
        "currency": "CNY", "total_micro": 50_000_000, "phases": ["preflight"],
    }), encoding="utf-8")
    c = Contract.load(p, approvals_dir=approvals)
    assert c.live_ready is False
    assert any("金额" in x for x in c.problems)


def test_agent_made_approval_record_rejected(tmp_path):
    raw = draft_contract()
    _fill_live(raw)
    raw["approval"] = {"approved": True, "approval_reference": "A3",
                       "approved_utc": "2026-11-11T00:00:00Z"}
    p = _write(tmp_path, raw)
    approvals = tmp_path / "approvals"
    approvals.mkdir()
    (approvals / "A3.json").write_text(json.dumps({
        "approval_id": "A3", "recorded_by": "agent", "approved": True,
        "quote": "", "currency": "CNY", "total_micro": raw["budget"]["total_micro"],
        "model_id": raw["provider"]["model_id"], "phases": ["preflight"],
    }), encoding="utf-8")
    c = Contract.load(p, approvals_dir=approvals)
    assert c.approved is False
    assert c.live_ready is False


def test_bad_input_bound_method_blocks_live(tmp_path):
    raw = draft_contract()
    _fill_live(raw)
    raw["limits"]["input_token_upper_bound_method"] = "chars_div_3"
    p = _write(tmp_path, raw)
    approvals = tmp_path / "approvals"
    approvals.mkdir()
    (approvals / "A4.json").write_text(json.dumps({
        "approval_id": "A4", "recorded_by": "author", "approved": True,
        "quote": "ok", "currency": "CNY",
        "total_micro": raw["budget"]["total_micro"],
        "model_id": raw["provider"]["model_id"], "phases": ["preflight"],
    }), encoding="utf-8")
    raw["approval"]["approval_reference"] = "A4"
    _write(tmp_path, raw)
    c = Contract.load(tmp_path / "contract.json", approvals_dir=approvals)
    assert c.live_ready is False
    assert any("输入 token 上界" in x for x in c.problems)


def test_schema_and_study_id_enforced(tmp_path):
    raw = draft_contract()
    raw["study_id"] = "some_other_study"
    p = _write(tmp_path, raw)
    with pytest.raises(ContractError):
        Contract.load(p)


def test_inherit_prior_authorization_rejected(tmp_path):
    raw = draft_contract()
    raw["inherit_prior_authorizations"] = True
    p = _write(tmp_path, raw)
    with pytest.raises(ContractError):
        Contract.load(p)


def _fill_live(raw, *, total_micro=100_000_000, preflight=10_000_000, main=90_000_000):
    raw["provider"].update({
        "name": "example", "base_url": "https://example.invalid/v1",
        "model_id": "model-x", "api_key_env": "EXAMPLE_KEY",
    })
    raw["provider"]["sampling"]["temperature_or_omitted_reason"] = "omit_under_thinking"
    raw["provider"]["timeout_seconds"] = 120
    raw["limits"]["input_token_upper_bound_method"] = "utf8_byte_upper_bound_v1"
    raw["tariff"].update({
        "currency": "CNY",
        "input_uncached_micro_per_million": 2_000_000,
        "output_micro_per_million": 8_000_000,
    })
    raw["tariff"]["source"] = {"url": "https://example.invalid/pricing",
                               "checked_utc": "2026-11-11T00:00:00Z"}
    raw["budget"].update({"currency": "CNY", "total_micro": total_micro,
                          "preflight_micro": preflight, "main_micro": main})
