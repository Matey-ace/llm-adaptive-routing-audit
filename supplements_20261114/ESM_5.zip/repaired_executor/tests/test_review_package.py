"""独立评审包的结构与隐私回归测试。"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import pytest

PKG = "Independent_Review_Package_v1"
FORBIDDEN_COLUMNS = {"strategy", "run_id", "execution_position", "stop_reason",
                     "steps", "usage", "cost", "asc", "dispatches"}


@pytest.fixture(scope="module")
def pkg(runner_root) -> Path:
    p = runner_root / "reports" / PKG
    if not p.is_dir():
        pytest.skip("评审包未生成")
    return p


def test_package_has_required_files(pkg):
    for name in ("README.md", "review_items.csv", "review_items.jsonl",
                 "score_sheet.csv", "adjudication_log.csv",
                 "priority_unknown_ids.txt", "sampled_audit_ids.txt",
                 "validate_review.py", "package_manifest.json"):
        assert (pkg / name).is_file(), name


def test_review_items_have_only_released_fields(pkg):
    with (pkg / "review_items.csv").open(encoding="utf-8-sig", newline="") as fh:
        rows = list(csv.DictReader(fh))
    assert len(rows) == 2000
    assert set(rows[0]) == {"blind_id", "task_id", "dataset", "prompt",
                            "submitted_answer", "reference_answer"}
    assert not (FORBIDDEN_COLUMNS & set(rows[0]))


def test_no_mapping_file_in_package(pkg):
    assert not (pkg / "blind_mapping_PRIVATE.json").exists()
    assert not (pkg / "blind_mapping.json").exists()


def test_manifest_records_mapping_hash_but_not_content(pkg):
    m = json.loads((pkg / "package_manifest.json").read_text(encoding="utf-8"))
    assert len(m["blind_mapping_sha256"]) == 64
    assert "blind_mapping" not in json.dumps(m.get("files", {}))
    assert "blinding_limitation" in m
    assert m["n_items"] == 2000


def test_priority_and_sample_lists(pkg):
    prio = [l for l in (pkg / "priority_unknown_ids.txt")
            .read_text(encoding="utf-8").splitlines() if l.strip()]
    samp = [l for l in (pkg / "sampled_audit_ids.txt")
            .read_text(encoding="utf-8").splitlines() if l.strip()]
    assert len(prio) == 95
    assert len(samp) == 200
    assert len(set(prio)) == 95
    assert len(set(samp)) == len(samp)
    with (pkg / "review_items.csv").open(encoding="utf-8-sig", newline="") as fh:
        ids = {r["blind_id"] for r in csv.DictReader(fh)}
    assert set(prio) <= ids
    assert set(samp) <= ids


def test_score_sheet_matches_item_ids(pkg):
    with (pkg / "review_items.csv").open(encoding="utf-8-sig", newline="") as fh:
        items = [r["blind_id"] for r in csv.DictReader(fh)]
    with (pkg / "score_sheet.csv").open(encoding="utf-8-sig", newline="") as fh:
        sheet = [r["blind_id"] for r in csv.DictReader(fh)]
    assert items == sheet
    assert len(sheet) == 2000


def test_validator_rejects_blank_sheet(pkg, tmp_path):
    import subprocess, sys
    done = subprocess.run(
        [sys.executable, "-B", "-X", "utf8", "validate_review.py",
         "score_sheet.csv", "review_items.csv"],
        cwd=pkg, capture_output=True, text=True, encoding="utf-8")
    assert done.returncode == 1
    assert "decision 为空" in done.stdout


def test_every_task_has_five_answers(pkg):
    from collections import Counter
    with (pkg / "review_items.csv").open(encoding="utf-8-sig", newline="") as fh:
        rows = list(csv.DictReader(fh))
    counts = Counter(r["task_id"] for r in rows)
    assert len(counts) == 400
    assert set(counts.values()) == {5}
