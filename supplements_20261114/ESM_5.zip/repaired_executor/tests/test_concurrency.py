"""并发竞争测试（计划 §8/§11 要求：增加并发前必须先补原子预留与竞争测试）。

覆盖：
  * 多线程同时预留，总额度不被击穿（不会超卖）；
  * 同一轨迹的 8 次门在并发下不被突破；
  * journal 并发写入无撕裂行、可校验；
  * 并发跑完整题块时，每题恰好五臂、每轨迹只派发一次；
  * 重复恢复不重发；
  * 限速器不超过设定 RPM。
"""

from __future__ import annotations

import json
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest

from sncs_fivearm.budget import Ledger
from sncs_fivearm.dispatcher import Dispatcher, RateLimiter
from sncs_fivearm.errors import BudgetBlocked, DispatchLimitReached
from sncs_fivearm.inputs import TaskPrompt, sha256_text
from sncs_fivearm.journal import Journal
from sncs_fivearm.providers import PurposeSyntheticProvider, SyntheticAction
from sncs_fivearm.registry import FiveArmRegistry
from sncs_fivearm.runner import RunConfig, Runner
from sncs_fivearm.simulation_runner import ownerless_contract

MSGS = [{"role": "system", "content": "s"}, {"role": "user", "content": "u"}]


def _ledger(total_micro: int) -> Ledger:
    return Ledger(currency="CNY", total_cap_micro=total_micro,
                  phase_caps_micro={"preflight": total_micro, "main": 0},
                  price_in_micro_per_million=2_000_000,
                  price_out_micro_per_million=8_000_000)


def _dispatcher(tmp_path, *, ledger, provider, contract=None):
    c = contract or ownerless_contract()
    return Dispatcher(journal=Journal(tmp_path / "j.jsonl"), ledger=ledger,
                      provider=provider, contract=c,
                      output_ceiling=c.output_ceiling, sampling=c.sampling(),
                      input_bound_method=c.input_bound_method)


def test_concurrent_reservations_never_oversell(tmp_path):
    """20 个线程同时预留：成功次数受额度约束，且账本绝不超卖。"""
    total = 1_600
    led = _ledger(total)
    provider = PurposeSyntheticProvider({"solve": [SyntheticAction.text("ANSWER: 1", pt=10, ct=10)]})
    d = _dispatcher(tmp_path, ledger=led, provider=provider)
    ok, denied = [], []
    barrier = threading.Barrier(20)

    def worker(i: int) -> None:
        barrier.wait()
        try:
            d.dispatch(run_id=f"R{i}", phase="preflight", purpose="solve",
                       messages=MSGS, max_tokens=64)
            ok.append(i)
        except BudgetBlocked:
            denied.append(i)

    with ThreadPoolExecutor(max_workers=20) as pool:
        list(pool.map(worker, range(20)))

    assert len(ok) + len(denied) == 20
    assert len(ok) >= 1
    # 核心不变式：已核费用 + 未决 + 预留 不超过总额度（无超卖）
    assert led.committed_micro() <= total
    events = Journal(tmp_path / "j.jsonl").read_all()
    intents = [e for e in events if e["event"] == "dispatch_intent_durable"]
    assert len(intents) == len(ok)
    assert len({e["request_id"] for e in intents}) == len(intents)
    # 被拒的请求不得留下 intent
    assert len(intents) == len(ok)


def test_concurrent_attempt_cap_not_exceeded(tmp_path):
    """同一 run_id 20 线程并发请求，8 次门只允许 8 次真正派发。"""
    led = _ledger(100_000_000)
    provider = PurposeSyntheticProvider(
        {"solve": [SyntheticAction.text("ANSWER: 1", pt=10, ct=10)] * 40})
    d = _dispatcher(tmp_path, ledger=led, provider=provider)
    d.reset_trajectory("R")
    results = {"ok": 0, "capped": 0}
    lock = threading.Lock()
    barrier = threading.Barrier(20)

    def worker(_i: int) -> None:
        barrier.wait()
        try:
            d.dispatch(run_id="R", phase="preflight", purpose="solve",
                       messages=MSGS, max_tokens=64)
            with lock:
                results["ok"] += 1
        except DispatchLimitReached:
            with lock:
                results["capped"] += 1

    with ThreadPoolExecutor(max_workers=20) as pool:
        list(pool.map(worker, range(20)))

    assert results["ok"] == 8, results
    assert results["capped"] == 12
    assert len(provider.calls) == 8
    events = Journal(tmp_path / "j.jsonl").read_all()
    assert len([e for e in events if e["event"] == "dispatch_intent_durable"]) == 8
    seqs = sorted(int(e["request_id"].rsplit("#d", 1)[1]) for e in events
                  if e["event"] == "dispatch_intent_durable")
    assert seqs == list(range(1, 9))


def test_journal_concurrent_append_has_no_torn_lines(tmp_path):
    path = tmp_path / "j.jsonl"
    j = Journal(path)

    def worker(i: int) -> None:
        for k in range(10):
            j.append("claim", run_id=f"R{i}-{k}")

    with ThreadPoolExecutor(max_workers=10) as pool:
        list(pool.map(worker, range(10)))

    raw = path.read_bytes()
    assert raw.endswith(b"\n")
    lines = [ln for ln in raw.decode("utf-8").splitlines() if ln]
    assert len(lines) == 100
    for ln in lines:
        rec = json.loads(ln)          # 每行都是完整 JSON
        assert rec["event"] == "claim"
    assert Journal(path).verify()["claims"] == 100


def test_concurrent_blocks_keep_five_arms_and_single_dispatch(tmp_path):
    """2 题 × 5 臂，2 worker 并发：每题五臂齐全，每轨迹只派发一次。"""
    qdir = tmp_path / "runs"
    tasks = [TaskPrompt(task_id=f"T{i}", prompt=f"Question {i}",
                        prompt_sha256=sha256_text(f"Question {i}")) for i in range(2)]
    rows = []
    seq = 0
    for block, task in enumerate(tasks, 1):
        block_id = f"b{block}:{task.task_id}"
        for pos, arm in enumerate(("direct", "planning", "plan_reflect",
                                   "adaptive_legacy", "asc_beta_8"), 1):
            seq += 1
            rows.append({"sequence": seq, "block_number": block,
                         "block_id": block_id, "run_id": f"{block_id}:{arm}",
                         "phase": "preflight", "task_id": task.task_id,
                         "source": "gsm8k", "sampling_stratum": "s",
                         "prompt_sha256": task.prompt_sha256, "repeat_id": 0,
                         "strategy": arm, "execution_position": pos})

    from sncs_fivearm.inputs import InputBundle, QueueRow
    bundle = InputBundle(phase="preflight",
                         prompts={t.task_id: t for t in tasks},
                         queue=[QueueRow.from_dict(r) for r in rows],
                         manifest=[], fingerprints={})
    purpose = {
        "judge": [SyntheticAction.text(
            '{"level": "medium", "confidence": 0.7, "reasoning_steps": 2, "reason": "ok"}')],
        "plan": [SyntheticAction.text("PLAN: 1. step")],
        "solve": [SyntheticAction.text("ANSWER: 1")],
        "baseline_solve": [SyntheticAction.text("ANSWER: 1")],
        "reflect": [SyntheticAction.text(
            "REFLECT: ok\nCONFIDENCE: 0.9\nVERDICT: PASS")],
        "replan": [SyntheticAction.text("PLAN: retry")],
    }
    provider = PurposeSyntheticProvider(purpose)
    contract = ownerless_contract()
    contract.raw["limits"]["max_dispatches_per_minute"] = 6000
    cfg = RunConfig(run_id="conc", phase="preflight", contract=contract,
                    bundle=bundle, queue=bundle.queue, purpose="test",
                    workers=2)
    summary = Runner(config=cfg, provider=provider, runs_root=qdir,
                     package_root=Path(__file__).resolve().parents[1] / "src" / "sncs_fivearm"
                     ).execute()
    assert summary.completed == 10, summary.as_dict()
    assert summary.failed == 0

    events = Journal(qdir / "conc" / "journal.jsonl").read_all()
    claims = [e["run_id"] for e in events if e["event"] == "claim"]
    assert len(claims) == len(set(claims)) == 10
    intents = [e for e in events if e["event"] == "dispatch_intent_durable"]
    per_run = {}
    for e in intents:
        per_run[e["run_id"]] = per_run.get(e["run_id"], 0) + 1
    assert all(v <= 8 for v in per_run.values()), per_run
    results = [json.loads(l) for l in
               (qdir / "conc" / "results.jsonl").read_text(encoding="utf-8").splitlines()]
    assert len(results) == 10
    by_task = {}
    for r in results:
        by_task.setdefault(r["task_id"], set()).add(r["strategy"])
    assert all(v == {"direct", "planning", "plan_reflect",
                     "adaptive_legacy", "asc_beta_8"} for v in by_task.values())


def test_concurrent_resume_does_not_redispatch(tmp_path):
    """并发跑完后再 resume：不新增任何派发。"""
    qdir = tmp_path / "runs"
    task = TaskPrompt(task_id="T", prompt="Q", prompt_sha256=sha256_text("Q"))
    rows = []
    for pos, arm in enumerate(("direct", "planning", "plan_reflect",
                               "adaptive_legacy", "asc_beta_8"), 1):
        rows.append({"sequence": pos, "block_number": 1, "block_id": "b1:T",
                     "run_id": f"b1:T:{arm}", "phase": "preflight",
                     "task_id": "T", "source": "gsm8k", "sampling_stratum": "s",
                     "prompt_sha256": task.prompt_sha256, "repeat_id": 0,
                     "strategy": arm, "execution_position": pos})
    from sncs_fivearm.inputs import InputBundle, QueueRow
    bundle = InputBundle(phase="preflight", prompts={"T": task},
                         queue=[QueueRow.from_dict(r) for r in rows],
                         manifest=[], fingerprints={})
    purpose = {
        "plan": [SyntheticAction.text("PLAN: 1. x")],
        "solve": [SyntheticAction.text("ANSWER: 1")],
        "baseline_solve": [SyntheticAction.text("ANSWER: 1")],
        "reflect": [SyntheticAction.text(
            "REFLECT: ok\nCONFIDENCE: 0.9\nVERDICT: PASS")],
        "replan": [SyntheticAction.text("PLAN: y")],
    }
    contract = ownerless_contract()
    root = Path(__file__).resolve().parents[1] / "src" / "sncs_fivearm"
    cfg = RunConfig(run_id="res", phase="preflight", contract=contract,
                    bundle=bundle, queue=bundle.queue, purpose="test", workers=2)
    Runner(config=cfg, provider=PurposeSyntheticProvider(purpose),
           runs_root=qdir, package_root=root).execute()

    provider2 = PurposeSyntheticProvider(purpose)
    Runner(config=cfg, provider=provider2, runs_root=qdir, package_root=root).execute()
    assert provider2.calls == []


def test_rate_limiter_caps_requests():
    """限速器：用假时钟验证每分钟不超过上限。"""
    clock = {"t": 0.0}
    slept = {"total": 0.0}

    def fake_sleep(s: float) -> None:
        slept["total"] += s
        clock["t"] += s

    limiter = RateLimiter(60, clock=lambda: clock["t"], sleep_fn=fake_sleep)
    for _ in range(120):
        limiter.acquire()
    # 120 次在 60 RPM 下至少需要 60 秒的模拟等待
    assert slept["total"] >= 60.0, slept
