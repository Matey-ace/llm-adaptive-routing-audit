"""原策略行为回归：新 adapter 与原 Agent 的调用角色/顺序/停止原因对照。

对照方式（工作包 A 第 5 项）：用固定的合成响应驱动，检查
  * 角色序列（plan / solve / reflect / replan / judge）与预期一致
  * 停止原因与旧 stopper 语义一致
  * 消息文本与旧 `AgentBase.build_messages` 输出逐字相同（提示未被改动）
  * Adaptive 的 S2 参数、router 指纹、judge 上限都来自冻结配置
"""

from __future__ import annotations

import json

import pytest

from sncs_fivearm.budget import Ledger
from sncs_fivearm.dispatcher import Dispatcher
from sncs_fivearm.inputs import TaskPrompt, sha256_text
from sncs_fivearm.journal import Journal
from sncs_fivearm.providers import PurposeSyntheticProvider, SyntheticAction
from sncs_fivearm.registry import (FROZEN_ADAPTIVE_OVERRIDES,
                                   FROZEN_AGENT_CONFIG, FROZEN_BASE_DECODING,
                                   FROZEN_ROUTER_SHA256, FiveArmRegistry)
from sncs_fivearm.simulation_runner import ownerless_contract


def _task(text="What is 2+2?") -> TaskPrompt:
    return TaskPrompt(task_id="T", prompt=text, prompt_sha256=sha256_text(text))


def _run(tmp_path, strategy, purpose_script, task=None, contract=None):
    c = contract or ownerless_contract()
    j = Journal(tmp_path / "j.jsonl")
    led = Ledger(currency="CNY", total_cap_micro=100_000_000,
                 phase_caps_micro={"preflight": 100_000_000, "main": 0},
                 price_in_micro_per_million=2_000_000,
                 price_out_micro_per_million=8_000_000)
    provider = PurposeSyntheticProvider(purpose_script)
    d = Dispatcher(journal=j, ledger=led, provider=provider, contract=c,
                   output_ceiling=c.output_ceiling, sampling=c.sampling(),
                   input_bound_method=c.input_bound_method)
    reg = FiveArmRegistry(dispatcher=d, contract=c, verify_router=False)
    outcome = reg.run_trajectory(strategy=strategy, task=task or _task(),
                                run_id="R", phase="preflight")
    purposes = [e["purpose"] for e in j.read_all()
                if e["event"] == "dispatch_intent_durable"]
    return outcome, purposes, provider, j


# ---------------------------------------------------------------- direct
def test_direct_single_shot(tmp_path):
    out, purposes, provider, _ = _run(tmp_path, "direct",
                                      {"solve": [SyntheticAction.text("ANSWER: 4")]})
    assert purposes == ["solve"]
    assert out.stop_reason == "direct_single_shot"
    assert out.final_answer == "4"


# ---------------------------------------------------------------- planning
def test_planning_plan_then_solve(tmp_path):
    out, purposes, provider, _ = _run(tmp_path, "planning", {
        "plan": [SyntheticAction.text("PLAN:\n1. add")],
        "solve": [SyntheticAction.text("ANSWER: 4")],
    })
    assert purposes == ["plan", "solve"]
    assert out.stop_reason == "planned_single_shot"
    assert out.final_answer == "4"


# ---------------------------------------------------------------- plan_reflect
def test_plan_reflect_pass_stops_after_one_reflection(tmp_path):
    out, purposes, _, _ = _run(tmp_path, "plan_reflect", {
        "plan": [SyntheticAction.text("PLAN:\n1. add")],
        "solve": [SyntheticAction.text("ANSWER: 4")],
        "reflect": [SyntheticAction.text(
            "REFLECT:\n- fine\nCONFIDENCE: 0.9\nVERDICT: PASS")],
    })
    assert purposes == ["plan", "solve", "reflect"]
    assert out.stop_reason == "reflection_verdict_pass"
    assert out.n_reflections == 1


def test_plan_reflect_s1_fixed_two_rounds(tmp_path):
    """S1(max_rounds=2)：第 2 轮反思后即停；只有第 1 轮会触发重规划。"""
    out, purposes, _, _ = _run(tmp_path, "plan_reflect", {
        "plan": [SyntheticAction.text("PLAN:\n1. add")],
        "solve": [SyntheticAction.text("ANSWER: 4")],
        "reflect": [SyntheticAction.text(
            "REFLECT:\n- hmm\nCONFIDENCE: 0.2\nVERDICT: REVISE")],
        "replan": [SyntheticAction.text("PLAN:\n1. redo")],
    })
    assert out.stop_reason == "fixed_rounds:2", out.stop_reason
    assert purposes.count("reflect") == 2
    assert out.n_reflections == 2
    assert out.n_replans == 1, "第 2 轮达到 max_rounds 后不再重规划"
    # 完整调用链：plan → solve → reflect → replan → solve → reflect
    assert purposes == ["plan", "solve", "reflect", "replan", "solve", "reflect"]


def test_plan_reflect_malformed_verdict_stops(tmp_path):
    out, purposes, _, _ = _run(tmp_path, "plan_reflect", {
        "plan": [SyntheticAction.text("PLAN:\n1. add")],
        "solve": [SyntheticAction.text("ANSWER: 4")],
        "reflect": [SyntheticAction.text("REFLECT:\n- no verdict at all")],
    })
    assert out.stop_reason == "verdict_malformed"
    assert purposes == ["plan", "solve", "reflect"]


# ---------------------------------------------------------------- adaptive
def test_adaptive_judge_path_and_router_recorded(tmp_path):
    """灰区 → judge → hard → plan_reflect 路径。"""
    task = _task("A shop sells pens for 3 dollars and notebooks for 7 dollars. "
                 "A customer buys 4 pens and 9 notebooks. Report the total cost in dollars and cents.")
    out, purposes, _, _ = _run(tmp_path, "adaptive_legacy", {
        "judge": [SyntheticAction.text(
            '{"level": "medium", "confidence": 0.7, "reasoning_steps": 2, "reason": "two steps"}')],
        "plan": [SyntheticAction.text("PLAN:\n1. multiply")],
        "solve": [SyntheticAction.text("ANSWER: 75")],
        "reflect": [SyntheticAction.text(
            "REFLECT:\n- ok\nCONFIDENCE: 0.95\nVERDICT: PASS")],
    }, task=task)
    assert purposes[0] == "judge", purposes
    assert out.selected_level == "medium"
    assert out.selected_path == "planning" or out.selected_path == "plan_reflect"
    assert "judge" in purposes


def test_adaptive_low_rule_score_goes_direct(tmp_path):
    task = _task("What is 2+2?")
    out, purposes, _, _ = _run(tmp_path, "adaptive_legacy", {
        "solve": [SyntheticAction.text("ANSWER: 4")],
        "plan": [SyntheticAction.text("PLAN:\n1. x")],
        "reflect": [SyntheticAction.text(
            "REFLECT:\n- ok\nCONFIDENCE: 0.9\nVERDICT: PASS")],
    }, task=task)
    assert out.selected_level == "easy"
    assert out.selected_path == "direct"
    assert purposes == ["solve"]


def test_frozen_parameters_match_source_config():
    """参数必须与 formal_{gsm8k,math}_primary_s6.yaml 一致。"""
    assert FROZEN_AGENT_CONFIG["max_reflections"] == 4
    assert FROZEN_AGENT_CONFIG["stopper"] == "S1"
    assert FROZEN_AGENT_CONFIG["stopper_params"] == {"max_rounds": 2}
    assert FROZEN_AGENT_CONFIG["judge_max_tokens"] == 4096
    assert FROZEN_AGENT_CONFIG["hard_cap"] == {"max_calls": 8, "max_rounds": 4}
    assert FROZEN_AGENT_CONFIG["budget"] == {"max_calls": 8}
    assert FROZEN_ADAPTIVE_OVERRIDES == {"stopper": "S2",
                                         "stopper_params": {"delta": 0.05, "streak": 2}}
    assert FROZEN_BASE_DECODING["temperature"] == 0.0
    assert FROZEN_BASE_DECODING["top_p"] == 1.0
    assert FROZEN_BASE_DECODING["seed"] == 42


def test_router_artifact_fingerprint_matches_frozen(workspace):
    from sncs_fivearm.inputs import sha256_file
    p = workspace / "results" / "complexity" / "router_candidate_s5_20261014.json"
    assert sha256_file(p) == FROZEN_ROUTER_SHA256


def test_registry_rejects_unknown_arm(tmp_path):
    from sncs_fivearm.registry import RegistryError
    c = ownerless_contract()
    j = Journal(tmp_path / "j.jsonl")
    led = Ledger(currency="CNY", total_cap_micro=1000,
                 phase_caps_micro={"preflight": 1000, "main": 0},
                 price_in_micro_per_million=1, price_out_micro_per_million=1)
    provider = PurposeSyntheticProvider({})
    d = Dispatcher(journal=j, ledger=led, provider=provider, contract=c,
                   output_ceiling=10, sampling={},
                   input_bound_method="utf8_byte_upper_bound_v1")
    reg = FiveArmRegistry(dispatcher=d, contract=c, verify_router=False)
    from sncs_fivearm.dispatcher import LegacyBridgeClient
    bridge = LegacyBridgeClient(d, role_limits={"default": 10}, model_name="m")
    with pytest.raises(RegistryError):
        reg.build("adaptive", bridge)


# ---------------------------------------------------------------- 提示未被改动
def test_prompt_messages_identical_to_legacy(legacy):
    """新 adapter 生成的 solve 消息必须与旧 `AgentBase.build_messages` 逐字相同。"""
    from sncs_fivearm.registry import _MessageBuilder
    av = legacy.agent_view.AgentView(task_id="T", prompt="What is 2+2?")
    new_msgs = _MessageBuilder(legacy.agent_base).build(av, "solve")

    # 用旧 Agent 实例直接调用同一方法
    class _FakeClient:
        meter = None
    agent = legacy.direct.DirectAgent.__new__(legacy.direct.DirectAgent)
    agent.toolbox = legacy.tools_builtin.MockToolBox()
    old_msgs = legacy.agent_base.AgentBase.build_messages(agent, av, "solve")
    assert new_msgs == old_msgs


def test_prompt_version_is_zh_v3(legacy):
    assert legacy.agent_base.PROMPT_VERSION == "zh-v3"


def test_all_three_prompt_kinds_match(legacy):
    from sncs_fivearm.registry import _MessageBuilder
    av = legacy.agent_view.AgentView(task_id="T", prompt="Question?")
    builder = _MessageBuilder(legacy.agent_base)

    class _A:
        pass
    agent = _A()
    agent.toolbox = legacy.tools_builtin.MockToolBox()
    for kind in ("plan", "solve", "reflect"):
        assert builder.build(av, kind, "hist") == \
            legacy.agent_base.AgentBase.build_messages(agent, av, kind, "hist")
