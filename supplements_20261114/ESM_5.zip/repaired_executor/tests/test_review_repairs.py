"""Offline acceptance for independently reproduced review findings."""
import base64
import http.client
import json
import threading
import types
from unittest.mock import patch

import pytest
from sncs_fivearm.budget import Ledger
from sncs_fivearm.dispatcher import Dispatcher
from sncs_fivearm.errors import ReconciliationRequired, RunLocked
from sncs_fivearm.evaluation.analysis import accuracy_by_arm
from sncs_fivearm.evaluation.stats import TaskOutcome, _pair_rows
from sncs_fivearm.inputs import TaskPrompt, sha256_text
from sncs_fivearm.journal import Journal, derive_trajectory_states
from sncs_fivearm.providers import (LocalGatewayProvider, PurposeSyntheticProvider,
                                   SyntheticAction, SyntheticProvider)
from sncs_fivearm.reconcile import reconcile_run
from sncs_fivearm.runner import Runner, RunConfig
from sncs_fivearm.simulation_runner import ownerless_contract, _fixture_bundle, _queue_rows

def task(t):
    return TaskPrompt(task_id=t, prompt='What is 1+1?', prompt_sha256=sha256_text('What is 1+1?'))

def runner(tmp_path, arms, provider, *, workers=1):
    tasks=[task('t')]
    bundle=_fixture_bundle(tasks,_queue_rows(tasks,arms,'fixture'))
    source=tmp_path/'source';source.mkdir(exist_ok=True)
    (source/'marker.py').write_text('VERSION=1\n')
    cfg=RunConfig(run_id='run',phase='preflight',contract=ownerless_contract(),
                  bundle=bundle,queue=bundle.queue,workers=workers)
    return Runner(config=cfg,provider=provider,runs_root=tmp_path,package_root=source)

def test_unknown_usage_halts_across_roles_and_tasks(tmp_path):
    p=PurposeSyntheticProvider({'plan':[SyntheticAction.missing_usage('PLAN: compute')]})
    r=runner(tmp_path,['planning','direct'],p)
    s=r.execute()
    assert len(p.calls)==1
    assert s.status=='STOPPED_WITH_UNRESOLVED_EXPOSURE'
    assert s.not_started==1
    assert any(e.get('content')=='PLAN: compute' for e in Journal(r.journal_path).read_all())

def test_reconcile_is_idempotent_and_releases_full_reservation(tmp_path):
    d=tmp_path/'billrun';d.mkdir();j=Journal(d/'journal.jsonl')
    j.append('reservation_created',request_id='q',phase='preflight',bound_micro=1000)
    j.append('reconciliation_required',request_id='q',phase='preflight',exposure_micro=1000)
    evidence=tmp_path/'bill.json'
    evidence.write_text(json.dumps({'items':[{'request_id':'q','billed_micro':800}]*2}))
    assert reconcile_run(run_id='billrun',runs_root=tmp_path,evidence=evidence)['status']=='RECONCILED'
    assert reconcile_run(run_id='billrun',runs_root=tmp_path,evidence=evidence)['status']=='NOTHING_TO_RECONCILE'
    led=Ledger.from_events(j.read_all(),currency='CNY',total_cap_micro=1000,
        phase_caps_micro={'preflight':1000},price_in_micro_per_million=1,price_out_micro_per_million=1)
    s=led.state()
    assert (s.known_charge_micro,s.unresolved_exposure_micro,s.unresolved_count)==(800,0,0)
    assert s.phase_known_micro=={'preflight':800}
    assert s.phase_unresolved_micro=={'preflight':0}
    assert sum(e['event']=='reconciled' for e in j.read_all())==1

def test_resume_preserves_cumulative_summary_and_rejects_code_drift(tmp_path):
    p=SyntheticProvider({});r=runner(tmp_path,['direct'],p);a=r.execute()
    r2=Runner(config=r.cfg,provider=SyntheticProvider({}),runs_root=tmp_path,package_root=r.package_root)
    b=r2.execute()
    assert (a.completed,a.dispatches)==(b.completed,b.dispatches)==(1,1)
    assert not r2.provider.calls
    (r.package_root/'marker.py').write_text('VERSION=2\n')
    with pytest.raises(RunLocked,match='code_fingerprint'):
        Runner(config=r.cfg,provider=SyntheticProvider({}),runs_root=tmp_path,package_root=r.package_root).execute()

def test_missing_pair_preserves_known_side_and_unstarted_upper():
    lookup={('t','B'):TaskOutcome('t','gsm8k',1,'completed')}
    assert _pair_rows(lookup,source='gsm8k',task_ids=['t'],arm_a='A',arm_b='B',policy='poor')==[(0,1)]
    assert accuracy_by_arm([],['t'],'A')['accuracy_optimistic']==1

def test_resume_orphan_halts_new_work_and_preserves_exposure(tmp_path):
    r=runner(tmp_path,['direct','planning'],SyntheticProvider({}))
    r.run_dir.mkdir();j=Journal(r.journal_path)
    rid=r.cfg.queue[0].run_id
    j.append('run_started',**r._run_meta())
    j.append('claim',run_id=rid)
    j.append('reservation_created',request_id=rid+'#d1',run_id=rid,phase='preflight',bound_micro=1000)
    j.append('dispatch_intent_durable',request_id=rid+'#d1',run_id=rid)
    s=r.execute()
    assert r.provider.calls==[]
    assert s.status=='STOPPED_WITH_UNRESOLVED_EXPOSURE'
    assert s.unresolved_micro==1000
    assert s.not_started==1

def test_concurrent_stop_preserves_completed_rows(tmp_path):
    tasks=[task(f'T{i}') for i in range(2)]
    rows=_queue_rows(tasks,['direct','planning','plan_reflect','adaptive_legacy','asc_beta_8'],'concurrent')
    bundle=_fixture_bundle(tasks,rows)
    rows=bundle.queue
    cfg=RunConfig(run_id='concurrent',phase='preflight',contract=ownerless_contract(),bundle=bundle,queue=bundle.queue,workers=2)
    r=Runner(config=cfg,provider=SyntheticProvider({}),runs_root=tmp_path,package_root=tmp_path)
    r.run_dir.mkdir();j=Journal(r.journal_path);done=threading.Event()
    def process(self,*,row,registry,journal):
        journal.append('claim',run_id=row.run_id)
        if row.task_id=='T0':
            assert done.wait(5)
            journal.append('budget_blocked',run_id=row.run_id)
            return 'budget_blocked'
        journal.append('completed',run_id=row.run_id)
        if row.execution_position==5:done.set()
        return 'completed'
    r._process_row=types.MethodType(process,r)
    r._loop_concurrent(registry=None,journal=j,dispatcher=None,plan={'resumable':[x.run_id for x in rows]},workers=2)
    states=derive_trajectory_states(j.read_all())
    assert all(states[x.run_id].state=='completed' for x in rows if x.task_id=='T1')

def make_dispatcher(tmp_path,provider):
    c=ownerless_contract()
    led=Ledger(currency='CNY',total_cap_micro=100_000_000,phase_caps_micro={'preflight':100_000_000},
               price_in_micro_per_million=2_000_000,price_out_micro_per_million=8_000_000)
    return Dispatcher(journal=Journal(tmp_path/'j.jsonl'),ledger=led,provider=provider,contract=c,
        output_ceiling=c.output_ceiling,sampling=c.sampling(),input_bound_method=c.input_bound_method)

def test_partial_response_bytes_survive_http_read_failure(tmp_path):
    partial=b'{"choices":[{"message":{"content":"PARTIAL_ANSWER"}}'
    class Partial:
        def __enter__(self):return self
        def __exit__(self,*a):pass
        def read(self):raise http.client.IncompleteRead(partial,100)
    d=make_dispatcher(tmp_path,LocalGatewayProvider('http://127.0.0.1:1','fixture','fixture'))
    with patch('urllib.request.urlopen',return_value=Partial()):
        rec=d.dispatch(run_id='t',phase='preflight',purpose='solve',messages=[{'role':'user','content':'2?'}],max_tokens=100)
    assert base64.b64decode(rec.envelope['raw_partial_base64'])==partial
    failed=next(e for e in d.journal.read_all() if e['event']=='failed')
    assert failed['partial_response']==rec.envelope
    assert d.ledger.state().unresolved_count==1

def test_request_receipt_matches_effective_request_and_unknown_zero_tariff_stops(tmp_path):
    p=SyntheticProvider({},default=SyntheticAction.missing_usage('saved'))
    d=make_dispatcher(tmp_path,p)
    d.ledger.price_in=d.ledger.price_out=0
    d.dispatch(run_id='t',phase='preflight',purpose='solve',messages=[{'role':'user','content':'2?'}],max_tokens=100)
    intent=next(e for e in d.journal.read_all() if e['event']=='dispatch_intent_durable')
    assert intent['request']['messages']==p.calls[0].messages
    assert intent['request']['max_tokens']==p.calls[0].max_tokens
    assert intent['request']['extra']==p.calls[0].extra
    assert len(intent['request_sha256'])==64
    assert d.ledger.unresolved_exposure_micro==0
    with pytest.raises(ReconciliationRequired):
        d.dispatch(run_id='other',phase='preflight',purpose='solve',messages=[],max_tokens=100)
    assert len(p.calls)==1
