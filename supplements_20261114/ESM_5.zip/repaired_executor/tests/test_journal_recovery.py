"""日志、恢复、崩溃注入（工作包 E 第 9–10 项）。"""

from __future__ import annotations

import json

import pytest

from sncs_fivearm.budget import Ledger
from sncs_fivearm.errors import JournalCorrupt, RunLocked
from sncs_fivearm.journal import (Journal, RunLock, derive_trajectory_states,
                                  resume_plan)


def test_append_is_durable_and_verifiable(tmp_path):
    j = Journal(tmp_path / "j.jsonl")
    j.append("claim", run_id="a")
    j.append("completed", run_id="a", final_answer="1")
    events = j.read_all()
    assert [e["event"] for e in events] == ["claim", "completed"]
    assert j.verify()["claims"] == 1


def test_tail_truncation_is_detected_not_skipped(tmp_path):
    path = tmp_path / "j.jsonl"
    j = Journal(path)
    j.append("claim", run_id="a")
    j.append("completed", run_id="a")
    with path.open("a", encoding="utf-8") as fh:
        fh.write('{"event":"claim","run_id":"b"')  # 半行
    j2 = Journal(path)
    tail = j2.tail_status()
    assert tail.truncated is True
    assert tail.trailing_bytes > 0
    with pytest.raises(JournalCorrupt):
        j2.read_all()
    with pytest.raises(JournalCorrupt):
        j2.append("claim", run_id="c")


def test_corrupt_line_raises_on_strict_read(tmp_path):
    path = tmp_path / "j.jsonl"
    path.write_text('{"event":"claim","run_id":"a"}\nnot json\n', encoding="utf-8")
    j = Journal(path)
    with pytest.raises(JournalCorrupt):
        j.read_all()


def test_duplicate_claim_detected(tmp_path):
    path = tmp_path / "j.jsonl"
    path.write_text(
        '{"event":"claim","run_id":"a"}\n{"event":"claim","run_id":"a"}\n',
        encoding="utf-8")
    with pytest.raises(JournalCorrupt):
        Journal(path).verify()


def test_duplicate_dispatch_intent_detected(tmp_path):
    path = tmp_path / "j.jsonl"
    path.write_text(
        '{"event":"dispatch_intent_durable","request_id":"q1","run_id":"a"}\n'
        '{"event":"dispatch_intent_durable","request_id":"q1","run_id":"a"}\n',
        encoding="utf-8")
    with pytest.raises(JournalCorrupt):
        Journal(path).verify()


def test_settle_without_reservation_detected(tmp_path):
    path = tmp_path / "j.jsonl"
    path.write_text(
        '{"event":"usage_settled","request_id":"q1"}\n', encoding="utf-8")
    with pytest.raises(JournalCorrupt):
        Journal(path).verify()


def test_unknown_event_type_rejected(tmp_path):
    j = Journal(tmp_path / "j.jsonl")
    with pytest.raises(JournalCorrupt):
        j.append("not_a_real_event", run_id="a")


def test_run_lock_is_exclusive(tmp_path):
    run_dir = tmp_path / "run"
    with RunLock(run_dir):
        with pytest.raises(RunLocked):
            with RunLock(run_dir):
                pass
    # 释放后可再次获取
    with RunLock(run_dir):
        pass


def test_crash_after_intent_is_quarantined_not_resent(tmp_path):
    """注入崩溃点：intent 已落盘、无 response → 恢复时必须隔离，不得重发。"""
    path = tmp_path / "j.jsonl"
    j = Journal(path)
    j.append("claim", run_id="traj1")
    j.append("reservation_created", request_id="traj1#d1", run_id="traj1",
             phase="preflight", bound_micro=1000)
    j.append("dispatch_intent_durable", request_id="traj1#d1", run_id="traj1")
    # 进程在此崩溃
    states = derive_trajectory_states(Journal(path).read_all())
    assert states["traj1"].state == "dispatched_unknown"
    plan = resume_plan(Journal(path).read_all(), ["traj1", "traj2"])
    assert plan["resumable"] == ["traj2"]
    assert plan["blocked_requires_reconciliation"][0]["run_id"] == "traj1"
    assert plan["blocked_requires_reconciliation"][0]["action"] == \
        "quarantine_reconciliation_required"


def test_crash_before_intent_is_safely_resumable(tmp_path):
    """注入崩溃点：claim + 预留已写，但 intent 未写 → 可安全重新 claim。"""
    path = tmp_path / "j.jsonl"
    j = Journal(path)
    j.append("claim", run_id="traj1")
    j.append("reservation_created", request_id="traj1#d1", run_id="traj1",
             phase="preflight", bound_micro=1000)
    states = derive_trajectory_states(Journal(path).read_all())
    assert states["traj1"].state == "claimed_no_dispatch"
    plan = resume_plan(Journal(path).read_all(), ["traj1"])
    assert plan["resumable"] == ["traj1"]


def test_completed_trajectory_never_resent(tmp_path):
    path = tmp_path / "j.jsonl"
    j = Journal(path)
    j.append("claim", run_id="t1")
    j.append("dispatch_intent_durable", request_id="t1#d1", run_id="t1")
    j.append("response_received", request_id="t1#d1", run_id="t1", content="x")
    j.append("usage_settled", request_id="t1#d1", run_id="t1", actual_micro=10)
    j.append("completed", run_id="t1", final_answer="ANSWER: 1")
    plan = resume_plan(Journal(path).read_all(), ["t1"])
    assert plan["resumable"] == []
    assert plan["already_terminal"] == ["t1"]


def test_replay_after_crash_keeps_dispatch_count(tmp_path):
    """崩溃恢复后，8 次门不重置：已派发次数必须从日志重放。"""
    path = tmp_path / "j.jsonl"
    j = Journal(path)
    for i in range(3):
        j.append("dispatch_intent_durable", request_id=f"t1#d{i+1}", run_id="t1")
    states = derive_trajectory_states(Journal(path).read_all())
    assert states["t1"].dispatches == 3


def test_journal_events_are_fsynced(tmp_path):
    """fsync 生效：写入后立刻读新文件句柄也能看到（不需要显式 close）。"""
    path = tmp_path / "j.jsonl"
    j = Journal(path)
    j.append("claim", run_id="a")
    raw = path.read_bytes()
    assert raw.endswith(b"\n")
    assert b'"claim"' in raw
