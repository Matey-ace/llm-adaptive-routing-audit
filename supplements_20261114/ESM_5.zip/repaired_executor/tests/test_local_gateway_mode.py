"""本机网关（upl）执行模式测试。

规则：
* 只允许 127.0.0.1 / localhost，不得指向公网；
* 不把"没有计费接口"说成"免费"，费用结论必须标为不可核实；
* 需要 `local_gateway_authorization`（作者指定入口），但**不需要**外部支出批准；
* 任何情况下都不写 approvals 目录。
"""

from __future__ import annotations

import json

import pytest

from sncs_fivearm.contracts import Contract, ContractError, draft_contract


def _gateway_contract(**over) -> dict:
    d = draft_contract()
    d["execution_mode"] = "local_gateway"
    d["phase_scope"] = ["preflight"]
    d["provider"].update({
        "name": "workbuddy-local-gateway",
        "base_url": "http://127.0.0.1:8787",
        "model_id": "deepseek-v4.1-flash",
        "api_key_env": "SNCS_UPL_API_KEY",
        "timeout_seconds": 180,
    })
    d["provider"]["sampling"]["temperature_or_omitted_reason"] = "thinking_no_temperature"
    d["limits"]["input_token_upper_bound_method"] = "utf8_byte_upper_bound_v1"
    d["tariff"].update({
        "currency": "CNY",
        "input_uncached_micro_per_million": 0,
        "output_micro_per_million": 0,
        "source": {"url": "local://workbuddy/no-billing-endpoint",
                   "checked_utc": "2026-11-13T00:00:00Z",
                   "provider_validated": False},
    })
    d["budget"].update({"currency": "CNY", "total_micro": 0,
                        "preflight_micro": 0, "main_micro": 0})
    d["local_gateway_authorization"] = {
        "quote": "请用 upl：http://127.0.0.1:8787 的 ds 模型",
        "external_billing": False,
        "phase_scope": ["preflight"],
    }
    for k, v in over.items():
        d[k] = v
    return d


def _load(tmp_path, raw) -> Contract:
    p = tmp_path / "c.json"
    p.write_text(json.dumps(raw, ensure_ascii=False), encoding="utf-8")
    return Contract.load(p, approvals_dir=tmp_path / "approvals")


def test_local_gateway_is_runnable_without_spending_approval(tmp_path):
    c = _load(tmp_path, _gateway_contract())
    assert c.mode == "local_gateway"
    assert c.approved is False, "本机网关不等于外部支出批准"
    assert c.live_ready is True, c.problems
    assert c.problems == []


def test_local_gateway_rejects_remote_endpoint(tmp_path):
    raw = _gateway_contract()
    raw["provider"]["base_url"] = "https://api.example.com/v1"
    c = _load(tmp_path, raw)
    assert c.live_ready is False
    assert any("127.0.0.1" in p or "localhost" in p for p in c.problems)


def test_local_gateway_requires_authorization_quote(tmp_path):
    raw = _gateway_contract()
    raw["local_gateway_authorization"]["quote"] = ""
    c = _load(tmp_path, raw)
    assert c.live_ready is False
    assert any("quote" in p for p in c.problems)


def test_local_gateway_requires_external_billing_false(tmp_path):
    raw = _gateway_contract()
    raw["local_gateway_authorization"]["external_billing"] = True
    c = _load(tmp_path, raw)
    assert c.live_ready is False
    assert any("external_billing" in p for p in c.problems)


def test_local_gateway_phase_scope_must_match(tmp_path):
    raw = _gateway_contract()
    raw["local_gateway_authorization"]["phase_scope"] = ["main"]
    c = _load(tmp_path, raw)
    assert c.live_ready is False
    assert any("phase_scope" in p for p in c.problems)


def test_zero_tariff_is_marked_not_provider_validated(tmp_path):
    c = _load(tmp_path, _gateway_contract())
    assert c.price_in_micro() == 0
    assert c.get("tariff.source.provider_validated") is False
    assert c.get("budget.cost_conclusion_allowed", False) in (False, None)


def test_live_mode_still_requires_human_approval(tmp_path):
    """对照：live 模式不能靠 local_gateway_authorization 放行。"""
    raw = _gateway_contract()
    raw["execution_mode"] = "live"
    c = _load(tmp_path, raw)
    assert c.live_ready is False
    assert c.approved is False


def test_provider_factory_rejects_non_local_base_url():
    from sncs_fivearm.providers import build_provider

    class Fake:
        mode = "local_gateway"
        def require_live_ready(self): return None
        def get(self, path, default=None):
            return {"provider.base_url": "http://10.0.0.5:8787",
                    "provider.api_key_env": "X"}.get(path, default)

    import os
    os.environ["X"] = "dummy"
    with pytest.raises(RuntimeError):
        build_provider(Fake(), allow_live=True)


def test_contract_schema_rejects_unknown_mode(tmp_path):
    raw = _gateway_contract()
    raw["execution_mode"] = "free_money"
    p = tmp_path / "c.json"
    p.write_text(json.dumps(raw, ensure_ascii=False), encoding="utf-8")
    with pytest.raises(ContractError):
        Contract.load(p)
