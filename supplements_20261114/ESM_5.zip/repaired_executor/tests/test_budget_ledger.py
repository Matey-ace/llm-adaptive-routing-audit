"""预算账本：精确整数、双额度、未知暴露、币种一致性。"""

from __future__ import annotations

import pytest

from sncs_fivearm.budget import (BudgetError, CurrencyMismatch, Ledger,
                                 ReservationViolation, cost_micro, cny_to_micro,
                                 micro_to_cny)


def _ledger(total=1_000_000, pre=1_000_000, main=0, pin=2_000_000, pout=8_000_000):
    return Ledger(currency="CNY", total_cap_micro=total,
                  phase_caps_micro={"preflight": pre, "main": main},
                  price_in_micro_per_million=pin,
                  price_out_micro_per_million=pout)


def test_cost_is_ceil_and_integer():
    # 1 token @ 2e6 micro / 1e6 = 2 micro
    assert cost_micro(1, 2_000_000) == 2
    # 上取整：1 token @ 1 micro per million = 1 micro（不能四舍五入成 0）
    assert cost_micro(1, 1) == 1
    assert cost_micro(0, 2_000_000) == 0
    assert isinstance(cost_micro(123456, 2_000_000), int)


def test_currency_conversion_never_uses_float():
    assert cny_to_micro("1") == 1_000_000
    assert cny_to_micro("0.000001") == 1
    assert cny_to_micro("-2.5") == -2_500_000
    assert micro_to_cny(1_500_000) == "1.500000"
    with pytest.raises(BudgetError):
        cny_to_micro("0.0000001")


def test_reject_non_cny_currency():
    with pytest.raises(CurrencyMismatch):
        Ledger(currency="USD", total_cap_micro=1,
               phase_caps_micro={"preflight": 1},
               price_in_micro_per_million=1, price_out_micro_per_million=1)


def test_reserve_and_settle_exact():
    led = _ledger()
    res = led.reserve(request_id="r1", run_id="run1", phase="preflight",
                      purpose="solve", input_tokens_upper=1000,
                      output_tokens_upper=100)
    assert res.bound_micro == cost_micro(1000, 2_000_000) + cost_micro(100, 8_000_000)
    assert led.reserved_micro == res.bound_micro
    outcome = led.settle(request_id="r1", prompt_tokens=800, completion_tokens=50)
    assert outcome == "settled"
    assert led.reserved_micro == 0
    assert led.known_charge_micro == (
        cost_micro(800, 2_000_000) + cost_micro(50, 8_000_000))


def test_duplicate_request_id_rejected():
    led = _ledger()
    led.reserve(request_id="r1", run_id="run1", phase="preflight", purpose="solve",
                input_tokens_upper=10, output_tokens_upper=10)
    with pytest.raises(BudgetError):
        led.reserve(request_id="r1", run_id="run1", phase="preflight", purpose="solve",
                    input_tokens_upper=10, output_tokens_upper=10)


def test_settle_without_reservation_rejected():
    led = _ledger()
    with pytest.raises(ReservationViolation):
        led.settle(request_id="ghost", prompt_tokens=1, completion_tokens=1)


def test_missing_usage_becomes_unresolved_not_zero():
    led = _ledger()
    res = led.reserve(request_id="r1", run_id="run1", phase="preflight",
                      purpose="solve", input_tokens_upper=1000, output_tokens_upper=1000)
    outcome = led.settle(request_id="r1", prompt_tokens=None, completion_tokens=None)
    assert outcome == "unresolved_missing_usage"
    assert led.known_charge_micro == 0
    assert led.unresolved_exposure_micro == res.bound_micro
    assert led.reserved_micro == 0


def test_overrun_becomes_unresolved_not_widened():
    led = _ledger()
    res = led.reserve(request_id="r1", run_id="run1", phase="preflight",
                      purpose="solve", input_tokens_upper=10, output_tokens_upper=10)
    outcome = led.settle(request_id="r1", prompt_tokens=10_000, completion_tokens=10_000)
    assert outcome == "unresolved_overrun"
    assert led.known_charge_micro == 0
    assert led.unresolved_exposure_micro == res.bound_micro


def test_total_cap_blocks_before_dispatch():
    led = _ledger(total=10_000)
    decision = led.check(request_id="r1", run_id="run1", phase="preflight",
                         purpose="solve", input_tokens_upper=10_000,
                         output_tokens_upper=10_000)
    assert decision.allowed is False
    assert decision.reason == "total_cap_exceeded"


def test_phase_cap_blocks_even_when_total_is_large():
    led = _ledger(total=10_000_000, pre=1_000, main=9_999_000)
    decision = led.check(request_id="r1", run_id="run1", phase="preflight",
                         purpose="solve", input_tokens_upper=10_000,
                         output_tokens_upper=10_000)
    assert decision.allowed is False
    assert decision.reason == "phase_cap_exceeded"


def test_both_caps_are_checked_and_reported():
    """阶段额度与总额度同时生效：哪个先卡住就报哪个。"""
    led = _ledger(total=1_000, pre=1_000_000, main=1_000_000)
    d = led.check(request_id="x", run_id="r", phase="preflight", purpose="solve",
                  input_tokens_upper=100_000, output_tokens_upper=100_000)
    assert d.reason == "total_cap_exceeded"

    led2 = _ledger(total=10_000_000, pre=1_000, main=10_000_000)
    d2 = led2.check(request_id="x", run_id="r", phase="preflight", purpose="solve",
                    input_tokens_upper=100_000, output_tokens_upper=100_000)
    assert d2.reason == "phase_cap_exceeded"


def test_unresolved_exposure_counts_against_cap():
    led = _ledger(total=100_000)
    led.reserve(request_id="r1", run_id="run1", phase="preflight", purpose="solve",
                input_tokens_upper=1000, output_tokens_upper=1000)
    led.settle(request_id="r1", prompt_tokens=None, completion_tokens=None)
    exposure = led.unresolved_exposure_micro
    assert exposure > 0
    decision = led.check(request_id="r2", run_id="run1", phase="preflight",
                         purpose="solve", input_tokens_upper=100_000,
                         output_tokens_upper=100_000)
    assert decision.allowed is False
    assert decision.state["unresolved_exposure_micro"] == exposure


def test_reconcile_moves_exposure_to_known():
    led = _ledger(total=10_000_000)
    led.reserve(request_id="r1", run_id="run1", phase="preflight", purpose="solve",
                input_tokens_upper=1000, output_tokens_upper=1000)
    led.settle(request_id="r1", prompt_tokens=None, completion_tokens=None)
    exposure = led.unresolved_exposure_micro
    led.reconcile(request_id="r1", amount_micro=exposure // 2, note="bill partial")
    assert led.unresolved_exposure_micro == 0
    assert led.state().phase_unresolved_micro["preflight"] == 0
    assert led.known_charge_micro == exposure // 2
    with pytest.raises(BudgetError):
        led.reconcile(request_id="r1", amount_micro=exposure * 10)


def test_replay_reconstructs_state():
    led = _ledger(total=10_000_000)
    led.reserve(request_id="r1", run_id="run1", phase="preflight", purpose="solve",
                input_tokens_upper=1000, output_tokens_upper=1000)
    led.settle(request_id="r1", prompt_tokens=500, completion_tokens=100)
    events = [
        {"event": "reservation_created", "request_id": "r1", "run_id": "run1",
         "phase": "preflight", "bound_micro": 2136, "input_tokens_upper": 1000,
         "output_tokens_upper": 1000, "purpose": "solve"},
        {"event": "usage_settled", "request_id": "r1", "phase": "preflight",
         "actual_micro": 1800},
    ]
    replay = Ledger.from_events(events, currency="CNY", total_cap_micro=10_000_000,
                                phase_caps_micro={"preflight": 10_000_000},
                                price_in_micro_per_million=2_000_000,
                                price_out_micro_per_million=8_000_000)
    assert replay.known_charge_micro == 1800
    assert replay.reserved_micro == 0
    assert replay.unresolved_exposure_micro == 0


def test_replay_preserves_unresolved():
    events = [
        {"event": "reservation_created", "request_id": "r1", "run_id": "run1",
         "phase": "preflight", "bound_micro": 5000, "input_tokens_upper": 1,
         "output_tokens_upper": 1, "purpose": "solve"},
        {"event": "reconciliation_required", "request_id": "r1", "phase": "preflight",
         "exposure_micro": 5000},
    ]
    replay = Ledger.from_events(events, currency="CNY", total_cap_micro=10_000_000,
                                phase_caps_micro={"preflight": 10_000_000},
                                price_in_micro_per_million=1, price_out_micro_per_million=1)
    assert replay.unresolved_exposure_micro == 5000
    assert replay.known_charge_micro == 0
