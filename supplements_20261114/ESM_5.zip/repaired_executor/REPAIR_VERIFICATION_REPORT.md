# 执行器修复与验收报告

2026-11-14。本目录为独立修复副本，不是生成 2026-11-13 主实验的原执行器。原实验仍应引用原版本；这些后续修复不得表述为实验前已具备的保障。

## Evidence and Gate Decision

既有独立审查的 8 个离线复现给出故障基线。用户“全交由你来解决”授权修复。按 `REPAIR_GATES.md` 逐个行为门修复；全部为局部修改，没有修改旧策略或重写算法。门禁路线为 code-quality-workflow，A0 收据已记录。

## Behavior Contract

| 原问题 | 修复后行为 | 证据 |
|---|---|---|
| 缺用量后继续调用 | 任意未决请求存在时停止新派发，即使合同价格为零；已收到正文仍保留 | `test_unknown_usage_halts_across_roles_and_tasks`、`test_request_receipt_matches_effective_request_and_unknown_zero_tariff_stops` |
| 同一账单重复入账、少释放预留、阶段账不一致 | request_id 对账幂等，释放原预留全额，只计实际金额；阶段与总账同步；负数和非整数账单拒绝 | `test_reconcile_is_idempotent_and_releases_full_reservation`、原账本测试 |
| 恢复后摘要归零、跨代码版本续跑 | 完成数/派发数由累计日志重算，代码指纹变动拒绝原 run_id | `test_resume_preserves_cumulative_summary_and_rejects_code_drift` |
| 恢复时孤儿 intent 尚未转为未决 | 在新工作前将对应预留全额转未决并停派发 | `test_resume_orphan_halts_new_work_and_preserves_exposure` |
| 残缺日志尾被跳过 | 严格读取及追加均拒绝残尾，先保全核查 | 更新 `test_tail_truncation_is_detected_not_skipped` |
| 并发停止覆盖已完成状态 | 各题块只标自己的未开始行，正在运行的任务排空；不批量重写其他线程状态 | `test_concurrent_stop_preserves_completed_rows` |
| HTTP 读取中断丢掉部分响应 | `IncompleteRead` 的已收字节以 base64、长度和 partial 标记保存入失败事件；全额保留费用暴露 | `test_partial_response_bytes_survive_http_read_failure` |
| 缺行填充值抹掉已知侧、乐观界遗漏未开始题 | 仅填未知侧，保留已知侧；乐观正确率包含计划但未开始的题 | `test_missing_pair_preserves_known_side_and_unstarted_upper` |
| 实际请求没有持久收据 | intent 写入 messages、输出上限、sampling、thinking/effort 等 extra、模型与 SHA-256；不保存鉴权头，结构化敏感字段脱敏 | 请求收据测试 |
| 测试锁定研究结论与恒真断言 | 删除“必须差值接近零/区间跨零/两评分必须不同”的要求，改检验合法范围和计数；抽查名单验证确实属于评审项目 | 更新 human_review / review_package 测试 |

## Authorized Scope and Patch Budget

维护代码与测试共 19 个文件有实质差异，增加 287 行、删除 43 行；其中新增回归测试占 145 行。所有旧策略源文件、算法参数、合同内容、题目清单和原始实验文件保持原样。没有新增依赖。`repair_evidence/repairs.patch` 给出逐行差异，`changed_files.json` 记录前后 SHA-256。

为隔离副本位置变化，CLI 新增可选 `SNCS_WORKSPACE_ROOT` 环境变量；默认行为保持不变。测试允许通过 `SNCS_ARCHIVE_FIXTURES` 指向只读原档。仅复制小型 legacy_copy_manifest 作为旧代码来源凭据；没有复制大型 runs。

## Pre-change Baseline

既有审查已运行原 225 项离线测试并记录通过，但其额外 8 个合成场景发现缺陷。首次在嵌套副本执行全套测试时出现 14 失败、43 跳过：包括路径变化、历史输入不在副本、临时目录权限，以及故障门修复后揭示的旧测试假设。保留 `verification_full_log.txt` 作为过程证据。

其中三个派发上限/并发用例的合成 token 用量超过其自己声明的预留上界；修正用例 pt/ct 为明确低于上界的值，仍完整验证预算竞争和 8 次派发门。运输场景先执行确定未计费失败，再执行可能计费失败，以适应后者发生后全 run 停派发的新合同。缺行正确率期望由 0.5 更正为 1.0。均有明确语义原因，不是为保留研究结论调整结果。

## Change Summary

改动集中在账本、对账、日志、恢复/并发、派发收据、HTTP 中断保全及不完整统计。未改提示词、路由器、ASC 后验、策略停止参数或主实验评分。缺用量的正文可继续作为该次响应留存，下一次模型派发则被明确阻断。

## Verification Results

- 最终完整离线测试：**233 passed in 10.86s，无失败、无跳过**（原 225 + 新 8 项）。见 `verification_final_log.txt`。
- 离线测试启动：`python -B -X utf8 verify_offline.py`。测试从本副本导入代码，并只读引用原归档数据。`socket.create_connection` 设为网络调用失败门；所有 provider 场景为 synthetic 或 mocked HTTP；没有调用模型或付费服务。
- Windows 兼容：仅测试启动器在内存中将 mkdir mode 改为 0777，TEMP/TMP 指向本目录；不修改系统权限或产品代码。
- 原目录 195 个文件在最终测试前后 SHA-256 一致，`original_changed=[]`。见 `verification_integrity.json`。
- 完整差异中无 legacy_root 变动，没有未分配到门禁组的维护文件。

## Final Scope Check

各模块的 numstat 均运行技能提供的 `check_patch_scope.py --fail-on-warning`。逐模块使用 local-fix（最多 2 文件/80 行）或 staged-refactor（最多 5 文件/200 行）；回归测试集中归入单独验收阶段。结果见 `repair_evidence/scope_*.json`。

这里采用独立副本与原件的完整维护树比较，而非 Git HEAD；检查器也明确标注 supplied numstat snapshot 的覆盖限制。完整维护树库存、逐文件散列与 unified diff 用于补齐该限制。门禁分组是审核批次，不宣称为 Git 历史提交。报告、运行日志、测试临时输出和辅助证据生成器属于新增交付材料，未混入产品代码行数。

## Residual Risk or Stop Reason

这些验证证明已审计故障路径的本地行为，不证明真实服务在断流、账单导出或部署故障时的全部行为。并发发生未决时，在未知状态被观察到之前已派发的请求仍可能返回；修复不声称可撤销已经在途的请求。HTTP 部分响应验证针对 `IncompleteRead` 能提供的字节，未获得的字节不存在可恢复证据。请求收据只适用于未来运行，历史请求不得伪补成当时持久化记录。

本次不重跑主实验，也不重新给历史分数。发表主张、争议题敏感性、全文整合和页面排版由总协调任务另行验收。恢复跨代码版本时使用新 run_id，历史运行只读，不在原 run 上强行续跑。
