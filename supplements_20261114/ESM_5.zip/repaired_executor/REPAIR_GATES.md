# 执行器修复门禁（2026-11-14）

用户授权：全部解决既有审查问题。仅修改本独立副本，原执行器、原实验日志、评分及历史结果保持原样。

Evidence and Gate Decision：既有独立审查的 8 个合成复现为变更前基线；原测试 225 项通过而缺少这些故障门。各行为选择 Local Fix / Local Fix Only，账本跨 replay 的同步选择 Staged Refactor（每阶段小于 200 行）。不重写策略。

Behavior Contract / stages：
1. 未知用量：派发器以未决请求数阻止后续派发（含零价合同），保留首个响应。范围 dispatcher.py / runner.py / 回归测试，目标 80 行。
2. 对账：按 request_id 全额消除原预留，计入实际金额，阶段与总账一致；重复账单幂等。范围 budget.py、reconcile.py、测试，分两个小于 120 行的阶段。
3. 恢复：摘要来自累计日志，代码指纹改变则拒绝复用 run_id。范围 runner.py / 测试，目标 60 行。
4. 日志：严格读取和追加均拒绝残尾；范围 journal.py / 测试，目标 40 行。
5. 并发停止：不覆盖已领取或完成任务；范围 runner.py / 测试，目标 40 行。
6. 部分响应：IncompleteRead 的字节证据持久保存，整笔保留费用暴露；范围 providers、dispatcher / 测试，目标 60 行。
7. 缺行统计：保留已知侧；乐观界覆盖未开始行。范围 stats.py、analysis.py / 测试，目标 40 行。
8. 请求收据：意图事件包含实际请求字段和散列（无鉴权头），范围 dispatcher.py / 测试，目标 50 行。
9. 测试：删除结论锁定和恒真断言，改成结构、代数与合法范围检查；不强迫研究结论不变。

Authorized Scope and Patch Budget：以上分步，每步按列示文件与行为验收。禁止变动原目录、原始评分、策略、依赖及任何联网调用。新增回归测试允许单一测试文件累计。

Verification gate：先针对每步已知复现写独立断言，再全部离线测试；网络连接设 tripwire。Windows 临时目录创建使用显式 0777 的内存兼容包装，仅测试启动器使用。原有依赖真实归档的测试通过只读原档夹具运行，不复制 runs。

Deletion safety：仅替换已证实错误分支与无效断言，无文件删除。Stop / rollback：出现策略或主结果变化即停止，副本随时可弃置回退原件。Remaining risks：不验证真实 HTTP 服务和故障时真实账单。

A0 receipt：goal=修复已审查故障并验收；red lines=原档只读、离线、无模型调用；acceptance=针对性回归与全套离线证据。route=code-quality-workflow；document=ST-A0；snapshot=2026-08-18；candidates=[]；unresolved=[]。
