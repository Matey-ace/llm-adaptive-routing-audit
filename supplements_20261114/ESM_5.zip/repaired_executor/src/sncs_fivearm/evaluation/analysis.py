"""分析：从已评分结果生成可重建的表与机器可读报告。

纪律：

* 只用 score 文件（不回读原始 results 做"更好的"判定）。
* 全错/全对/全 unknown/零完整配对 → 明确状态，不伪造数值。
* 两源**不合池**做主结论；合池只给"仅描述"的示意值。
* 费用与 usage 覆盖率单列，未决暴露不清零。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

from . import ANALYSIS_PLAN_VERSION
from .stats import (BOOTSTRAP_DRAWS, DELTA_MARGIN, SEED, build_lookup,
                    clustered_bootstrap, compare_arms,
                    paired_cluster_bootstrap, resource_summary)
from .resources import (assert_totals_match_summary, load_calls, per_arm,
                        per_purpose, per_task_arm, run_to_arm, totals,
                        usage_coverage)

PRIMARY = ("adaptive_legacy", "plan_reflect")
EXPLORATORY = ("direct", "planning", "asc_beta_8")
ALL_ARMS = ("direct", "planning", "plan_reflect", "adaptive_legacy", "asc_beta_8")


def load_scored(path: Path | str) -> List[Dict[str, Any]]:
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines()
            if line.strip()]


def load_results(path: Path | str) -> List[Dict[str, Any]]:
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines()
            if line.strip()]


def plan_task_ids(queue_rows: Sequence[Dict[str, Any]], phase: str,
                  source: str) -> List[str]:
    seen: List[str] = []
    known: set = set()
    for row in queue_rows:
        if row.get("phase") != phase or row.get("source") != source:
            continue
        tid = str(row.get("task_id"))
        if tid not in known:
            known.add(tid)
            seen.append(tid)
    return seen


def accuracy_by_arm(scored: Sequence[Dict[str, Any]], task_ids: Sequence[str],
                    arm: str) -> Dict[str, Any]:
    wanted = set(task_ids)
    rows = [r for r in scored if r.get("strategy") == arm
            and str(r.get("task_id")) in wanted]
    n_planned = len(task_ids)
    n_scored = len(rows)
    correct = sum(1 for r in rows if (r.get("score") or {}).get("decision") == "correct")
    incorrect = sum(1 for r in rows if (r.get("score") or {}).get("decision") == "incorrect")
    unknown = sum(1 for r in rows if (r.get("score") or {}).get("decision") == "unknown")
    if n_planned == 0:
        return {"arm": arm, "status": "NO_TASKS"}
    return {
        "arm": arm,
        "status": "OK",
        "n_planned": n_planned,
        "n_scored": n_scored,
        "not_started": max(0, n_planned - n_scored),
        "correct": correct, "incorrect": incorrect, "unknown": unknown,
        "accuracy_on_scored": (correct / n_scored) if n_scored else None,
        "accuracy_pessimistic": (correct / n_planned) if n_planned else None,
        "accuracy_optimistic": ((correct + unknown + max(0, n_planned - n_scored)) / n_planned) if n_planned else None,
        "unknown_rate": (unknown / n_scored) if n_scored else None,
    }


def build_report(*, scored_rows: Sequence[Dict[str, Any]],
                 results_rows: Sequence[Dict[str, Any]],
                 queue_rows: Sequence[Dict[str, Any]],
                 phase: str,
                 run_meta: Optional[Dict[str, Any]] = None,
                 journal_path: Optional[Path | str] = None,
                 summary: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    sources = sorted({str(q.get("source")) for q in queue_rows if q.get("phase") == phase})
    lookup = build_lookup(scored_rows)
    report: Dict[str, Any] = {
        "plan_version": ANALYSIS_PLAN_VERSION,
        "phase": phase,
        "seed": SEED,
        "bootstrap_draws": BOOTSTRAP_DRAWS,
        "margin_reference": DELTA_MARGIN,
        "primary_comparison": list(PRIMARY),
        "exploratory_arms": list(EXPLORATORY),
        "all_arms": list(ALL_ARMS),
        "run_meta": run_meta or {},
        "sources": {},
    }

    # journal 为唯一真源的资源账目（steps 不含 token，ASC 无 steps）
    if journal_path is not None:
        calls = load_calls(journal_path)
        mapping = run_to_arm(queue_rows)
        resources_block = {
            "source": "journal",
            "totals": totals(calls),
            "by_purpose": per_purpose(calls),
            "by_arm": per_arm(calls, mapping),
            "usage_coverage": usage_coverage(calls),
            "per_task_arm": per_task_arm(calls, mapping),
        }
        if summary is not None:
            resources_block["reconciliation"] = assert_totals_match_summary(calls, summary)
        report["journal_resources"] = resources_block

    for source in sources:
        tids = plan_task_ids(queue_rows, phase, source)
        arm_acc = {arm: accuracy_by_arm(scored_rows, tids, arm) for arm in ALL_ARMS}
        primary = compare_arms(lookup=lookup, source=source, task_ids=tids,
                               arm_a=PRIMARY[0], arm_b=PRIMARY[1])
        exploratory = {}
        for arm in EXPLORATORY:
            exploratory[f"{arm}_minus_plan_reflect"] = compare_arms(
                lookup=lookup, source=source, task_ids=tids,
                arm_a=arm, arm_b="plan_reflect")
        resources = {arm: resource_summary(results_rows=results_rows,
                                          task_ids=tids, arm=arm)
                     for arm in ALL_ARMS}
        report["sources"][source] = {
            "n_tasks": len(tids),
            "accuracy_by_arm": arm_acc,
            "primary": primary,
            "exploratory": exploratory,
            "resources": resources,
        }
        if journal_path is not None:
            tr = report["journal_resources"]["per_task_arm"]
            report["sources"][source]["paired_bootstrap"] = {
                metric: paired_cluster_bootstrap(
                    task_resources=tr, task_ids=tids, arm_a=PRIMARY[0],
                    arm_b=PRIMARY[1], metric=metric)
                for metric in ("dispatches", "prompt_tokens", "completion_tokens")
            }
    report["pooled_descriptive_only"] = _pooled(scored_rows, queue_rows, phase)
    return report


def _pooled(scored: Sequence[Dict[str, Any]], queue_rows: Sequence[Dict[str, Any]],
            phase: str) -> Dict[str, Any]:
    tids: List[str] = []
    seen: set = set()
    for q in queue_rows:
        if q.get("phase") != phase:
            continue
        tid = str(q.get("task_id"))
        if tid not in seen:
            seen.add(tid)
            tids.append(tid)
    lookup = build_lookup(scored)
    return {
        "role": "descriptive_only_not_for_primary_claim",
        "n_tasks": len(tids),
        "primary": compare_arms(lookup=lookup, source="pooled", task_ids=tids,
                                arm_a=PRIMARY[0], arm_b=PRIMARY[1]),
        "note": "两源不合池做主结论；此处仅作示意值。",
    }


def markdown_table(report: Dict[str, Any]) -> str:
    """生成人能读的质量/资源表（用于 reports/ 与论文草稿）。"""
    lines: List[str] = []
    lines.append("# 五臂结果表（自动生成）\n")
    lines.append(f"分析计划版本：{report.get('plan_version')}；"
                 f"bootstrap 次数：{report.get('bootstrap_draws')}；"
                 f"种子：{report.get('seed')}\n")
    for source, block in report.get("sources", {}).items():
        lines.append(f"## {source}（计划题数 {block['n_tasks']}）\n")
        lines.append("| 臂 | 已评分 | 未开始 | 对 | 错 | unknown | 正确率(已评分) | 悲观 | 乐观 |")
        lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |")
        for arm, acc in block["accuracy_by_arm"].items():
            if acc.get("status") != "OK":
                lines.append(f"| {arm} | {acc.get('status')} | - | - | - | - | - | - | - |")
                continue
            fmt = lambda v: "NA" if v is None else f"{v:.4f}"
            lines.append(
                f"| {arm} | {acc['n_scored']} | {acc['not_started']} | {acc['correct']} | "
                f"{acc['incorrect']} | {acc['unknown']} | {fmt(acc['accuracy_on_scored'])} | "
                f"{fmt(acc['accuracy_pessimistic'])} | {fmt(acc['accuracy_optimistic'])} |")
        p = block["primary"]
        lines.append("")
        lines.append(f"**主要对比（adaptive_legacy − plan_reflect）**：状态 {p['status']}")
        if p.get("primary"):
            ci = p["primary"]
            lines.append(f"- 配对表：{p['paired_table']}，完整配对 n={p['n_known_pairs']}")
            lines.append(f"- 差值 {ci['difference']:+.4f}，"
                         f"{int(ci['confidence_at_least']*100)}% 区间 "
                         f"[{ci['lower']:+.4f}, {ci['upper']:+.4f}]（{ci['method']}）")
            lines.append(f"- McNemar 精确双侧 p = {p['mcnemar_exact_p']:.4g}")
            lines.append(f"- 缺失识别界：[{p['identification_bounds']['lower']:+.4f}, "
                         f"{p['identification_bounds']['upper']:+.4f}]"
                         "（缺失可能范围，非置信区间）")
        else:
            lines.append(f"- {p.get('note','')}")
        lines.append("")

        bs = block.get("paired_bootstrap")
        if bs:
            lines.append("**配对 cluster bootstrap（题级重采样，2000 次，seed 20261111）**\n")
            lines.append("| 指标 | 观测均值差 | 95% 区间 | 题数 |")
            lines.append("| --- | ---: | --- | ---: |")
            label = {"dispatches": "派发数", "prompt_tokens": "输入 tokens",
                     "completion_tokens": "输出 tokens"}
            for metric in ("dispatches", "prompt_tokens", "completion_tokens"):
                row = bs.get(metric) or {}
                if row.get("status") != "OK":
                    lines.append(f"| {label[metric]} | {row.get('status','NA')} | - | "
                                 f"{row.get('n_tasks','-')} |")
                    continue
                lo, hi = row["bootstrap_95"]
                lines.append(f"| {label[metric]} | {row['observed_mean_difference']:+.4f} | "
                             f"[{lo:+.4f}, {hi:+.4f}] | {row['n_tasks']} |")
            lines.append("")

        lines.append("| 臂 | 轨迹数 | 派发 | 派发/题 | 失败 | 截断答案 |")
        lines.append("| --- | ---: | ---: | ---: | ---: | ---: |")
        for arm, res in block["resources"].items():
            if res.get("status") == "NO_ROWS":
                lines.append(f"| {arm} | 0 | - | - | - | - |")
                continue
            lines.append(f"| {arm} | {res['n_trajectories']} | {res['dispatches']} | "
                         f"{res['dispatches_per_task']:.2f} | {res['failed_trajectories']} | "
                         f"{res['truncated_answer_trajectories']} |")
        lines.append("")
    pooled = report.get("pooled_descriptive_only")
    if pooled:
        lines.append(f"> 合池仅描述：{pooled['note']}\n")

    jr = report.get("journal_resources")
    if jr:
        lines.append("## 逐角色资源（journal 为唯一真源）\n")
        lines.append("| purpose | 派发 | 响应 | 已核 | 未决 | 失败 | 输入 tokens | 输出 tokens |")
        lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |")
        for purpose, row in jr["by_purpose"].items():
            lines.append(f"| {purpose} | {row['dispatches']} | {row['responses']} | "
                         f"{row['settled']} | {row['unresolved']} | {row['failed']} | "
                         f"{row['prompt_tokens']:,} | {row['completion_tokens']:,} |")
        t = jr["totals"]
        lines.append(f"| **合计** | **{t['dispatches']}** | **{t['responses']}** | "
                     f"**{t['settled']}** | **{t['unresolved']}** | **{t['failed']}** | "
                     f"**{t['prompt_tokens']:,}** | **{t['completion_tokens']:,}** |")
        lines.append("")

        lines.append("## 逐臂资源\n")
        lines.append("| 臂 | 派发 | 输入 tokens | 输出 tokens | 有派发轨迹 | 未决 | 失败 |")
        lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: |")
        for arm, row in jr["by_arm"].items():
            if arm.startswith("_"):
                continue
            lines.append(f"| {arm} | {row['dispatches']} | {row['prompt_tokens']:,} | "
                         f"{row['completion_tokens']:,} | "
                         f"{row['trajectories_with_dispatch']} | {row['unresolved']} | "
                         f"{row['failed']} |")
        lines.append("")

        cov = jr["usage_coverage"]
        lines.append(f"**usage 覆盖率**：{cov['with_complete_usage']}/{cov['dispatched']}"
                     f" = {cov['coverage']:.4f}（缺失 {cov['missing_usage']}）\n")
        rec = jr.get("reconciliation")
        if rec:
            lines.append(f"**与 summary 对账**：{'一致' if rec['ok'] else '不一致'}\n")
    return "\n".join(lines)
