"""以**题**为单位的配对统计（主数据前封存）。

封锁的口径：

* 主要对比：每个数据集内 `adaptive_legacy − plan_reflect`。
* 其他臂：`direct` / `planning` / `asc_beta_8` 作为**预先指定的探索性参照**。
* 二元评分下的配对差：b = A 对 B 错，c = A 错 B 对，差 = (b − c)/N。
  区间用 discordant 计数的 Clopper–Pearson 联合界（双侧、每侧 α/4），
  不假设 A、B 独立，也不把两次独立正确率区间当配对结论。
* unknown 处理三口径并列输出：known（仅完整配对）、poor(0/1 悲观)、rich(1/0 乐观)，
  以及计划全样本的识别外区间（lower/upper）。
* McNemar 精确检验用于"无差异"这一零假设的尾概率；不作为非劣效证据。
* 资源以**完整题**为单位累计；bootstrap 按题整组重采样，保留方法配对。
* 全错/全对/全 unknown/零完整配对时返回明确状态，不伪造数值。
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from . import ANALYSIS_PLAN_VERSION

SEED = 20261111
BOOTSTRAP_DRAWS = 2000
DELTA_MARGIN = -0.03          # 敏感性参考；不是已确认的实用容忍度


class StatsError(Exception):
    pass


# ---------------------------------------------------------------- 精确区间
def _log_comb(n: int) -> Tuple[float, ...]:
    return tuple(math.lgamma(n + 1) - math.lgamma(i + 1) - math.lgamma(n - i + 1)
                 for i in range(n + 1))


def _binom_cdf(n: int, p: float, lo: int, hi: int) -> float:
    if lo > hi:
        return 0.0
    if p <= 0.0:
        return float(lo == 0)
    if p >= 1.0:
        return float(hi == n)
    lg = _log_comb(n)
    lp, lq = math.log(p), math.log1p(-p)
    vals = [lg[i] + i * lp + (n - i) * lq for i in range(lo, hi + 1)]
    mx = max(vals)
    return min(1.0, math.exp(mx) * math.fsum(math.exp(v - mx) for v in vals))


def clopper_pearson(k: int, n: int, tail: float = 0.025) -> Tuple[float, float]:
    """双侧 Clopper–Pearson 区间（单侧尾 = tail）。"""
    if n < 1 or not (0 <= k <= n) or not (0 < tail < 0.5):
        raise StatsError(f"非法 CP 参数 k={k} n={n} tail={tail}")
    lower = 0.0
    if k:
        lo, hi = 0.0, 1.0
        for _ in range(80):
            mid = (lo + hi) / 2
            if _binom_cdf(n, mid, k, n) >= tail:
                hi = mid
            else:
                lo = mid
        lower = (lo + hi) / 2
    upper = 1.0
    if k < n:
        lo, hi = 0.0, 1.0
        for _ in range(80):
            mid = (lo + hi) / 2
            if _binom_cdf(n, mid, 0, k) > tail:
                lo = mid
            else:
                hi = mid
        upper = (lo + hi) / 2
    return lower, upper


def paired_difference_interval(b: int, c: int, n: int,
                               confidence: float = 0.95) -> Dict[str, Any]:
    """discordant 计数的 CP 联合界：Δ = (b − c)/n。"""
    if b < 0 or c < 0 or b + c > n or not (0 < confidence < 1):
        raise StatsError(f"非法配对计数 b={b} c={c} n={n}")
    tail = (1 - confidence) / 4
    lb, ub = clopper_pearson(b, n, tail)
    lc, uc = clopper_pearson(c, n, tail)
    return {
        "difference": (b - c) / n,
        "lower": lb - uc,
        "upper": ub - lc,
        "confidence_at_least": confidence,
        "tail_each_marginal": tail,
        "method": "paired_discordant_clopper_pearson_union_bound",
        "n_independent_tasks": n,
        "scope": "IID paired binary task outcomes; one outcome per strategy per task",
    }


def mcnemar_exact(b: int, c: int) -> float:
    """双侧精确 McNemar（discordant 上 p=0.5 的二项检验）。"""
    m = b + c
    if m == 0:
        return 1.0
    k = min(b, c)
    lg = _log_comb(m)
    p = math.fsum(math.exp(lg[i] - m * math.log(2)) for i in range(0, k + 1)) * 2
    return min(1.0, p)


# ---------------------------------------------------------------- 题级结果
@dataclass
class TaskOutcome:
    """一题在某一臂上的评分结果（unknown 用 None）。"""

    task_id: str
    source: str
    value: Optional[int]
    status: str                     # completed / failed / not_started / unknown


def build_lookup(scored_rows: Iterable[Dict[str, Any]]) -> Dict[Tuple[str, str], TaskOutcome]:
    out: Dict[Tuple[str, str], TaskOutcome] = {}
    for row in scored_rows:
        sc = row.get("score") or {}
        decision = sc.get("decision")
        if decision == "correct":
            val, status = 1, "completed"
        elif decision == "incorrect":
            val, status = 0, "completed"
        else:
            val, status = None, "unknown"
        out[(str(row["task_id"]), str(row["strategy"]))] = TaskOutcome(
            task_id=str(row["task_id"]), source=str(row.get("source") or "unknown"),
            value=val, status=status)
    return out


def _pair_rows(lookup, *, source: str, task_ids: Sequence[str],
               arm_a: str, arm_b: str, policy: str) -> List[Tuple[Optional[int], Optional[int]]]:
    """按 policy 生成配对值列表。

    policy:
      known  两边都有值才保留（其余丢弃）
      poor   缺失记 0（对两臂都悲观）
      rich   缺失记 1（对两臂都乐观）
    """
    pairs: List[Tuple[Optional[int], Optional[int]]] = []
    for tid in task_ids:
        a = lookup.get((tid, arm_a))
        b = lookup.get((tid, arm_b))
        if a is None or b is None:
            if policy == "known":
                continue
            fill = 0 if policy == "poor" else 1
            va = a.value if a is not None and a.value is not None else fill
            vb = b.value if b is not None and b.value is not None else fill
            pairs.append((va, vb))
            continue
        if a.value is None or b.value is None:
            if policy == "known":
                continue
            va = 0 if policy == "poor" else 1
            vb = 0 if policy == "poor" else 1
            # 已知的一边保留真值，未知的一边按 policy
            if a.value is not None:
                va = a.value
            if b.value is not None:
                vb = b.value
            pairs.append((va, vb))
            continue
        pairs.append((a.value, b.value))
    return pairs


def compare_arms(*, lookup: Dict[Tuple[str, str], TaskOutcome],
                 source: str, task_ids: Sequence[str],
                 arm_a: str, arm_b: str) -> Dict[str, Any]:
    """一个数据集内两臂的完整配对报告。"""
    n_planned = len(task_ids)
    out: Dict[str, Any] = {
        "source": source,
        "arm_a": arm_a,
        "arm_b": arm_b,
        "n_planned": n_planned,
        "plan_version": ANALYSIS_PLAN_VERSION,
        "margin_reference": DELTA_MARGIN,
        "margin_note": "δ=0.03 仅作明确标注的敏感性参考，不是已确认的实用容忍度",
    }
    known_pairs = _pair_rows(lookup, source=source, task_ids=task_ids,
                             arm_a=arm_a, arm_b=arm_b, policy="known")
    n_known = len(known_pairs)
    both_correct = sum(1 for a, b in known_pairs if a == 1 and b == 1)
    a_only = sum(1 for a, b in known_pairs if a == 1 and b == 0)
    b_only = sum(1 for a, b in known_pairs if a == 0 and b == 1)
    neither = sum(1 for a, b in known_pairs if a == 0 and b == 0)

    unknown_pairs = sum(
        1 for tid in task_ids
        if (lookup.get((tid, arm_a)) is None or lookup[(tid, arm_a)].value is None)
        or (lookup.get((tid, arm_b)) is None or lookup[(tid, arm_b)].value is None))

    out["paired_table"] = {"both_correct": both_correct, "a_only": a_only,
                           "b_only": b_only, "neither_correct": neither}
    out["n_known_pairs"] = n_known
    out["n_unknown_or_missing_pairs"] = unknown_pairs

    if n_known == 0:
        out["status"] = "NO_COMPLETE_PAIRS"
        out["primary"] = None
        out["note"] = "没有完整配对；不伪造数值。已给出全计划识别界如下。"
    else:
        out["status"] = "OK"
        out["primary"] = paired_difference_interval(a_only, b_only, n_known)
        out["primary"]["difference_definition"] = "(a_only − b_only) / n_known"
        out["mcnemar_exact_p"] = mcnemar_exact(a_only, b_only)
        acc_a = (both_correct + a_only) / n_known
        acc_b = (both_correct + b_only) / n_known
        out["accuracy_on_known"] = {arm_a: acc_a, arm_b: acc_b,
                                    "difference": acc_a - acc_b,
                                    "note": "仅已知配对；不等于全计划正确率"}
        out["primary"]["lower_gt_margin"] = out["primary"]["lower"] > DELTA_MARGIN

    # 缺失识别外区间（同时给两向）
    out["identification_bounds"] = _identification_bounds(
        lookup, task_ids=task_ids, arm_a=arm_a, arm_b=arm_b)

    # 敏感性口径
    out["sensitivity"] = {}
    for policy in ("poor", "rich"):
        pr = _pair_rows(lookup, source=source, task_ids=task_ids,
                        arm_a=arm_a, arm_b=arm_b, policy=policy)
        n = len(pr)
        bb = sum(1 for a, b in pr if a == 1 and b == 0)
        cc = sum(1 for a, b in pr if a == 0 and b == 1)
        out["sensitivity"][policy] = {
            "policy": policy, "n": n, "a_only": bb, "b_only": cc,
            "interval": paired_difference_interval(bb, cc, n) if n else None,
        }

    # 分母状态表
    out["denominators"] = _denominators(lookup, task_ids, arm_a, arm_b)
    return out


def _identification_bounds(lookup, *, task_ids: Sequence[str],
                           arm_a: str, arm_b: str) -> Dict[str, Any]:
    """缺失导致的可能范围（不是置信区间）。

    每个评分取值 [l,u]：正确[1,1]、错误[0,0]、unknown/缺失[0,1]。
    lower = Σ(l_A − u_B)/N；upper = Σ(u_A − l_B)/N。
    """
    n = len(task_ids)
    if n == 0:
        return {"status": "NO_TASKS"}
    lo = hi = 0.0
    unknown = 0
    for tid in task_ids:
        a = lookup.get((tid, arm_a))
        b = lookup.get((tid, arm_b))
        av = None if a is None else a.value
        bv = None if b is None else b.value
        la, ua = (1, 1) if av == 1 else ((0, 0) if av == 0 else (0, 1))
        lb, ub = (1, 1) if bv == 1 else ((0, 0) if bv == 0 else (0, 1))
        if av is None or bv is None:
            unknown += 1
        lo += la - ub
        hi += ua - lb
    return {"lower": lo / n, "upper": hi / n, "n_planned": n,
            "unknown_or_missing_pairs": unknown,
            "note": "缺失引起的可能范围，不是置信区间；抽样不确定性另外报告"}


def _denominators(lookup, task_ids: Sequence[str],
                  arm_a: str, arm_b: str) -> Dict[str, int]:
    stats = {"planned_arm_a": len(task_ids), "planned_arm_b": len(task_ids),
             "a_not_started": 0, "b_not_started": 0,
             "a_unknown": 0, "b_unknown": 0,
             "a_scorable": 0, "b_scorable": 0}
    for tid in task_ids:
        for arm, prefix in ((arm_a, "a"), (arm_b, "b")):
            o = lookup.get((tid, arm))
            if o is None or o.status == "not_started":
                stats[f"{prefix}_not_started"] += 1
            elif o.value is None:
                stats[f"{prefix}_unknown"] += 1
            else:
                stats[f"{prefix}_scorable"] += 1
    return stats


# ---------------------------------------------------------------- 资源
def resource_summary(*, results_rows: Sequence[Dict[str, Any]],
                     task_ids: Sequence[str], arm: str) -> Dict[str, Any]:
    """单臂资源：请求数、tokens、费用、失败/截断、usage 覆盖率。"""
    rows = [r for r in results_rows if r.get("strategy") == arm
            and r.get("task_id") in set(task_ids)]
    n = len(rows)
    if not n:
        return {"arm": arm, "n": 0, "status": "NO_ROWS"}
    disp = sum(int((r.get("outcome") or {}).get("dispatches") or 0) for r in rows)
    usage_cov = 0
    tokens_in = tokens_out = 0
    failed = 0
    truncated = 0
    for r in rows:
        outcome = r.get("outcome") or {}
        record = outcome.get("answer_record") or {}
        if record.get("reason") == "truncated_without_final_marker":
            truncated += 1
        if outcome.get("error"):
            failed += 1
        steps = outcome.get("steps") or []
        for s in steps:
            detail = s.get("detail") or {}
            if isinstance(detail.get("prompt_tokens"), int):
                usage_cov += 1
                tokens_in += detail["prompt_tokens"]
                tokens_out += int(detail.get("completion_tokens") or 0)
    return {
        "arm": arm, "n_trajectories": n, "dispatches": disp,
        "dispatches_per_task": disp / n,
        "steps_recorded": sum(len((r.get("outcome") or {}).get("steps") or []) for r in rows),
        "usage_step_coverage": usage_cov,
        "prompt_tokens_from_steps": tokens_in,
        "completion_tokens_from_steps": tokens_out,
        "failed_trajectories": failed,
        "truncated_answer_trajectories": truncated,
        "note": "费用以 journal 的 usage_settled 为准；此处 tokens 仅作交叉核对",
    }


def clustered_bootstrap(tokens_by_task: Sequence[Tuple[str, float]], *,
                        draws: int = BOOTSTRAP_DRAWS, seed: int = SEED) -> Dict[str, Any]:
    """按题整组重采样（题是抽样单位；内部请求不是新题）。"""
    import numpy as np

    if not tokens_by_task:
        return {"status": "NO_DATA"}
    ids = [t for t, _ in tokens_by_task]
    vals = np.asarray([v for _, v in tokens_by_task], dtype=float)
    rng = np.random.default_rng(seed)
    n = len(vals)
    idx = rng.integers(0, n, size=(draws, n))
    means = vals[idx].mean(axis=1)
    return {
        "n_tasks": n,
        "observed_mean": float(vals.mean()),
        "bootstrap_95": [float(np.percentile(means, 2.5)),
                         float(np.percentile(means, 97.5))],
        "draws": draws, "seed": seed,
        "unit": "per task (cluster)",
        "task_ids_sample": ids[:5],
    }


def paired_cluster_bootstrap(*, task_resources: Dict[str, Dict[str, Dict[str, int]]],
                             task_ids: Sequence[str], arm_a: str, arm_b: str,
                             metric: str = "dispatches",
                             draws: int = BOOTSTRAP_DRAWS,
                             seed: int = SEED) -> Dict[str, Any]:
    """**配对**的题级 cluster bootstrap。

    每题先算差值 d_i = metric(A,i) − metric(B,i)，再对题有放回重采样。
    这样保留两臂在同一题上的配对结构；把内部请求当独立样本会低估方差。

    `task_resources` 形如 `{task_id: {arm: {dispatches, prompt_tokens, ...}}}`。
    只保留两臂都有记录的题；缺失题不插补。
    """
    import numpy as np

    if metric not in ("dispatches", "prompt_tokens", "completion_tokens"):
        raise StatsError(f"不支持的 metric: {metric}")

    diffs: List[float] = []
    used_ids: List[str] = []
    for tid in task_ids:
        arms = task_resources.get(tid)
        if not arms or arm_a not in arms or arm_b not in arms:
            continue
        a = float(arms[arm_a].get(metric, 0))
        b = float(arms[arm_b].get(metric, 0))
        diffs.append(a - b)
        used_ids.append(tid)

    n = len(diffs)
    if n < 3:
        return {"status": "INSUFFICIENT_TASKS", "n_tasks": n,
                "metric": metric, "arm_a": arm_a, "arm_b": arm_b,
                "note": "少于 3 个完整配对，不给 bootstrap 区间"}

    vals = np.asarray(diffs, dtype=float)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, n, size=(draws, n))
    means = vals[idx].mean(axis=1)
    return {
        "status": "OK",
        "metric": metric,
        "arm_a": arm_a,
        "arm_b": arm_b,
        "n_tasks": n,
        "observed_mean_difference": float(vals.mean()),
        "bootstrap_95": [float(np.percentile(means, 2.5)),
                         float(np.percentile(means, 97.5))],
        "draws": draws,
        "seed": seed,
        "unit": "per task (paired cluster)",
        "note": "差值定义为 A − B；只含两臂都有记录的题；缺失不插补。",
        "task_ids_sample": used_ids[:5],
    }
