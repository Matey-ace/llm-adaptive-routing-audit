"""CLI：全部命令都先做能力/批准检查，再决定是否真的派发。

命令与语义：

    doctor --offline         环境自检（依赖、路径、指纹）；不联网
    validate-inputs          核对清单/题库/队列与锁定指纹
    simulate                 跑离线场景套件（0 网络）
    seal                     计算并保存指纹封存（不等于支出批准）
    run --phase ...          离线模拟可跑；live 需人工批准记录
    status                   查看某 run 的状态表与账本
    resume                   续跑（只继续从未派发的轨迹）
    score                    评分（另存新版本，不覆盖）
    analyze                  分析（生成表格与 JSON）
    export                   导出可交付的报告与账本
    reconcile                只读本地账单证据做对账，不发探针
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from . import RUNNER_ID, __version__
from .budget import Ledger, micro_to_cny
from .contracts import Contract, draft_contract, sha256_json
from .errors import (BudgetBlocked, ContractNotApproved, DispatchLimitReached,
                     InputIntegrityError, JournalCorrupt, RunLocked)
from .inputs import (ARMS, LOCKED_SHA256, READ_ONLY_ROOTS, build_bundle,
                     sha256_file, verify_locked_fingerprints)
from .journal import Journal, resume_plan

RUNNER_ROOT = Path(__file__).resolve().parents[2]
WORKSPACE = Path(os.environ.get("SNCS_WORKSPACE_ROOT", RUNNER_ROOT.parent))
PREP_DIR = WORKSPACE / "SNCS_Experiment_Preparation_20261110"
RUNS_DIR = RUNNER_ROOT / "runs"
CONFIGS_DIR = RUNNER_ROOT / "configs"
EVIDENCE_DIR = RUNNER_ROOT / "evidence"
REPORTS_DIR = RUNNER_ROOT / "reports"


# ---------------------------------------------------------------- 打印
def _p(msg: str = "") -> None:
    print(msg, flush=True)


def _dump(obj: Any) -> None:
    _p(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True))


# ---------------------------------------------------------------- doctor
def cmd_doctor(args: argparse.Namespace) -> int:
    problems: List[str] = []
    info: Dict[str, Any] = {
        "runner_id": RUNNER_ID,
        "version": __version__,
        "offline_mode": True,
        "live_calls_made": 0,
        "python": sys.version.split()[0],
        "runner_root": str(RUNNER_ROOT),
        "prep_dir_exists": PREP_DIR.is_dir(),
    }
    if not PREP_DIR.is_dir():
        problems.append(f"准备包不存在: {PREP_DIR}")
    # 依赖
    deps: Dict[str, Optional[str]] = {}
    for mod in ("pyarrow", "sympy", "numpy", "scipy"):
        try:
            m = __import__(mod)
            deps[mod] = getattr(m, "__version__", "?")
        except ImportError:
            deps[mod] = None
            problems.append(f"缺少依赖 {mod}")
    info["dependencies"] = deps
    # 旧源码封存副本
    from .runtime import LEGACY_ROOT, legacy_fingerprints
    info["legacy_root"] = str(LEGACY_ROOT)
    fp = legacy_fingerprints()
    info["legacy_file_count"] = len(fp)
    manifest_path = EVIDENCE_DIR / "legacy_copy_manifest.json"
    if manifest_path.is_file():
        man = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
        bad = []
        for row in man:
            key = str(row["local"]).replace("\\", "/")
            if fp.get(key) != row["sha256"]:
                bad.append(key)
        info["legacy_manifest_match"] = not bad
        if bad:
            problems.append(f"封存副本被改动: {bad[:5]}")
    else:
        problems.append("缺少 evidence/legacy_copy_manifest.json")
    # 输入指纹
    if PREP_DIR.is_dir():
        try:
            report = verify_locked_fingerprints(PREP_DIR)
            info["input_fingerprints_ok"] = True
            info["input_files_checked"] = len(report)
        except InputIntegrityError as exc:
            info["input_fingerprints_ok"] = False
            problems.append(str(exc))
    # 网络拦截自检：离线命令不得创建 live client
    info["live_provider_constructed"] = False
    info["network_calls"] = 0
    info["problems"] = problems
    info["status"] = "OK" if not problems else "PROBLEMS"
    _dump(info)
    return 0 if not problems else 2


# ---------------------------------------------------------------- validate
def cmd_validate_inputs(args: argparse.Namespace) -> int:
    phases = [args.phase] if args.phase else ["preflight", "main"]
    out: Dict[str, Any] = {"phases": {}, "checked_utc_files": {}}
    for phase in phases:
        if phase == "preflight":
            manifest = PREP_DIR / "manifests_v2" / "preflight_tasks_20.json"
            queue = PREP_DIR / "draft" / "preflight_five_arm_queue_100.jsonl"
        else:
            manifest = PREP_DIR / "manifests_v2" / "main_tasks_400.json"
            queue = PREP_DIR / "draft" / "main_five_arm_queue_2000.jsonl"
        bundle = build_bundle(phase=phase, manifest_path=manifest,
                              prompt_store_path=PREP_DIR / "draft" / "generation_prompt_only_420.jsonl",
                              queue_path=queue, prep_dir=PREP_DIR)
        out["phases"][phase] = {
            "manifest": str(manifest),
            "queue": str(queue),
            "n_manifest": len(bundle.manifest),
            "n_queue": len(bundle.queue),
            "n_distinct_tasks": len(bundle.task_ids_in_queue),
            "arms": list(ARMS),
            "sha256": {k: v for k, v in bundle.fingerprints.items()},
        }
    # 合并核对（2100）
    from .inputs import build_merged_bundle
    merged = build_merged_bundle(prep_dir=PREP_DIR)
    out["merged"] = {
        "n_queue_rows": len(merged.queue),
        "n_distinct_tasks": len({r.task_id for r in merged.queue}),
        "calibration_reserve_queued": any(
            r.task_id in {"x"} for r in merged.queue),
    }
    out["status"] = "OK"
    out["note"] = "生成入口只读取 task_id/prompt/prompt_sha256；gold 不在本命令的任何输入中。"
    _dump(out)
    return 0


# ---------------------------------------------------------------- simulate
def cmd_simulate(args: argparse.Namespace) -> int:
    from .simulation_runner import run_scenario_suite
    summary = run_scenario_suite(
        suite_path=Path(args.scenario_suite) if args.scenario_suite else None,
        out_dir=RUNS_DIR,
        evidence_dir=EVIDENCE_DIR)
    _dump(summary)
    return 0 if summary.get("failed", 0) == 0 else 2


# ---------------------------------------------------------------- seal
def cmd_seal(args: argparse.Namespace) -> int:
    from .seal import seal_snapshot
    result = seal_snapshot(contract_path=Path(args.contract) if args.contract else None,
                           runner_root=RUNNER_ROOT, prep_dir=PREP_DIR,
                           out_path=Path(args.out) if args.out else None)
    _dump(result)
    return 0


# ---------------------------------------------------------------- run
def cmd_run(args: argparse.Namespace) -> int:
    contract = Contract.load(args.contract, approvals_dir=CONFIGS_DIR / "approvals")
    if contract.mode in ("live", "local_gateway"):
        try:
            contract.require_live_ready()
        except ContractNotApproved as exc:
            _p("【未派发】真实执行条件未满足。")
            _p(str(exc))
            _p("")
            _p("可执行动作：")
            _p("  1) 用 `sncs-fivearm seal --contract <草案>` 生成待批准清单；")
            _p("  2) 由作者在 configs/approvals/<ref>.json 写入人工批准记录；")
            _p("  3) 重新运行本命令。离线模拟不受影响（--mode offline）。")
            return 3
        return _run_live(args, contract)
    return _run_offline(args, contract)


def _bundle_for(phase: str):
    if phase == "preflight":
        manifest = PREP_DIR / "manifests_v2" / "preflight_tasks_20.json"
        queue = PREP_DIR / "draft" / "preflight_five_arm_queue_100.jsonl"
    else:
        manifest = PREP_DIR / "manifests_v2" / "main_tasks_400.json"
        queue = PREP_DIR / "draft" / "main_five_arm_queue_2000.jsonl"
    return build_bundle(phase=phase, manifest_path=manifest,
                        prompt_store_path=PREP_DIR / "draft" / "generation_prompt_only_420.jsonl",
                        queue_path=queue, prep_dir=PREP_DIR)


def _run_offline(args: argparse.Namespace, contract: Contract) -> int:
    from .providers import SyntheticProvider, SyntheticAction
    from .runner import RunConfig, Runner
    from .inputs import select_phase

    bundle = _bundle_for(args.phase)
    queue = select_phase(bundle.queue, args.phase)
    if args.limit:
        queue = queue[: int(args.limit)]

    # 离线缺省脚本：每题每臂返回一个可解析答案
    script = {}
    for row in queue:
        script[row.run_id] = [SyntheticAction.text(f"ANSWER: {abs(hash(row.task_id)) % 97}")]
    provider = SyntheticProvider(script)

    run_id = args.run_id or f"offline_{args.phase}_{RUNNER_ID}"
    cfg = RunConfig(run_id=run_id, phase=args.phase, contract=contract,
                    bundle=bundle, queue=queue, purpose="offline_simulation",
                    notes="synthetic provider; no network; not experimental data")
    runner = Runner(config=cfg, provider=provider, runs_root=RUNS_DIR,
                    package_root=RUNNER_ROOT / "src" / "sncs_fivearm")
    summary = runner.execute()
    _dump(summary.as_dict())
    return 0


def _run_live(args: argparse.Namespace, contract: Contract) -> int:
    from .inputs import select_phase
    from .providers import build_provider
    from .runner import RunConfig, Runner

    provider = build_provider(contract, allow_live=True)
    bundle = _bundle_for(args.phase)
    queue = select_phase(bundle.queue, args.phase)
    if args.limit:
        queue = queue[: int(args.limit)]
    run_id = args.run_id or f"{'localgw' if contract.mode == 'local_gateway' else 'live'}_{args.phase}_" \
                            f"{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}"
    workers = int(args.workers or contract.get("limits.trajectory_workers") or 1)
    cfg = RunConfig(run_id=run_id, phase=args.phase, contract=contract,
                    bundle=bundle, queue=queue, purpose="experiment",
                    workers=workers)
    _p(f"[run] workers={workers} "
       f"rpm={contract.get('limits.max_dispatches_per_minute')}")
    runner = Runner(config=cfg, provider=provider, runs_root=RUNS_DIR,
                    package_root=RUNNER_ROOT / "src" / "sncs_fivearm")
    summary = runner.execute()
    _dump(summary.as_dict())
    return 0


# ---------------------------------------------------------------- status/resume
def _load_journal(run_id: str) -> Journal:
    return Journal(RUNS_DIR / run_id / "journal.jsonl")


def cmd_status(args: argparse.Namespace) -> int:
    run_dir = RUNS_DIR / args.run
    journal = Journal(run_dir / "journal.jsonl")
    if not journal.path.is_file():
        _p(f"找不到 run: {run_dir}")
        return 2
    verify = journal.verify()
    events = journal.read_all()
    tail = journal.tail_status()
    from .journal import derive_trajectory_states
    states = derive_trajectory_states(events)
    by_state: Dict[str, int] = {}
    for st in states.values():
        by_state[st.state] = by_state.get(st.state, 0) + 1
    summary_file = run_dir / "summary.json"
    summary = json.loads(summary_file.read_text(encoding="utf-8")) if summary_file.is_file() else None
    _dump({"run": args.run, "verify": verify, "tail": tail.as_dict(),
           "trajectory_states": by_state, "summary": summary})
    return 0


def cmd_resume(args: argparse.Namespace) -> int:
    contract = Contract.load(args.contract, approvals_dir=CONFIGS_DIR / "approvals")
    run_dir = RUNS_DIR / args.run
    journal = Journal(run_dir / "journal.jsonl")
    if not journal.path.is_file():
        _p(f"找不到 run: {run_dir}")
        return 2
    tail = journal.tail_status()
    if tail.truncated and not args.allow_tail_repair:
        _p("日志尾行损坏，需要人工确认：")
        _dump(tail.as_dict())
        _p("确认后加 --allow-tail-repair 重试（损坏行会被隔离并记录）。")
        return 4
    meta = {}
    for ev in journal.read_all():
        if ev["event"] == "run_started":
            meta = ev
            break
    if not meta:
        _p("日志中没有 run_started，无法核对合同。")
        return 4
    if meta.get("contract_sha256") != contract.sha256:
        _p(f"合同哈希不符：日志 {str(meta.get('contract_sha256'))[:12]} "
           f"!= 当前 {contract.sha256[:12]}")
        return 4
    phase = str(meta.get("phase"))
    bundle = _bundle_for(phase)
    from .inputs import select_phase
    queue = select_phase(bundle.queue, phase)
    plan = resume_plan(journal.read_all(), [r.run_id for r in queue])
    if plan["blocked_requires_reconciliation"]:
        _p("以下轨迹派发结果不明，已隔离为 reconciliation_required（不会重发）：")
        _dump(plan["blocked_requires_reconciliation"][:20])
    if not plan["resumable"]:
        _p("没有可安全继续的轨迹。")
        _dump(plan["counts"])
        return 0
    if contract.mode == "live":
        contract.require_live_ready()
        provider = __import__("sncs_fivearm.providers", fromlist=["x"]).build_provider(
            contract, allow_live=True)
    else:
        from .providers import SyntheticAction, SyntheticProvider
        script = {rid: [SyntheticAction.text("ANSWER: 0")] for rid in plan["resumable"]}
        provider = SyntheticProvider(script)
    from .runner import RunConfig, Runner
    cfg = RunConfig(run_id=args.run, phase=phase, contract=contract,
                    bundle=bundle, queue=queue, purpose=str(meta.get("purpose")),
                    notes="resumed")
    summary = Runner(config=cfg, provider=provider, runs_root=RUNS_DIR,
                     package_root=RUNNER_ROOT / "src" / "sncs_fivearm").execute()
    _dump(summary.as_dict())
    return 0


# ---------------------------------------------------------------- score/analyze
def cmd_score(args: argparse.Namespace) -> int:
    from .evaluation.gold import load_gold
    from .evaluation.scoring import score_run
    run_dir = RUNS_DIR / args.run
    results_path = run_dir / "results.jsonl"
    if not results_path.is_file():
        _p(f"找不到结果: {results_path}")
        return 2
    phase = _phase_of(run_dir)
    manifest_path = (PREP_DIR / "manifests_v2" /
                     ("preflight_tasks_20.json" if phase == "preflight"
                      else "main_tasks_400.json"))
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    from .inputs import load_prompt_store
    prompts = load_prompt_store(PREP_DIR / "draft" / "generation_prompt_only_420.jsonl")
    gold = load_gold(manifest, workspace_root=WORKSPACE, prompt_store=prompts,
                     verify_prompt_hash=not args.skip_prompt_check)
    out = run_dir / (args.out or f"scores_v{args.version}.jsonl")
    result = score_run(results_path=results_path, gold=gold, out_path=out,
                       source_sha256=sha256_file(results_path))
    _dump(result)
    return 0


def _phase_of(run_dir: Path) -> str:
    for ev in Journal(run_dir / "journal.jsonl").read_all():
        if ev["event"] == "run_started":
            return str(ev.get("phase"))
    raise JournalCorrupt("日志中没有 run_started")


def cmd_analyze(args: argparse.Namespace) -> int:
    from .evaluation.analysis import build_report, load_results, load_scored, markdown_table
    run_dir = RUNS_DIR / args.run
    scored_path = run_dir / (args.scores or "scores_v1.jsonl")
    if not scored_path.is_file():
        _p(f"找不到评分文件: {scored_path}")
        return 2
    phase = _phase_of(run_dir)
    queue_rows = []
    for name in ("preflight_five_arm_queue_100.jsonl", "main_five_arm_queue_2000.jsonl"):
        for line in (PREP_DIR / "draft" / name).read_text(encoding="utf-8").splitlines():
            if line.strip():
                queue_rows.append(json.loads(line))
    results_rows = load_results(run_dir / "results.jsonl")
    meta = {}
    for ev in Journal(run_dir / "journal.jsonl").read_all():
        if ev["event"] == "run_started":
            meta = {k: ev.get(k) for k in
                    ("run_id", "phase", "purpose", "execution_mode",
                     "contract_sha256", "provider")}
            break
    report = build_report(scored_rows=load_scored(scored_path),
                          results_rows=results_rows, queue_rows=queue_rows,
                          phase=phase, run_meta=meta,
                          journal_path=run_dir / "journal.jsonl",
                          summary=json.loads((run_dir / "summary.json")
                                             .read_text(encoding="utf-8"))
                          if (run_dir / "summary.json").is_file() else None)
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    md_path = REPORTS_DIR / f"{args.run}_report.md"
    js_path = REPORTS_DIR / f"{args.run}_report.json"
    md_path.write_text(markdown_table(report), encoding="utf-8")
    js_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    _dump({"markdown": str(md_path), "json": str(js_path),
           "sources": list(report["sources"])})
    return 0


def cmd_status_matrix(args: argparse.Namespace) -> int:
    from .evaluation.status_matrix import (build_matrix, summarise,
                                          unknown_cases, write_outputs)
    run_dir = RUNS_DIR / args.run
    if not (run_dir / "results.jsonl").is_file():
        _p(f"找不到结果: {run_dir}")
        return 2
    queue_rows = []
    for name in ("preflight_five_arm_queue_100.jsonl", "main_five_arm_queue_2000.jsonl"):
        for line in (PREP_DIR / "draft" / name).read_text(encoding="utf-8").splitlines():
            if line.strip():
                queue_rows.append(json.loads(line))
    phase = _phase_of(run_dir)
    queue_rows = [r for r in queue_rows if r.get("phase") == phase]
    journal_events = Journal(run_dir / "journal.jsonl").read_all()

    # 可选：用人工评分替代自动评分
    scored_rows = _jsonl(run_dir / (args.scores or "scores_v1.jsonl"))
    tag = ""
    if args.human:
        hp = run_dir / "review" / f"human_scores_{args.human}.jsonl"
        if not hp.is_file():
            _p(f"找不到人工评分: {hp}")
            return 2
        hum = _jsonl(hp)
        scored_rows = [{
            "task_id": h["task_id"], "strategy": h["strategy"],
            "source": h.get("source"), "run_id": h["run_id"],
            "score": {"decision": h["decision"], "reason": h.get("reason", ""),
                      "needs_review": h["decision"] == "unknown"},
        } for h in hum]
        tag = f"human_{args.human}_"

    rows = build_matrix(queue_rows=queue_rows,
                        results_rows=_jsonl(run_dir / "results.jsonl"),
                        scored_rows=scored_rows,
                        journal_events=journal_events)
    summary = summarise(rows)
    unknowns = unknown_cases(rows, scored_rows)
    if tag:
        d = run_dir / "review"
        d.mkdir(exist_ok=True)
        paths = write_outputs(run_dir=d, rows=rows, summary=summary, unknowns=unknowns)
        # 重命名以区分口径
        for key, suffix in (("matrix", "status_matrix.jsonl"),
                            ("summary", "status_matrix_summary.json"),
                            ("unknown", "unknown_cases.jsonl")):
            src = Path(paths[key])
            dst = d / f"{tag}{suffix}"
            src.replace(dst)
            paths[key] = str(dst)
    else:
        paths = write_outputs(run_dir=run_dir, rows=rows, summary=summary,
                              unknowns=unknowns)
    paths["rows"] = len(rows)
    paths["unknown"] = len(unknowns)
    paths["basis"] = "human" if tag else "auto"
    _dump(paths)
    return 0


def cmd_service_window(args: argparse.Namespace) -> int:
    from .evaluation.service_window import build_window
    run_dir = RUNS_DIR / args.run
    events = Journal(run_dir / "journal.jsonl").read_all()
    contract = None
    if args.contract:
        c = Contract.load(args.contract, approvals_dir=CONFIGS_DIR / "approvals")
        contract = dict(c.raw)
        contract["_sha256"] = c.sha256
    result = build_window(journal_events=events, contract=contract)
    out = run_dir / "service_window.json"
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    _dump({"path": str(out), "status": result["status"],
           "duration_seconds": result["duration_seconds"],
           "dispatches": result["dispatches"],
           "peak_rpm": result["dispatches_per_minute"]["peak"]})
    return 0


def _jsonl(path: Path) -> list:
    if not path.is_file():
        return []
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]


def cmd_export(args: argparse.Namespace) -> int:
    from .export import export_run
    out = export_run(run_id=args.run, runs_root=RUNS_DIR,
                     reports_dir=REPORTS_DIR, evidence_dir=EVIDENCE_DIR)
    _dump(out)
    return 0


def cmd_reconcile(args: argparse.Namespace) -> int:
    from .reconcile import reconcile_run
    out = reconcile_run(run_id=args.run, runs_root=RUNS_DIR,
                        evidence=Path(args.evidence) if args.evidence else None)
    _dump(out)
    return 0


# ---------------------------------------------------------------- parser
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="sncs-fivearm",
                                description="SNCS 五臂执行器（离线优先）")
    sub = p.add_subparsers(dest="command", required=True)

    d = sub.add_parser("doctor", help="环境自检（不联网）")
    d.add_argument("--offline", action="store_true", default=True)
    d.set_defaults(func=cmd_doctor)

    v = sub.add_parser("validate-inputs", help="核对清单/题库/队列与锁定指纹")
    v.add_argument("--phase", choices=["preflight", "main"])
    v.set_defaults(func=cmd_validate_inputs)

    s = sub.add_parser("simulate", help="跑离线场景套件（0 网络）")
    s.add_argument("--scenario-suite")
    s.set_defaults(func=cmd_simulate)

    se = sub.add_parser("seal", help="指纹封存（不等于支出批准）")
    se.add_argument("--contract")
    se.add_argument("--out")
    se.set_defaults(func=cmd_seal)

    r = sub.add_parser("run", help="执行一个阶段")
    r.add_argument("--phase", choices=["preflight", "main"], required=True)
    r.add_argument("--contract", required=True)
    r.add_argument("--mode", choices=["live", "offline"], default=None)
    r.add_argument("--run-id")
    r.add_argument("--limit", type=int)
    r.add_argument("--workers", type=int,
                   help="跨题并发数；默认取合同 limits.trajectory_workers")
    r.set_defaults(func=cmd_run)

    st = sub.add_parser("status", help="查看 run 状态")
    st.add_argument("--run", required=True)
    st.set_defaults(func=cmd_status)

    rs = sub.add_parser("resume", help="续跑（只继续从未派发的轨迹）")
    rs.add_argument("--run", required=True)
    rs.add_argument("--contract", required=True)
    rs.add_argument("--allow-tail-repair", action="store_true")
    rs.set_defaults(func=cmd_resume)

    sc = sub.add_parser("score", help="评分（另存新版本）")
    sc.add_argument("--run", required=True)
    sc.add_argument("--version", type=int, default=1)
    sc.add_argument("--out")
    sc.add_argument("--skip-prompt-check", action="store_true")
    sc.set_defaults(func=cmd_score)

    an = sub.add_parser("analyze", help="分析（生成表格与 JSON）")
    an.add_argument("--run", required=True)
    an.add_argument("--scores")
    an.set_defaults(func=cmd_analyze)

    ex = sub.add_parser("export", help="导出报告与账本")
    ex.add_argument("--run", required=True)
    ex.set_defaults(func=cmd_export)

    sm = sub.add_parser("status-matrix", help="生成逐题逐臂状态矩阵与 unknown 清单")
    sm.add_argument("--run", required=True)
    sm.add_argument("--scores")
    sm.add_argument("--human", help="用 review/human_scores_<tag>.jsonl 作为判定口径")
    sm.set_defaults(func=cmd_status_matrix)

    sw = sub.add_parser("service-window", help="服务窗口与漂移检查")
    sw.add_argument("--run", required=True)
    sw.add_argument("--contract")
    sw.set_defaults(func=cmd_service_window)

    rc = sub.add_parser("reconcile", help="只读本地账单证据做对账")
    rc.add_argument("--run", required=True)
    rc.add_argument("--evidence")
    rc.set_defaults(func=cmd_reconcile)
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except (InputIntegrityError, ContractNotApproved, JournalCorrupt, RunLocked) as exc:
        _p(f"[错误] {type(exc).__name__}: {exc}")
        return 5


if __name__ == "__main__":
    raise SystemExit(main())
