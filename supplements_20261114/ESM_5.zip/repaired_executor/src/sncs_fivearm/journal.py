"""持久事件日志与跨进程独占。

设计要点（对应交接计划工作包 D 与 E 第 9/10 条）：

* 每行一个 JSON 事件，`append → flush → fsync`，落盘顺序即事实顺序。
* **尾行损坏**（未以换行结束 / JSON 不完整）不静默跳过：标记
  `tail_truncated`，该行之后的恢复一律要求人工确认（`--allow-tail-repair`）。
* **重复 id**（同一 request_id 出现两次 intent，或同一 run_id 出现两次 claim）
  直接抛 `JournalCorrupt`，不"取最新一条"。
* run 目录由 `run.lock` 独占（O_EXCL 创建 + pid/host 记录）。第二个 CLI 进程
  拿不到锁即退出，避免重复派发。
* 轨迹唯一 claim：`claim` 事件对某 run_id 只允许出现一次；恢复时已 claim 未终态的
  轨迹一律进入 `reconciliation_required` 并保留费用暴露，**不重发**。

事件类型（尽量少而正交）：

    run_started            run 元信息 + 合同/输入/代码指纹
    claim                  某轨迹开始执行（唯一）
    planned                请求意图已决定（未预留）
    reservation_created    预留已建立
    dispatch_intent_durable 请求意图已落盘，即将真正派发（崩溃点分界）
    response_received      收到响应（含 partial / 无 usage）
    usage_settled          usage 已核费用结算
    failed                 本次尝试失败（含是否可能已计费）
    reconciliation_required 派发结果不明 / usage 缺失，保留暴露
    reconciled             人工对账完成
    reservation_released   确定未派发，释放预留
    budget_blocked         预算或阶段额度拒绝（**未**派发）
    completed              轨迹终态：成功产出答案
    not_started            轨迹终态：因额度/极限而未开始
    run_finished           run 级终态
"""

from __future__ import annotations

import json
import os
import socket
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Set

from .errors import JournalCorrupt, RunLocked

EVENT_TYPES = frozenset({
    "run_started", "claim", "planned", "reservation_created",
    "dispatch_intent_durable", "response_received", "usage_settled", "failed",
    "reconciliation_required", "reconciled", "reservation_released",
    "budget_blocked", "completed", "not_started", "run_finished",
})

TERMINAL_TRAJECTORY_STATES = frozenset({
    "completed", "not_started", "failed", "reconciliation_required", "budget_blocked",
})

# run 级事件（带 run_id 但不是轨迹终态）：不得计入轨迹状态推导
RUN_LEVEL_EVENTS = frozenset({"run_started", "run_finished"})


def _now_utc() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()) + f".{int(time.time()*1e6)%1000000:06d}Z"


@dataclass
class TailStatus:
    truncated: bool
    trailing_bytes: int
    last_complete_line: int

    def as_dict(self) -> Dict[str, Any]:
        return {"truncated": self.truncated,
                "trailing_bytes": self.trailing_bytes,
                "last_complete_line": self.last_complete_line}


class Journal:
    """append-only JSONL 事件日志。"""

    def __init__(self, path: Path | str, *, fsync: bool = True) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.fsync = fsync
        self._created = not self.path.exists()
        # 跨题并发时多个线程会同时 append；行写入必须互斥，否则会出现交叉撕裂行。
        self._write_lock = threading.RLock()

    # ------------------------------------------------------------------ 写
    def append(self, event: str, **fields: Any) -> Dict[str, Any]:
        if event not in EVENT_TYPES:
            raise JournalCorrupt(f"未登记的事件类型: {event}")
        rec: Dict[str, Any] = {"event": event, "ts_utc": _now_utc()}
        rec.update(fields)
        line = json.dumps(rec, ensure_ascii=False, allow_nan=False,
                          sort_keys=True, separators=(",", ":"))
        if "\n" in line:  # 不可能，除非有人把换行塞进字符串；防御性检查
            raise JournalCorrupt("事件序列化后含换行")
        with self._write_lock:
            if self.path.exists() and self.path.stat().st_size:
                with self.path.open("rb") as check:
                    check.seek(-1, 2)
                    if check.read(1) != b"\n":
                        raise JournalCorrupt("拒绝追加到不完整日志尾行")
            with self.path.open("a", encoding="utf-8", newline="\n") as fh:
                fh.write(line + "\n")
                fh.flush()
                if self.fsync:
                    os.fsync(fh.fileno())
        return rec

    def append_many(self, events: Iterable[Dict[str, Any]]) -> None:
        with self._write_lock:
            if self.path.exists() and self.path.stat().st_size:
                with self.path.open("rb") as check:
                    check.seek(-1, 2)
                    if check.read(1) != b"\n":
                        raise JournalCorrupt("拒绝追加到不完整日志尾行")
            with self.path.open("a", encoding="utf-8", newline="\n") as fh:
                for rec in events:
                    if rec.get("event") not in EVENT_TYPES:
                        raise JournalCorrupt(f"未登记的事件类型: {rec.get('event')}")
                    rec.setdefault("ts_utc", _now_utc())
                    fh.write(json.dumps(rec, ensure_ascii=False, allow_nan=False,
                                        sort_keys=True, separators=(",", ":")) + "\n")
                fh.flush()
                if self.fsync:
                    os.fsync(fh.fileno())

    # ------------------------------------------------------------------ 读
    def read_all(self) -> List[Dict[str, Any]]:
        events, _tail = self._iter_events(strict=True)
        return events

    def tail_status(self) -> TailStatus:
        _, tail = self._iter_events(strict=False)
        return tail

    def _iter_events(self, *, strict: bool):
        events: List[Dict[str, Any]] = []
        tail = TailStatus(truncated=False, trailing_bytes=0, last_complete_line=0)
        if not self.path.exists():
            return events, tail
        raw = self.path.read_bytes()
        if not raw:
            return events, tail
        complete = raw
        if not raw.endswith(b"\n"):
            tail.truncated = True
            cut = raw.rfind(b"\n")
            tail.trailing_bytes = len(raw) - (cut + 1)
            complete = raw[: cut + 1] if cut >= 0 else b""
            if strict:
                raise JournalCorrupt("日志尾行未完整落盘；请保全并核查后再恢复")
        for idx, line in enumerate(complete.splitlines(), 1):
            if not line.strip():
                continue
            try:
                rec = json.loads(line.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                tail.truncated = True
                tail.trailing_bytes = max(tail.trailing_bytes, len(line))
                if strict:
                    raise JournalCorrupt(
                        f"第 {idx} 行不是合法 JSON（{exc}）；需要人工对账后再继续") from exc
                break
            if rec.get("event") not in EVENT_TYPES:
                raise JournalCorrupt(f"第 {idx} 行事件类型未登记: {rec.get('event')!r}")
            events.append(rec)
            tail.last_complete_line = idx
        return events, tail

    def verify(self) -> Dict[str, Any]:
        """结构校验：重复 claim / intent / 非法状态迁移。返回摘要，失败抛错。"""
        events, tail = self._iter_events(strict=False)
        claims: Set[str] = set()
        intents: Set[str] = set()
        reservations: Dict[str, Dict[str, Any]] = {}
        settled: Set[str] = set()
        for i, ev in enumerate(events, 1):
            kind = ev["event"]
            if kind == "claim":
                rid = str(ev.get("run_id"))
                if rid in claims:
                    raise JournalCorrupt(f"第 {i} 行重复 claim: {rid}")
                claims.add(rid)
            elif kind == "dispatch_intent_durable":
                qid = str(ev.get("request_id"))
                if qid in intents:
                    raise JournalCorrupt(f"第 {i} 行重复派发意图: {qid}")
                intents.add(qid)
            elif kind == "reservation_created":
                qid = str(ev.get("request_id"))
                if qid in reservations:
                    raise JournalCorrupt(f"第 {i} 行重复预留: {qid}")
                reservations[qid] = ev
            elif kind == "usage_settled":
                qid = str(ev.get("request_id"))
                if qid not in reservations:
                    raise JournalCorrupt(f"第 {i} 行结算了不存在的预留: {qid}")
                if qid in settled:
                    raise JournalCorrupt(f"第 {i} 行重复结算: {qid}")
                settled.add(qid)
        unexplained = [q for q in reservations if q not in settled
                       and not any(e.get("event") == "reconciliation_required"
                                   and e.get("request_id") == q for e in events)
                       and not any(e.get("event") == "reservation_released"
                                   and e.get("request_id") == q for e in events)]
        return {
            "events": len(events),
            "claims": len(claims),
            "intents": len(intents),
            "reservations": len(reservations),
            "settled": len(settled),
            "unsettled_reservations": unexplained,
            "tail": tail.as_dict(),
        }

    def completed_trajectories(self) -> Set[str]:
        return {str(e["run_id"]) for e in self.read_all()
                if e["event"] == "completed" and e.get("run_id")}

    def terminal_map(self) -> Dict[str, str]:
        """run_id -> 最近一次终态事件名。"""
        out: Dict[str, str] = {}
        for e in self.read_all():
            if e["event"] in TERMINAL_TRAJECTORY_STATES and e.get("run_id"):
                out[str(e["run_id"])] = str(e["event"])
        return out


class RunLock:
    """run 目录独占锁（跨进程）。

    用 O_EXCL 创建 `run.lock` 并写入 pid/host/开始时间。进程退出未清理时，
    `--steal-stale` 允许在确认 pid 不属于本机存活进程后接管（人工操作）。
    """

    def __init__(self, run_dir: Path | str) -> None:
        self.run_dir = Path(run_dir)
        self.path = self.run_dir / "run.lock"
        self._fd: Optional[int] = None

    def __enter__(self) -> "RunLock":
        self.run_dir.mkdir(parents=True, exist_ok=True)
        payload = json.dumps({
            "pid": os.getpid(),
            "host": socket.gethostname(),
            "started_utc": _now_utc(),
            "argv": sys.argv[:8],
        }, ensure_ascii=False).encode("utf-8")
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
        except FileExistsError as exc:
            holder = "unknown"
            try:
                holder = self.path.read_text(encoding="utf-8").strip()
            except OSError:
                pass
            raise RunLocked(
                f"run 目录已被独占：{self.path}\n持有者：{holder}\n"
                "如需接管，请先确认该进程已结束，再删除 run.lock（不自动抢锁）。") from exc
        os.write(fd, payload)
        os.fsync(fd)
        self._fd = fd
        return self

    def __exit__(self, *exc_info) -> None:
        if self._fd is not None:
            try:
                os.close(self._fd)
            finally:
                self._fd = None
        try:
            self.path.unlink()
        except FileNotFoundError:
            pass


@dataclass
class TrajectoryState:
    """单条轨迹在恢复逻辑中的可解释状态。"""

    run_id: str
    state: str                      # not_started / claimed / dispatched_unknown / completed ...
    dispatches: int = 0
    last_event: Optional[str] = None
    detail: Dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        return {"run_id": self.run_id, "state": self.state,
                "dispatches": self.dispatches, "last_event": self.last_event,
                "detail": dict(self.detail)}


def derive_trajectory_states(events: Iterable[Dict[str, Any]]) -> Dict[str, TrajectoryState]:
    """从事件流推导每条轨迹的状态。

    规则：
      * 有 completed / not_started / failed / budget_blocked → 对应终态；
      * 有 dispatch_intent_durable 但无 response_received 也无 failed
        → `dispatched_unknown`（必须对账，不得重发）；
      * 有 claim 无任何派发意图 → `claimed_no_dispatch`（可安全重新 claim）；
      * 其余 → `not_started`。
    """
    states: Dict[str, TrajectoryState] = {}
    intents: Dict[str, int] = {}
    responses: Set[str] = set()
    for ev in events:
        rid = ev.get("run_id")
        if not rid:
            continue
        if ev["event"] in RUN_LEVEL_EVENTS:
            continue
        rid = str(rid)
        st = states.setdefault(rid, TrajectoryState(run_id=rid, state="not_started"))
        st.last_event = str(ev["event"])
        kind = ev["event"]
        if kind == "claim":
            if st.state == "not_started":
                st.state = "claimed_no_dispatch"
        elif kind == "dispatch_intent_durable":
            intents[rid] = intents.get(rid, 0) + 1
            st.dispatches = intents[rid]
            st.state = "dispatched_unknown"
        elif kind == "response_received":
            responses.add(rid)
            st.state = "responded"
        elif kind in TERMINAL_TRAJECTORY_STATES:
            st.state = kind
        elif kind == "failed":
            if rid not in responses:
                st.state = "failed"
    # dispatch 后既无 response 也无 failed 的，保持 dispatched_unknown
    for rid, st in states.items():
        if st.state in ("claimed_no_dispatch", "responded") and rid in intents:
            if rid not in responses:
                st.state = "dispatched_unknown"
    return states


def resume_plan(events: Iterable[Dict[str, Any]], queue_run_ids: Iterable[str]
                ) -> Dict[str, Any]:
    """给定队列顺序，返回可安全继续的 run_id 列表与各阻塞原因。"""
    states = derive_trajectory_states(events)
    safe: List[str] = []
    blocked: List[Dict[str, Any]] = []
    done: List[str] = []
    for rid in queue_run_ids:
        st = states.get(rid)
        if st is None or st.state in ("not_started", "claimed_no_dispatch"):
            safe.append(rid)
        elif st.state in ("completed", "not_started", "failed", "budget_blocked"):
            done.append(rid)
        else:
            blocked.append({"run_id": rid, "state": st.state,
                            "dispatches": st.dispatches,
                            "action": "quarantine_reconciliation_required"})
    return {"resumable": safe, "already_terminal": done,
            "blocked_requires_reconciliation": blocked,
            "counts": {"resumable": len(safe), "terminal": len(done),
                       "blocked": len(blocked)}}
