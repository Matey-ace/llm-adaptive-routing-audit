"""精确费用账本（整数微人民币，micro-CNY）。

口径（与交接计划工作包 D 一致）：

* 内部只用 `int` 表示金额，**从不使用浮点**。1 micro-CNY = 1e-6 元。
* 价格以「micro-CNY / 百万 tokens」登记，因此
  `cost_micro = ceil(tokens * price_micro_per_million / 1_000_000)`
  向上取整是刻意选择：宁可高估一分也不低估，保证预留是**上界**。
* 每次派发前的门限条件：

      已核费用 + 未决暴露 + 活动预留 + 本次有依据的费用上界  <=  阶段额度
      已核费用 + 未决暴露 + 活动预留 + 本次有依据的费用上界  <=  总额度

  两条同时成立才允许派发。任一不成立 → 不派发，返回 `Decision(False, reason)`。
* 未决费用（结算时 usage 缺失 / 派发结果不明）**不释放为 0**，
  而是整笔转入 `unresolved_exposure`；只有人工对账（`reconcile`）才能把它转为已核费用
  或释放。
* 币种混用直接抛错：账本只接受合同声明的同一币种。
"""

from __future__ import annotations

import math
import threading
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Tuple

MICRO = 1_000_000

# 币种 -> 允许的币种集合（本项目只做 CNY，不做隐式汇率换算）
_SUPPORTED_CURRENCIES = ("CNY",)


class BudgetError(Exception):
    pass


class CurrencyMismatch(BudgetError):
    pass


class ReservationViolation(BudgetError):
    pass


def cost_micro(tokens: int, price_micro_per_million: int) -> int:
    """按上界计算费用（向上取整）。tokens 必须是非负整数。"""
    if not isinstance(tokens, int) or tokens < 0:
        raise BudgetError(f"tokens 必须是非负整数，收到 {tokens!r}")
    if not isinstance(price_micro_per_million, int) or price_micro_per_million < 0:
        raise BudgetError(f"价格必须是非负整数 micro，收到 {price_micro_per_million!r}")
    if tokens == 0 or price_micro_per_million == 0:
        return 0
    return -((-tokens * price_micro_per_million) // MICRO)  # ceil 除法，纯整数


def micro_to_cny(micro: int) -> str:
    """仅用于报告；返回 6 位小数字符串，不参与任何计算。"""
    sign = "-" if micro < 0 else ""
    micro = abs(int(micro))
    return f"{sign}{micro // MICRO}.{micro % MICRO:06d}"


def cny_to_micro(text: str) -> int:
    """把 "12.345678" 这类十进制字符串精确转成 micro（不经过 float）。"""
    s = str(text).strip()
    if not s:
        raise BudgetError("空金额")
    neg = s.startswith("-")
    if neg:
        s = s[1:]
    if "." in s:
        whole, frac = s.split(".", 1)
    else:
        whole, frac = s, ""
    if not whole:
        whole = "0"
    if not whole.isdigit() or (frac and not frac.isdigit()):
        raise BudgetError(f"非法金额字符串: {text!r}")
    if len(frac) > 6:
        raise BudgetError(f"金额精度超过 micro（6 位小数）: {text!r}")
    frac = (frac + "000000")[:6]
    value = int(whole) * MICRO + int(frac)
    return -value if neg else value


@dataclass(frozen=True)
class Reservation:
    request_id: str
    run_id: str
    phase: str
    bound_micro: int
    input_tokens_upper: int
    output_tokens_upper: int
    purpose: str


@dataclass
class Decision:
    allowed: bool
    reason: str
    bound_micro: int = 0
    state: Dict[str, object] = field(default_factory=dict)

    def __bool__(self) -> bool:  # 便于 `if not decision: ...`
        return self.allowed


@dataclass
class LedgerState:
    currency: str
    total_cap_micro: int
    phase_caps_micro: Dict[str, int]
    known_charge_micro: int
    unresolved_exposure_micro: int
    reserved_micro: int
    phase_known_micro: Dict[str, int]
    phase_unresolved_micro: Dict[str, int]
    phase_reserved_micro: Dict[str, int]
    settled_count: int
    unresolved_count: int
    reconciled_count: int

    def as_dict(self) -> Dict[str, object]:
        return {
            "currency": self.currency,
            "total_cap_micro": self.total_cap_micro,
            "total_cap_cny": micro_to_cny(self.total_cap_micro),
            "known_charge_micro": self.known_charge_micro,
            "known_charge_cny": micro_to_cny(self.known_charge_micro),
            "unresolved_exposure_micro": self.unresolved_exposure_micro,
            "unresolved_exposure_cny": micro_to_cny(self.unresolved_exposure_micro),
            "reserved_micro": self.reserved_micro,
            "reserved_cny": micro_to_cny(self.reserved_micro),
            "phase_caps_micro": dict(self.phase_caps_micro),
            "phase_known_micro": dict(self.phase_known_micro),
            "phase_unresolved_micro": dict(self.phase_unresolved_micro),
            "phase_reserved_micro": dict(self.phase_reserved_micro),
            "settled_count": self.settled_count,
            "unresolved_count": self.unresolved_count,
            "reconciled_count": self.reconciled_count,
            "unit": "micro_CNY",
        }


class Ledger:
    """单进程内的费用账本；状态由 journal 事件重放而来（见 journal.replay_ledger）。"""

    def __init__(self, *, currency: str, total_cap_micro: int,
                 phase_caps_micro: Dict[str, int],
                 price_in_micro_per_million: int,
                 price_out_micro_per_million: int) -> None:
        if currency not in _SUPPORTED_CURRENCIES:
            raise CurrencyMismatch(
                f"账本只支持 {_SUPPORTED_CURRENCIES}，收到 {currency!r}；不做隐式汇率换算")
        if total_cap_micro < 0 or any(v < 0 for v in phase_caps_micro.values()):
            raise BudgetError("额度不能为负")
        self.currency = currency
        self.total_cap_micro = total_cap_micro
        self.phase_caps_micro = dict(phase_caps_micro)
        self.price_in = price_in_micro_per_million
        self.price_out = price_out_micro_per_million

        self._known = 0
        self._unresolved = 0
        self._reserved: Dict[str, Reservation] = {}
        self._phase_known: Dict[str, int] = {}
        self._phase_unresolved: Dict[str, int] = {}
        self._settled = 0
        self._unresolved_count = 0
        self._pending: Dict[str, Tuple[str, int]] = {}
        self._reconciled_ids: Dict[str, int] = {}
        self._reconciled = 0
        # 跨题并发时多个线程会同时 reserve / settle；账本状态变更必须互斥。
        self._lock = threading.RLock()

    # ------------------------------------------------------------------ 查询
    @property
    def reserved_micro(self) -> int:
        with self._lock:
            return sum(r.bound_micro for r in self._reserved.values())

    def phase_reserved(self, phase: str) -> int:
        with self._lock:
            return sum(r.bound_micro for r in self._reserved.values() if r.phase == phase)

    @property
    def known_charge_micro(self) -> int:
        with self._lock:
            return self._known

    @property
    def unresolved_exposure_micro(self) -> int:
        with self._lock:
            return self._unresolved

    def committed_micro(self) -> int:
        with self._lock:
            return self._known + self._unresolved + sum(
                r.bound_micro for r in self._reserved.values())

    def state(self) -> LedgerState:
        with self._lock:
            return LedgerState(
            currency=self.currency,
            total_cap_micro=self.total_cap_micro,
            phase_caps_micro=dict(self.phase_caps_micro),
            known_charge_micro=self._known,
            unresolved_exposure_micro=self._unresolved,
            reserved_micro=self.reserved_micro,
            phase_known_micro=dict(self._phase_known),
            phase_unresolved_micro=dict(self._phase_unresolved),
            phase_reserved_micro={p: self.phase_reserved(p) for p in self.phase_caps_micro},
            settled_count=self._settled,
            unresolved_count=self._unresolved_count,
            reconciled_count=self._reconciled,
        )

    # ------------------------------------------------------------------ 预留上界
    def bound_micro(self, input_tokens_upper: int, output_tokens_upper: int) -> int:
        return (cost_micro(input_tokens_upper, self.price_in)
                + cost_micro(output_tokens_upper, self.price_out))

    # ------------------------------------------------------------------ 门限
    def check(self, *, request_id: str, run_id: str, phase: str, purpose: str,
              input_tokens_upper: int, output_tokens_upper: int) -> Decision:
        """派发前检查。不改变账本状态（纯查询），便于先检查后决定。"""
        with self._lock:
            return self._check_unlocked(request_id=request_id, run_id=run_id,
                                        phase=phase, purpose=purpose,
                                        input_tokens_upper=input_tokens_upper,
                                        output_tokens_upper=output_tokens_upper)

    def _check_unlocked(self, *, request_id: str, run_id: str, phase: str, purpose: str,
                        input_tokens_upper: int, output_tokens_upper: int) -> Decision:
        if request_id in self._reserved:
            return Decision(False, "duplicate_request_id", state=self.state().as_dict())
        if phase not in self.phase_caps_micro:
            return Decision(False, f"unknown_phase:{phase}", state=self.state().as_dict())
        bound = self.bound_micro(input_tokens_upper, output_tokens_upper)
        total_after = self.committed_micro() + bound
        if total_after > self.total_cap_micro:
            return Decision(
                False,
                "total_cap_exceeded",
                bound_micro=bound,
                state={"would_commit": total_after,
                       "total_cap": self.total_cap_micro,
                       **self.state().as_dict()})
        phase_after = (self._phase_known.get(phase, 0)
                       + self._phase_unresolved.get(phase, 0)
                       + self.phase_reserved(phase) + bound)
        phase_cap = self.phase_caps_micro[phase]
        if phase_after > phase_cap:
            return Decision(
                False,
                "phase_cap_exceeded",
                bound_micro=bound,
                state={"would_commit": phase_after, "phase_cap": phase_cap,
                       "phase": phase, **self.state().as_dict()})
        return Decision(True, "ok", bound_micro=bound, state=self.state().as_dict())

    def reserve(self, *, request_id: str, run_id: str, phase: str, purpose: str,
                input_tokens_upper: int, output_tokens_upper: int) -> Reservation:
        # 与 _check_unlocked 在**同一把锁**内完成：杜绝并发下两个线程同时通过检查。
        with self._lock:
            decision = self._check_unlocked(request_id=request_id, run_id=run_id,
                                            phase=phase, purpose=purpose,
                                            input_tokens_upper=input_tokens_upper,
                                            output_tokens_upper=output_tokens_upper)
            if not decision.allowed:
                raise BudgetError(f"预留被拒（{decision.reason}）：{request_id}")
            res = Reservation(request_id=request_id, run_id=run_id, phase=phase,
                              bound_micro=decision.bound_micro,
                              input_tokens_upper=input_tokens_upper,
                              output_tokens_upper=output_tokens_upper,
                              purpose=purpose)
            self._reserved[request_id] = res
            return res

    # ------------------------------------------------------------------ 结算
    def settle(self, *, request_id: str, prompt_tokens: Optional[int],
               completion_tokens: Optional[int]) -> str:
        """结算一次派发。"""
        with self._lock:
            res = self._reserved.pop(request_id, None)
            if res is None:
                raise ReservationViolation(f"没有该预留：{request_id}")
            if prompt_tokens is None or completion_tokens is None:
                self._unresolved += res.bound_micro
                self._phase_unresolved[res.phase] = (
                    self._phase_unresolved.get(res.phase, 0) + res.bound_micro)
                self._unresolved_count += 1
                self._pending[request_id] = (res.phase, res.bound_micro)
                return "unresolved_missing_usage"
            if prompt_tokens < 0 or completion_tokens < 0:
                raise BudgetError("usage 不能为负")
            actual = (cost_micro(int(prompt_tokens), self.price_in)
                      + cost_micro(int(completion_tokens), self.price_out))
            if actual > res.bound_micro:
                self._unresolved += res.bound_micro
                self._phase_unresolved[res.phase] = (
                    self._phase_unresolved.get(res.phase, 0) + res.bound_micro)
                self._unresolved_count += 1
                self._pending[request_id] = (res.phase, res.bound_micro)
                return "unresolved_overrun"
            self._known += actual
            self._phase_known[res.phase] = self._phase_known.get(res.phase, 0) + actual
            self._settled += 1
            return "settled"

    def release(self, request_id: str) -> None:
        """仅在**确定从未派发**时释放。"""
        with self._lock:
            self._reserved.pop(request_id, None)

    def reconcile(self, *, request_id: str, amount_micro: int,
                  note: str = "") -> None:
        """人工对账：把整笔未决暴露转为已核费用（或释放为 0）。"""
        with self._lock:
            if type(amount_micro) is not int or amount_micro < 0:
                raise BudgetError("对账金额必须为非负整数")
            if request_id in self._reconciled_ids:
                if self._reconciled_ids[request_id] != amount_micro:
                    raise BudgetError("重复账单金额冲突")
                return
            if request_id not in self._pending:
                raise BudgetError("没有该请求的未决暴露")
            phase, exposure = self._pending[request_id]
            if amount_micro > exposure:
                raise BudgetError("对账金额超过该请求预留")
            self._pending.pop(request_id)
            self._unresolved -= exposure
            self._phase_unresolved[phase] -= exposure
            self._known += amount_micro
            self._phase_known[phase] = self._phase_known.get(phase, 0) + amount_micro
            self._unresolved_count -= 1
            self._reconciled_ids[request_id] = amount_micro
            self._reconciled += 1

    # ------------------------------------------------------------------ 重放
    @classmethod
    def from_events(cls, events: Iterable[Dict[str, object]], *,
                    currency: str, total_cap_micro: int,
                    phase_caps_micro: Dict[str, int],
                    price_in_micro_per_million: int,
                    price_out_micro_per_million: int) -> "Ledger":
        """由 journal 事件重放出账本状态（崩溃恢复的唯一真源）。"""
        led = cls(currency=currency, total_cap_micro=total_cap_micro,
                  phase_caps_micro=phase_caps_micro,
                  price_in_micro_per_million=price_in_micro_per_million,
                  price_out_micro_per_million=price_out_micro_per_million)
        for ev in events:
            kind = ev.get("event")
            rid = ev.get("request_id")
            if kind == "reservation_created" and isinstance(rid, str):
                led._reserved[rid] = Reservation(
                    request_id=rid,
                    run_id=str(ev.get("run_id", "")),
                    phase=str(ev.get("phase", "")),
                    bound_micro=int(ev.get("bound_micro", 0) or 0),
                    input_tokens_upper=int(ev.get("input_tokens_upper", 0) or 0),
                    output_tokens_upper=int(ev.get("output_tokens_upper", 0) or 0),
                    purpose=str(ev.get("purpose", "")),
                )
            elif kind == "usage_settled" and isinstance(rid, str):
                led._reserved.pop(rid, None)
                actual = int(ev.get("actual_micro", 0) or 0)
                led._known += actual
                ph = str(ev.get("phase", ""))
                led._phase_known[ph] = led._phase_known.get(ph, 0) + actual
                led._settled += 1
            elif kind == "reconciliation_required" and isinstance(rid, str):
                res = led._reserved.pop(rid, None)
                amount = int(ev.get("exposure_micro", 0) or 0)
                if res is not None and amount == 0:
                    amount = res.bound_micro
                led._unresolved += amount
                ph = str(ev.get("phase", ""))
                led._phase_unresolved[ph] = led._phase_unresolved.get(ph, 0) + amount
                led._unresolved_count += 1
                led._pending[rid] = (ph, amount)
            elif kind == "reconciled" and isinstance(rid, str):
                led.reconcile(request_id=rid, amount_micro=int(ev.get("amount_micro", 0) or 0))
            elif kind == "reservation_released" and isinstance(rid, str):
                led._reserved.pop(rid, None)
        return led


def summarise_by_purpose(records: List[Dict[str, object]]) -> Dict[str, Dict[str, int]]:
    """按 purpose 汇总请求数/输入/输出/费用（供报告使用）。"""
    out: Dict[str, Dict[str, int]] = {}
    for r in records:
        p = str(r.get("purpose", "unknown"))
        slot = out.setdefault(p, {"dispatches": 0, "prompt_tokens": 0,
                                  "completion_tokens": 0, "cost_micro": 0,
                                  "failed": 0})
        slot["dispatches"] += 1
        slot["prompt_tokens"] += int(r.get("prompt_tokens") or 0)
        slot["completion_tokens"] += int(r.get("completion_tokens") or 0)
        slot["cost_micro"] += int(r.get("actual_micro") or 0)
        if r.get("failed"):
            slot["failed"] += 1
    return out


def required_total(tokens: int, price_in: int, price_out: int,
                   out_share: float = 1.0) -> Tuple[int, int]:
    """给预算估算用的保守拆分（out_share=1.0 表示全部按输出价，最保守）。"""
    in_tokens = int(math.floor(tokens * (1 - out_share)))
    out_tokens = tokens - in_tokens
    return in_tokens, out_tokens
