"""内置离线场景定义（工作包 E 第 2–8 项的可重复证据）。

每个场景给出：任务、臂、合成脚本、预算覆盖，以及断言函数。
断言函数只读 run 目录里的**真实产物**（journal / results / summary），
不去相信内存对象，因此也能证明"落盘 → 重放"这条链路是对的。
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from .inputs import TaskPrompt, sha256_text
from .providers import SyntheticAction, SyntheticProvider


def _task(task_id: str, prompt: str) -> TaskPrompt:
    return TaskPrompt(task_id=task_id, prompt=prompt, prompt_sha256=sha256_text(prompt))


@dataclass
class Scenario:
    scenario_id: str
    description: str
    tasks: List[TaskPrompt]
    arms: List[str]
    actions: Dict[str, List[SyntheticAction]]
    check: Callable[..., List[Dict[str, Any]]]
    contract_overrides: Dict[str, Any] = field(default_factory=dict)
    purpose_script: Optional[Dict[str, List[SyntheticAction]]] = None

    def build_provider(self, rows: List[Dict[str, Any]]) -> Any:
        if getattr(self, "purpose_script", None):
            from .providers import PurposeSyntheticProvider
            return PurposeSyntheticProvider(self.purpose_script)
        script: Dict[str, List[SyntheticAction]] = {}
        for row in rows:
            key = f"{row['task_id']}|{row['strategy']}"
            strategy = str(row["strategy"])
            fallback = (self.actions.get(key)
                        or self.actions.get(strategy)
                        or self.actions.get("default"))
            if fallback is None and strategy == "asc_beta_8":
                # ASC 的实际 purpose 是 baseline_solve
                fallback = self.actions.get("baseline_solve")
            if fallback is None:
                raise KeyError(f"{self.scenario_id} 缺少动作：{key}")
            script[row["run_id"]] = list(fallback)
        return SyntheticProvider(script)


# ---------------------------------------------------------------- 断言工具
def _read_journal(run_dir: Path) -> List[Dict[str, Any]]:
    p = run_dir / "journal.jsonl"
    return [json.loads(line) for line in p.read_text(encoding="utf-8").splitlines()
            if line.strip()]


def _read_results(run_dir: Path) -> List[Dict[str, Any]]:
    p = run_dir / "results.jsonl"
    if not p.is_file():
        return []
    return [json.loads(line) for line in p.read_text(encoding="utf-8").splitlines()
            if line.strip()]


def _check(name: str, passed: bool, **detail) -> Dict[str, Any]:
    return {"name": name, "passed": bool(passed), "detail": detail}


def _events(journal: List[Dict[str, Any]], kind: str) -> List[Dict[str, Any]]:
    return [e for e in journal if e["event"] == kind]


# ---------------------------------------------------------------- 场景实现
def _sc_asc_early_stop() -> Scenario:
    """4 次同答 → 第 4 次即停，第 5 次不派发。"""
    t = _task("T_ASC_EARLY", "What is 2+2?")
    actions = {"baseline_solve": [SyntheticAction.text("ANSWER: 4")] * 8}

    def check(*, run_dir, summary, provider, **_):
        journal = _read_journal(run_dir)
        results = _read_results(run_dir)
        intents = [e for e in _events(journal, "dispatch_intent_durable")
                   if e.get("purpose") == "baseline_solve"]
        outcome = (results[0]["outcome"] if results else {})
        asc = outcome.get("asc") or {}
        return [
            _check("四答即停：仅派发 4 次", len(intents) == 4, intents=len(intents)),
            _check("停止原因=asc_beta_threshold",
                   asc.get("stop_reason") == "asc_beta_threshold",
                   stop_reason=asc.get("stop_reason")),
            _check("后验 ≥ 0.95（31/32）",
                   (asc.get("posterior_top_two") or 0) >= 0.968,
                   posterior=asc.get("posterior_top_two")),
            _check("未消费第 5 次", asc.get("early_stop_skipped_attempts") == 4,
                   skipped=asc.get("early_stop_skipped_attempts")),
            _check("选中答案保留原始片段",
                   (asc.get("selected_raw_span") or "").strip() == "4",
                   selected=asc.get("selected_raw_span")),
        ]

    return Scenario("asc_early_stop", "ASC 四次同答即停，第 5 次不派发", [t],
                    ["asc_beta_8"], actions, check)


def _sc_asc_cap() -> Scenario:
    """8 次全不同 → 用满 8 次，第 9 次不派发，平票取最先出现。"""
    t = _task("T_ASC_CAP", "Name a number.")
    answers = [f"ANSWER: {i}" for i in range(1, 10)]
    actions = {"baseline_solve": [SyntheticAction.text(a) for a in answers]}

    def check(*, run_dir, summary, provider, **_):
        journal = _read_journal(run_dir)
        results = _read_results(run_dir)
        intents = [e for e in _events(journal, "dispatch_intent_durable")
                   if e.get("purpose") == "baseline_solve"]
        asc = (results[0]["outcome"].get("asc") if results else {}) or {}
        return [
            _check("派发恰好 8 次（第 9 次未发生）", len(intents) == 8,
                   intents=len(intents)),
            _check("provider 只被调用 8 次", len(provider.calls) == 8,
                   calls=len(provider.calls)),
            _check("停止原因=attempt_cap", asc.get("stop_reason") == "attempt_cap",
                   stop_reason=asc.get("stop_reason")),
            _check("平票取最早出现的答案", asc.get("selected_alias") == "1",
                   selected=asc.get("selected_alias")),
        ]

    return Scenario("asc_cap", "ASC 八次上限，第 9 次不消费", [t], ["asc_beta_8"],
                    actions, check)


def _sc_asc_all_invalid() -> Scenario:
    """全部无效（空 + 截断无标记） → 明确失败状态，不被伪装成答错。"""
    t = _task("T_ASC_INVALID", "Solve it.")
    actions = {"baseline_solve": [SyntheticAction.empty()] * 8}

    def check(*, run_dir, summary, provider, **_):
        results = _read_results(run_dir)
        outcome = results[0]["outcome"] if results else {}
        asc = outcome.get("asc") or {}
        rec = outcome.get("answer_record") or {}
        return [
            _check("八次尝试全部消耗", asc.get("attempts") == 8,
                   attempts=asc.get("attempts")),
            _check("有效票为 0", (asc.get("valid_votes") or 0) == 0,
                   valid_votes=asc.get("valid_votes")),
            _check("未选出答案", asc.get("selected_key") is None,
                   selected=asc.get("selected_key")),
            _check("终态为无效而非答错", rec.get("valid") is False,
                   answer_valid=rec.get("valid")),
            _check("停止原因=attempt_cap", asc.get("stop_reason") == "attempt_cap",
                   stop_reason=asc.get("stop_reason")),
        ]

    return Scenario("asc_all_invalid", "ASC 全部无效：消耗尝试但不投票", [t],
                    ["asc_beta_8"], actions, check)


def _sc_truncated() -> Scenario:
    """截断且无显式标记 → 无效；有显式标记 → 有效。"""
    t1 = _task("T_TRUNC", "Long reasoning task.")
    t2 = _task("T_TRUNC_MARK", "Long reasoning task with marker.")
    actions = {
        "T_TRUNC|direct": [SyntheticAction.truncated("partial reasoning without answer")],
        "T_TRUNC_MARK|direct": [SyntheticAction.truncated("...ANSWER: 42")],
    }

    def check(*, run_dir, summary, provider, **_):
        results = {r["task_id"]: r for r in _read_results(run_dir)}
        a = (results.get("T_TRUNC", {}).get("outcome") or {}).get("answer_record") or {}
        b = (results.get("T_TRUNC_MARK", {}).get("outcome") or {}).get("answer_record") or {}
        return [
            _check("截断且无标记 → 无效",
                   a.get("valid") is False
                   and a.get("reason") == "truncated_without_final_marker",
                   reason=a.get("reason")),
            _check("截断但有 ANSWER 标记 → 有效",
                   b.get("valid") is True and (b.get("key") or "").startswith("num:"),
                   reason=b.get("reason"), key=b.get("key")),
        ]

    return Scenario("truncated", "截断处理：无标记无效，有标记有效", [t1, t2],
                    ["direct"], actions, check)


def _sc_missing_usage() -> Scenario:
    """有正文但缺 usage → 保留正文、转未决暴露、不重发。"""
    t = _task("T_NOUSAGE", "What is 7*6?")
    actions = {"direct": [SyntheticAction.missing_usage("ANSWER: 42")]}

    def check(*, run_dir, summary, provider, **_):
        journal = _read_journal(run_dir)
        results = _read_results(run_dir)
        rec = (results[0].get("outcome") or {}) if results else {}
        recon = _events(journal, "reconciliation_required")
        return [
            _check("正文被保全", "42" in (rec.get("final_answer") or ""),
                   final=rec.get("final_answer")),
            _check("转为 reconciliation_required", len(recon) == 1, count=len(recon)),
            _check("未决暴露 > 0（不释放为 0）",
                   summary.unresolved_micro > 0, unresolved=summary.unresolved_micro),
            _check("已核费用保持 0", summary.known_charge_micro == 0,
                   known=summary.known_charge_micro),
            _check("没有自动重发（仅 1 次派发）",
                   len(_events(journal, "dispatch_intent_durable")) == 1),
            _check("run 状态标出未决暴露",
                   summary.status == "STOPPED_WITH_UNRESOLVED_EXPOSURE",
                   status=summary.status),
        ]

    return Scenario("missing_usage", "缺 usage：保全正文 + 保留暴露 + 不重发", [t],
                    ["direct"], actions, check)


def _sc_transport_failures() -> Scenario:
    """两类传输失败：可能已计费 → 保留暴露；肯定未计费 → 释放预留。"""
    t1 = _task("T_ERR_BILLED", "Task A")
    t2 = _task("T_ERR_FREE", "Task B")
    actions = {
        "T_ERR_BILLED|direct": [SyntheticAction.error("connection reset", may_have_billed=True)],
        "T_ERR_FREE|direct": [SyntheticAction.error("400 bad request", may_have_billed=False,
                                                    status_code=400)],
    }

    def check(*, run_dir, summary, provider, **_):
        journal = _read_journal(run_dir)
        recon = _events(journal, "reconciliation_required")
        released = _events(journal, "reservation_released")

        def _for(events, task_id):
            return [e for e in events if str(e.get("run_id", "")).split(":")[1:2] == [task_id]]

        billed_rid = _for(recon, "T_ERR_BILLED")
        free_rid = _for(released, "T_ERR_FREE")
        return [
            _check("可能已计费 → 保留暴露", len(billed_rid) == 1, count=len(billed_rid),
                   run_ids=sorted({e.get("run_id") for e in recon})),
            _check("肯定未计费 → 释放预留", len(free_rid) == 1, count=len(free_rid),
                   run_ids=sorted({e.get("run_id") for e in released})),
            _check("失败未伪装成成功",
                   summary.completed == 0, completed=summary.completed),
            _check("失败计为 failed", summary.failed == 2, failed=summary.failed),
            _check("未决暴露 > 0 且已核费用为 0",
                   summary.unresolved_micro > 0 and summary.known_charge_micro == 0,
                   unresolved=summary.unresolved_micro,
                   known=summary.known_charge_micro),
        ]

    # Exercise the certainly-unbilled branch first: after the unknown-billed
    # branch the whole run intentionally stops until reconciliation.
    return Scenario("transport_failures", "传输失败的两类财务处置", [t2, t1],
                    ["direct"], actions, check)


def _sc_dispatch_cap_plan_reflect() -> Scenario:
    """plan_reflect 的反思轮数由 S1(max_rounds=2) 决定；8 次派发门不越权。"""
    t = _task("T_CAP_PR", "Reflect twice then stop.")
    purpose = {
        "plan": [SyntheticAction.text("PLAN:\n1. step")],
        "solve": [SyntheticAction.text("ANSWER: 1")],
        "reflect": [SyntheticAction.text(
            "REFLECT:\n- still wrong\nCONFIDENCE: 0.1\nVERDICT: REVISE")],
        "replan": [SyntheticAction.text("PLAN:\n1. retry")],
    }

    def check(*, run_dir, summary, provider, **_):
        journal = _read_journal(run_dir)
        intent = _events(journal, "dispatch_intent_durable")
        results = _read_results(run_dir)
        rec = (results[0].get("outcome") or {}) if results else {}
        purposes = [e.get("purpose") for e in intent]
        return [
            _check("派发不超过 8 次", len(intent) <= 8, intents=len(intent)),
            _check("provider 调用不超过 8 次", len(provider.calls) <= 8,
                   calls=len(provider.calls)),
            _check("路径确实走了 reflect/replan",
                   "reflect" in purposes and "replan" in purposes, purposes=purposes),
            _check("由 S1 固定轮次停止（不是被 8 次门截断）",
                   rec.get("stop_reason") == "fixed_rounds:2",
                   stop_reason=rec.get("stop_reason")),
            _check("调用链为 plan→solve→reflect→replan→solve→reflect",
                   purposes == ["plan", "solve", "reflect", "replan", "solve", "reflect"],
                   purposes=purposes),
        ]

    return Scenario("plan_reflect_cap", "plan_reflect 的 S1 固定轮次与 8 次门并存", [t],
                    ["plan_reflect"], {}, check, purpose_script=purpose)


def _sc_adaptive_judge() -> Scenario:
    """adaptive_legacy 在灰区必须经过 judge；judge 调用同样计入派发与费用。"""
    # 分数落在冻结 router 的灰区 (0.05, 0.15) 内（实测 0.0525），从而必然触发 judge
    t = _task("T_ADAPT",
              "A shop sells pens for 3 dollars and notebooks for 7 dollars. "
              "A customer buys 4 pens and 9 notebooks. Report the total cost in dollars and cents.")
    purpose = {
        "judge": [SyntheticAction.text(
            '{"level": "hard", "confidence": 0.8, "reasoning_steps": 4, "reason": "multi"}')],
        "plan": [SyntheticAction.text("PLAN:\n1. solve x")],
        "solve": [SyntheticAction.text("ANSWER: 3")],
        "reflect": [SyntheticAction.text(
            "REFLECT:\n- looks fine\nCONFIDENCE: 0.9\nVERDICT: PASS")],
        "replan": [SyntheticAction.text("PLAN:\n1. redo")],
    }

    def check(*, run_dir, summary, provider, **_):
        journal = _read_journal(run_dir)
        intent = _events(journal, "dispatch_intent_durable")
        purposes = [e.get("purpose") for e in intent]
        results = _read_results(run_dir)
        rec = (results[0].get("outcome") or {}) if results else {}
        return [
            _check("judge 经过共享 dispatcher", "judge" in purposes, purposes=purposes),
            _check("judge 计入费用（usage_settled 中有 judge）",
                   any(e.get("purpose") == "judge"
                       for e in _events(journal, "usage_settled")),
                   settled=[e.get("purpose") for e in _events(journal, "usage_settled")]),
            _check("路由结果被记录", rec.get("selected_level") is not None,
                   level=rec.get("selected_level"), path=rec.get("selected_path")),
            _check("总派发 ≤ 8", len(intent) <= 8, intents=len(intent)),
        ]

    return Scenario("adaptive_judge", "adaptive 的 judge 无旁路", [t],
                    ["adaptive_legacy"], {}, check, purpose_script=purpose)


def _sc_budget_stop() -> Scenario:
    """额度极紧：第一次派发后即无法支付下一次，且第 2 次未派发。

    数值口径（与 micro-CNY 一致）：
      单价 输入 2 元/百万 tokens、输出 8 元/百万 tokens
      短提示一次派发：输入上界 584 bytes ⇒ 1,168 micro，输出上限 4096 ⇒ 32,768 micro
      ⇒ 单次预留 33,936 micro；首次结算仅 1,800 micro（pt=500/ct=100）。
      总额度 34,000 micro：第 1 次 33,936 ≤ 34,000 通过；
      第 2 次 1,800 + 33,936 = 35,736 > 34,000 必然被拒。
    """
    t1 = _task("T_BUDGET_1", "Task one")
    t2 = _task("T_BUDGET_2", "Task two")
    actions = {"direct": [SyntheticAction.text("ANSWER: 1", pt=500, ct=100)]}
    overrides = {"budget": {"currency": "CNY", "total_micro": 34_000,
                            "preflight_micro": 34_000, "main_micro": 0,
                            "unknown_usage_policy":
                                "retain_full_reservation_as_unresolved_exposure",
                            "stop_before_dispatch_when_insufficient": True,
                            "topup_without_approval": False}}

    def check(*, run_dir, summary, provider, **_):
        journal = _read_journal(run_dir)
        blocked = _events(journal, "budget_blocked")
        intent = _events(journal, "dispatch_intent_durable")
        return [
            _check("预算拒绝被单独记录", len(blocked) >= 1, blocked=len(blocked)),
            _check("预算拒绝不计为已派发",
                   all(b.get("dispatched") is False for b in blocked)),
            _check("实际派发少于计划（第二次未派发）", len(intent) == 1,
                   intents=len(intent)),
            _check("provider 只被调用 1 次", len(provider.calls) == 1,
                   calls=len(provider.calls)),
            _check("已核费用不超总额",
                   summary.known_charge_micro <= 34_000,
                   known=summary.known_charge_micro),
            _check("剩余轨迹有明确终态（budget_blocked / not_started）",
                   (summary.not_started + summary.budget_blocked) >= 1,
                   not_started=summary.not_started,
                   budget_blocked=summary.budget_blocked),
        ]

    return Scenario("budget_stop", "额度不足在下一派发前停止", [t1, t2], ["direct"],
                    actions, check, contract_overrides=overrides)


def _sc_conflicting_markers() -> Scenario:
    """同一输出里多个不同标记 → 采用最后一个并标记冲突。"""
    t = _task("T_CONFLICT", "Pick one.")
    actions = {"direct": [SyntheticAction.text("ANSWER: 1\nsome text\nANSWER: 2")]}

    def check(*, run_dir, summary, provider, **_):
        results = _read_results(run_dir)
        rec = (results[0]["outcome"].get("answer_record") if results else {}) or {}
        return [
            _check("采用最后一个标记", (rec.get("key") or "").endswith("2/1"),
                   key=rec.get("key")),
            _check("冲突被标记", rec.get("conflicting_markers") is True,
                   conflicting=rec.get("conflicting_markers")),
        ]

    return Scenario("conflicting_markers", "冲突多答案：取最后并标记", [t], ["direct"],
                    actions, check)


def _sc_identical_answers() -> Scenario:
    """不同表示同一数值 → 同票（0.5 与 1/2）。"""
    t = _task("T_SAME_VALUE", "Half of one.")
    actions = {"baseline_solve": [
        SyntheticAction.text("ANSWER: 1/2"),
        SyntheticAction.text("ANSWER: 0.5"),
        SyntheticAction.text("ANSWER: \\frac{1}{2}"),
        SyntheticAction.text("ANSWER: 0.50"),
    ]}

    def check(*, run_dir, summary, provider, **_):
        results = _read_results(run_dir)
        asc = (results[0]["outcome"].get("asc") if results else {}) or {}
        keys = [h.get("key") for h in asc.get("history") or []]
        return [
            _check("四种表示归为同一键", len(set(keys)) == 1, keys=keys),
            _check("四次同票即停", asc.get("attempts") == 4, attempts=asc.get("attempts")),
            _check("停止原因=阈值", asc.get("stop_reason") == "asc_beta_threshold",
                   stop_reason=asc.get("stop_reason")),
        ]

    return Scenario("identical_answers", "相同数值不同表示归为一票", [t],
                    ["asc_beta_8"], actions, check)


def _sc_second_place_blocks_stop() -> Scenario:
    """第二名计数改变后验：a=3,b=1 时不达 0.95。"""
    t = _task("T_SECOND", "Vote.")
    actions = {"baseline_solve": [
        SyntheticAction.text("ANSWER: 7"),
        SyntheticAction.text("ANSWER: 7"),
        SyntheticAction.text("ANSWER: 8"),
        SyntheticAction.text("ANSWER: 7"),
        SyntheticAction.text("ANSWER: 7"),
    ]}

    def check(*, run_dir, summary, provider, **_):
        results = _read_results(run_dir)
        asc = (results[0]["outcome"].get("asc") if results else {}) or {}
        hist = asc.get("history") or []
        q3 = next((h["posterior_top_two"] for h in hist if h["index"] == 4), None)
        return [
            _check("第 4 次（a=2,b=1）未达标", (hist[3]["posterior_top_two"] or 0) < 0.95,
                   posterior=hist[3]["posterior_top_two"]),
            _check("第 5 次（a=3,b=1）仍未达标",
                   (hist[4]["posterior_top_two"] or 0) < 0.95,
                   posterior=hist[4]["posterior_top_two"]),
            _check("未提前停止", asc.get("attempts") >= 5, attempts=asc.get("attempts")),
        ]

    return Scenario("second_place", "第二名计数改变后验，不提前停", [t],
                    ["asc_beta_8"], actions, check)


def builtin_scenarios() -> List[Scenario]:
    return [
        _sc_asc_early_stop(),
        _sc_asc_cap(),
        _sc_asc_all_invalid(),
        _sc_identical_answers(),
        _sc_second_place_blocks_stop(),
        _sc_truncated(),
        _sc_missing_usage(),
        _sc_transport_failures(),
        _sc_dispatch_cap_plan_reflect(),
        _sc_adaptive_judge(),
        _sc_budget_stop(),
        _sc_conflicting_markers(),
    ]
