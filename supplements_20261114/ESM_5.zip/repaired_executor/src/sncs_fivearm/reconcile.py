"""对账：只读本地账单/回执证据，把未决暴露转为已核费用或释放。

纪律：

* **不发**任何网络请求、不构造 live client、不探测服务。
* 证据文件由人工从控制台导出后放在本地，形如：

      {"request_id": "...", "billed_micro": 123456, "note": "..."}

  或按 run 级汇总：

      {"run_id": "...", "billed_micro": 1234567, "note": "..."}

* 匹配不上的证据留档但不改动账本；帐实不符时报告差额，由人决定。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from .budget import Ledger
from .journal import Journal


def reconcile_run(*, run_id: str, runs_root: Path,
                  evidence: Optional[Path]) -> Dict[str, Any]:
    run_dir = runs_root / run_id
    journal = Journal(run_dir / "journal.jsonl")
    events = journal.read_all()
    pending: Dict[str, Dict[str, Any]] = {}
    for ev in events:
        if ev["event"] == "reconciliation_required":
            rid = ev.get("request_id")
            if rid:
                pending[rid] = ev
        elif ev["event"] == "reconciled":
            pending.pop(ev.get("request_id"), None)
    if not pending:
        return {"run_id": run_id, "status": "NOTHING_TO_RECONCILE",
                "pending_requests": 0}

    if evidence is None or not Path(evidence).is_file():
        return {
            "run_id": run_id,
            "status": "EVIDENCE_REQUIRED",
            "pending_requests": len(pending),
            "pending_sample": list(pending)[:10],
            "note": ("需要本地账单证据文件（JSON）。本命令不发起任何网络请求，"
                     "也不猜费用。"),
        }

    data = json.loads(Path(evidence).read_text(encoding="utf-8-sig"))
    items: List[Dict[str, Any]] = data.get("items") if isinstance(data, dict) else None
    if items is None and isinstance(data, list):
        items = data
    if not items:
        return {"run_id": run_id, "status": "EVIDENCE_EMPTY",
                "pending_requests": len(pending)}

    matched: List[Dict[str, Any]] = []
    unmatched: List[Dict[str, Any]] = []
    for item in items:
        rid = item.get("request_id")
        if rid not in pending:
            unmatched.append(item)
            continue
        exposure = int(pending[rid].get("exposure_micro") or 0)
        billed = item.get("billed_micro")
        if type(billed) is not int or billed < 0:
            unmatched.append({**item, "reason": "invalid_billed_micro"})
            continue
        if billed > exposure:
            unmatched.append({**item, "reason": "billed_exceeds_exposure"})
            continue
        journal.append("reconciled", run_id=run_id, phase=pending[rid].get("phase"),
                       request_id=rid, amount_micro=billed,
                       note=str(item.get("note", "")))
        matched.append({"request_id": rid, "exposure_micro": exposure,
                        "billed_micro": billed})
        pending.pop(rid)

    total_billed = sum(m["billed_micro"] for m in matched)
    remaining = len(pending)
    return {
        "run_id": run_id,
        "status": "PARTIAL" if remaining else "RECONCILED",
        "pending_requests": len(pending),
        "matched": len(matched),
        "unmatched_evidence": unmatched[:20],
        "total_reconciled_micro": total_billed,
        "remaining_pending": remaining,
        "note": "未匹配的证据已留档；账本只按证据金额调整，不猜。",
    }
