"""共享派发入口：所有模型请求的唯一实际发起点。

任何角色（judge / plan / solve / reflect / replan / baseline_solve）以及 ASC 的每一次
采样都必须经过本模块。旧 Agent 只看到 `LegacyBridgeClient.chat(...)`，而它只是本
dispatcher 的薄壳，因此不存在旁路。

单次派发的固定顺序（崩溃可解释性来自这个顺序）：

    1. 轨迹派发门：本轨迹已派发次数 + 1 <= 8，否则 DispatchLimitReached（未派发）
    2. 预算门（纯查询）：已核 + 未决 + 预留 + 本次上界 <= 阶段额度、总额度
       - 不通过 → 记 budget_blocked 事件，**不写 intent**，不派发
    3. 预留：记 reservation_created
    4. 意图落盘：记 dispatch_intent_durable（崩溃点分界：此后一律视为可能已产生费用）
    5. 真正调用 provider
    6. 成功：记 response_received（含 partial / 缺 usage），结算：
       - usage 齐全 → usage_settled（按实际上界计费）
       - usage 缺失 → reconciliation_required（整笔保留为未决暴露）
       失败：记 failed（含 may_have_billed）；may_have_billed=True 一律
       reconciliation_required 保留整笔预留；=False 才 reservation_released。
"""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .budget import Ledger
from .errors import ReconciliationRequired, BudgetBlocked, DispatchLimitReached, TransportError
from .inputs import estimate_input_tokens_upper
from .journal import Journal
from .providers import ChatRequest, Provider, ProviderResponse


@dataclass
class DispatchRecord:
    """一次派发的完整记录（成功或失败）。"""

    request_id: str
    run_id: str
    phase: str
    purpose: str
    index: int
    dispatched: bool
    settled: str
    content: str = ""
    finish_reason: str = ""
    model_reported: Optional[str] = None
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    usage_missing_reason: Optional[str] = None
    latency_ms: float = 0.0
    bound_micro: int = 0
    actual_micro: int = 0
    error: Optional[str] = None
    envelope: Dict[str, Any] = field(default_factory=dict)
    messages: List[Dict[str, str]] = field(default_factory=list)
    ledger_outcome: str = ""

    def as_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "run_id": self.run_id,
            "phase": self.phase,
            "purpose": self.purpose,
            "index": self.index,
            "dispatched": self.dispatched,
            "settled": self.settled,
            "content": self.content,
            "finish_reason": self.finish_reason,
            "model_reported": self.model_reported,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "usage_missing_reason": self.usage_missing_reason,
            "latency_ms": round(self.latency_ms, 3),
            "bound_micro": self.bound_micro,
            "actual_micro": self.actual_micro,
            "error": self.error,
            "envelope": self.envelope,
        }


class RateLimiter:
    """每分钟派发上限（线程安全滑动窗口）。

    用户授权上限 500 RPM；本实现留 20 次余量，默认 480。
    """

    def __init__(self, max_per_minute: int, *, clock=time.monotonic,
                 sleep_fn=time.sleep) -> None:
        self.max_per_minute = max(1, int(max_per_minute))
        self._clock = clock
        self._sleep = sleep_fn
        self._times: deque = deque()
        self._lock = threading.Lock()

    def acquire(self) -> None:
        while True:
            with self._lock:
                now = self._clock()
                while self._times and now - self._times[0] >= 60.0:
                    self._times.popleft()
                if len(self._times) < self.max_per_minute:
                    self._times.append(now)
                    return
                wait = 60.0 - (now - self._times[0]) + 0.001
            self._sleep(max(0.0, wait))


class Dispatcher:
    """共享派发器。

    单 worker 时行为与 v1 完全一致；多 worker 时通过 `_gate_lock` 保证：
      * 预算检查 + 预留 + 落盘是原子的，不会超卖额度；
      * 同一轨迹的 request_id 序号不会冲突；
      * `records` 列表写入互斥。
    网络调用在锁外进行，因此并发仍真正并行。
    """

    def __init__(self, *, journal: Journal, ledger: Ledger, provider: Provider,
                 contract, output_ceiling: int, sampling: Dict[str, Any],
                 input_bound_method: str, sleep_fn=time.sleep) -> None:
        self.journal = journal
        self.ledger = ledger
        self.provider = provider
        self.contract = contract
        self.output_ceiling = int(output_ceiling)
        self.sampling = dict(sampling)
        self.input_bound_method = input_bound_method
        self._sleep = sleep_fn
        self.thinking = dict(contract.get("provider.thinking", {}) or {})
        self._gate_lock = threading.RLock()
        rpm = contract.get("limits.max_dispatches_per_minute")
        self.rate_limiter = RateLimiter(int(rpm), sleep_fn=sleep_fn) if rpm else None

        self._dispatch_counts: Dict[str, int] = {}
        self._sequences: Dict[str, int] = {}
        self.records: List[DispatchRecord] = []
        self.blocked_events: List[Dict[str, Any]] = []
        self.last_block: Optional[str] = None

    # ------------------------------------------------------------------ 查询
    def dispatches(self, run_id: str) -> int:
        return self._dispatch_counts.get(run_id, 0)

    def remaining(self, run_id: str) -> int:
        return max(0, int(self.contract.dispatch_cap) - self.dispatches(run_id))

    def reset_trajectory(self, run_id: str) -> None:
        """每轨迹开始时调用；不跨轨迹共享任何状态。"""
        self._dispatch_counts.setdefault(run_id, 0)
        self._sequences.setdefault(run_id, 0)

    def seed_dispatch_count(self, run_id: str, count: int) -> None:
        """恢复时从 journal 重放已派发次数（保证 8 次门不被重置）。"""
        self._dispatch_counts[run_id] = int(count)
        self._sequences[run_id] = int(count)

    # ------------------------------------------------------------------ 主入口
    def dispatch(self, *, run_id: str, phase: str, purpose: str,
                 messages: List[Dict[str, str]], max_tokens: int,
                 extra: Optional[Dict[str, Any]] = None) -> DispatchRecord:
        # ── 原子门区：检查 + 预留 + 落盘 + 计数全部在同一把锁内 ──
        # 并发下若把 check 与 reserve 分开，两个线程会同时通过检查导致超卖。
        with self._gate_lock:
            if self.ledger.state().unresolved_count:
                raise ReconciliationRequired("有未决请求，已停止新派发，先完成对账")
            cap = int(self.contract.dispatch_cap)
            used = self.dispatches(run_id)
            if used + 1 > cap:
                self.last_block = "dispatch_cap"
                raise DispatchLimitReached(
                    f"{run_id} 已派发 {used} 次，达到每轨迹上限 {cap}")

            seq = self._sequences.get(run_id, 0) + 1
            self._sequences[run_id] = seq
            request_id = f"{run_id}#d{seq}"
            max_tokens = min(int(max_tokens), self.output_ceiling)

            text = "\n".join(f"[{m.get('role','')}]{m.get('content','')}" for m in messages)
            input_upper = estimate_input_tokens_upper(text, self.input_bound_method)

            decision = self.ledger.check(request_id=request_id, run_id=run_id, phase=phase,
                                         purpose=purpose, input_tokens_upper=input_upper,
                                         output_tokens_upper=max_tokens)
            if not decision.allowed:
                self.last_block = decision.reason
                ev = {
                    "run_id": run_id, "phase": phase, "request_id": request_id,
                    "purpose": purpose, "reason": decision.reason,
                    "bound_micro": decision.bound_micro,
                    "input_tokens_upper": input_upper,
                    "output_tokens_upper": max_tokens,
                    "dispatched": False,
                    "ledger": decision.state,
                }
                self.journal.append("budget_blocked", **ev)
                self.blocked_events.append(ev)
                raise BudgetBlocked(
                    f"预算拒绝（{decision.reason}）：{request_id}", state=decision.state)

            reservation = self.ledger.reserve(request_id=request_id, run_id=run_id,
                                              phase=phase, purpose=purpose,
                                              input_tokens_upper=input_upper,
                                              output_tokens_upper=max_tokens)
            self.journal.append("reservation_created", run_id=run_id, phase=phase,
                                request_id=request_id, purpose=purpose,
                                bound_micro=reservation.bound_micro,
                                input_tokens_upper=input_upper,
                                output_tokens_upper=max_tokens)

            request_extra = dict(extra or {})
            if self.thinking.get("enabled") is not None:
                request_extra["thinking"] = {"type": "enabled" if self.thinking["enabled"] else "disabled"}
            if self.thinking.get("reasoning_effort"):
                request_extra["reasoning_effort"] = self.thinking["reasoning_effort"]
            request_receipt = {"messages": list(messages), "max_tokens": max_tokens,
                               "sampling": dict(self.sampling), "extra": request_extra,
                               "model": self.contract.get("provider.model_id")}
            import hashlib, json
            from .providers import _redact
            request_receipt = _redact(request_receipt)
            receipt_hash = hashlib.sha256(json.dumps(request_receipt, sort_keys=True,
                ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()
            self.journal.append("dispatch_intent_durable", run_id=run_id, phase=phase,
                                request_id=request_id, purpose=purpose,
                                bound_micro=reservation.bound_micro,
                                request=request_receipt, request_sha256=receipt_hash)

            self._dispatch_counts[run_id] = used + 1

        request_extra = dict(extra or {})
        if self.thinking.get("enabled") is not None:
            request_extra["thinking"] = {
                "type": "enabled" if self.thinking["enabled"] else "disabled"}
        if self.thinking.get("reasoning_effort"):
            request_extra["reasoning_effort"] = self.thinking["reasoning_effort"]
        request = ChatRequest(request_id=request_id, run_id=run_id, phase=phase,
                              purpose=purpose, messages=list(messages),
                              max_tokens=max_tokens, sampling=dict(self.sampling),
                              extra=request_extra)

        rec = DispatchRecord(request_id=request_id, run_id=run_id, phase=phase,
                             purpose=purpose, index=seq, dispatched=True,
                             settled="pending", bound_micro=reservation.bound_micro,
                             messages=list(messages))

        if self.rate_limiter is not None:
            self.rate_limiter.acquire()  # 锁外等待，不阻塞其它轨迹的记账
        try:
            resp: ProviderResponse = self.provider.call(request)
        except TransportError as exc:
            return self._on_failure(rec, exc, phase=phase, purpose=purpose)
        except Exception as exc:  # noqa: BLE001 - 未知异常按"可能已计费"处理
            return self._on_failure(
                rec, TransportError(str(exc), may_have_billed=True),
                phase=phase, purpose=purpose)

        rec.content = resp.content
        rec.finish_reason = resp.finish_reason
        rec.model_reported = resp.model_reported
        rec.prompt_tokens = resp.prompt_tokens
        rec.completion_tokens = resp.completion_tokens
        rec.usage_missing_reason = resp.usage_missing_reason
        rec.latency_ms = resp.latency_ms
        rec.envelope = resp.as_dict()["envelope"]

        self.journal.append(
            "response_received", run_id=run_id, phase=phase,
            request_id=request_id, purpose=purpose,
            finish_reason=resp.finish_reason,
            model_reported=resp.model_reported,
            prompt_tokens=resp.prompt_tokens,
            completion_tokens=resp.completion_tokens,
            usage_missing_reason=resp.usage_missing_reason,
            latency_ms=round(resp.latency_ms, 3),
            partial=resp.partial,
            content=resp.content,
            envelope=rec.envelope)

        if not resp.usage_complete:
            outcome = self.ledger.settle(request_id=request_id, prompt_tokens=None,
                                         completion_tokens=None)
            rec.settled = "reconciliation_required"
            rec.ledger_outcome = outcome
            self.journal.append(
                "reconciliation_required", run_id=run_id, phase=phase,
                request_id=request_id, purpose=purpose,
                reason=resp.usage_missing_reason or "usage_missing",
                exposure_micro=reservation.bound_micro,
                content=resp.content)
            self.records.append(rec)
            return rec

        outcome = self.ledger.settle(request_id=request_id,
                                     prompt_tokens=resp.prompt_tokens,
                                     completion_tokens=resp.completion_tokens)
        rec.ledger_outcome = outcome
        if outcome == "settled":
            rec.settled = "settled"
            rec.actual_micro = (
                _cost(resp.prompt_tokens, self.ledger.price_in)
                + _cost(resp.completion_tokens, self.ledger.price_out))
            self.journal.append(
                "usage_settled", run_id=run_id, phase=phase,
                request_id=request_id, purpose=purpose,
                prompt_tokens=resp.prompt_tokens,
                completion_tokens=resp.completion_tokens,
                actual_micro=rec.actual_micro)
        else:  # unresolved_overrun
            rec.settled = "reconciliation_required"
            self.journal.append(
                "reconciliation_required", run_id=run_id, phase=phase,
                request_id=request_id, purpose=purpose,
                reason="actual_exceeded_reservation",
                exposure_micro=reservation.bound_micro,
                prompt_tokens=resp.prompt_tokens,
                completion_tokens=resp.completion_tokens,
                content=resp.content)
        self.records.append(rec)
        return rec

    # ------------------------------------------------------------------ 失败路径
    def _on_failure(self, rec: DispatchRecord, exc: TransportError, *,
                    phase: str, purpose: str) -> DispatchRecord:
        rec.settled = "failed"
        rec.error = f"{type(exc).__name__}: {exc}"
        from .providers import _redact
        rec.envelope = _redact(exc.envelope or {})
        self.journal.append("failed", run_id=rec.run_id, phase=phase,
                            request_id=rec.request_id, purpose=purpose,
                            error=rec.error,
                            status_code=exc.status_code,
                            may_have_billed=exc.may_have_billed,
                            partial_response=rec.envelope)
        if exc.may_have_billed:
            self.ledger.settle(request_id=rec.request_id, prompt_tokens=None,
                               completion_tokens=None)
            rec.settled = "reconciliation_required"
            self.journal.append(
                "reconciliation_required", run_id=rec.run_id, phase=phase,
                request_id=rec.request_id, purpose=purpose,
                reason="dispatch_outcome_unknown",
                exposure_micro=rec.bound_micro,
                error=rec.error)
        else:
            self.ledger.release(rec.request_id)
            rec.settled = "released"
            self.journal.append("reservation_released", run_id=rec.run_id,
                                phase=phase, request_id=rec.request_id,
                                purpose=purpose, reason="not_billed")
        self.records.append(rec)
        return rec


def _cost(tokens: Optional[int], price: int) -> int:
    if not tokens or not price:
        return 0
    return -((-int(tokens) * int(price)) // 1_000_000)


# ---------------------------------------------------------------- 旧 Agent 桥
class LegacyBridgeClient:
    """把旧 Agent 的 `client.chat(...)` 接到 dispatcher。

    旧接口签名（`llm_proxy/client.py`）：
        chat(messages, purpose=..., max_tokens=..., decoding_override=..., repeat_id=...)
    旧 Agent 还会读 `client.meter`、`client.failed_attempts`、`client.call_audit`、
    `client.repeat_id`、`client.model`、`client.max_request_attempts`。

    本桥**只**允许安全差异：
      * `decoding_override` 里的 temperature/top_p/seed 一律忽略（采样由封存合同决定），
        并在首次出现时记录 `override_ignored`，防止策略侧偷偷改成更有利的采样；
      * `max_tokens` 只能**更小**（取 min），不能突破单次输出上限；
      * `purpose` 必填且必须在登记集合内。
    """

    ALLOWED_PURPOSES = ("judge", "plan", "solve", "reflect", "replan",
                        "baseline_solve", "tool")

    def __init__(self, dispatcher: Dispatcher, *, role_limits: Dict[str, int],
                 model_name: str) -> None:
        self.dispatcher = dispatcher
        self.role_limits = dict(role_limits)
        self.model = model_name
        self.repeat_id = ""
        self.failed_attempts: List[Dict[str, Any]] = []
        self.call_audit: List[Dict[str, Any]] = []
        self.override_violations: List[Dict[str, Any]] = []
        self._purpose_stack: List[str] = []
        # 旧 Agent 会调用 `client.meter.summary()` / `.n_calls` / `.total_tokens`
        self.meter = BridgeMeter(self)
        self.max_request_attempts = None
        self._run_id: Optional[str] = None
        self._phase: Optional[str] = None
        self._current_purpose: str = "solve"

    # ------------------------------------------------------------------ 上下文
    def bind(self, *, run_id: str, phase: str) -> None:
        self._run_id = run_id
        self._phase = phase

    # ------------------------------------------------------------------ 旧接口
    def chat(self, messages: List[Dict[str, str]], purpose: str = "solve",
             max_tokens: Optional[int] = None,
             decoding_override: Optional[Dict[str, Any]] = None,
             repeat_id: Optional[str] = None):
        if self._run_id is None or self._phase is None:
            raise RuntimeError("LegacyBridgeClient 未绑定轨迹上下文")
        if purpose not in self.ALLOWED_PURPOSES:
            raise ValueError(f"未登记的 purpose: {purpose!r}")
        if decoding_override:
            self.override_violations.append({
                "purpose": purpose,
                "keys": sorted(decoding_override),
                "reason": "sampling_is_fixed_by_sealed_contract",
            })
        limit = min(int(max_tokens or self.role_limits.get(purpose,
                                                           self.role_limits["default"])),
                    int(self.role_limits.get(purpose, self.role_limits["default"])),
                    self.dispatcher.output_ceiling)
        rec = self.dispatcher.dispatch(run_id=self._run_id, phase=self._phase,
                                       purpose=purpose, messages=messages,
                                       max_tokens=limit,
                                       extra={"repeat_id": repeat_id or self.repeat_id})
        self.call_audit.append({
            "purpose": purpose,
            "request_id": rec.request_id,
            "finish_reason": rec.finish_reason,
            "model_reported": rec.model_reported,
            "prompt_tokens": rec.prompt_tokens,
            "completion_tokens": rec.completion_tokens,
            "usage_missing_reason": rec.usage_missing_reason,
            "settled": rec.settled,
            "error": rec.error,
        })
        if rec.error is not None:
            self.failed_attempts.append({
                "purpose": purpose,
                "request_id": rec.request_id,
                "error": rec.error,
                "may_have_billed": rec.settled == "reconciliation_required",
            })
            raise BridgeTransportFailure(rec.error)
        return BridgeReply(content=rec.content,
                           prompt_tokens=rec.prompt_tokens or 0,
                           completion_tokens=rec.completion_tokens or 0,
                           latency_ms=rec.latency_ms,
                           cached=False,
                           model=rec.model_reported or self.model,
                           finish_reason=rec.finish_reason)


class BridgeTransportFailure(RuntimeError):
    """桥接到 transport 失败；旧 Agent 的 try/except 会照常处理。"""


@dataclass
class BridgeReply:
    """与旧 `LLMReply` 字段对齐（旧 Agent 只读这些）。"""

    content: str
    prompt_tokens: int
    completion_tokens: int
    latency_ms: float
    cached: bool
    model: str
    finish_reason: str = "stop"


class BridgeMeter:
    """把 dispatcher 的派发记录投影成旧 `UsageMeter` 的只读视图。

    只提供旧 Agent 实际用到的属性：`n_calls`、`total_tokens`、`records`、
    `prompt_tokens`、`completion_tokens`、`summary()`。
    """

    def __init__(self, bridge: LegacyBridgeClient) -> None:
        self._bridge = bridge
        self.model = bridge.model

    def _recs(self) -> List[DispatchRecord]:
        rid = self._bridge._run_id
        return [r for r in self._bridge.dispatcher.records if r.run_id == rid]

    @property
    def n_calls(self) -> int:
        return sum(1 for r in self._recs() if r.error is None)

    @property
    def n_uncached_calls(self) -> int:
        return self.n_calls

    @property
    def prompt_tokens(self) -> int:
        return sum(int(r.prompt_tokens or 0) for r in self._recs())

    @property
    def completion_tokens(self) -> int:
        return sum(int(r.completion_tokens or 0) for r in self._recs())

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens

    @property
    def total_latency_ms(self) -> float:
        return sum(r.latency_ms for r in self._recs())

    @property
    def total_cost_cny(self) -> float:
        micro = sum(r.actual_micro for r in self._recs())
        return micro / 1_000_000

    @property
    def total_cost_usd(self) -> float:
        return 0.0  # 本项目只做 CNY；保留字段以兼容旧调用点

    @property
    def records(self) -> List[Any]:
        return self._recs()

    def calls_by_purpose(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for r in self._recs():
            out[r.purpose] = out.get(r.purpose, 0) + 1
        return out

    def summary(self) -> Dict[str, Any]:
        return {
            "model": self.model,
            "n_calls": self.n_calls,
            "n_uncached_calls": self.n_uncached_calls,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
            "total_latency_ms": round(self.total_latency_ms, 3),
            "total_cost_usd": 0.0,
            "total_cost_cny": round(self.total_cost_cny, 6),
            "calls_by_purpose": self.calls_by_purpose(),
        }
