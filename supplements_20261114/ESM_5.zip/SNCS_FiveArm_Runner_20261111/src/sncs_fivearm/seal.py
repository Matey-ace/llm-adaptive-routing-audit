"""指纹封存：把"这一次要跑的东西是什么"固化成一份可核对的快照。

`seal` **不**表示支出批准。它只回答：

* 合同草案的字节哈希；
* 输入（清单 / 题库 / 队列）的字节哈希；
* 执行器源码与封存旧源码的哈希；
* router artifact 的哈希；
* 评分与分析计划的版本号。

真实执行前，这些值会写进 run 元信息；恢复时逐项核对。
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import RUNNER_ID, __version__
from .contracts import Contract, draft_contract, sha256_json
from .evaluation import ANALYSIS_PLAN_VERSION, SCORE_SCHEMA_VERSION
from .inputs import LOCKED_SHA256, sha256_file
from .runtime import legacy_fingerprints

FROZEN_ROUTER_SHA256 = (
    "3178631cb9426c1620b608eadff1b5109e24184c9954836e1af15ae0641573ea")


def _code_hashes(package_root: Path) -> Dict[str, str]:
    out = {}
    for p in sorted(package_root.rglob("*.py")):
        if "__pycache__" in p.parts or "legacy_root" in p.parts:
            continue
        out[str(p.relative_to(package_root)).replace("\\", "/")] = sha256_file(p)
    return out


def seal_snapshot(*, contract_path: Optional[Path], runner_root: Path,
                  prep_dir: Path, out_path: Optional[Path] = None) -> Dict[str, Any]:
    package_root = runner_root / "src" / "sncs_fivearm"
    workspace = runner_root.parent

    if contract_path is not None and contract_path.is_file():
        contract = Contract.load(contract_path, approvals_dir=runner_root / "configs" / "approvals")
        contract_block = {
            "path": str(contract_path),
            "sha256": contract.sha256,
            "mode": contract.mode,
            "approved": contract.approved,
            "problems": list(contract.problems),
        }
    else:
        draft = draft_contract()
        contract_block = {
            "path": None,
            "sha256": sha256_json(draft),
            "mode": "draft",
            "approved": False,
            "problems": ["未提供合同文件；此块仅为草案模板的哈希"],
        }

    inputs_block: Dict[str, Any] = {}
    problems: List[str] = []
    for rel, expected in LOCKED_SHA256.items():
        p = prep_dir / rel
        if not p.is_file():
            problems.append(f"缺失输入 {rel}")
            inputs_block[rel] = {"exists": False, "expected": expected}
            continue
        actual = sha256_file(p)
        inputs_block[rel] = {"exists": True, "sha256": actual, "expected": expected,
                             "match": actual == expected, "bytes": p.stat().st_size}
        if actual != expected:
            problems.append(f"{rel} 哈希不符")

    router_path = workspace / "results" / "complexity" / "router_candidate_s5_20261014.json"
    router_block: Dict[str, Any] = {"path": str(router_path)}
    if router_path.is_file():
        sha = sha256_file(router_path)
        router_block.update({"sha256": sha, "expected": FROZEN_ROUTER_SHA256,
                             "match": sha == FROZEN_ROUTER_SHA256})
        if sha != FROZEN_ROUTER_SHA256:
            problems.append("router artifact 哈希不符")
    else:
        problems.append("router artifact 缺失")
        router_block["exists"] = False

    legacy = legacy_fingerprints()
    manifest_file = runner_root / "evidence" / "legacy_copy_manifest.json"
    legacy_block: Dict[str, Any] = {"files": len(legacy)}
    if manifest_file.is_file():
        man = json.loads(manifest_file.read_text(encoding="utf-8"))
        mismatch = [m["local"] for m in man
                    if legacy.get(str(m["local"]).replace("\\", "/")) != m["sha256"]]
        legacy_block["manifest_match"] = not mismatch
        legacy_block["mismatch_sample"] = mismatch[:5]
        if mismatch:
            problems.append(f"封存旧源码被改动：{mismatch[:3]}")

    payload = {
        "runner_id": RUNNER_ID,
        "runner_version": __version__,
        "sealed_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "purpose": "fingerprint_seal_only_not_spending_approval",
        "contract": contract_block,
        "inputs": inputs_block,
        "router_artifact": router_block,
        "legacy_sources": legacy_block,
        "executor_code": _code_hashes(package_root),
        "evaluation_versions": {
            "score_schema_version": SCORE_SCHEMA_VERSION,
            "analysis_plan_version": ANALYSIS_PLAN_VERSION,
        },
        "problems": problems,
        "status": "SEALED_CONSISTENT" if not problems else "SEALED_WITH_PROBLEMS",
        "approval_note": ("本封存不代表任何支出批准。真实派发还需要 "
                          "configs/approvals/<ref>.json 中 recorded_by=author 的人工记录。"),
    }
    payload["self_sha256"] = hashlib.sha256(
        json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()

    target = out_path or (runner_root / "evidence" / "seal_snapshot.json")
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(".json.pending")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(target)
    return {"status": payload["status"], "problems": problems,
            "path": str(target), "self_sha256": payload["self_sha256"],
            "contract_mode": contract_block["mode"],
            "inputs_checked": len(inputs_block)}
