"""执行合同：读取、校验、批准门。

结构性规则（不可由代码自行放宽）：

1. **批准只能来自人工记录**。合同的 `approval.approved` 只有在
   `configs/approvals/<id>.json` 存在、且该文件 `recorded_by == "author"`、
   带非空 `quote`（用户原话）与具体金额/模型/范围时才算成立。
   执行器从不写 approvals 目录，测试也只写临时目录，因此"agent 把 false 改成 true"
   在结构上无法通过校验。
2. **未批准的合同不派发**。`live_readiness()` 返回缺失项清单，`run` 命令在
   派发前打印该清单并退出，不构造任何 live client。
3. **离线模拟合同与真实合同分离**。`execution_mode` 只有两个取值；
   `offline_simulation` 不读取凭证、不联网，其"批准"字段是模拟开关而非支出授权。
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .errors import ContractNotApproved

SCHEMA_VERSION = "sncs-fivearm-contract-v1"
STUDY_ID = "sncs_fivearm_pilot_20261111"

MODES = ("live", "local_gateway", "offline_simulation")

# 真实派发必须具备的字段路径（缺一即视为不可运行）。
REQUIRED_LIVE_PATHS: Tuple[str, ...] = (
    "provider.name",
    "provider.base_url",
    "provider.model_id",
    "provider.api_key_env",
    "provider.sampling.temperature_or_omitted_reason",
    "provider.timeout_seconds",
    "limits.per_call_output_token_ceiling",
    "limits.per_trajectory_dispatch_cap",
    "limits.input_token_upper_bound_method",
    "tariff.currency",
    "tariff.input_uncached_micro_per_million",
    "tariff.output_micro_per_million",
    "tariff.source.url",
    "tariff.source.checked_utc",
    "budget.total_micro",
    "budget.preflight_micro",
    "budget.main_micro",
)

# 允许作为"输入 token 上界"的方法。其余取值一律视为无可解释上界。
ALLOWED_INPUT_BOUND_METHODS = (
    "utf8_byte_upper_bound_v1",
    "provider_tokenizer_exact_v1",
)


def _dig(data: Any, path: str) -> Any:
    cur = data
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def canonical_json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_json(data: Any) -> str:
    return hashlib.sha256(canonical_json(data).encode("utf-8")).hexdigest()


@dataclass
class ApprovalRecord:
    """人工批准记录（只读自 configs/approvals/*.json）。"""

    approval_id: str
    recorded_by: str
    approved: bool
    quote: str
    approved_utc: Optional[str]
    model_id: Optional[str]
    currency: Optional[str]
    total_micro: Optional[int]
    phases: Tuple[str, ...]
    approval_reference: str

    @property
    def is_human(self) -> bool:
        return self.recorded_by == "author" and bool(self.quote.strip())


class ContractError(ContractNotApproved):
    pass


@dataclass
class Contract:
    """已加载并校验过的合同。"""

    path: Path
    raw: Dict[str, Any]
    sha256: str
    approval: Optional[ApprovalRecord] = None
    problems: List[str] = field(default_factory=list)

    # ------------------------------------------------------------------ 读取
    @classmethod
    def load(cls, path: Path | str, approvals_dir: Path | str | None = None) -> "Contract":
        p = Path(path)
        if not p.is_file():
            raise ContractError(f"合同文件不存在: {p}")
        raw_bytes = p.read_bytes()
        try:
            raw = json.loads(raw_bytes.decode("utf-8-sig"))
        except json.JSONDecodeError as exc:
            raise ContractError(f"合同不是合法 JSON: {exc}") from exc
        sha = hashlib.sha256(raw_bytes).hexdigest()
        obj = cls(path=p, raw=raw, sha256=sha)
        obj._validate_shape()
        if approvals_dir is not None:
            obj.approval = _resolve_approval(raw, Path(approvals_dir))
        obj.problems = obj._collect_problems()
        return obj

    # ------------------------------------------------------------------ 形状
    def _validate_shape(self) -> None:
        r = self.raw
        if r.get("schema_version") != SCHEMA_VERSION:
            raise ContractError(
                f"合同 schema 版本不符：{r.get('schema_version')!r} != {SCHEMA_VERSION!r}")
        if r.get("study_id") != STUDY_ID:
            raise ContractError("study_id 不符；不继承任何旧研究或旧授权")
        if r.get("execution_mode") not in MODES:
            raise ContractError(f"execution_mode 必须是 {MODES} 之一")
        if r.get("inherit_prior_authorizations") is not False:
            raise ContractError("inherit_prior_authorizations 必须为 false")
        for key in ("provider", "limits", "tariff", "budget", "approval"):
            if key not in r:
                raise ContractError(f"合同缺少顶层字段 {key}")

    # ------------------------------------------------------------------ 判定
    def _collect_problems(self) -> List[str]:
        problems: List[str] = []
        r = self.raw
        if self.mode in ("live", "local_gateway"):
            for path in REQUIRED_LIVE_PATHS:
                if _dig(r, path) in (None, "", {}):
                    problems.append(f"缺少 {path}")
            method = _dig(r, "limits.input_token_upper_bound_method")
            if method not in ALLOWED_INPUT_BOUND_METHODS:
                problems.append(
                    f"输入 token 上界方法 {method!r} 不在允许列表 {ALLOWED_INPUT_BOUND_METHODS}")
            if _dig(r, "tariff.currency") not in (None, "CNY"):
                problems.append("tariff.currency 必须为 CNY（不做隐式汇率换算）")
            if _dig(r, "budget.currency") not in (None, "CNY"):
                problems.append("budget.currency 必须为 CNY")
            if self.mode == "local_gateway":
                problems.extend(self._local_gateway_problems())
            elif not self.approval or not self.approval.is_human or not self.approval.approved:
                problems.append("没有可核验的人工批准记录（configs/approvals/*.json，recorded_by=author）")
            elif self.approval.approved:
                problems.extend(self._approval_consistency())
        return problems

    def _local_gateway_problems(self) -> List[str]:
        """本机网关：只允许 127.0.0.1/localhost；不把它冒充外部付费服务。"""
        out: List[str] = []
        base = str(_dig(self.raw, "provider.base_url") or "")
        if not (base.startswith("http://127.0.0.1") or base.startswith("http://localhost")):
            out.append("local_gateway 的 base_url 必须指向 127.0.0.1 或 localhost")
        auth = _dig(self.raw, "local_gateway_authorization") or {}
        if not str(auth.get("quote") or "").strip():
            out.append("缺少 local_gateway_authorization.quote（作者原话）")
        if auth.get("external_billing") is not False:
            out.append("local_gateway_authorization.external_billing 必须为 false")
        if auth.get("phase_scope") != list(_dig(self.raw, "phase_scope") or []):
            out.append("local_gateway_authorization.phase_scope 必须与合同 phase_scope 一致")
        return out
        return problems

    def _approval_consistency(self) -> List[str]:
        out: List[str] = []
        a = self.approval
        assert a is not None
        if a.model_id and a.model_id != _dig(self.raw, "provider.model_id"):
            out.append(f"批准记录模型 {a.model_id} 与合同 model_id 不一致")
        total = _dig(self.raw, "budget.total_micro")
        if a.total_micro is not None and total is not None and a.total_micro != total:
            out.append(f"批准金额 {a.total_micro} 与合同总额 {total} 不一致")
        phases = set(_dig(self.raw, "phase_scope") or [])
        if a.phases and not set(a.phases) <= phases:
            out.append(f"批准阶段 {sorted(a.phases)} 不在合同 phase_scope {sorted(phases)} 内")
        return out

    # ------------------------------------------------------------------ 属性
    @property
    def mode(self) -> str:
        return str(self.raw.get("execution_mode"))

    @property
    def approved(self) -> bool:
        return bool(self.approval and self.approval.is_human and self.approval.approved)

    @property
    def live_ready(self) -> bool:
        """是否可真实执行。

        * offline_simulation：永远可跑（不联网）；
        * local_gateway：靠 `local_gateway_authorization`（作者指定入口，非外部付费），
          问题清单为空即可跑，**不需要** approval.approved；
        * live：必须有人工支出批准记录且问题清单为空。
        """
        if self.mode == "offline_simulation":
            return True
        if self.mode == "local_gateway":
            return not self.problems
        return bool(self.approved and not self.problems)

    @property
    def is_billable_external(self) -> bool:
        """是否外部付费执行。local_gateway 只连本机服务，不按外部付费处理。"""
        return self.mode == "live"

    @property
    def paid_cost_reported(self) -> bool:
        """是否可以报告真实费用。local_gateway 无服务方计费接口，费用不可核实。"""
        return self.mode == "live"

    def require_live_ready(self) -> None:
        if self.live_ready:
            return
        if self.problems:
            detail = "\n".join(f"  - {p}" for p in self.problems)
            raise ContractNotApproved(
                f"合同未具备真实执行条件（{self.path}）：\n{detail}\n"
                "离线开发与模拟可继续；真实派发需要人工批准记录。")
        # problems 为空但未通过：说明缺口在批准状态本身
        reason = ("合同未获人工支出批准（approval.approved 必须为 true 且存在 "
                  "configs/approvals/<ref>.json）" if self.mode == "live"
                  else "合同未获批准")
        raise ContractNotApproved(
            f"合同未具备真实执行条件（{self.path}）：\n  - {reason}\n"
            "离线开发与模拟可继续；真实派发需要人工批准记录。")

    # ------------------------------------------------------------------ 取数
    def get(self, path: str, default: Any = None) -> Any:
        v = _dig(self.raw, path)
        return default if v is None else v

    @property
    def dispatch_cap(self) -> int:
        return int(self.get("limits.per_trajectory_dispatch_cap", 8))

    @property
    def output_ceiling(self) -> int:
        return int(self.get("limits.per_call_output_token_ceiling", 16384))

    def role_limit(self, purpose: str) -> int:
        limits = self.get("limits.role_output_limits", {}) or {}
        return int(limits.get(purpose, limits.get("default", 4096)))

    @property
    def input_bound_method(self) -> str:
        return str(self.get("limits.input_token_upper_bound_method",
                            "utf8_byte_upper_bound_v1"))

    def phase_cap_micro(self, phase: str) -> int:
        return int(self.get(f"budget.{phase}_micro", 0) or 0)

    @property
    def total_cap_micro(self) -> int:
        return int(self.get("budget.total_micro", 0) or 0)

    def price_in_micro(self) -> int:
        return int(self.get("tariff.input_uncached_micro_per_million", 0) or 0)

    def price_out_micro(self) -> int:
        return int(self.get("tariff.output_micro_per_million", 0) or 0)

    def sampling(self) -> Dict[str, Any]:
        s = dict(self.get("provider.sampling", {}) or {})
        s.pop("temperature_or_omitted_reason", None)
        return s

    # ------------------------------------------------------------------ 指纹
    def fingerprint(self) -> Dict[str, Any]:
        return {
            "path": str(self.path),
            "sha256": self.sha256,
            "mode": self.mode,
            "approved": self.approved,
            "problems": list(self.problems),
        }


def _resolve_approval(raw: Dict[str, Any], approvals_dir: Path) -> Optional[ApprovalRecord]:
    """按 approval.approval_reference 找人工批准文件。

    找不到就返回 None —— 也就是"未批准"，而不是伪造一个已批准对象。
    """
    ref = _dig(raw, "approval.approval_reference")
    if not ref:
        return None
    candidate = approvals_dir / f"{ref}.json"
    if not candidate.is_file():
        return None
    try:
        data = json.loads(candidate.read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError:
        return None
    money = data.get("total_micro")
    return ApprovalRecord(
        approval_id=str(data.get("approval_id", ref)),
        recorded_by=str(data.get("recorded_by", "")),
        approved=bool(data.get("approved", False)),
        quote=str(data.get("quote", "")),
        approved_utc=data.get("approved_utc"),
        model_id=data.get("model_id"),
        currency=data.get("currency"),
        total_micro=int(money) if isinstance(money, int) else None,
        phases=tuple(data.get("phases") or ()),
        approval_reference=ref,
    )


def draft_contract(template: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """生成一份**全部待填**的合同草案（不复制任何旧的启用值）。"""
    base: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "study_id": STUDY_ID,
        "status": "DRAFT_PENDING_MODEL_AND_BUDGET_DECISION",
        "execution_mode": "live",
        "model_clarification": {
            "author_quote": "BigChat 是笔误，指 dsv4-flash",
            "service_family": "DeepSeek V4 Flash",
            "alias_map_ref": "configs/model_alias_clarification.json",
            "note": "语义消歧，不是模型选定、不是支出批准；端点/请求字符串/价格/额度仍待填",
        },
        "inherit_prior_authorizations": False,
        "credentials": None,
        "phase_scope": ["preflight"],
        "provider": {
            "name": None,
            "base_url": None,
            "model_id": None,
            "api_key_env": None,
            "service_region": None,
            "reported_release": None,
            "thinking": {"enabled": None, "reasoning_effort": None},
            "sampling": {
                "temperature": None,
                "top_p": None,
                "seed": None,
                "temperature_or_omitted_reason": None,
            },
            "sdk_retries": 0,
            "timeout_seconds": None,
            "stream": False,
            "response_cache_enabled": False,
        },
        "limits": {
            "per_call_output_token_ceiling": 16384,
            "per_trajectory_dispatch_cap": 8,
            "role_output_limits": {
                "default": 4096,
                "judge": 4096,
                "plan": 4096,
                "solve": 4096,
                "reflect": 4096,
                "replan": 4096,
                "baseline_solve": 4096,
            },
            "input_token_upper_bound_method": None,
            "trajectory_workers": 1,
            "max_dispatches_per_minute": None,
        },
        "tariff": {
            "currency": None,
            "unit": "micro_CNY_per_million_tokens",
            "input_uncached_micro_per_million": None,
            "output_micro_per_million": None,
            "cached_input_micro_per_million": None,
            "reasoning_counting": "included_in_completion_single_count",
            "source": {"url": None, "checked_utc": None, "sha256": None},
            "effective_window_utc": [None, None],
        },
        "budget": {
            "currency": "CNY",
            "total_micro": None,
            "preflight_micro": None,
            "main_micro": None,
            "unknown_usage_policy": "retain_full_reservation_as_unresolved_exposure",
            "stop_before_dispatch_when_insufficient": True,
            "topup_without_approval": False,
        },
        "approval": {
            "approved": False,
            "approval_reference": None,
            "approved_utc": None,
        },
        "seals": {},
        "decisions_pending": [
            "端点：官方 https://api.deepseek.com 还是本机网关 http://127.0.0.1:8787（BigChat 已澄清为 dsv4-flash，服务家族定为 DeepSeek V4 Flash）",
            "请求中发送的 model_id 字符串（建议 deepseek-flash；dsv4-flash/deepseek-v4-flash 是别名）",
            "thinking / reasoning_effort 与采样参数是否有效（开跑前重新核验）",
            "官方价目与币种（CNY，micro 单位）+ 来源 URL + 核对时间",
            "预检与总额度（micro CNY）",
            "输入 token 上界方法的服务方依据",
            "未决费用与停止政策确认",
            "数据发送范围确认",
        ],
    }
    if template:
        merge_missing(base, template)
    return base


def merge_missing(target: Dict[str, Any], source: Dict[str, Any]) -> None:
    """只补齐 target 中缺失的键，不覆盖已有（含 None）值。"""
    for k, v in source.items():
        if k not in target:
            target[k] = v
        elif isinstance(target[k], dict) and isinstance(v, dict):
            merge_missing(target[k], v)
