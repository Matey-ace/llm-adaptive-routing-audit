"""输入锁定：题目清单、prompt-only 题库、平衡队列的只读加载与指纹核对。

结构性保证（对应交接计划工作包 A 验收）：

1. 生成路径只接受 `task_id / prompt / prompt_sha256` 三字段。
   任何行出现 `gold`、`answer`、`success`、`score`、`labels`、`reference_answer`
   → `ForbiddenFieldError`，不"过滤掉继续跑"。
2. 清单与队列必须是 metadata-only（不含 prompt 正文、不含 gold）。
3. 所有字节指纹以**实际文件字节**计算，并与交接包 `输入与证据索引.json` 中的锁定值比对；
   不一致即 `InputIntegrityError`，不降级为警告。
4. 本模块不导入 `evaluation.gold`，也不解析答案列；评分侧另行读取。
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from .errors import ForbiddenFieldError, InputIntegrityError

PROMPT_STORE_FIELDS = frozenset({"task_id", "prompt", "prompt_sha256"})
FORBIDDEN_FIELDS = frozenset({
    "gold", "answer", "answers", "success", "score", "scores", "labels",
    "reference_answer", "solution", "final_answer", "is_correct", "correctness",
})
MANIFEST_REQUIRED = frozenset({"task_id", "source", "split", "prompt_sha256", "sampling_stratum"})
ARMS: Tuple[str, ...] = ("direct", "planning", "plan_reflect",
                         "adaptive_legacy", "asc_beta_8")

# 交接包锁定的字节指纹（来自 SNCS_Agent_Handoff_20261111/输入与证据索引.json）
LOCKED_SHA256: Dict[str, str] = {
    "manifests_v2/main_tasks_400.json":
        "4f46265d27be58e7a38c14a35875b599b1d9357fd7487a41533c3a76f4214946",
    "manifests_v2/preflight_tasks_20.json":
        "862e5fb1fe800a7f09dbde0c0eaf062ea3c0a25b74e928ec2c420be8b7503d7b",
    "manifests_v2/calibration_tasks_100.json":
        "a47c7cc127b81bf6394956a6e86207840514ed3f00f3177ad2b54db18ae82e93",
    "manifests_v2/selected_tasks_all.json":
        "3043e3b56ad96d89e9da876a50ccb9e437e07404adbc93c1f626108cc11cfc44",
    "draft/generation_prompt_only_420.jsonl":
        "ba356e6510c65649ee66f0a9ce7c8aa7c408bc37c3b039fac00f1765a731a329",
    "draft/five_arm_queue_2100.jsonl":
        "16a64c21d5fa9e8675a65913411bbf4670193bdf980fc41103ca22f8a34ee6c9",
    "draft/main_five_arm_queue_2000.jsonl":
        "5f5455877caebd65a1cf4087741ede39f6d116ebc7bdf338f51290cd4fd98f9f",
    "draft/preflight_five_arm_queue_100.jsonl":
        "d013777ba004aca707cd7a4e41038f3a12da69f014c6ec20e22c6bd66f470df0",
    "draft/execution_contract_PENDING.json":
        "5cd6755bb10f4a1d5d830f66331ef92d29a8f99b756be74de2f8bf86e8e3f3c9",
}

# 只读来源（旧项目）。任何写操作都不得指向这些路径。
READ_ONLY_ROOTS: Tuple[str, ...] = (
    "agents", "complexity", "llm_proxy", "eval", "runner", "tasks", "results",
    "validation", "paper", "review", "analysis", "configs", "scripts", "figures",
    "release", "references", "logs", "local_models",
    "SNCS_Autonomous_Audit_20261109", "SNCS_Experiment_Preparation_20261110",
    "SNCS_Agent_Handoff_20261111", "IJMLC投稿专用_20261104", "IJMLC投稿专用_20261105_v5",
)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path | str) -> str:
    return sha256_bytes(Path(path).read_bytes())


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


@dataclass(frozen=True)
class TaskPrompt:
    """生成端可见的最小任务（三字段，无 gold）。"""

    task_id: str
    prompt: str
    prompt_sha256: str

    def as_agent_view_kwargs(self) -> Dict[str, object]:
        return {"task_id": self.task_id, "prompt": self.prompt}


@dataclass(frozen=True)
class QueueRow:
    """队列中的一条轨迹（metadata-only）。"""

    sequence: int
    block_number: int
    block_id: str
    run_id: str
    phase: str
    task_id: str
    source: str
    sampling_stratum: str
    prompt_sha256: str
    repeat_id: int
    strategy: str
    execution_position: int

    @classmethod
    def from_dict(cls, d: Dict[str, object]) -> "QueueRow":
        missing = {"sequence", "block_number", "block_id", "run_id", "phase", "task_id",
                   "source", "sampling_stratum", "prompt_sha256", "repeat_id",
                   "strategy", "execution_position"} - set(d)
        if missing:
            raise InputIntegrityError(f"队列行缺少字段: {sorted(missing)}")
        return cls(
            sequence=int(d["sequence"]),
            block_number=int(d["block_number"]),
            block_id=str(d["block_id"]),
            run_id=str(d["run_id"]),
            phase=str(d["phase"]),
            task_id=str(d["task_id"]),
            source=str(d["source"]),
            sampling_stratum=str(d["sampling_stratum"]),
            prompt_sha256=str(d["prompt_sha256"]),
            repeat_id=int(d["repeat_id"]),
            strategy=str(d["strategy"]),
            execution_position=int(d["execution_position"]),
        )


# ---------------------------------------------------------------- 读取 + 校验
def _assert_metadata_only(row: Dict[str, object], where: str) -> None:
    bad = FORBIDDEN_FIELDS.intersection(row)
    if bad:
        raise ForbiddenFieldError(f"{where} 出现评分/答案字段 {sorted(bad)}")
    if "prompt" in row:
        raise InputIntegrityError(f"{where} 含 prompt 正文；队列与清单必须 metadata-only")


def load_prompt_store(path: Path | str) -> Dict[str, TaskPrompt]:
    """读取 prompt-only 题库并逐行校验字段集合与哈希。

    校验项：
      * 字段集合严格等于 {task_id, prompt, prompt_sha256}
      * prompt 的 UTF-8 SHA-256 与自报值一致
      * task_id 唯一
    """
    p = Path(path)
    if not p.is_file():
        raise InputIntegrityError(f"题库不存在: {p}")
    out: Dict[str, TaskPrompt] = {}
    for lineno, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise InputIntegrityError(f"{p} 第 {lineno} 行非法 JSON: {exc}") from exc
        if not isinstance(row, dict):
            raise InputIntegrityError(f"{p} 第 {lineno} 行不是对象")
        extra = set(row) - PROMPT_STORE_FIELDS
        if extra:
            raise ForbiddenFieldError(f"{p} 第 {lineno} 行含未允许字段 {sorted(extra)}")
        if set(row) != PROMPT_STORE_FIELDS:
            raise InputIntegrityError(
                f"{p} 第 {lineno} 行字段不全：需要 {sorted(PROMPT_STORE_FIELDS)}")
        tid = str(row["task_id"])
        prompt = row["prompt"]
        digest = str(row["prompt_sha256"])
        if not isinstance(prompt, str):
            raise InputIntegrityError(f"{p} 第 {lineno} 行 prompt 不是字符串")
        actual = sha256_text(prompt)
        if actual != digest:
            raise InputIntegrityError(
                f"{p} 第 {lineno} 行 prompt 哈希不符：自报 {digest[:12]} 实际 {actual[:12]}")
        if tid in out:
            raise InputIntegrityError(f"{p} 第 {lineno} 行 task_id 重复: {tid}")
        out[tid] = TaskPrompt(task_id=tid, prompt=prompt, prompt_sha256=digest)
    if not out:
        raise InputIntegrityError(f"{p} 为空")
    return out


def load_manifest(path: Path | str, expected_phase: str | None = None
                  ) -> List[Dict[str, object]]:
    p = Path(path)
    if not p.is_file():
        raise InputIntegrityError(f"清单不存在: {p}")
    rows = json.loads(p.read_text(encoding="utf-8-sig"))
    if not isinstance(rows, list) or not rows:
        raise InputIntegrityError(f"{p} 不是非空数组")
    seen: set = set()
    for i, row in enumerate(rows):
        if not isinstance(row, dict):
            raise InputIntegrityError(f"{p} 第 {i} 项不是对象")
        _assert_metadata_only(row, f"{p}[{i}]")
        missing = MANIFEST_REQUIRED - set(row)
        if missing:
            raise InputIntegrityError(f"{p}[{i}] 缺少字段 {sorted(missing)}")
        tid = str(row["task_id"])
        if tid in seen:
            raise InputIntegrityError(f"{p} 重复 task_id: {tid}")
        seen.add(tid)
        if expected_phase and row.get("split") != expected_phase:
            raise InputIntegrityError(
                f"{p}[{i}] split={row.get('split')!r} 与阶段 {expected_phase!r} 不符")
        if row.get("source") not in ("gsm8k", "math"):
            raise InputIntegrityError(f"{p}[{i}] 未知 source: {row.get('source')!r}")
        digest = row["prompt_sha256"]
        if not isinstance(digest, str) or len(digest) != 64 or \
                any(c not in "0123456789abcdef" for c in digest):
            raise InputIntegrityError(f"{p}[{i}] prompt_sha256 非法")
    return rows


def load_queue(path: Path | str, phase: str | None = None) -> List[QueueRow]:
    p = Path(path)
    if not p.is_file():
        raise InputIntegrityError(f"队列不存在: {p}")
    rows: List[QueueRow] = []
    for lineno, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            raw = json.loads(line)
        except json.JSONDecodeError as exc:
            raise InputIntegrityError(f"{p} 第 {lineno} 行非法 JSON: {exc}") from exc
        _assert_metadata_only(raw, f"{p}[{lineno}]")
        row = QueueRow.from_dict(raw)
        if phase and row.phase != phase:
            raise InputIntegrityError(f"{p} 第 {lineno} 行 phase={row.phase} 与 {phase} 不符")
        rows.append(row)
    if not rows:
        raise InputIntegrityError(f"{p} 为空")
    run_ids = [r.run_id for r in rows]
    if len(set(run_ids)) != len(run_ids):
        raise InputIntegrityError(f"{p} run_id 重复")
    if [r.sequence for r in rows] != list(range(1, len(rows) + 1)):
        raise InputIntegrityError(f"{p} sequence 不是 1..N 连续")
    return rows


# ---------------------------------------------------------------- 一致性核验
@dataclass
class InputBundle:
    """一次运行所需的全部输入，已交叉核验。"""

    phase: str
    prompts: Dict[str, TaskPrompt]
    queue: List[QueueRow]
    manifest: List[Dict[str, object]]
    fingerprints: Dict[str, str]

    @property
    def task_ids_in_queue(self) -> List[str]:
        seen: List[str] = []
        known: set = set()
        for r in self.queue:
            if r.task_id not in known:
                known.add(r.task_id)
                seen.append(r.task_id)
        return seen

    def prompt_for(self, task_id: str) -> TaskPrompt:
        try:
            return self.prompts[task_id]
        except KeyError as exc:
            raise InputIntegrityError(f"题库中没有 {task_id}") from exc


def verify_arm_membership(queue: Sequence[QueueRow]) -> None:
    """每连续 5 行必须同题且恰好覆盖五个臂。"""
    if len(queue) % 5 != 0:
        raise InputIntegrityError("队列长度不是 5 的倍数")
    for off in range(0, len(queue), 5):
        block = queue[off:off + 5]
        if {r.strategy for r in block} != set(ARMS):
            raise InputIntegrityError(f"第 {off//5+1} 块不是五臂齐全：{[r.strategy for r in block]}")
        if len({r.task_id for r in block}) != 1:
            raise InputIntegrityError(f"第 {off//5+1} 块跨题")
        for pos, row in enumerate(block, 1):
            if row.execution_position != pos:
                raise InputIntegrityError(
                    f"{row.run_id} execution_position={row.execution_position} != {pos}")


def verify_queue_against_sources(queue: Sequence[QueueRow],
                                 prompts: Dict[str, TaskPrompt],
                                 manifest: Sequence[Dict[str, object]]) -> None:
    by_id = {str(m["task_id"]): m for m in manifest}
    for row in queue:
        if row.task_id not in by_id:
            raise InputIntegrityError(f"队列引用清单外任务: {row.task_id}")
        if row.task_id not in prompts:
            raise InputIntegrityError(f"队列引用题库外任务: {row.task_id}")
        if row.prompt_sha256 != prompts[row.task_id].prompt_sha256:
            raise InputIntegrityError(f"{row.run_id} prompt_sha256 与题库不一致")
        if row.prompt_sha256 != by_id[row.task_id]["prompt_sha256"]:
            raise InputIntegrityError(f"{row.run_id} prompt_sha256 与清单不一致")
        if row.source != by_id[row.task_id]["source"]:
            raise InputIntegrityError(f"{row.run_id} source 与清单不一致")


def verify_locked_fingerprints(prep_dir: Path | str,
                               keys: Iterable[str] | None = None) -> Dict[str, Dict[str, object]]:
    """逐个核对锁定指纹；返回明细，任一不符即抛错。"""
    base = Path(prep_dir)
    wanted = list(keys or LOCKED_SHA256.keys())
    report: Dict[str, Dict[str, object]] = {}
    problems: List[str] = []
    for rel in wanted:
        path = base / rel
        if not path.is_file():
            problems.append(f"缺失 {rel}")
            report[rel] = {"exists": False}
            continue
        actual = sha256_file(path)
        expected = LOCKED_SHA256.get(rel)
        ok = expected is None or actual == expected
        report[rel] = {"exists": True, "sha256": actual, "expected": expected,
                       "match": ok, "bytes": path.stat().st_size}
        if not ok:
            problems.append(f"{rel}: 实际 {actual[:12]} != 锁定 {str(expected)[:12]}")
    if problems:
        raise InputIntegrityError("输入指纹不符：\n  - " + "\n  - ".join(problems))
    return report


def build_bundle(*, phase: str, manifest_path: Path | str, prompt_store_path: Path | str,
                 queue_path: Path | str, prep_dir: Path | str,
                 verify_locks: bool = True) -> InputBundle:
    """组装并交叉核验一次运行的输入。"""
    fingerprints: Dict[str, str] = {}
    if verify_locks:
        for rel, info in verify_locked_fingerprints(prep_dir).items():
            if info.get("exists"):
                fingerprints[rel] = str(info["sha256"])
    prompts = load_prompt_store(prompt_store_path)
    manifest = load_manifest(manifest_path, expected_phase=phase)
    queue = load_queue(queue_path, phase=phase)
    verify_arm_membership(queue)
    verify_queue_against_sources(queue, prompts, manifest)

    expected_traj = 5 * len(manifest)
    if len(queue) != expected_traj:
        raise InputIntegrityError(
            f"队列轨迹数 {len(queue)} != 5×{len(manifest)}={expected_traj}")
    queued_tasks = {r.task_id for r in queue}
    if queued_tasks != {str(m["task_id"]) for m in manifest}:
        raise InputIntegrityError("队列题目集合与清单成员不一致")
    fingerprints[str(Path(manifest_path))] = sha256_file(manifest_path)
    fingerprints[str(Path(prompt_store_path))] = sha256_file(prompt_store_path)
    fingerprints[str(Path(queue_path))] = sha256_file(queue_path)
    return InputBundle(phase=phase, prompts=prompts, queue=queue,
                       manifest=manifest, fingerprints=fingerprints)


def build_merged_bundle(*, prep_dir: Path | str) -> InputBundle:
    """预检 + 主筛查合并（2100 轨迹），用于整体一致性核对。"""
    base = Path(prep_dir)
    merged_queue: List[QueueRow] = []
    for phase, qname in (("preflight", "preflight_five_arm_queue_100.jsonl"),
                         ("main", "main_five_arm_queue_2000.jsonl")):
        merged_queue.extend(load_queue(base / "draft" / qname, phase=phase))
    for idx, row in enumerate(merged_queue, 1):
        if row.sequence != idx:
            object.__setattr__(row, "sequence", idx)
    prompts = load_prompt_store(base / "draft" / "generation_prompt_only_420.jsonl")
    manifest = (load_manifest(base / "manifests_v2" / "preflight_tasks_20.json", "preflight")
                + load_manifest(base / "manifests_v2" / "main_tasks_400.json", "main"))
    # 合并后块边界按 phase 分别校验
    for phase in ("preflight", "main"):
        sub = [r for r in merged_queue if r.phase == phase]
        verify_arm_membership(sub)
    verify_queue_against_sources(merged_queue, prompts, manifest)
    return InputBundle(phase="merged", prompts=prompts, queue=merged_queue,
                       manifest=manifest,
                       fingerprints={
                           "merged_queue_rows": str(len(merged_queue)),
                           "prompt_store": sha256_file(
                               base / "draft" / "generation_prompt_only_420.jsonl"),
                       })


def select_phase(queue: Sequence[QueueRow], phase: str) -> List[QueueRow]:
    rows = [r for r in queue if r.phase == phase]
    if not rows:
        raise InputIntegrityError(f"队列中没有 phase={phase}")
    return rows


def estimate_input_tokens_upper(text: str, method: str) -> int:
    """输入 token 的**上界**估计。

    * `utf8_byte_upper_bound_v1`：按 UTF-8 字节数取上界。
      典型 BPE tokenizer 对任意文本满足 tokens <= bytes（每个 token 至少编码 1 字节，
      且字节序列不会比 token 更多），因此字节数是可解释的保守上界。
    * `provider_tokenizer_exact_v1`：需要服务方 tokenizer 可用时另行实现；
      本模块不猜测，直接抛错要求显式实现。
    """
    if method == "utf8_byte_upper_bound_v1":
        return len(text.encode("utf-8"))
    if method == "provider_tokenizer_exact_v1":
        raise InputIntegrityError(
            "provider_tokenizer_exact_v1 需要服务方 tokenizer；本轮未提供，"
            "请改用 utf8_byte_upper_bound_v1 或接入已核实 tokenizer")
    raise InputIntegrityError(f"未知的输入上界方法: {method!r}")
