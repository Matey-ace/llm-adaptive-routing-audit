"""旧源码的显式装载桥。

为什么需要它：
交接计划要求"保留原方法行为、封存实际导入模块路径、避免运行时误加载另一个旧版本"。
旧 `agents/`、`complexity/`、`llm_proxy/`、`tasks/`、`eval/`、`runner/` 是按**顶层包名**
导入的（`from agents.base import ...`），无法直接改包名而不动源码。

做法：
1. 旧源码已**按字节原样**复制到 `src/sncs_fivearm/legacy_root/`（见
   `evidence/legacy_copy_manifest.json`，逐文件 SHA-256 与源一致）。
2. 本模块把 `legacy_root` 插到 `sys.path[0]`，导入后**立即核验**每个已装载模块的
   `__file__` 确实位于 `legacy_root` 内；否则抛错。这样即便外部环境里有同名旧包，
   也不会被静默使用。
3. 对外只暴露一个 `LegacyModules` 容器，避免各模块各自 import 出不同实例。
"""

from __future__ import annotations

import importlib
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any, Dict, Tuple

LEGACY_ROOT = Path(__file__).resolve().parent / "legacy_root"

# 需要装载的旧模块（顺序即依赖顺序）
LEGACY_MODULES: Tuple[str, ...] = (
    "tasks",
    "tasks.dataset",
    "tasks.agent_view",
    "tasks.tools",
    "tasks.tools.builtin",
    "llm_proxy",
    "llm_proxy.usage",
    "llm_proxy.cache",
    "llm_proxy.client",
    "agents",
    "agents.stoppers",
    "agents.base",
    "agents.direct",
    "agents.planning",
    "agents.plan_reflect",
    "agents.adaptive",
    "complexity",
    "complexity.features",
    "complexity.rule_scorer",
    "complexity.llm_judge",
    "complexity.router",
    "complexity.artifact",
    "eval",
    "eval.extractors",
    "eval.metrics",
    "runner",
    "runner.scoring",
)


class LegacyPathViolation(RuntimeError):
    """装载到的模块不在封存副本内 —— 说明加载了错误的旧版本。"""


def _ensure_path() -> None:
    root = str(LEGACY_ROOT)
    if root in sys.path:
        sys.path.remove(root)
    sys.path.insert(0, root)


def _assert_inside(name: str, module: ModuleType) -> None:
    f = getattr(module, "__file__", None)
    if f is None:
        return  # 命名空间包
    resolved = Path(f).resolve()
    if not resolved.is_relative_to(LEGACY_ROOT):
        raise LegacyPathViolation(
            f"模块 {name} 实际装载自 {resolved}，不在封存副本 {LEGACY_ROOT} 内；"
            "拒绝继续，以免混用另一个旧版本。")


@dataclass(frozen=True)
class LegacyModules:
    """已核验来源的旧模块集合。"""

    tasks_dataset: ModuleType
    agent_view: ModuleType
    tools_builtin: ModuleType
    usage: ModuleType
    client: ModuleType
    stoppers: ModuleType
    agent_base: ModuleType
    direct: ModuleType
    planning: ModuleType
    plan_reflect: ModuleType
    adaptive: ModuleType
    router: ModuleType
    artifact: ModuleType
    rule_scorer_mod: ModuleType
    features: ModuleType
    extractors: ModuleType
    metrics: ModuleType
    scoring: ModuleType

    def files(self) -> Dict[str, str]:
        out: Dict[str, str] = {}
        for name in LEGACY_MODULES:
            mod = sys.modules.get(name)
            if mod is not None and getattr(mod, "__file__", None):
                out[name] = str(Path(mod.__file__).resolve())
        return out


_CACHE: LegacyModules | None = None


def load_legacy(force: bool = False) -> LegacyModules:
    """装载并核验旧模块（进程内只做一次）。"""
    global _CACHE
    if _CACHE is not None and not force:
        return _CACHE
    _ensure_path()
    loaded: Dict[str, ModuleType] = {}
    for name in LEGACY_MODULES:
        mod = importlib.import_module(name)
        _assert_inside(name, mod)
        loaded[name] = mod
    _CACHE = LegacyModules(
        tasks_dataset=loaded["tasks.dataset"],
        agent_view=loaded["tasks.agent_view"],
        tools_builtin=loaded["tasks.tools.builtin"],
        usage=loaded["llm_proxy.usage"],
        client=loaded["llm_proxy.client"],
        stoppers=loaded["agents.stoppers"],
        agent_base=loaded["agents.base"],
        direct=loaded["agents.direct"],
        planning=loaded["agents.planning"],
        plan_reflect=loaded["agents.plan_reflect"],
        adaptive=loaded["agents.adaptive"],
        router=loaded["complexity.router"],
        artifact=loaded["complexity.artifact"],
        rule_scorer_mod=loaded["complexity.rule_scorer"],
        features=loaded["complexity.features"],
        extractors=loaded["eval.extractors"],
        metrics=loaded["eval.metrics"],
        scoring=loaded["runner.scoring"],
    )
    return _CACHE


def assert_no_foreign_legacy_packages() -> None:
    """若 sys.modules 中已有来自其它路径的同名旧包，立即报错（而非静默复用）。"""
    bad = []
    for name in LEGACY_MODULES:
        mod = sys.modules.get(name)
        if mod is None:
            continue
        f = getattr(mod, "__file__", None)
        if f is None:
            continue
        if not Path(f).resolve().is_relative_to(LEGACY_ROOT):
            bad.append((name, str(Path(f).resolve())))
    if bad:
        detail = "\n  ".join(f"{n} -> {p}" for n, p in bad)
        raise LegacyPathViolation(
            "检测到非封存来源的同名旧模块已装载：\n  " + detail +
            "\n请在新进程中使用本执行器，或先清理 sys.modules。")


def legacy_fingerprints() -> Dict[str, str]:
    """封存副本各文件的 SHA-256（用于 run 元信息与恢复核对）。"""
    import hashlib
    out: Dict[str, str] = {}
    for p in sorted(LEGACY_ROOT.rglob("*.py")):
        out[str(p.relative_to(LEGACY_ROOT)).replace("\\", "/")] = hashlib.sha256(
            p.read_bytes()).hexdigest()
    return out
