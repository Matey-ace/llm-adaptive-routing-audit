"""provider 适配层。

三类实现，互不越界：

* `SyntheticProvider`  —— 完全离线，按预置脚本返回确定性响应（含各故障模式）。
* `LocalGatewayProvider` —— 打本地 OpenAI 兼容网关（127.0.0.1:8787），
  仅用于**工程冒烟**；不计费、不属于实验数据，且必须显式声明。
* `OpenAICompatProvider` —— 真实付费服务；只由 dispatcher 在合同已批准、
  预算门通过后调用。本轮**不启用**。

统一的返回对象 `ProviderResponse` 保留原始 envelope、finish_reason、
usage（缺失时置 None 并记录原因），使"已收到答案但缺 usage"这种情形可以被
正确保全（旧执行器在此处丢过正文）。
"""

from __future__ import annotations

import json
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Protocol

from ..errors import TransportError


@dataclass(frozen=True)
class ChatRequest:
    """一次派发的完整请求描述（不含任何 gold 信息）。"""

    request_id: str
    run_id: str
    phase: str
    purpose: str
    messages: List[Dict[str, str]]
    max_tokens: int
    sampling: Dict[str, Any] = field(default_factory=dict)
    extra: Dict[str, Any] = field(default_factory=dict)

    def flattened_text(self) -> str:
        """用于输入 token 上界：把 system+user 内容按实际发送顺序拼接。"""
        return "\n".join(f"[{m.get('role','')}]{m.get('content','')}" for m in self.messages)


@dataclass
class ProviderResponse:
    """一次成功派发的结果。"""

    content: str
    finish_reason: str
    model_reported: Optional[str]
    prompt_tokens: Optional[int]
    completion_tokens: Optional[int]
    usage_missing_reason: Optional[str]
    latency_ms: float
    envelope: Dict[str, Any]
    raw_bytes_received: int = 0
    partial: bool = False

    @property
    def usage_complete(self) -> bool:
        return self.prompt_tokens is not None and self.completion_tokens is not None

    def as_dict(self, *, redact: bool = True) -> Dict[str, Any]:
        env = dict(self.envelope)
        if redact:
            env = _redact(env)
        return {
            "content": self.content,
            "finish_reason": self.finish_reason,
            "model_reported": self.model_reported,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "usage_missing_reason": self.usage_missing_reason,
            "latency_ms": round(self.latency_ms, 3),
            "raw_bytes_received": self.raw_bytes_received,
            "partial": self.partial,
            "envelope": env,
        }


_SECRET_KEYS = {"authorization", "api_key", "apikey", "x-api-key", "cookie",
                "set-cookie", "token", "secret", "password"}


def _redact(obj: Any) -> Any:
    """脱敏：只保留结构与长度，不保留凭证类字段的原值。"""
    if isinstance(obj, dict):
        out: Dict[str, Any] = {}
        for k, v in obj.items():
            if str(k).lower() in _SECRET_KEYS:
                out[k] = "***redacted***"
            else:
                out[k] = _redact(v)
        return out
    if isinstance(obj, list):
        return [_redact(v) for v in obj]
    return obj


class Provider(Protocol):
    name: str

    def call(self, request: ChatRequest) -> ProviderResponse: ...


# ------------------------------------------------------------------ 合成 provider
class SyntheticProvider:
    """离线的确定性 provider。

    由一个"脚本"驱动：`script` 是 request_id -> list[动作] 的映射，动作按调用次序消耗。
    动作可以是响应、异常、部分响应、缺 usage 等，用于构造全部故障场景。
    """

    name = "synthetic"

    def __init__(self, script: Dict[str, List["SyntheticAction"]],
                 default: Optional["SyntheticAction"] = None) -> None:
        self.script = script
        self.default = default or SyntheticAction.text("ANSWER: 0")
        self._cursor: Dict[str, int] = {}
        self.calls: List[ChatRequest] = []
        self._lock = threading.RLock()

    def call(self, request: ChatRequest) -> ProviderResponse:
        with self._lock:
            self.calls.append(request)
            # 脚本既可按 request_id（run_id#dN）索引，也可按 run_id 索引；
            # run_id 是轨迹级键，dispatcher 每次派发都会生成新的 request_id。
            key = request.request_id if request.request_id in self.script else request.run_id
            idx = self._cursor.get(key, 0)
            actions = self.script.get(key)
            if actions is None:
                action = self.default
            else:
                if idx >= len(actions):
                    action = actions[-1]
                else:
                    action = actions[idx]
            self._cursor[key] = idx + 1
        return action.invoke(request)


class PurposeSyntheticProvider(SyntheticProvider):
    """按 **purpose** 分派的合成 provider（用于 reflect/replan 循环场景）。

    `by_purpose` 是 purpose -> 动作列表；同一 purpose 的第 n 次调用消耗第 n 个动作。
    未登记的 purpose 回退到 `default`。
    """

    def __init__(self, by_purpose: Dict[str, List["SyntheticAction"]],
                 default: Optional["SyntheticAction"] = None) -> None:
        super().__init__({}, default=default)
        self.by_purpose = {k: list(v) for k, v in by_purpose.items()}
        self._purpose_lock = threading.RLock()

    def call(self, request: ChatRequest) -> ProviderResponse:
        with self._purpose_lock:
            self.calls.append(request)
            key = f"purpose:{request.purpose}"
            actions = self.by_purpose.get(request.purpose)
            idx = self._cursor.get(key, 0)
            if actions is None:
                action = self.default
            else:
                action = actions[idx] if idx < len(actions) else actions[-1]
            self._cursor[key] = idx + 1
        return action.invoke(request)


@dataclass
class SyntheticAction:
    """一个可编程的合成动作。"""

    kind: str                       # text / raise / partial / missing_usage / malformed
    content: str = ""
    finish_reason: str = "stop"
    prompt_tokens: Optional[int] = 100
    completion_tokens: Optional[int] = 50
    usage_missing_reason: Optional[str] = None
    error: Optional[str] = None
    may_have_billed: bool = True
    status_code: Optional[int] = None
    model_reported: str = "synthetic-model"

    @classmethod
    def text(cls, content: str, *, finish: str = "stop",
             pt: int = 100, ct: int = 50) -> "SyntheticAction":
        return cls(kind="text", content=content, finish_reason=finish,
                   prompt_tokens=pt, completion_tokens=ct)

    @classmethod
    def truncated(cls, content: str, *, pt: int = 100, ct: int = 4000) -> "SyntheticAction":
        return cls(kind="text", content=content, finish_reason="length",
                   prompt_tokens=pt, completion_tokens=ct)

    @classmethod
    def error(cls, message: str, *, may_have_billed: bool = True,
              status_code: Optional[int] = None) -> "SyntheticAction":
        return cls(kind="raise", error=message, may_have_billed=may_have_billed,
                   status_code=status_code, prompt_tokens=None, completion_tokens=None)

    @classmethod
    def missing_usage(cls, content: str, reason: str = "provider_omitted_usage",
                      *, finish: str = "stop") -> "SyntheticAction":
        return cls(kind="missing_usage", content=content, finish_reason=finish,
                   prompt_tokens=None, completion_tokens=None,
                   usage_missing_reason=reason)

    @classmethod
    def empty(cls) -> "SyntheticAction":
        return cls(kind="text", content="", prompt_tokens=10, completion_tokens=0)

    def invoke(self, request: ChatRequest) -> ProviderResponse:
        started = time.perf_counter()
        if self.kind == "raise":
            raise TransportError(self.error or "synthetic failure",
                                 may_have_billed=self.may_have_billed,
                                 status_code=self.status_code)
        latency = (time.perf_counter() - started) * 1000.0
        envelope = {
            "id": f"synthetic-{request.request_id}",
            "object": "chat.completion",
            "model": self.model_reported,
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": self.content},
                "finish_reason": self.finish_reason,
            }],
            "usage": (None if self.kind == "missing_usage" else {
                "prompt_tokens": self.prompt_tokens,
                "completion_tokens": self.completion_tokens,
                "total_tokens": (self.prompt_tokens or 0) + (self.completion_tokens or 0),
            }),
            "synthetic": True,
        }
        return ProviderResponse(
            content=self.content,
            finish_reason=self.finish_reason,
            model_reported=self.model_reported,
            prompt_tokens=self.prompt_tokens,
            completion_tokens=self.completion_tokens,
            usage_missing_reason=(self.usage_missing_reason
                                  if self.kind == "missing_usage" else None),
            latency_ms=latency,
            envelope=envelope,
            raw_bytes_received=len(json.dumps(envelope).encode("utf-8")),
            partial=False,
        )


# ------------------------------------------------------------------ 本地网关（冒烟）
class LocalGatewayProvider:
    """本地 OpenAI 兼容网关：仅用于工程连通性冒烟。

    不计费、不写实验数据；调用方必须在 run 元信息里标注 `purpose=smoke`。
    """

    name = "local_gateway"

    def __init__(self, base_url: str, model: str, api_key: str,
                 timeout: float = 60.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self._api_key = api_key
        self.timeout = timeout

    def call(self, request: ChatRequest) -> ProviderResponse:
        import urllib.error
        import urllib.request

        body = {
            "model": self.model,
            "messages": request.messages,
            "max_tokens": request.max_tokens,
            "stream": False,
        }
        for k in ("temperature", "top_p", "seed"):
            if k in request.sampling and request.sampling[k] is not None:
                body[k] = request.sampling[k]
        # 归档官方资料：thinking 放在 extra_body；reasoning_effort 是顶层字段。
        # LocalGatewayProvider 通过 request.extra 接收，dispatcher 只透传合同登记值。
        thinking = request.extra.get("thinking")
        if thinking is not None:
            body["thinking"] = thinking
        effort = request.extra.get("reasoning_effort")
        if effort is not None:
            body["reasoning_effort"] = effort
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            f"{self.base_url}/v1/chat/completions", data=data,
            headers={"Content-Type": "application/json",
                     "Authorization": f"Bearer {self._api_key}"},
            method="POST")
        started = time.perf_counter()
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read()
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            raise TransportError(
                f"HTTP {exc.code}: {raw[:400].decode('utf-8', 'replace')}",
                may_have_billed=exc.code >= 500,
                status_code=exc.code) from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise TransportError(f"网络失败: {exc}", may_have_billed=True) from exc
        latency = (time.perf_counter() - started) * 1000.0
        try:
            payload = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise TransportError(f"响应不是 JSON: {raw[:200]!r}",
                                 may_have_billed=True) from exc
        choice = (payload.get("choices") or [{}])[0]
        message = choice.get("message") or {}
        usage = payload.get("usage")
        pt = ct = None
        missing = None
        if isinstance(usage, dict):
            pt = usage.get("prompt_tokens")
            ct = usage.get("completion_tokens")
        else:
            missing = "gateway_omitted_usage"
        return ProviderResponse(
            content=str(message.get("content") or ""),
            finish_reason=str(choice.get("finish_reason") or "stop"),
            model_reported=payload.get("model"),
            prompt_tokens=pt,
            completion_tokens=ct,
            usage_missing_reason=missing,
            latency_ms=latency,
            envelope=payload,
            raw_bytes_received=len(raw),
        )


# ------------------------------------------------------------------ 真实服务
class OpenAICompatProvider:
    """真实付费服务适配器（OpenAI 兼容）。

    刻意做的三件事：
    1. **关闭 SDK 自动重试**（max_retries=0）：每次网络尝试都必须经过同一个费用门与
       8 次门，不能让库偷偷重发。
    2. 请求里只发送合同登记的字段；不在本地"猜"服务是否支持某参数。
    3. 任何异常都带上 `may_have_billed`，交给 dispatcher 决定保留预留还是释放。
    """

    name = "openai_compatible"

    def __init__(self, *, base_url: str, model: str, api_key: str,
                 timeout: float = 120.0, extra_body: Optional[Dict[str, Any]] = None) -> None:
        from openai import OpenAI  # 延迟导入：离线路径不依赖

        self.model = model
        self._client = OpenAI(api_key=api_key, base_url=base_url,
                              timeout=timeout, max_retries=0)
        self._extra_body = dict(extra_body or {})

    def call(self, request: ChatRequest) -> ProviderResponse:
        import time as _time

        kwargs: Dict[str, Any] = {
            "model": self.model,
            "messages": request.messages,
            "max_tokens": request.max_tokens,
        }
        for k in ("temperature", "top_p", "seed"):
            if k in request.sampling and request.sampling[k] is not None:
                kwargs[k] = request.sampling[k]
        if self._extra_body:
            kwargs["extra_body"] = dict(self._extra_body)
        started = _time.perf_counter()
        try:
            resp = self._client.chat.completions.create(**kwargs)
        except Exception as exc:  # noqa: BLE001 - 统一转成 TransportError
            status = getattr(exc, "status_code", None)
            raise TransportError(str(exc), may_have_billed=True,
                                 status_code=status) from exc
        latency = (_time.perf_counter() - started) * 1000.0
        envelope = resp.model_dump() if hasattr(resp, "model_dump") else {}
        choice = (envelope.get("choices") or [{}])[0]
        usage = envelope.get("usage") or {}
        pt = usage.get("prompt_tokens")
        ct = usage.get("completion_tokens")
        missing = None if (pt is not None and ct is not None) else "response_usage_absent"
        message = choice.get("message") or {}
        return ProviderResponse(
            content=str(message.get("content") or ""),
            finish_reason=str(choice.get("finish_reason") or "stop"),
            model_reported=envelope.get("model"),
            prompt_tokens=pt,
            completion_tokens=ct,
            usage_missing_reason=missing,
            latency_ms=latency,
            envelope=envelope,
            raw_bytes_received=len(json.dumps(envelope).encode("utf-8")),
        )


def build_provider(contract, *, allow_live: bool = False) -> Provider:
    """按合同构造 provider。离线模式永不构造 live client。"""
    mode = contract.mode
    if mode == "offline_simulation":
        raise RuntimeError("offline 模式由 runner 直接注入 SyntheticProvider，不经过本函数")
    if mode == "local_gateway":
        contract.require_live_ready()
        import os

        env_name = contract.get("provider.api_key_env")
        key = os.environ.get(str(env_name)) if env_name else None
        if not key:
            raise RuntimeError(f"环境变量 {env_name} 未设置；不构造本机网关 client")
        base = str(contract.get("provider.base_url")).rstrip("/")
        if not base.startswith("http://127.0.0.1") and not base.startswith("http://localhost"):
            raise RuntimeError(f"local_gateway 只允许本机端点，收到 {base}")
        return LocalGatewayProvider(
            base_url=base,
            model=str(contract.get("provider.model_id")),
            api_key=key,
            timeout=float(contract.get("provider.timeout_seconds") or 120.0))
    if not allow_live:
        raise RuntimeError("live provider 需要显式 allow_live=True")
    contract.require_live_ready()
    import os

    env_name = contract.get("provider.api_key_env")
    key = os.environ.get(str(env_name)) if env_name else None
    if not key:
        raise RuntimeError(f"环境变量 {env_name} 未设置；不构造 live client")

    thinking = contract.get("provider.thinking", {}) or {}
    extra_body: Dict[str, Any] = {}
    if thinking.get("enabled") is not None:
        extra_body["thinking"] = {"type": "enabled" if thinking["enabled"] else "disabled"}
    if thinking.get("reasoning_effort"):
        extra_body["reasoning_effort"] = thinking["reasoning_effort"]
    return OpenAICompatProvider(
        base_url=str(contract.get("provider.base_url")),
        model=str(contract.get("provider.model_id")),
        api_key=key,
        timeout=float(contract.get("provider.timeout_seconds") or 120.0),
        extra_body=extra_body or None,
    )
