"""SNCS 五臂执行器（离线优先）。

模块边界（导入方向固定，禁止反向）：

    contracts  ->  只依赖标准库
    budget     ->  只依赖标准库（精确整数微货币）
    journal    ->  只依赖标准库
    inputs     ->  contracts（不导入任何 gold / 评分模块）
    answers    ->  只依赖 vendored 旧提取器（gold-free）
    registry   ->  strategies
    dispatcher ->  contracts, budget, journal, providers, inputs
    runner     ->  registry, dispatcher, answers, journal
    evaluation.* ->  answers, inputs；gold 只在 evaluation.gold 内读取

结构性约束（由 tests/test_isolation.py 强制）：
生成路径（runner/registry/strategies/dispatcher）不得导入 `evaluation.gold`，
也不得出现 `gold` 字段访问。
"""

from __future__ import annotations

__version__ = "0.1.0"
RUNNER_ID = "sncs-fivearm-20261111"
