"""五臂 registry：显式 ID → 策略实现，不允许隐式映射。

| ID | 实现 | 与原流程的关系 |
| --- | --- | --- |
| `direct` | `DirectAgent` | 逐字节相同的旧源码，单次直接解题 |
| `planning` | `PlanningAgent` | 旧源码，先计划后解题 |
| `plan_reflect` | `PlanReflectAgent` + S1(max_rounds=2) | 旧源码 + 冻结的固定参照参数 |
| `adaptive_legacy` | `AdaptiveAgent` + 冻结 router + S2(delta=.05, streak=2) | 旧源码，参数不因新结果而调整 |
| `asc_beta_8` | `AscBeta8Strategy` | 新 adapter：已发表 top-two Beta 停止，最多 8 次派发 |

参数来源：`configs/exp/formal_{gsm8k,math}_primary_s6.yaml`（只读原配置）。

    agent: max_reflections=4, stopper=S1/max_rounds=2, judge_max_tokens=4096,
           hard_cap={max_calls:8, max_rounds:4}, budget={max_calls:8}
    adaptive: stopper=S2, delta=0.05, streak=2
    base: decoding temperature=0 top_p=1 seed=42 max_tokens=4096, retry.max_attempts=1,
          cache.enabled=false

`hard_cap.max_calls = 8` 与"每轨迹 8 次实际派发"门一致；dispatcher 另有一道独立门，
两者都在，缺一不可（旧代码只改一处会漏）。
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from . import answers as answers_mod
from .answers.asc import AscOutcome, AscRunner, STOP_BUDGET, STOP_SERVICE
from .dispatcher import Dispatcher, LegacyBridgeClient
from .errors import DispatchLimitReached, BudgetBlocked
from .inputs import ARMS, TaskPrompt
from .runtime import load_legacy

# 冻结的原配置（只读来源，SHA-256 在 evidence/legacy_copy_manifest.json 侧核对）
FROZEN_AGENT_CONFIG: Dict[str, Any] = {
    "max_reflections": 4,
    "stopper": "S1",
    "stopper_params": {"max_rounds": 2},
    "judge_max_tokens": 4096,
    "hard_cap": {"max_calls": 8, "max_rounds": 4},
    "budget": {"max_calls": 8},
}
FROZEN_ADAPTIVE_OVERRIDES: Dict[str, Any] = {
    "stopper": "S2",
    "stopper_params": {"delta": 0.05, "streak": 2},
}
FROZEN_BASE_DECODING: Dict[str, Any] = {
    "temperature": 0.0, "top_p": 1.0, "seed": 42, "max_tokens": 4096,
}

FROZEN_ROUTER_SHA256 = (
    "3178631cb9426c1620b608eadff1b5109e24184c9954836e1af15ae0641573ea")
DEFAULT_ROUTER_PATH = Path(
    r"E:\论文相关\results\complexity\router_candidate_s5_20261014.json")


class RegistryError(Exception):
    pass


@dataclass
class StrategyOutcome:
    """一条轨迹的终态（不含任何 gold 评分）。"""

    strategy: str
    final_answer: str
    stop_reason: str
    dispatches: int
    steps: List[Dict[str, Any]] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    asc: Optional[Dict[str, Any]] = None
    answer_record: Optional[Dict[str, Any]] = None
    n_reflections: int = 0
    n_replans: int = 0
    selected_level: Optional[str] = None
    selected_path: Optional[str] = None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "strategy": self.strategy,
            "final_answer": self.final_answer,
            "stop_reason": self.stop_reason,
            "dispatches": self.dispatches,
            "steps": self.steps,
            "extra": self.extra,
            "error": self.error,
            "asc": self.asc,
            "answer_record": self.answer_record,
            "n_reflections": self.n_reflections,
            "n_replans": self.n_replans,
            "selected_level": self.selected_level,
            "selected_path": self.selected_path,
        }


def _trajectory_steps(traj) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for s in getattr(traj, "steps", []) or []:
        out.append({
            "kind": getattr(s, "kind", ""),
            "prompt": getattr(s, "prompt", ""),
            "response": getattr(s, "response", ""),
            "latency_ms": round(float(getattr(s, "latency_ms", 0.0) or 0.0), 3),
            "detail": getattr(s, "detail", {}) or {},
        })
    return out


class FiveArmRegistry:
    """构造并运行五臂。每条轨迹都得到独立的 client / meter / 状态。"""

    def __init__(self, *, dispatcher: Dispatcher, contract,
                 router_path: Optional[Path | str] = None,
                 verify_router: bool = True) -> None:
        self.dispatcher = dispatcher
        self.contract = contract
        self.legacy = load_legacy()
        self.role_limits = dict(contract.get("limits.role_output_limits", {}))
        self.role_limits.setdefault("default", 4096)
        self.model_name = str(contract.get("provider.model_id") or "offline-synthetic")
        self._router_data = None
        self._router_sha = None
        self.router_path = Path(router_path) if router_path else DEFAULT_ROUTER_PATH
        self.verify_router = verify_router

    # ------------------------------------------------------------------ router
    def router_artifact(self):
        if self._router_data is not None:
            return self._router_data, self._router_sha
        raw = self.router_path.read_bytes()
        sha = hashlib.sha256(raw).hexdigest()
        if self.verify_router and sha != FROZEN_ROUTER_SHA256:
            raise RegistryError(
                f"router artifact 指纹不符：实际 {sha[:12]} != 冻结 {FROZEN_ROUTER_SHA256[:12]}")
        data, sha2 = self.legacy.artifact.load_artifact(self.router_path)
        self._router_data, self._router_sha = data, sha2
        return data, sha2

    # ------------------------------------------------------------------ 构造
    def _agent_kwargs(self, *, adaptive: bool) -> Dict[str, Any]:
        cfg = dict(FROZEN_AGENT_CONFIG)
        if adaptive:
            cfg.update(FROZEN_ADAPTIVE_OVERRIDES)
        return cfg

    def build(self, strategy: str, bridge: LegacyBridgeClient):
        if strategy not in ARMS:
            raise RegistryError(f"未登记的臂: {strategy}；可选 {ARMS}")
        stoppers = self.legacy.stoppers
        hard_cap = stoppers.HardCapStopper(**FROZEN_AGENT_CONFIG["hard_cap"])
        budget = stoppers.BudgetGuard(**FROZEN_AGENT_CONFIG["budget"])
        common = {"hard_cap": hard_cap, "budget": budget,
                  "max_reflections": FROZEN_AGENT_CONFIG["max_reflections"]}

        if strategy == "direct":
            return self.legacy.direct.DirectAgent(bridge, **common)
        if strategy == "planning":
            return self.legacy.planning.PlanningAgent(bridge, **common)
        if strategy == "plan_reflect":
            stopper = stoppers.build_stopper("S1", dict(FROZEN_AGENT_CONFIG["stopper_params"]))
            return self.legacy.plan_reflect.PlanReflectAgent(
                bridge, stopper=stopper, on_malformed="stop", ignore_pass=False, **common)
        if strategy == "adaptive_legacy":
            stopper = stoppers.build_stopper(
                FROZEN_ADAPTIVE_OVERRIDES["stopper"],
                dict(FROZEN_ADAPTIVE_OVERRIDES["stopper_params"]))
            data, _sha = self.router_artifact()
            judge_max = int(FROZEN_AGENT_CONFIG["judge_max_tokens"])
            judge_max = min(judge_max, int(self.contract.role_limit("judge")))
            router = self.legacy.artifact.router_from_artifact(
                data, judge_max_tokens=judge_max, mode="hybrid")
            return self.legacy.adaptive.AdaptiveAgent(
                bridge, stopper=stopper, router=router, on_malformed="stop",
                ignore_pass=False, enable_reflection=True, **common)
        raise RegistryError(f"{strategy} 由 AscBeta8Strategy 执行，不经 build()")

    # ------------------------------------------------------------------ 运行
    def run_trajectory(self, *, strategy: str, task: TaskPrompt,
                       run_id: str, phase: str) -> StrategyOutcome:
        """一条轨迹：独立 bridge/meter，跑完释放。"""
        self.dispatcher.reset_trajectory(run_id)
        bridge = LegacyBridgeClient(self.dispatcher, role_limits=self.role_limits,
                                    model_name=self.model_name)
        bridge.bind(run_id=run_id, phase=phase)
        av = self.legacy.agent_view.AgentView(task_id=task.task_id, prompt=task.prompt)

        if strategy == "asc_beta_8":
            return self._run_asc(task=task, run_id=run_id, phase=phase, bridge=bridge)

        try:
            agent = self.build(strategy, bridge)
            traj = agent.run(av)
        except DispatchLimitReached as exc:
            return StrategyOutcome(strategy=strategy, final_answer="",
                                   stop_reason="dispatch_cap", dispatches=self.dispatcher.dispatches(run_id),
                                   error=str(exc))
        except BudgetBlocked as exc:
            return StrategyOutcome(strategy=strategy, final_answer="",
                                   stop_reason="budget_blocked", dispatches=self.dispatcher.dispatches(run_id),
                                   error=str(exc))
        except Exception as exc:  # noqa: BLE001 - 旧 Agent 内部的任何异常都要保全
            return StrategyOutcome(strategy=strategy, final_answer="",
                                   stop_reason="run_error",
                                   dispatches=self.dispatcher.dispatches(run_id),
                                   error=f"{type(exc).__name__}: {exc}")

        final = str(getattr(traj, "final_answer", "") or "")
        # finish_reason 与原始响应都取**最后一次"求解类"派发**：
        # plan_reflect/adaptive 的最后一次派发通常是 reflect 或 replan，
        # 若拿它们的内容去解析答案，会把反思正文误当最终答案（真实数据已复现）。
        answer_purposes = ("solve", "baseline_solve", "tool")
        last_finish = "stop"
        raw_content = ""
        for rec in reversed(self.dispatcher.records):
            if rec.run_id == run_id and rec.error is None \
                    and rec.purpose in answer_purposes:
                last_finish = rec.finish_reason or "stop"
                raw_content = rec.content or ""
                break
        # 答案记录优先基于原始求解响应（保留 ANSWER: 前缀与多标记信号）；
        # 找不到求解响应时退回 Agent 已剥前缀的 final_answer。
        record = answers_mod.parse_answer_attempt(
            raw_content or final, finish_reason=last_finish)
        return StrategyOutcome(
            strategy=strategy,
            final_answer=final,
            stop_reason=str(getattr(traj, "stop_reason", None) or "unknown"),
            dispatches=self.dispatcher.dispatches(run_id),
            steps=_trajectory_steps(traj),
            extra=dict(getattr(traj, "extra", {}) or {}),
            n_reflections=int(getattr(traj, "n_reflections", 0) or 0),
            n_replans=int(getattr(traj, "n_replans", 0) or 0),
            selected_level=getattr(traj, "selected_level", None),
            selected_path=getattr(traj, "selected_path", None),
            answer_record=record.as_dict(),
        )

    # ------------------------------------------------------------------ ASC
    def _run_asc(self, *, task: TaskPrompt, run_id: str, phase: str,
                 bridge: LegacyBridgeClient) -> StrategyOutcome:
        asc = AscRunner(max_attempts=min(8, int(self.contract.dispatch_cap)))
        answer_records: List[answers_mod.AnswerRecord] = []

        def draw(index: int) -> answers_mod.AnswerRecord:
            # 每次都是新会话：只含题目与"直接给答案"，不含之前任何候选答案
            messages = bridge_aware_solve_messages(self.legacy.agent_base, av_factory(task), "")
            try:
                reply = bridge.chat(messages, purpose="baseline_solve")
            except DispatchLimitReached:
                rec = answers_mod.AnswerRecord(
                    key=None, valid=False, reason="dispatch_cap_reached",
                    raw_span="", span_source="empty")
                answer_records.append(rec)
                raise
            except BudgetBlocked:
                rec = answers_mod.AnswerRecord(
                    key=None, valid=False, reason="budget_blocked",
                    raw_span="", span_source="empty")
                answer_records.append(rec)
                raise
            record = answers_mod.parse_answer_attempt(
                reply.content, finish_reason=reply.finish_reason)
            answer_records.append(record)
            return record

        def blocked(index: int) -> Optional[str]:
            if self.dispatcher.remaining(run_id) <= 0:
                return STOP_BUDGET if self.dispatcher.last_block == "dispatch_cap" else "dispatch_cap"
            decision_state = self.dispatcher.ledger.state()
            if decision_state.unresolved_exposure_micro > 0:
                return STOP_SERVICE
            return None

        outcome: AscOutcome
        try:
            outcome = asc.run(draw, blocked=blocked)
        except (DispatchLimitReached, BudgetBlocked) as exc:
            final = answers_mod.AnswerRecord(
                key=None, valid=False, reason=str(type(exc).__name__),
                raw_span="", span_source="empty")
            return StrategyOutcome(
                strategy="asc_beta_8", final_answer="",
                stop_reason="dispatch_cap" if isinstance(exc, DispatchLimitReached) else "budget_blocked",
                dispatches=self.dispatcher.dispatches(run_id),
                error=str(exc),
                asc={"attempts": len(answer_records),
                     "stop_reason": "dispatch_cap",
                     "history": [r.as_dict() for r in answer_records]},
                answer_record=final.as_dict())

        final_span = ""
        if outcome.selected_key is not None:
            for r in answer_records:
                if r.valid and r.key == outcome.selected_key:
                    final_span = r.raw_span
                    break
        final_record = answers_mod.parse_answer_attempt(final_span or "")
        return StrategyOutcome(
            strategy="asc_beta_8",
            final_answer=final_span,
            stop_reason=outcome.stop_reason,
            dispatches=self.dispatcher.dispatches(run_id),
            extra={"asc_attempts": outcome.attempts,
                   "asc_posterior": outcome.posterior_top_two,
                   "asc_valid_votes": outcome.valid_votes,
                   "asc_invalid_attempts": outcome.invalid_attempts},
            asc=outcome.as_dict(),
            answer_record=final_record.as_dict() if final_span else
            answers_mod.AnswerRecord(key=None, valid=False,
                                     reason="asc_no_valid_answer",
                                     raw_span="", span_source="empty").as_dict(),
        )


def av_factory(task: TaskPrompt):
    from .runtime import load_legacy
    return load_legacy().agent_view.AgentView(task_id=task.task_id, prompt=task.prompt)


def bridge_aware_solve_messages(agent_base_mod, av, history: str = "") -> List[Dict[str, str]]:
    """用旧 `AgentBase.build_messages` 生成 solve 消息，保证与其它臂同一提示骨架。

    这里借用一个最小实例以免直接复制提示文本；`build_messages` 不依赖 client。
    """
    builder = _MessageBuilder(agent_base_mod)
    return builder.build(av, "solve", history)


class _MessageBuilder:
    """调用旧 `AgentBase.build_messages` 而不构造完整 Agent 的最小载体。

    旧实现里 `build_messages` 只用到 `self.toolbox.describe(...)`，因此注入默认工具箱
    即可；不传 client、不触发任何派发。
    """

    def __init__(self, agent_base_mod) -> None:
        from .runtime import load_legacy
        legacy = load_legacy()
        self._toolbox = legacy.tools_builtin.MockToolBox()
        self._fn = agent_base_mod.AgentBase.build_messages

    def build(self, av, kind: str, history: str = "") -> List[Dict[str, str]]:
        proxy = type("_Proxy", (), {})()
        proxy.toolbox = self._toolbox
        return list(self._fn(proxy, av, kind, history))
