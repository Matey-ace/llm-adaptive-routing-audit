"""五臂共用的 gold-free 答案解析与归一化。

两种用途，互不泄漏：

* **ASC 聚类**：把一次采样输出转成"答案类别键"，同键即同票。
* **评分**：把同一键与 gold 的键比较（`evaluation.scoring` 侧执行）。
  本模块**从不读取 gold**，也不接受 gold 作为参数。

────────────────────────────────────────────────────────────────────────
事前冻结的有效性政策（在跑主数据前写入 `protocol/Answer_Extraction_Policy.md`）
────────────────────────────────────────────────────────────────────────

一次输出被判为 **有效答案** 需同时满足：

1. 内容非空（去除首尾空白后）；
2. 能找到"最终答案位置"：`\\boxed{...}`，或显式标记
   （`ANSWER:` / `FINAL:` / `答案是` / `answer is` / `####`）之后的内容，
   或最后一个非空行；
3. 若 `finish_reason == "length"`（被截断）且**没有**显式标记或 boxed，
   视为截断且无合格最终答案 → **无效**（消耗尝试但不投票）；
4. 取出的片段在归一化后能落到下面**四**种键之一：
   * `num:<数值>`     纯数值（含分数、有限小数、科学计数法、千分位）
   * `sym:<表达式>`   纯符号表达式（含变量，sympy 规范打印）
   * `struct:<全串>`  结构化答案：区间、矩阵、方程、多解、集合、坐标
   * `text:<字面>`    短字面答案（单个词，≤ 60 字符），如 `yes` / `A`

   否则 → **无效**（例如整段散文、协议复述、`EMPTY`）。

键的相等即"同一个答案类别"。**不做**以下合并：

* 不因为两个浮点数接近而合并（数值相等用精确有理数比较）；
* 不使用 gold、不使用付费 judge、不使用语义相似度；
* 不支持的一般符号等价（如三角恒等式）保持为不同键，并在评分侧标 `needs_review`。

**恒等性自检（结构性守卫）**：把 gold 原样当预测输入，评分必须全部为 `correct`。
这条检查由 `tools/identity_check.py` 与
`tests/test_scoring_stats.py::test_identity_scoring_accepts_every_real_answer_shape`
双重覆盖；它保证了"真实存在的答案形态"都能归类，而不是被悄悄判成 unknown。

冲突多答案（同一输出里出现多个不同 `ANSWER:` 行）：采用**最后一个**显式标记
（与 `extract_answer_span` 一致），并在记录里置 `conflicting_markers=true`，
评分侧据此可转人工复核；ASC 侧仍按该键投票（口径固定、可复现）。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

POLICY_VERSION = "answer-policy-20261111.1"

MAX_TEXT_ANSWER_CHARS = 60

# 协议残留词：出现即说明输出没有给出答案
_PROTOCOL_NOISE = (
    "ANSWER:", "FINAL:", "PLAN:", "REFLECT:", "VERDICT:", "CONFIDENCE:",
    "ACTION:", "答案:", "最终答案:",
)

_MARKER_RE = re.compile(
    r"(?:ANSWER|FINAL|ANS)\s*[:：]|"
    r"(?:the\s+)?answer\s+is\s*[:：]?|"
    r"答案是\s*[:：]?|最终答案(?:是|为)\s*[:：]?|"
    r"####\s*",
    re.IGNORECASE,
)


class AnswerPolicyError(Exception):
    pass


@dataclass(frozen=True)
class AnswerRecord:
    """一次输出解析结果（可序列化，进入 journal 与评分包）。"""

    key: Optional[str]            # 答案类别键；None 表示无效
    valid: bool                   # 是否构成一次有效投票
    reason: str                   # 判定原因码
    raw_span: str                 # 提取到的原始答案片段（保留原样）
    span_source: str              # boxed / marker / last_line / whole / empty
    conflicting_markers: bool = False
    policy_version: str = POLICY_VERSION
    detail: Dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key,
            "valid": self.valid,
            "reason": self.reason,
            "raw_span": self.raw_span,
            "span_source": self.span_source,
            "conflicting_markers": self.conflicting_markers,
            "policy_version": self.policy_version,
            "detail": dict(self.detail),
        }


# ---------------------------------------------------------------- 旧提取器桥
def _extractors():
    """延迟装载封存的旧提取器（path 已核验）。"""
    from ..runtime import load_legacy
    return load_legacy().extractors


def _count_markers(text: str) -> int:
    return len(list(_MARKER_RE.finditer(text)))


def _has_protocol_noise(span: str) -> bool:
    up = span.upper()
    return any(tok in up for tok in _PROTOCOL_NOISE)


def _strip_wrapping(span: str) -> str:
    s = span.strip()
    for _ in range(4):
        if len(s) >= 2 and s[0] == "$" and s[-1] == "$":
            s = s[1:-1].strip()
        elif len(s) >= 2 and s[0] == "`" and s[-1] == "`":
            s = s[1:-1].strip()
        # 真实模型常把答案包成 LaTeX 行内公式：\(...\) 或 \[...\]
        elif s.startswith("\\(") and s.endswith("\\)"):
            s = s[2:-2].strip()
        elif s.startswith("\\[") and s.endswith("\\]"):
            s = s[2:-2].strip()
        else:
            break
    return s


# 常见单位后缀（中英文）。只在**紧跟数值**且不改变数值语义时剥离。
_UNIT_SUFFIXES = (
    "美元", "美金", "元", "块钱", "块",
    "分钟", "小时", "秒", "天", "周", "个月", "年",
    "厘米", "毫米", "米", "千米", "公里", "英寸", "英尺",
    "克", "千克", "公斤", "吨", "磅",
    "平方米", "平方厘米", "立方米", "立方厘米",
    "度", "摄氏度", "毫升", "升", "加仑",
    "个", "人", "只", "张", "件", "本", "辆", "次", "倍",
)

_UNIT_RE = re.compile(
    r"^\s*([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)"
    r"\s*(?:美元|美金|元|块钱|块|分钟|小时|秒|天|周|个月|年|"
    r"厘米|毫米|千米|公里|米|英寸|英尺|克|千克|公斤|吨|磅|"
    r"平方米|平方厘米|立方米|立方厘米|摄氏度|度|毫升|升|加仑|"
    r"个|人|只|张|件|本|辆|次|倍)\s*$"
)


def _strip_unit(span: str) -> str:
    """剥掉紧跟数值的单位，只保留数值本体。

    口径（事前声明）：`475美元`、`21分钟`、`78元` 与 `475`、`21`、`78` 视为同一数值答案。
    这是**书写单位**的归一化，不是语义合并——`25%` 不在此列（百分号是独立单位符号，
    按政策不与裸数字等同）。
    """
    m = _UNIT_RE.match(span)
    if m:
        return m.group(1)
    return span


def number_key(value_text: str) -> Optional[str]:
    """纯数值 → 规范键；非纯数值返回 None。

    用 Python `Fraction` 做精确有理比较，避免浮点误差把 0.5 与 1/2 分成两类、
    或把 1e-7 与 0 合并。
    """
    ex = _extractors()
    span = _strip_wrapping(value_text)
    if not span:
        return None
    # 单位后缀归一化（475美元 → 475），并在千分位处理之前做
    span = _strip_unit(span)
    # 千分位：1,234 -> 1234（只处理标准三位分组）
    if re.fullmatch(r"-?\d{1,3}(?:,\d{3})+(?:\.\d+)?", span):
        span = span.replace(",", "")
    from fractions import Fraction
    # 1) 十进制 / 科学计数法（允许 .5 这类无整数部分写法）
    m = re.fullmatch(r"([+-]?)(?:(\d+)(?:\.(\d*))?|\.(\d+))(?:[eE]([+-]?\d+))?", span)
    if m:
        sign = m.group(1)
        whole = m.group(2) or ""
        frac = m.group(3) if m.group(2) is not None else m.group(4)
        exp = m.group(5)
        frac = frac or ""
        digits = whole + frac
        if not digits:
            return None
        denom = 10 ** len(frac)
        value = Fraction(int(digits), denom)
        if exp:
            e = int(exp)
            value = value * (10 ** e) if e >= 0 else value / (10 ** -e)
        if sign == "-":
            value = -value
        return f"num:{value.numerator}/{value.denominator}"
    # 2) 简单分数 a/b（b 非零）
    m = re.fullmatch(r"([+-]?\d+)\s*/\s*([+-]?\d+)", span)
    if m:
        num, den = int(m.group(1)), int(m.group(2))
        if den == 0:
            return None
        value = Fraction(num, den)
        return f"num:{value.numerator}/{value.denominator}"
    # 3) sympy 可解析且无自由变量 → 精确数值（覆盖 \frac、\sqrt、幂等）
    expr = ex.to_sympy(span)
    if expr is not None:
        try:
            if not set(expr.free_symbols) and getattr(expr, "is_number", False):
                ratio = __import__("sympy").nsimplify(expr)
                value = Fraction(str(ratio)) if ratio.is_rational else None
                if value is None:
                    return f"num:float:{float(expr.evalf(30)):.17g}"
                return f"num:{value.numerator}/{value.denominator}"
        except Exception:  # noqa: BLE001 - 解析失败即不是数值
            pass
    return None


def symbolic_key(span: str) -> Optional[str]:
    """纯符号表达式键。

    收紧规则（避免把散文片段当成符号）：sympy 会把任意字母串 sympify 成 Symbol，
    因此"notakeyatall" 这种词也会变成 `sym:notakeyatall`。这里显式排除：

      * 裸标识符（无任何运算符/数字/括号）且长度 > 4 且不是已知数学名
        （希腊字母、pi、e、i 等）→ 不当作符号答案；
      * 仍允许 `x`、`n`、`alpha`、`x+2`、`2x`、`\\sqrt{2}` 这类真正的数学答案。
    """
    s = _strip_wrapping(span)
    if not s:
        return None
    ex = _extractors()
    # 纯字母串（"yes" / "x" / "notakeyatall"）不当作符号表达式：
    # sympy 会把任意字母串 sympify 成 Symbol，无法区分"变量答案"与"一个单词"。
    # 这类一律走 text 键，保证两侧用同一政策、结果确定。
    canon = ex.canonical_text(s) or ""
    if re.fullmatch(r"[A-Za-z]+", canon):
        return None
    expr = ex.to_sympy(s)
    if expr is None:
        return None
    try:
        if set(expr.free_symbols):
            return "sym:" + str(expr)
    except Exception:  # noqa: BLE001
        return None
    return None


_KNOWN_MATH_NAMES = frozenset({
    "alpha", "beta", "gamma", "delta", "epsilon", "theta", "lambda", "mu",
    "sigma", "phi", "omega", "pi", "tau", "infty",
})


def text_key(span: str) -> Optional[str]:
    """短字面答案键（**单个词**，无协议残留）。

    明确拒绝：多词短语（散文片段）、超长串、含空白或协议标记的串。
    这样 `yes` / `no` / `A` / `None` 这类答案可比，而
    `not a key at all` 这类描述性文字不会被误当成答案类别。
    """
    s = _strip_wrapping(span)
    if not s:
        return None
    raw = s.strip()
    if len(raw) > MAX_TEXT_ANSWER_CHARS:
        return None
    if "\n" in raw or any(ch.isspace() for ch in raw):
        return None
    if _has_protocol_noise(raw):
        return None
    ex = _extractors()
    canon = ex.canonical_text(raw)
    if not canon or len(canon) > MAX_TEXT_ANSWER_CHARS:
        return None
    return "text:" + canon


_STRUCT_MARKERS = ("\\begin{", "\\end{", "\\left", "\\right", "\\cup", "\\cap",
                   "\\pm", "\\infty", "\\pi", "\\matrix", "\\cases")


def _looks_structural(canon: str) -> bool:
    """内部是否仍含结构标记（决定外层包裹是否算冗余）。"""
    if any(m in canon for m in _STRUCT_MARKERS):
        return True
    if "=" in canon:
        return True
    return bool(re.search(r"[\[\(\{][^\]\)\}]*,[^\]\)\}]*[\]\)\}]", canon))


def struct_key(span: str) -> Optional[str]:
    r"""结构化答案键：区间、矩阵、方程、多解等。

    只在片段**确实含结构性标记**时启用，避免把散文当答案：
      * 含 `=`（等式或未约简的赋值）
      * 含 CSV 类的 LaTeX 环境或定界符命令（`\begin{}` / `\left[` / `\cup` …）
      * 含逗号分隔且被括号包裹（区间 `[a, b]`、多解 `(1, 2)`）

    键在**同一冻结规范化**（`canonical_text`）下生成，并额外做两件**书写层**归一化：

      1. 全局剥掉数学模式定界符 `\(` `\)` `\[` `\]`。
         它们只表示"这里是公式"，不含数学含义；真实模型经常只包住其中一段
         （例如 `\(-\infty,1\)\cup...`），不剥会把同一集合判成不同类。
      2. 剥掉整体冗余包裹的 `\left( ... \right)` / `( ... )`（只剥一层）。

    不做任何语义化简。
    """
    s = _strip_wrapping(span)
    if not s:
        return None
    ex = _extractors()
    canon = ex.canonical_text(s)
    if not canon or len(canon) > 400:
        return None
    for tok in ("\\(", "\\)", "\\[", "\\]"):
        canon = canon.replace(tok, "")
    # 只在**内部仍含结构标记**时才剥外层包裹：
    # 否则 `(1, 2)` 这种坐标/多解会被剥成 `1,2`，与它自身不再同一键。
    stripped = _strip_outer_wrapper(canon)
    if stripped != canon and _looks_structural(stripped):
        canon = stripped
    has_any_marker = any(m in canon for m in _STRUCT_MARKERS)
    has_eq = "=" in canon
    # 括号包裹 + 顶层逗号（区间 / 多解 / 坐标）
    bracketed_csv = bool(re.search(r"[\[\(\{][^\]\)\}]*,[^\]\)\}]*[\]\)\}]", canon))
    if not (has_any_marker or has_eq or bracketed_csv):
        return None
    return "struct:" + canon


def _strip_outer_wrapper(canon: str) -> str:
    """剥掉整体包裹的 `\\left( ... \\right)` 或 `( ... )`（只剥一层）。

    判定：首部是开括号（含 `\\left(` / `\\(` 等写法），与之配对的闭括号正好是末尾。
    """
    s = canon
    prefixes = (
        ("\\left(", "\\right)"),
        ("\\left[", "\\right]"),
        ("\\(", "\\)"),
        ("\\[", "\\]"),
        ("(", ")"),
        ("[", "]"),
    )
    for left, right in prefixes:
        if s.startswith(left) and s.endswith(right):
            inner = s[len(left):-len(right)]
            if _balanced(inner):
                return inner
    return s


def _balanced(s: str) -> bool:
    depth = 0
    for ch in s:
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
            if depth < 0:
                return False
    return depth == 0


def answer_key(span: str) -> Tuple[Optional[str], str]:
    """把答案片段转成类别键。返回 (key, kind)，key=None 表示无法归类。

    优先顺序：数值 → 符号 → 结构化 → 字面。
    先按冻结口径做赋值约简：`x = 5`（右侧是纯值、且变量不在右侧出现）→ `5`；
    `y = \\frac{1}{2} x + 2` 这类右侧仍有变量的等式进 struct 键，保持为独立类别。
    """
    ex = _extractors()
    s = _strip_wrapping(span)
    if s:
        try:
            canon_before = ex.canonical_text(s)
            reduced, _lhs = ex.strip_assignment(canon_before)
            if reduced and reduced != canon_before:
                s = reduced
        except Exception:  # noqa: BLE001 - 约简失败不影响后续判定
            pass
    nk = number_key(s)
    if nk:
        return nk, "numeric"
    sk = symbolic_key(s)
    if sk:
        return sk, "symbolic"
    stk = struct_key(s)
    if stk:
        return stk, "structured"
    tk = text_key(s)
    if tk:
        return tk, "text"
    return None, "unclassifiable"


# ---------------------------------------------------------------- 主入口
def parse_answer_attempt(text: str, *, finish_reason: str = "stop",
                         expected_source: str = "gsm8k") -> AnswerRecord:
    """解析一次模型输出，给出是否有效、类别键与原因。

    `expected_source` 只影响对"未加标记"的宽容度（GSM8K 允许 `####`，
    MATH 更依赖 boxed），不读取任何 gold。
    """
    ex = _extractors()
    if text is None or not str(text).strip():
        return AnswerRecord(key=None, valid=False, reason="empty_content",
                            raw_span="", span_source="empty")
    raw = str(text)
    span, source = ex.extract_answer_span(raw)
    span = _strip_wrapping(span or "")
    markers = _count_markers(raw)
    # 同一输出里出现多次"最终答案"标记即视为冲突：即便写法相同，也说明模型给了
    # 多个候选位置。取最后一个（与 extract_answer_span 一致）并标记，评分侧可转人工。
    conflicting = markers > 1

    if source == "empty" or not span:
        return AnswerRecord(key=None, valid=False, reason="no_span",
                            raw_span=span, span_source=source,
                            conflicting_markers=conflicting)

    if finish_reason == "length" and source in ("last_line", "whole"):
        # 截断且没有显式标记：不能确定这是最终答案
        return AnswerRecord(key=None, valid=False,
                            reason="truncated_without_final_marker",
                            raw_span=span, span_source=source,
                            conflicting_markers=conflicting)

    key, kind = answer_key(span)
    if key is None:
        return AnswerRecord(key=None, valid=False, reason="unclassifiable_output",
                            raw_span=span, span_source=source,
                            conflicting_markers=conflicting,
                            detail={"marker_count": markers})

    detail: Dict[str, Any] = {"kind": kind, "marker_count": markers}
    if source == "whole":
        # 整串被当作答案：只在它是短字面时可信，已在 text_key 的长度限制内
        detail["whole_text_answer"] = True
    return AnswerRecord(key=key, valid=True, reason="ok", raw_span=span,
                        span_source=source, conflicting_markers=conflicting,
                        detail=detail)


def alias_of(key: str) -> str:
    """键的展示形式（去掉 num: 前缀的内部有理数表示）。"""
    if key.startswith("num:"):
        from fractions import Fraction
        body = key[4:]
        if body.startswith("float:"):
            return body[6:]
        try:
            f = Fraction(body)
            if f.denominator == 1:
                return str(f.numerator)
            return f"{f.numerator}/{f.denominator}"
        except (ValueError, ZeroDivisionError):
            return body
    return key.split(":", 1)[-1]


def keys_equivalent(a: Optional[str], b: Optional[str]) -> bool:
    """两个键是否同一类别（严格相等；不做近似合并）。"""
    return a is not None and a == b


def vote_key_or_none(record: AnswerRecord) -> Optional[str]:
    """供 ASC 核心使用的投票键：无效返回 None（消耗尝试但不投票）。"""
    return record.key if record.valid else None
