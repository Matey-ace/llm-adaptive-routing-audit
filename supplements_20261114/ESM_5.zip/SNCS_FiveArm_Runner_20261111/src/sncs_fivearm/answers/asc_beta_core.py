"""Offline ASC stopping mechanism for a planned eight-attempt API adaptation.

Independent implementation of the published top-two Beta stopping rule.
No model client, prompts, reference answers, networking, or live runner.
Answer normalization must be supplied by the future shared answer extractor.
"""
from collections import Counter
from fractions import Fraction
from itertools import islice
from math import comb

def top_two_confidence(top,second=0):
    if not isinstance(top,int) or not isinstance(second,int) or top<1 or second<0 or second>top:
        raise ValueError('Counts must be integers with top >= 1 and 0 <= second <= top')
    a,b=top+1,second+1
    n=a+b-1
    return Fraction(sum(comb(n,k) for k in range(a)),2**n)

def summarize_attempts(normalized_keys,max_attempts=8,threshold=Fraction(95,100)):
    """None means extraction failed; it consumes an attempt but casts no vote.

    Tie fallback is the earliest observed tied key, explicitly a local adapter
    policy. No Bayesian sampling or correctness guarantee is asserted.
    """
    if max_attempts<1 or not 0<threshold<1:raise ValueError('Invalid stopping parameters')
    counts=Counter();first={};history=[]
    for attempt,key in enumerate(islice(normalized_keys,max_attempts),1):
        if key is not None:
            if not isinstance(key,str) or not key:raise ValueError('A normalized answer key must be a nonempty string or None')
            first.setdefault(key,attempt);counts[key]+=1
        ranked=sorted(counts,key=lambda x:(-counts[x],first[x]))
        conf=top_two_confidence(counts[ranked[0]],counts[ranked[1]] if len(ranked)>1 else 0) if ranked else Fraction(0)
        history.append({'attempt':attempt,'valid':key is not None,'confidence':float(conf)})
        if conf>=threshold:return {'attempts':attempt,'selected_key':ranked[0],'stop_reason':'asc_beta_threshold','posterior_top_two':float(conf),'history':history}
    used=len(history)
    return {'attempts':used,'selected_key':ranked[0] if counts else None,'stop_reason':'attempt_cap' if used==max_attempts else 'fixture_inputs_exhausted','posterior_top_two':float(conf) if history else 0.,'history':history}
