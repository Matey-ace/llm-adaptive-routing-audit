"""ASC-Beta-8 适配器：把已发表 top-two Beta 停止规则接到逐次真实派发。

机制（固定，不允许为新结果调整）：

* 领先类别计数 a、第二高频计数 b；后验 Beta(a+1, b+1)；P(X > 1/2) >= 0.95 即停。
  b 是**第二高频类别**的计数，不是其余所有类别之和。
* 三个同答 q = 15/16 = 0.9375 < 0.95 → 继续；四个同答 q = 31/32 = 0.96875 → 可最早停止。
* 最多 8 次**实际派发**（含失败尝试）；每次都是新会话，后一次解题**不含**前一次候选答案。
* 不预先并行发出全部样本：必须逐次决策，命中阈值即停。
* 无效/空白/无合格最终答案的截断输出**消耗尝试但不投票**。
* 上限平票取最先出现的有效类别；全无有效答案 = 明确失败状态。

本模块只负责"何时再发一次、发几次、选谁"，实际派发与计费由 dispatcher 统一执行，
数学核心来自封存的 `asc_beta_core.py`（与准备包 SHA-256 一致，见 evidence）。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Callable, Dict, List, Optional

from . import AnswerRecord, alias_of, vote_key_or_none
from .asc_beta_core import summarize_attempts, top_two_confidence

THRESHOLD = Fraction(95, 100)
MAX_ATTEMPTS = 8

# 停止原因的四类分离（计划工作包 C 要求）
STOP_THRESHOLD = "asc_beta_threshold"
STOP_CAP = "attempt_cap"
STOP_BUDGET = "budget_stop"
STOP_SERVICE = "service_failure"
STOP_EXHAUSTED = "fixture_inputs_exhausted"


@dataclass
class AscAttempt:
    index: int
    record: AnswerRecord
    selected_key: Optional[str] = None
    confidence: Optional[float] = None
    note: str = ""

    def as_dict(self) -> Dict[str, Any]:
        return {
            "index": self.index,
            "valid": self.record.valid,
            "key": self.record.key,
            "key_alias": alias_of(self.record.key) if self.record.key else None,
            "reason": self.record.reason,
            "raw_span": self.record.raw_span,
            "span_source": self.record.span_source,
            "posterior_top_two": self.confidence,
            "note": self.note,
        }


@dataclass
class AscOutcome:
    """一次 ASC 轨迹的最终状态。"""

    attempts: int
    stop_reason: str
    selected_key: Optional[str]
    selected_raw_span: Optional[str]
    posterior_top_two: float
    history: List[Dict[str, Any]] = field(default_factory=list)
    valid_votes: int = 0
    invalid_attempts: int = 0
    early_stop_skipped_attempts: int = 0   # 因早停而**未**发出的次数

    def as_dict(self) -> Dict[str, Any]:
        return {
            "attempts": self.attempts,
            "stop_reason": self.stop_reason,
            "selected_key": self.selected_key,
            "selected_alias": alias_of(self.selected_key) if self.selected_key else None,
            "selected_raw_span": self.selected_raw_span,
            "posterior_top_two": self.posterior_top_two,
            "valid_votes": self.valid_votes,
            "invalid_attempts": self.invalid_attempts,
            "early_stop_skipped_attempts": self.early_stop_skipped_attempts,
            "history": self.history,
            "threshold": float(THRESHOLD),
            "max_attempts": MAX_ATTEMPTS,
        }


def sequential_confidence(keys: List[Optional[str]]) -> List[Optional[float]]:
    """逐步后验（与核心同口径），用于在每次派发后立即判断是否停。"""
    out: List[Optional[float]] = []
    seen: Dict[str, int] = {}
    first: Dict[str, int] = {}
    for i, k in enumerate(keys, 1):
        if k is not None:
            seen[k] = seen.get(k, 0) + 1
            first.setdefault(k, i)
        ranked = sorted(seen, key=lambda x: (-seen[x], first[x]))
        if not ranked:
            out.append(0.0)
        else:
            top = seen[ranked[0]]
            second = seen[ranked[1]] if len(ranked) > 1 else 0
            out.append(float(top_two_confidence(top, second)))
    return out


def should_stop_now(keys: List[Optional[str]]) -> tuple[bool, Optional[float]]:
    """每次派发后调用：是否已达阈值。"""
    confs = sequential_confidence(keys)
    if not confs:
        return False, None
    q = confs[-1]
    return (q is not None and q >= float(THRESHOLD)), q


class AscRunner:
    """逐次派发 + 停止判定。

    调用方（runner）提供一个 `draw(attempt_index) -> AnswerRecord` 回调，
    该回调内部必然经过共享 dispatcher（含预算门与 8 次门）。本类**不**自行调用模型。
    """

    def __init__(self, *, max_attempts: int = MAX_ATTEMPTS,
                 threshold: Fraction = THRESHOLD) -> None:
        if max_attempts < 1:
            raise ValueError("max_attempts 必须 >= 1")
        if not 0 < float(threshold) < 1:
            raise ValueError("threshold 必须在 (0,1)")
        self.max_attempts = max_attempts
        self.threshold = threshold
        self.attempts: List[AscAttempt] = []

    def run(self, draw: Callable[[int], AnswerRecord], *,
            on_attempt: Optional[Callable[[AscAttempt], None]] = None,
            blocked: Optional[Callable[[int], Optional[str]]] = None) -> AscOutcome:
        """逐次采样直到停止。

        `blocked(i)` 返回非 None 表示"不应该再发第 i 次"（预算/上限/服务异常），
        该字符串作为停止原因；此时不做第 i 次派发。
        """
        keys: List[Optional[str]] = []
        stop_reason: Optional[str] = None
        for i in range(1, self.max_attempts + 1):
            if blocked is not None:
                why = blocked(i)
                if why:
                    stop_reason = why
                    break
            record = draw(i)
            keys.append(vote_key_or_none(record))
            stop, q = should_stop_now(keys)
            attempt = AscAttempt(index=i, record=record,
                                 selected_key=keys[0] if keys else None,
                                 confidence=q)
            self.attempts.append(attempt)
            if on_attempt is not None:
                on_attempt(attempt)
            if stop:
                stop_reason = STOP_THRESHOLD
                break
        if stop_reason is None:
            stop_reason = STOP_CAP if len(keys) >= self.max_attempts else STOP_EXHAUSTED
        summary = summarize_attempts(keys, max_attempts=self.max_attempts,
                                     threshold=self.threshold)
        selected = summary.get("selected_key")
        raw_span = None
        if selected is not None:
            for a in self.attempts:
                if a.record.valid and a.record.key == selected:
                    raw_span = a.record.raw_span
                    break
        valid_votes = sum(1 for k in keys if k is not None)
        not_sent = self.max_attempts - len(keys)
        return AscOutcome(
            attempts=len(keys),
            stop_reason=stop_reason,
            selected_key=selected,
            selected_raw_span=raw_span,
            posterior_top_two=float(summary.get("posterior_top_two") or 0.0),
            history=[a.as_dict() for a in self.attempts],
            valid_votes=valid_votes,
            invalid_attempts=len(keys) - valid_votes,
            early_stop_skipped_attempts=not_sent if stop_reason == STOP_THRESHOLD else 0,
        )


def final_answer_text(outcome: AscOutcome, attempts: List[AscAttempt]) -> str:
    """最终答案：选中所属类别的**原始回答片段**，不是规范化字符串。"""
    if outcome.selected_key is None:
        return ""
    for a in attempts:
        if a.record.valid and a.record.key == outcome.selected_key:
            return a.record.raw_span
    return ""
