"""run 编排：按队列顺序执行轨迹，落盘事件、结果与状态表。

关键规则：

* 单进程、单 worker、同题五臂按排定顺序串行（v1 明确不做跨题并发）。
* 每条轨迹的唯一 claim，已 claim 未终态 → 隔离为 reconciliation_required，不重发。
* 预算拒绝（BudgetBlocked）写成 budget_blocked 终态，**不伪装成已派发**；
  后续轨迹继续尝试（下一题可能更便宜），但阶段额度已满时整体停下并写 `not_started`。
* 生成进程只接触 prompt store；本模块不导入 gold 相关模块。
"""

from __future__ import annotations

import hashlib
import json
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

from . import RUNNER_ID
from .budget import Ledger, micro_to_cny
from .contracts import Contract
from .dispatcher import Dispatcher
from .errors import BudgetBlocked, DispatchLimitReached, RunLocked
from .inputs import InputBundle, QueueRow, estimate_input_tokens_upper
from .journal import Journal, RunLock, derive_trajectory_states, resume_plan
from .providers import Provider, SyntheticProvider
from .registry import FiveArmRegistry


def sha256_file(path: Path | str) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def code_fingerprint(package_root: Path | str) -> Dict[str, str]:
    root = Path(package_root)
    out: Dict[str, str] = {}
    for p in sorted(root.rglob("*.py")):
        if "__pycache__" in p.parts:
            continue
        out[str(p.relative_to(root)).replace("\\", "/")] = sha256_file(p)
    return out


@dataclass
class RunConfig:
    """一次运行的静态配置（全部进入 run 元信息，恢复时逐项核对）。"""

    run_id: str
    phase: str
    contract: Contract
    bundle: InputBundle
    queue: List[QueueRow]
    purpose: str = "experiment"     # experiment / smoke
    notes: str = ""
    workers: int = 1                # 跨题并发数；同题五臂始终串行


@dataclass
class RunSummary:
    run_id: str
    run_dir: Path
    planned: int
    completed: int = 0
    failed: int = 0
    budget_blocked: int = 0
    not_started: int = 0
    reconciliation_required: int = 0
    dispatches: int = 0
    known_charge_micro: int = 0
    unresolved_micro: int = 0
    status: str = "RUNNING"

    def as_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "run_dir": str(self.run_dir),
            "planned": self.planned,
            "completed": self.completed,
            "failed": self.failed,
            "budget_blocked": self.budget_blocked,
            "not_started": self.not_started,
            "reconciliation_required": self.reconciliation_required,
            "dispatches": self.dispatches,
            "known_charge_micro": self.known_charge_micro,
            "known_charge_cny": micro_to_cny(self.known_charge_micro),
            "unresolved_exposure_micro": self.unresolved_micro,
            "unresolved_exposure_cny": micro_to_cny(self.unresolved_micro),
            "status": self.status,
        }


class Runner:
    """执行一次 run（新建或续跑）。"""

    def __init__(self, *, config: RunConfig, provider: Provider,
                 runs_root: Path | str, package_root: Path | str) -> None:
        self.cfg = config
        self.provider = provider
        self.runs_root = Path(runs_root)
        self.package_root = Path(package_root)
        self.run_dir = self.runs_root / config.run_id
        self.journal_path = self.run_dir / "journal.jsonl"
        self.results_path = self.run_dir / "results.jsonl"
        self.summary_path = self.run_dir / "summary.json"
        self._summary = RunSummary(run_id=config.run_id, run_dir=self.run_dir,
                                   planned=len(config.queue))
        self._state_lock = threading.RLock()
        self._results_lock = threading.RLock()
        self._halt = False

    # ------------------------------------------------------------------ 元信息
    def _run_meta(self) -> Dict[str, Any]:
        c = self.cfg.contract
        return {
            "runner_id": RUNNER_ID,
            "run_id": self.cfg.run_id,
            "phase": self.cfg.phase,
            "purpose": self.cfg.purpose,
            "notes": self.cfg.notes,
            "execution_mode": c.mode,
            "contract_sha256": c.sha256,
            "contract_path": str(c.path),
            "contract_approved": c.approved,
            "contract_problems": list(c.problems),
            "provider": {
                "name": c.get("provider.name") or getattr(self.provider, "name", "unknown"),
                "model_id": c.get("provider.model_id"),
                "base_url": c.get("provider.base_url"),
                "thinking": c.get("provider.thinking"),
                "sampling": c.sampling(),
            },
            "limits": c.get("limits"),
            "tariff": c.get("tariff"),
            "budget": c.get("budget"),
            "input_fingerprints": self.cfg.bundle.fingerprints,
            "queue_size": len(self.cfg.queue),
            "distinct_tasks": len({r.task_id for r in self.cfg.queue}),
            "code_fingerprint": code_fingerprint(self.package_root),
            "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }

    def _assert_resume_consistent(self, events: Sequence[Dict[str, Any]]) -> None:
        for ev in events:
            if ev["event"] == "run_started":
                old = ev
                new = self._run_meta()
                for key in ("contract_sha256", "phase", "provider", "input_fingerprints",
                            "queue_size", "distinct_tasks"):
                    if json.dumps(old.get(key), sort_keys=True) != json.dumps(new.get(key),
                                                                             sort_keys=True):
                        raise RunLocked(
                            f"恢复被拒：{key} 与原始 run 不一致；同一 run_id 不跨版本重用")
                return

    # ------------------------------------------------------------------ 主流程
    def execute(self) -> RunSummary:
        self.run_dir.mkdir(parents=True, exist_ok=True)
        with RunLock(self.run_dir):
            journal = Journal(self.journal_path)
            existing = journal.read_all()
            if existing:
                self._assert_resume_consistent(existing)
                self._summary.status = "RESUMED"
            else:
                journal.append("run_started", **self._run_meta())

            c = self.cfg.contract
            ledger = Ledger.from_events(
                existing, currency=str(c.get("budget.currency", "CNY")),
                total_cap_micro=c.total_cap_micro,
                phase_caps_micro={p: c.phase_cap_micro(p)
                                  for p in ("preflight", "main")},
                price_in_micro_per_million=c.price_in_micro(),
                price_out_micro_per_million=c.price_out_micro())
            dispatcher = Dispatcher(
                journal=journal, ledger=ledger, provider=self.provider, contract=c,
                output_ceiling=c.output_ceiling, sampling=c.sampling(),
                input_bound_method=c.input_bound_method)

            # 恢复：把已派发次数回填，保证 8 次门不被重置
            states = derive_trajectory_states(existing)
            for rid, st in states.items():
                dispatcher.seed_dispatch_count(rid, st.dispatches)

            plan = resume_plan(existing, [r.run_id for r in self.cfg.queue])
            blocked_ids = {b["run_id"] for b in plan["blocked_requires_reconciliation"]}
            for rid in blocked_ids:
                journal.append("reconciliation_required", run_id=rid,
                               phase=self.cfg.phase, request_id=None,
                               reason="orphan_dispatch_no_terminal_state",
                               exposure_micro=0)
                self._summary.reconciliation_required += 1

            registry = FiveArmRegistry(dispatcher=dispatcher, contract=c,
                                       verify_router=(c.mode != "offline_simulation"))
            self._summary.status = "RUNNING"
            workers = max(1, int(self.cfg.workers))
            if workers > 1:
                self._loop_concurrent(registry=registry, journal=journal,
                                      dispatcher=dispatcher, plan=plan,
                                      workers=workers)
            else:
                self._loop(registry=registry, journal=journal, dispatcher=dispatcher,
                           plan=plan)
            self._summary.dispatches = len(dispatcher.records)
            self._summary.known_charge_micro = ledger.known_charge_micro
            self._summary.unresolved_micro = ledger.unresolved_exposure_micro
            if self._summary.not_started:
                self._summary.status = ("STOPPED_WITH_UNRESOLVED_EXPOSURE"
                                        if ledger.unresolved_exposure_micro else "INCOMPLETE")
            elif ledger.unresolved_exposure_micro:
                self._summary.status = "STOPPED_WITH_UNRESOLVED_EXPOSURE"
            else:
                self._summary.status = "COMPLETE"
            journal.append("run_finished", run_id=self.cfg.run_id,
                           status=self._summary.status,
                           ledger=ledger.state().as_dict(),
                           summary=self._summary.as_dict())
            self._write_summary(self._summary, ledger)
        return self._summary

    def _loop(self, *, registry: FiveArmRegistry, journal: Journal,
              dispatcher: Dispatcher, plan: Dict[str, Any]) -> None:
        resumable = set(plan["resumable"])
        since_budget_full = 0
        for row in self.cfg.queue:
            if row.run_id not in resumable:
                continue
            if self._halt:
                self._mark_not_started(journal, row, "phase_halted_after_budget_stop")
                continue
            status = self._process_row(row=row, registry=registry, journal=journal)
            if status == "budget_blocked":
                since_budget_full += 1
                if since_budget_full >= 5:
                    self._halt = True
                    self._mark_remaining_not_started(journal, after=row)
                    return
            else:
                since_budget_full = 0

    def _loop_concurrent(self, *, registry: FiveArmRegistry, journal: Journal,
                         dispatcher: Dispatcher, plan: Dict[str, Any],
                         workers: int) -> None:
        """跨题并发：同一题的五个臂仍按队列顺序串行，不同题并行。

        并发单位是一个 block（同题五臂），因此不会出现同题两臂同时执行，
        保持原有的顺序平衡设计。
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed

        resumable = [r for r in self.cfg.queue if r.run_id in set(plan["resumable"])]
        blocks: List[List[QueueRow]] = []
        current: List[QueueRow] = []
        for row in resumable:
            if current and row.block_id != current[-1].block_id:
                blocks.append(current)
                current = []
            current.append(row)
        if current:
            blocks.append(current)

        def run_block(block: List[QueueRow]) -> List[str]:
            out: List[str] = []
            for row in block:
                if self._halt:
                    self._mark_not_started(journal, row, "phase_halted_after_budget_stop")
                    out.append("not_started")
                    continue
                out.append(self._process_row(row=row, registry=registry,
                                             journal=journal))
            return out

        offset = 0
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(run_block, b): i for i, b in enumerate(blocks)}
            for fut in as_completed(futures):
                statuses = fut.result()
                if statuses.count("budget_blocked") >= len(statuses):
                    # 整题五臂都无法支付：停止接收新块
                    if not self._halt:
                        self._halt = True
                        self._mark_remaining_not_started(journal,
                                                         after=blocks[futures[fut]][-1])
                offset += len(statuses)

    # ------------------------------------------------------------------ 单行处理
    def _process_row(self, *, row: QueueRow, registry: FiveArmRegistry,
                     journal: Journal) -> str:
        journal.append("claim", run_id=row.run_id, phase=row.phase,
                       task_id=row.task_id, strategy=row.strategy,
                       sequence=row.sequence)
        task = self.cfg.bundle.prompt_for(row.task_id)
        try:
            outcome = registry.run_trajectory(strategy=row.strategy, task=task,
                                              run_id=row.run_id, phase=row.phase)
        except Exception as exc:  # noqa: BLE001 - 任何异常都必须留痕
            journal.append("failed", run_id=row.run_id, phase=row.phase,
                           reason="runner_exception",
                           error=f"{type(exc).__name__}: {exc}")
            with self._state_lock:
                self._summary.failed += 1
            return "failed"

        rec = {
            "run_id": row.run_id,
            "sequence": row.sequence,
            "phase": row.phase,
            "task_id": row.task_id,
            "source": row.source,
            "sampling_stratum": row.sampling_stratum,
            "prompt_sha256": row.prompt_sha256,
            "strategy": row.strategy,
            "execution_position": row.execution_position,
            "block_id": row.block_id,
            "repeat_id": row.repeat_id,
            "outcome": outcome.as_dict(),
            "recorded_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        self._append_result(rec)

        if outcome.stop_reason == "budget_blocked":
            journal.append("budget_blocked", run_id=row.run_id, phase=row.phase,
                           reason="insufficient_budget_before_trajectory",
                           dispatched=False)
            with self._state_lock:
                self._summary.budget_blocked += 1
            return "budget_blocked"
        if outcome.error:
            journal.append("failed", run_id=row.run_id, phase=row.phase,
                           reason=outcome.stop_reason, error=outcome.error)
            with self._state_lock:
                self._summary.failed += 1
            return "failed"
        journal.append("completed", run_id=row.run_id, phase=row.phase,
                       stop_reason=outcome.stop_reason,
                       dispatches=outcome.dispatches,
                       final_answer=outcome.final_answer,
                       answer_record=outcome.answer_record)
        with self._state_lock:
            self._summary.completed += 1
        return "completed"

    # ------------------------------------------------------------------ 停止标记
    def _mark_not_started(self, journal: Journal, row: QueueRow, reason: str) -> None:
        journal.append("not_started", run_id=row.run_id, phase=row.phase,
                       reason=reason)
        with self._state_lock:
            self._summary.not_started += 1

    def _mark_remaining_not_started(self, journal: Journal, *, after: QueueRow) -> None:
        seen = False
        for row in self.cfg.queue:
            if row.run_id == after.run_id:
                seen = True
                continue
            if seen:
                self._mark_not_started(journal, row, "phase_halted_after_budget_stop")

    def _halt_remaining(self, current: QueueRow) -> None:
        """向后兼容旧调用：仅计数（journal 由 _mark_remaining_not_started 写）。"""
        seen = False
        for row in self.cfg.queue:
            if row.run_id == current.run_id:
                seen = True
                continue
            if seen:
                with self._state_lock:
                    self._summary.not_started += 1

    def _append_result(self, rec: Dict[str, Any]) -> None:
        with self._results_lock:
            with self.results_path.open("a", encoding="utf-8", newline="\n") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False, allow_nan=False,
                                    sort_keys=True) + "\n")
                fh.flush()

    def _write_summary(self, summary: RunSummary, ledger: Ledger) -> None:
        payload = {
            "summary": summary.as_dict(),
            "ledger": ledger.state().as_dict(),
            "by_purpose": _purpose_table(ledger),
        }
        tmp = self.summary_path.with_suffix(".json.pending")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.summary_path)


def _purpose_table(ledger: Ledger) -> Dict[str, Any]:
    return {"note": "按 purpose 的明细在 results.jsonl 与 journal.jsonl 中逐条可查",
            "known_charge_micro": ledger.known_charge_micro}


# ---------------------------------------------------------------- 离线模拟便捷入口
def offline_run_config(*, run_id: str, phase: str, contract: Contract,
                       bundle: InputBundle, queue: List[QueueRow],
                       purpose: str = "offline_simulation",
                       notes: str = "") -> RunConfig:
    return RunConfig(run_id=run_id, phase=phase, contract=contract,
                     bundle=bundle, queue=queue, purpose=purpose, notes=notes)
