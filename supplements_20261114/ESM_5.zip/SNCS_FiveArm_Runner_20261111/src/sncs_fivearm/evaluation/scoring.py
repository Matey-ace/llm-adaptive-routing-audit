"""评分：把一条轨迹的最终答案与 gold 比较，三分而不是二分。

三分口径（主数据前冻结）：

    correct    预测键与 gold 键相等（同一冻结的 answers 政策）
    incorrect  明确不等
    unknown    无法自动判定 → needs_review，**不默认判错，也不默认判对**

`unknown` 的典型来源：
  * 轨迹没有有效最终答案（空、截断、全无效 ASC 采样）；
  * 预测或 gold 无法归入 num/sym/text 任一类键；
  * 预测是多解/集合且与 gold 结构不可比。

区间计算时 unknown 同时给悲观(0)/乐观(1)两界（见 stats）。
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

from .. import answers as answers_mod
from . import SCORE_SCHEMA_VERSION
from .gold import GoldItem

# 评分版本：修改比较语义必须递增，并写进每条 score 记录
COMPARATOR_VERSION = "comparator-20261111.1"


@dataclass(frozen=True)
class ScoreResult:
    task_id: str
    run_id: str
    strategy: str
    decision: str            # correct / incorrect / unknown
    reason: str
    predicted_key: Optional[str]
    gold_key: Optional[str]
    predicted_span: str
    gold_span: str
    needs_review: bool
    comparator_version: str = COMPARATOR_VERSION
    score_schema_version: str = SCORE_SCHEMA_VERSION

    @property
    def value(self) -> Optional[int]:
        """0/1，unknown 返回 None。"""
        return {"correct": 1, "incorrect": 0}.get(self.decision)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "run_id": self.run_id,
            "strategy": self.strategy,
            "decision": self.decision,
            "value": self.value,
            "reason": self.reason,
            "predicted_key": self.predicted_key,
            "gold_key": self.gold_key,
            "predicted_span": self.predicted_span,
            "gold_span": self.gold_span,
            "needs_review": self.needs_review,
            "comparator_version": self.comparator_version,
            "score_schema_version": self.score_schema_version,
        }


def score_one(*, task_id: str, run_id: str, strategy: str,
              final_answer: str, gold: GoldItem,
              finish_reason: str = "stop") -> ScoreResult:
    """比较单条轨迹。不修改任何输入，不写文件。"""
    gold_span, gold_src = answers_mod._extractors().extract_answer_span(gold.gold_text)
    gold_key, gold_kind = answers_mod.answer_key(gold_span)

    pred = answers_mod.parse_answer_attempt(final_answer, finish_reason=finish_reason)
    if not pred.valid:
        return ScoreResult(
            task_id=task_id, run_id=run_id, strategy=strategy,
            decision="unknown", reason=f"prediction_invalid:{pred.reason}",
            predicted_key=None, gold_key=gold_key,
            predicted_span=pred.raw_span, gold_span=gold_span,
            needs_review=True)

    if gold_key is None:
        return ScoreResult(
            task_id=task_id, run_id=run_id, strategy=strategy,
            decision="unknown", reason="gold_unclassifiable",
            predicted_key=pred.key, gold_key=None,
            predicted_span=pred.raw_span, gold_span=gold_span,
            needs_review=True)

    if pred.key == gold_key:
        return ScoreResult(
            task_id=task_id, run_id=run_id, strategy=strategy,
            decision="correct", reason=f"key_equal:{gold_kind}",
            predicted_key=pred.key, gold_key=gold_key,
            predicted_span=pred.raw_span, gold_span=gold_span,
            needs_review=False)

    # 类型不同但可能等价的情形：交给旧 compare_answers 做第二道判定；
    # 它返回 needs_review 时我们保持 unknown，不把"相近"当"相等"。
    ex = answers_mod._extractors()
    ok, needs_review, reason = ex.compare_answers(gold_span, pred.raw_span)
    if ok:
        return ScoreResult(
            task_id=task_id, run_id=run_id, strategy=strategy,
            decision="correct", reason=f"compare_answers:{reason}",
            predicted_key=pred.key, gold_key=gold_key,
            predicted_span=pred.raw_span, gold_span=gold_span,
            needs_review=False)
    if needs_review:
        return ScoreResult(
            task_id=task_id, run_id=run_id, strategy=strategy,
            decision="unknown", reason=f"needs_review:{reason}",
            predicted_key=pred.key, gold_key=gold_key,
            predicted_span=pred.raw_span, gold_span=gold_span,
            needs_review=True)
    return ScoreResult(
        task_id=task_id, run_id=run_id, strategy=strategy,
        decision="incorrect", reason=f"compare_answers:{reason}",
        predicted_key=pred.key, gold_key=gold_key,
        predicted_span=pred.raw_span, gold_span=gold_span,
        needs_review=False)


def score_run(*, results_path: Path | str, gold: Dict[str, GoldItem],
              out_path: Path | str, source_sha256: str) -> Dict[str, Any]:
    """对一次 run 的全部结果评分，写一个新的 score 版本文件。

    绝不覆盖原始 results.jsonl 或旧 score 文件（调用方给新文件名）。
    """
    import hashlib
    from collections import Counter

    src = Path(results_path)
    out = Path(out_path)
    if out.exists():
        raise FileExistsError(
            f"评分文件已存在：{out}；评分版本必须另存，不覆盖旧分数")
    out.parent.mkdir(parents=True, exist_ok=True)

    counts: Counter = Counter()
    n = 0
    tmp = out.with_suffix(out.suffix + ".pending")
    with tmp.open("w", encoding="utf-8", newline="\n") as fh:
        for line in src.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            rec = json.loads(line)
            outcome = rec.get("outcome") or {}
            task_id = str(rec["task_id"])
            if task_id not in gold:
                raise KeyError(f"gold 中没有 {task_id}")
            res = score_one(task_id=task_id, run_id=str(rec["run_id"]),
                            strategy=str(rec["strategy"]),
                            final_answer=str(outcome.get("final_answer") or ""),
                            gold=gold[task_id])
            payload = {
                "run_id": rec["run_id"],
                "task_id": task_id,
                "source": rec.get("source"),
                "strategy": rec["strategy"],
                "execution_position": rec.get("execution_position"),
                "score": res.as_dict(),
                "source_results_sha256": source_sha256,
            }
            fh.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
            counts[res.decision] += 1
            n += 1
        fh.flush()
    tmp.replace(out)
    return {
        "scored_rows": n,
        "counts": dict(counts),
        "unknown_rate": (counts["unknown"] / n) if n else None,
        "path": str(out),
        "sha256": hashlib.sha256(out.read_bytes()).hexdigest(),
        "comparator_version": COMPARATOR_VERSION,
        "score_schema_version": SCORE_SCHEMA_VERSION,
        "source_results": str(src),
        "source_results_sha256": source_sha256,
    }
