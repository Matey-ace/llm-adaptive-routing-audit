"""评分与统计工具（主数据前封存）。

模块划分：

* `gold`      —— **唯一**读取 gold 的模块；只在评分进程里被导入。
* `scoring`   —— 用冻结的 answers 政策把一次预测与 gold 比较，三分：correct /
                 incorrect / unknown(needs_review)，并给出原因码与版本。
* `stats`     —— 以**题**为单位的配对分析：discordant 计数、精确区间、
                 McNemar 精确检验、缺失带来的识别界、cluster bootstrap。
* `blind`     —— 盲评包生成：随机编号、隐藏方法名/顺序/提示/推理/token/费用。
* `analysis`  —— 从已评分结果生成表格与 JSON 报告。

分层纪律：生成路径不导入本包的任何模块。
"""

from __future__ import annotations

SCORE_SCHEMA_VERSION = "scoring-20261111.1"
ANALYSIS_PLAN_VERSION = "analysis-plan-20261111.1"

__all__ = ["SCORE_SCHEMA_VERSION", "ANALYSIS_PLAN_VERSION"]
