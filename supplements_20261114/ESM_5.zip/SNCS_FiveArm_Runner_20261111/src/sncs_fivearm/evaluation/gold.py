"""gold 存储：评分进程专用的最小读取器。

设计约束（结构性隔离）：

1. 本模块只被 `evaluation.scoring` / `evaluation.blind` / `evaluation.analysis` 导入；
   生成路径（registry / dispatcher / runner / strategies）不导入它。
   `tests/test_isolation.py` 通过 AST 扫描强制这一条。
2. gold 只从原始 parquet 的**答案列**读取，按 (source_file, source_row) 定位，
   并核对题面哈希与清单一致；不使用任何已存在的 gold 中间文件。
3. 读取时只取需要的行，不整体物化答案列到内存（GSM8K 只有 1319 行，MATH 分文件）。
4. 返回的 `GoldItem` 只含 `task_id` / `gold_text` / `metric` / `source`，
   不携带 prompt 正文（评分包另有题面来源）。

口径：
* GSM8K：官方 `answer` 列形如 "推理... #### 1234"，取 `####` 之后。
* MATH：官方 `solution` 列，取最后一个 `\\boxed{...}`，否则取最后一行。
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence

from ..errors import InputIntegrityError
from ..inputs import sha256_text


@dataclass(frozen=True)
class GoldItem:
    task_id: str
    source: str
    gold_text: str
    metric: str

    def as_dict(self) -> Dict[str, str]:
        return {"task_id": self.task_id, "source": self.source,
                "gold_text": self.gold_text, "metric": self.metric}


def _read_parquet_column(path: Path, column: str, rows: Sequence[int]) -> Dict[int, str]:
    import pyarrow.parquet as pq

    table = pq.read_table(path, columns=[column])
    col = table[column]
    out: Dict[int, str] = {}
    for r in rows:
        if r < 0 or r >= table.num_rows:
            raise InputIntegrityError(f"{path} 行号 {r} 越界（共 {table.num_rows} 行）")
        out[int(r)] = col[int(r)].as_py()
    return out


def gsm8k_gold(answer_text: str) -> str:
    if answer_text is None:
        return ""
    s = str(answer_text)
    if "####" in s:
        return s.split("####")[-1].strip()
    lines = [ln.strip() for ln in s.splitlines() if ln.strip()]
    return lines[-1] if lines else s.strip()


def math_gold(solution_text: str) -> str:
    if solution_text is None:
        return ""
    s = str(solution_text)
    idx = s.rfind("\\boxed{")
    if idx != -1:
        start = idx + len("\\boxed{")
        depth = 0
        for i in range(start, len(s)):
            ch = s[i]
            if ch == "{":
                depth += 1
            elif ch == "}":
                if depth == 0:
                    return s[start:i].strip()
                depth -= 1
    lines = [ln.strip() for ln in s.splitlines() if ln.strip()]
    return lines[-1] if lines else s.strip()


def load_gold(manifest: Sequence[Dict[str, object]], *,
              workspace_root: Path | str,
              prompt_store: Optional[Dict[str, object]] = None,
              verify_prompt_hash: bool = True) -> Dict[str, GoldItem]:
    """按清单指针读取 gold。

    `manifest` 行必须含 `task_id / source / source_file / source_row / prompt_sha256`。
    `prompt_store` 提供 task_id -> prompt 文本，用于核对题面哈希（可选但推荐）。
    """
    root = Path(workspace_root)
    grouped: Dict[tuple, List[Dict[str, object]]] = {}
    for row in manifest:
        for key in ("task_id", "source", "source_file", "source_row", "prompt_sha256"):
            if key not in row:
                raise InputIntegrityError(f"清单行缺字段 {key}：{row.get('task_id')}")
        grouped.setdefault((str(row["source_file"]), str(row["source"])), []).append(row)

    out: Dict[str, GoldItem] = {}
    for (source_file, source), rows in grouped.items():
        path = (root / source_file).resolve()
        if not path.is_file():
            raise InputIntegrityError(f"源数据文件不存在: {path}")
        column = "answer" if source == "gsm8k" else "solution"
        prompt_col = "question" if source == "gsm8k" else "problem"
        row_ids = [int(r["source_row"]) for r in rows]
        golds = _read_parquet_column(path, column, row_ids)
        prompts = None
        if verify_prompt_hash and prompt_store is not None:
            prompts = _read_parquet_column(path, prompt_col, row_ids)
        for row in rows:
            rid = int(row["source_row"])
            if prompts is not None:
                expected = str(row["prompt_sha256"])
                stored = prompt_store.get(str(row["task_id"]))
                if stored is not None:
                    got = sha256_text(str(getattr(stored, "prompt", stored)))
                    if got != expected:
                        raise InputIntegrityError(
                            f"{row['task_id']} 题面哈希与清单不符")
                if sha256_text(str(prompts[rid])) != expected:
                    raise InputIntegrityError(
                        f"{row['task_id']} 源文件题面哈希与清单不符（源数据已变）")
            text = gsm8k_gold(golds[rid]) if source == "gsm8k" else math_gold(golds[rid])
            metric = "gsm8k_numeric" if source == "gsm8k" else "math_equiv"
            out[str(row["task_id"])] = GoldItem(
                task_id=str(row["task_id"]), source=source,
                gold_text=text, metric=metric)
    return out


def write_gold_snapshot(gold: Dict[str, GoldItem], path: Path | str,
                        *, manifest_sha256: str, note: str = "") -> Dict[str, object]:
    """把 gold 写成评分进程私有的快照（**不放进 run 目录**）。"""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema": "gold-snapshot-v1",
        "manifest_sha256": manifest_sha256,
        "note": note,
        "items": [g.as_dict() for g in gold.values()],
    }
    import hashlib
    tmp = p.with_suffix(p.suffix + ".pending")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)
    return {"path": str(p), "count": len(gold),
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
