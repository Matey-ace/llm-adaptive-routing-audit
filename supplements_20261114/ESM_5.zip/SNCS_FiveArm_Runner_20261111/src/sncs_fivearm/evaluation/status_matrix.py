"""计划轨迹的状态矩阵：每题 × 每臂一行，共 计划轨迹数 行。

状态口径（计划 §13）：

    not_started        未派发
    dispatched_unknown 派发结果未明（reconciliation_required）
    failed             已尝试但不可用
    scored_correct     可评分且判对
    scored_incorrect   可评分且判错
    unknown            已执行但无有效最终答案 / 无法自动判定
    budget_blocked     预算拒绝（未派发）

纪律：
* 以**队列**为分母，缺行也要出现（不删题）。
* 不把未启动伪装成答错。
* unknown 单独成清单，含原因码与原始片段。
"""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List, Sequence


def _load_jsonl(path: Path | str) -> List[Dict[str, Any]]:
    p = Path(path)
    if not p.is_file():
        return []
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def build_matrix(*, queue_rows: Sequence[Dict[str, Any]],
                 results_rows: Sequence[Dict[str, Any]],
                 scored_rows: Sequence[Dict[str, Any]],
                 journal_events: Sequence[Dict[str, Any]] = ()) -> List[Dict[str, Any]]:
    """逐 (task, strategy) 状态行，以队列顺序输出。"""
    res = {str(r["run_id"]): r for r in results_rows}
    sco = {str(r["run_id"]): r for r in scored_rows}
    terminal: Dict[str, str] = {}
    for e in journal_events:
        if e.get("event") in ("completed", "failed", "budget_blocked",
                              "not_started", "reconciliation_required"):
            rid = e.get("run_id")
            if rid:
                terminal[str(rid)] = str(e["event"])
    dispatches: Dict[str, int] = defaultdict(int)
    for e in journal_events:
        if e.get("event") == "dispatch_intent_durable" and e.get("run_id"):
            dispatches[str(e["run_id"])] += 1

    rows: List[Dict[str, Any]] = []
    for q in queue_rows:
        rid = str(q["run_id"])
        r = res.get(rid)
        s = sco.get(rid)
        outcome = (r or {}).get("outcome") or {}
        answer = outcome.get("answer_record") or {}
        decision = ((s or {}).get("score") or {}).get("decision")
        reason = ((s or {}).get("score") or {}).get("reason")

        if terminal.get(rid) == "not_started":
            status = "not_started"
        elif terminal.get(rid) == "budget_blocked":
            status = "budget_blocked"
        elif terminal.get(rid) == "reconciliation_required":
            status = "dispatched_unknown"
        elif terminal.get(rid) == "failed":
            status = "failed"
        elif r is None:
            status = "not_started"
        elif decision == "correct":
            status = "scored_correct"
        elif decision == "incorrect":
            status = "scored_incorrect"
        elif decision == "unknown":
            status = "unknown"
        elif outcome.get("error"):
            status = "failed"
        else:
            status = "unknown"

        rows.append({
            "task_id": str(q["task_id"]),
            "source": str(q.get("source") or ""),
            "strategy": str(q["strategy"]),
            "execution_position": q.get("execution_position"),
            "sequence": q.get("sequence"),
            "status": status,
            "score_decision": decision,
            "score_reason": reason,
            "dispatches": dispatches.get(rid, 0),
            "final_answer_present": bool(str(outcome.get("final_answer") or "").strip()),
            "answer_valid": bool(answer.get("valid")),
            "needs_review": bool(((s or {}).get("score") or {}).get("needs_review")),
            "stop_reason": outcome.get("stop_reason"),
        })
    return rows


def summarise(rows: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    """source × arm × status 计数，以及总量校验。"""
    by: Dict[str, Dict[str, Dict[str, int]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(int)))
    overall: Counter = Counter()
    for r in rows:
        by[r["source"]][r["strategy"]][r["status"]] += 1
        overall[r["status"]] += 1
    return {
        "n_rows": len(rows),
        "overall": dict(overall),
        "by_source_arm": {s: {a: dict(c) for a, c in arms.items()}
                          for s, arms in by.items()},
        "status_vocabulary": ["not_started", "budget_blocked", "dispatched_unknown",
                              "failed", "scored_correct", "scored_incorrect", "unknown"],
    }


def unknown_cases(rows: Sequence[Dict[str, Any]],
                  scored_rows: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """unknown 行 + 原始片段与原因码。"""
    sco = {str(r["run_id"]): r for r in scored_rows}
    out = []
    for r in rows:
        if r["status"] != "unknown":
            continue
        s = None
        for key, val in sco.items():
            if val.get("task_id") == r["task_id"] and val.get("strategy") == r["strategy"]:
                s = val
                break
        sc = (s or {}).get("score") or {}
        out.append({
            "task_id": r["task_id"], "source": r["source"],
            "strategy": r["strategy"], "reason": sc.get("reason"),
            "predicted_span": sc.get("predicted_span"),
            "gold_span": sc.get("gold_span"),
            "needs_review": sc.get("needs_review"),
            "final_answer_present": r["final_answer_present"],
        })
    return out


def write_outputs(*, run_dir: Path | str, rows: List[Dict[str, Any]],
                  summary: Dict[str, Any],
                  unknowns: List[Dict[str, Any]]) -> Dict[str, str]:
    d = Path(run_dir)
    d.mkdir(parents=True, exist_ok=True)
    m = d / "status_matrix.jsonl"
    s = d / "status_matrix_summary.json"
    u = d / "unknown_cases.jsonl"
    with m.open("w", encoding="utf-8", newline="\n") as fh:
        for r in rows:
            fh.write(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n")
    s.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    with u.open("w", encoding="utf-8", newline="\n") as fh:
        for r in unknowns:
            fh.write(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n")
    return {"matrix": str(m), "summary": str(s), "unknown": str(u)}
