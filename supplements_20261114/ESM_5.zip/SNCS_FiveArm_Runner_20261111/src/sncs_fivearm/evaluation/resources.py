"""资源账目：以 journal 为唯一真源，逐 purpose / 逐臂 / 逐题统计。

为什么不用 `outcome.steps`：
旧 Agent 的 `Step.detail` 不写 token；ASC 根本不产生 steps。
实测主筛查里 `usage_step_coverage=0`，用 steps 算 token 会得到全 0。
因此 token / 费用 / 派发数一律从 journal 的
`dispatch_intent_durable` + `response_received` + `usage_settled` 合并得到。

口径：
* 一次"调用" = 一个 `request_id`；
* `dispatched`：存在 intent 即算已派发（无论成功失败）；
* `settled`：存在 usage_settled → 已核；存在 reconciliation_required → 未决；
* 费用只在 `actual_micro` 有值时计入已核，缺失不填 0。
"""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


@dataclass
class CallRecord:
    """一个 request_id 的合并视图。"""

    request_id: str
    run_id: str = ""
    phase: str = ""
    purpose: str = ""
    dispatched: bool = False
    responded: bool = False
    settled: str = ""                 # settled / reconciliation_required / ""
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    actual_micro: Optional[int] = None
    bound_micro: Optional[int] = None
    finish_reason: str = ""
    error: Optional[str] = None
    may_have_billed: Optional[bool] = None
    model_reported: Optional[str] = None
    latency_ms: float = 0.0

    def as_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id, "run_id": self.run_id,
            "phase": self.phase, "purpose": self.purpose,
            "dispatched": self.dispatched, "responded": self.responded,
            "settled": self.settled,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "actual_micro": self.actual_micro,
            "bound_micro": self.bound_micro,
            "finish_reason": self.finish_reason,
            "error": self.error, "may_have_billed": self.may_have_billed,
            "model_reported": self.model_reported,
            "latency_ms": round(self.latency_ms, 3),
        }


def load_calls(journal_path: Path | str) -> List[CallRecord]:
    """把 journal 事件合并成逐调用记录（按首次出现顺序）。"""
    path = Path(journal_path)
    if not path.is_file():
        raise FileNotFoundError(f"journal 不存在: {path}")
    calls: Dict[str, CallRecord] = {}
    order: List[str] = []

    def get(rid: str) -> CallRecord:
        if rid not in calls:
            calls[rid] = CallRecord(request_id=rid)
            order.append(rid)
        return calls[rid]

    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        ev = json.loads(line)
        kind = ev.get("event")
        rid = ev.get("request_id")
        if not rid:
            continue
        rec = get(str(rid))
        if kind == "reservation_created":
            rec.run_id = str(ev.get("run_id") or rec.run_id)
            rec.phase = str(ev.get("phase") or rec.phase)
            rec.purpose = str(ev.get("purpose") or rec.purpose)
            rec.bound_micro = ev.get("bound_micro")
        elif kind == "dispatch_intent_durable":
            rec.dispatched = True
            rec.run_id = str(ev.get("run_id") or rec.run_id)
            rec.purpose = str(ev.get("purpose") or rec.purpose)
        elif kind == "response_received":
            rec.responded = True
            rec.finish_reason = str(ev.get("finish_reason") or "")
            rec.model_reported = ev.get("model_reported")
            rec.latency_ms = float(ev.get("latency_ms") or 0.0)
            if ev.get("prompt_tokens") is not None:
                rec.prompt_tokens = int(ev["prompt_tokens"])
            if ev.get("completion_tokens") is not None:
                rec.completion_tokens = int(ev["completion_tokens"])
        elif kind == "usage_settled":
            rec.settled = "settled"
            rec.actual_micro = ev.get("actual_micro")
            if ev.get("prompt_tokens") is not None:
                rec.prompt_tokens = int(ev["prompt_tokens"])
            if ev.get("completion_tokens") is not None:
                rec.completion_tokens = int(ev["completion_tokens"])
        elif kind == "reconciliation_required":
            rec.settled = "reconciliation_required"
        elif kind == "failed":
            rec.error = ev.get("error")
            rec.may_have_billed = ev.get("may_have_billed")
    return [calls[rid] for rid in order]


def run_to_arm(queue_rows: Sequence[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """run_id → 队列元信息（题、源、臂、位置）。"""
    return {
        str(r["run_id"]): {
            "task_id": str(r["task_id"]),
            "source": str(r.get("source") or ""),
            "strategy": str(r["strategy"]),
            "execution_position": r.get("execution_position"),
            "phase": str(r.get("phase") or ""),
        }
        for r in queue_rows
    }


def per_purpose(calls: Iterable[CallRecord]) -> Dict[str, Dict[str, Any]]:
    """逐 purpose 汇总。"""
    out: Dict[str, Dict[str, Any]] = {}
    for c in calls:
        slot = out.setdefault(c.purpose or "unknown", {
            "dispatches": 0, "responses": 0, "settled": 0,
            "unresolved": 0, "failed": 0,
            "prompt_tokens": 0, "completion_tokens": 0,
            "actual_micro": 0, "bound_micro": 0,
            "usage_missing": 0,
        })
        if c.dispatched:
            slot["dispatches"] += 1
        if c.responded:
            slot["responses"] += 1
        if c.settled == "settled":
            slot["settled"] += 1
        elif c.settled == "reconciliation_required":
            slot["unresolved"] += 1
        if c.error:
            slot["failed"] += 1
        if c.prompt_tokens is not None:
            slot["prompt_tokens"] += c.prompt_tokens
        elif c.dispatched:
            slot["usage_missing"] += 1
        if c.completion_tokens is not None:
            slot["completion_tokens"] += c.completion_tokens
        if c.actual_micro is not None:
            slot["actual_micro"] += int(c.actual_micro)
        if c.bound_micro is not None:
            slot["bound_micro"] += int(c.bound_micro)
    return dict(sorted(out.items()))


def per_arm(calls: Iterable[CallRecord],
            mapping: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """逐臂汇总（通过 run_id 映射到臂）。"""
    buckets: Dict[str, List[CallRecord]] = defaultdict(list)
    unknown_runs: Counter = Counter()
    for c in calls:
        meta = mapping.get(c.run_id)
        if meta is None:
            unknown_runs[c.run_id] += 1
            continue
        buckets[meta["strategy"]].append(c)
    out: Dict[str, Dict[str, Any]] = {}
    for arm, rows in sorted(buckets.items()):
        dispatched = sum(1 for c in rows if c.dispatched)
        prompt = sum(c.prompt_tokens for c in rows if c.prompt_tokens is not None)
        completion = sum(c.completion_tokens for c in rows
                         if c.completion_tokens is not None)
        out[arm] = {
            "dispatches": dispatched,
            "responses": sum(1 for c in rows if c.responded),
            "settled": sum(1 for c in rows if c.settled == "settled"),
            "unresolved": sum(1 for c in rows if c.settled == "reconciliation_required"),
            "failed": sum(1 for c in rows if c.error),
            "prompt_tokens": prompt,
            "completion_tokens": completion,
            "actual_micro": sum(int(c.actual_micro or 0) for c in rows),
            "usage_missing": sum(1 for c in rows if c.dispatched
                                 and c.prompt_tokens is None),
            "trajectories_with_dispatch": len({c.run_id for c in rows if c.dispatched}),
        }
    if unknown_runs:
        out["_unmapped_run_ids"] = {"count": len(unknown_runs),
                                    "sample": list(unknown_runs)[:5]}
    return out


def usage_coverage(calls: Sequence[CallRecord]) -> Dict[str, Any]:
    dispatched = [c for c in calls if c.dispatched]
    with_usage = [c for c in dispatched if c.prompt_tokens is not None
                  and c.completion_tokens is not None]
    return {
        "dispatched": len(dispatched),
        "with_complete_usage": len(with_usage),
        "coverage": (len(with_usage) / len(dispatched)) if dispatched else None,
        "missing_usage": len(dispatched) - len(with_usage),
    }


def per_task_arm(calls: Iterable[CallRecord],
                 mapping: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Dict[str, int]]]:
    """task_id → arm → 资源量（供配对 bootstrap）。"""
    out: Dict[str, Dict[str, Dict[str, int]]] = defaultdict(
        lambda: defaultdict(lambda: {"dispatches": 0, "prompt_tokens": 0,
                                     "completion_tokens": 0}))
    for c in calls:
        meta = mapping.get(c.run_id)
        if meta is None or not c.dispatched:
            continue
        slot = out[meta["task_id"]][meta["strategy"]]
        slot["dispatches"] += 1
        slot["prompt_tokens"] += int(c.prompt_tokens or 0)
        slot["completion_tokens"] += int(c.completion_tokens or 0)
    return {t: {a: dict(v) for a, v in arms.items()} for t, arms in out.items()}


def totals(calls: Sequence[CallRecord]) -> Dict[str, int]:
    return {
        "dispatches": sum(1 for c in calls if c.dispatched),
        "responses": sum(1 for c in calls if c.responded),
        "settled": sum(1 for c in calls if c.settled == "settled"),
        "unresolved": sum(1 for c in calls if c.settled == "reconciliation_required"),
        "failed": sum(1 for c in calls if c.error),
        "prompt_tokens": sum(c.prompt_tokens for c in calls
                             if c.prompt_tokens is not None),
        "completion_tokens": sum(c.completion_tokens for c in calls
                                 if c.completion_tokens is not None),
        "actual_micro": sum(int(c.actual_micro or 0) for c in calls),
    }


def assert_totals_match_summary(calls: Sequence[CallRecord],
                                summary: Dict[str, Any]) -> Dict[str, Any]:
    """与 summary.json 对账；不一致就抛错（不静默放过）。"""
    t = totals(calls)
    s = summary.get("summary", summary)
    checks = {
        "dispatches": (t["dispatches"], s.get("dispatches")),
        "known_charge_micro": (t["actual_micro"], s.get("known_charge_micro")),
        "unresolved": (t["unresolved"], s.get("reconciliation_required")),
        "failed": (t["failed"], s.get("failed")),
    }
    bad = {k: v for k, v in checks.items() if v[1] is not None and v[0] != v[1]}
    if bad:
        raise AssertionError(f"资源账目与 summary 不一致: {bad}")
    return {"ok": True, "totals": t, "checked": checks}
