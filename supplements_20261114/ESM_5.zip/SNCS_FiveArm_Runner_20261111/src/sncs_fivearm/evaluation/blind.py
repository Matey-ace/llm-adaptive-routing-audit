"""盲评包生成：随机编号、隐藏方法与一切可识别线索。

盲评包内容（每份一个 JSONL + 一份 PDF/MD 说明模板）：

    项目编号  B-0001 ...
    题目      prompt 正文
    提交答案  该轨迹的最终答案原文（**不含**推理过程）

明确**不**放进包里的：方法名、执行顺序、prompt、推理步骤、token、费用、run_id、
strategy、execution_position、stop_reason、ASC 采样数。

限制（必须登记在案）：输出文本本身可能暴露方法特征（例如反思残留格式），
盲法**不可能**完全；这一点写进 `protocol/Blinding_And_Scoring_Protocol.md`。
映射表单独保存，只有统计侧持有。
"""

from __future__ import annotations

import hashlib
import json
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence


@dataclass
class BlindEntry:
    blind_id: str
    task_id: str
    source: str
    prompt: str
    submitted_answer: str

    def as_public(self) -> Dict[str, str]:
        return {
            "blind_id": self.blind_id,
            "task_id": self.task_id,      # 题号本身不泄漏方法，保留以便核对
            "source": self.source,
            "prompt": self.prompt,
            "submitted_answer": self.submitted_answer,
        }


def build_blind_package(*, results_rows: Sequence[Dict[str, Any]],
                        prompts: Dict[str, Any],
                        seed: int = 20261111,
                        arms: Optional[Sequence[str]] = None,
                        include_unknown: bool = True) -> Dict[str, Any]:
    """生成盲评包与映射表（两者内容分离，调用方分别落盘）。

    返回 {"public_rows": [...], "mapping": {...}, "counts": {...}}
    """
    rows = [r for r in results_rows if not arms or r.get("strategy") in arms]
    rng = random.Random(seed)
    rows = list(rows)
    rng.shuffle(rows)          # 打乱顺序，使 blind_id 不携带位置信息

    public: List[Dict[str, Any]] = []
    mapping: Dict[str, Dict[str, Any]] = {}
    counts: Dict[str, int] = {}
    n = 0
    for r in rows:
        outcome = r.get("outcome") or {}
        answer = str(outcome.get("final_answer") or "")
        record = outcome.get("answer_record") or {}
        if not include_unknown and not record.get("valid"):
            continue
        prompt_obj = prompts.get(str(r["task_id"]))
        prompt = getattr(prompt_obj, "prompt", None) or (
            prompt_obj.get("prompt") if isinstance(prompt_obj, dict) else "")
        n += 1
        blind_id = f"B-{n:04d}"
        entry = BlindEntry(blind_id=blind_id, task_id=str(r["task_id"]),
                           source=str(r.get("source") or ""),
                           prompt=str(prompt), submitted_answer=answer)
        public.append(entry.as_public())
        mapping[blind_id] = {
            "run_id": r.get("run_id"),
            "task_id": r.get("task_id"),
            "strategy": r.get("strategy"),
            "execution_position": r.get("execution_position"),
            "answer_valid": bool(record.get("valid")),
        }
        counts[str(r.get("strategy"))] = counts.get(str(r.get("strategy")), 0) + 1

    manifest = {
        "schema": "blind-package-v1",
        "seed": seed,
        "n_items": len(public),
        "arms_included": sorted(counts),
        "hidden_fields": ["strategy", "execution_position", "steps", "usage",
                          "cost", "asc", "run_id", "stop_reason"],
        "released_fields": ["blind_id", "task_id", "source", "prompt", "submitted_answer"],
        "blinding_limitation": (
            "提交答案文本本身可能暴露方法特征（如格式残留）。本包只隐藏方法标签、"
            "顺序、提示、推理与费用；不能声称完全盲法。"),
        "per_arm_counts": counts,
    }
    return {"public_rows": public, "mapping": mapping, "manifest": manifest}


def write_blind_package(*, out_dir: Path | str, package: Dict[str, Any],
                        results_sha256: str) -> Dict[str, str]:
    """落盘：公开包（含映射的只有 manifest 之外的独立文件）。"""
    d = Path(out_dir)
    d.mkdir(parents=True, exist_ok=True)
    public_path = d / "blind_items.jsonl"
    mapping_path = d / "blind_mapping_PRIVATE.json"
    manifest_path = d / "blind_manifest.json"

    tmp = public_path.with_suffix(".jsonl.pending")
    with tmp.open("w", encoding="utf-8", newline="\n") as fh:
        for row in package["public_rows"]:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        fh.flush()
    tmp.replace(public_path)

    tmp = mapping_path.with_suffix(".json.pending")
    tmp.write_text(json.dumps(package["mapping"], ensure_ascii=False, indent=2),
                   encoding="utf-8")
    tmp.replace(mapping_path)

    man = dict(package["manifest"])
    man["results_sha256"] = results_sha256
    man["public_items_sha256"] = hashlib.sha256(public_path.read_bytes()).hexdigest()
    man["mapping_sha256"] = hashlib.sha256(mapping_path.read_bytes()).hexdigest()
    tmp = manifest_path.with_suffix(".json.pending")
    tmp.write_text(json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(manifest_path)

    return {"public": str(public_path), "mapping": str(mapping_path),
            "manifest": str(manifest_path)}
