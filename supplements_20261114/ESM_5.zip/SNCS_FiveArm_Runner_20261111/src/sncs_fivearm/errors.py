"""执行器内部错误类型。

设计原则：每一种"不能继续"的原因都有一个独立类型，使终态与账目状态可区分，
不会把预算拒绝、派发上限、合同未批准混成一个笼统的 Exception。
"""

from __future__ import annotations


class FiveArmError(Exception):
    """所有执行器错误的基类。"""


class ContractNotApproved(FiveArmError):
    """合同未获批准 / 关键字段缺失，不允许真实派发。"""


class InputIntegrityError(FiveArmError):
    """输入的字节指纹、字段集合或成员关系与锁定值不符。"""


class ForbiddenFieldError(FiveArmError):
    """生成路径收到 gold / 评分字段。"""


class BudgetBlocked(FiveArmError):
    """预算不足以覆盖本次有依据的费用上界；本次**未**派发。"""

    def __init__(self, message: str, state: dict | None = None) -> None:
        super().__init__(message)
        self.state = state or {}


class DispatchLimitReached(FiveArmError):
    """轨迹的 8 次实际派发门已用尽。"""


class JournalCorrupt(FiveArmError):
    """日志尾行损坏、重复 id 或状态不可解释。"""


class RunLocked(FiveArmError):
    """run 目录已被另一个进程独占。"""


class TransportError(FiveArmError):
    """传输层失败；是否可能已产生费用由 failed_may_have_billed 标记。"""

    def __init__(self, message: str, *, may_have_billed: bool = True,
                 status_code: int | None = None, envelope: dict | None = None) -> None:
        super().__init__(message)
        self.may_have_billed = may_have_billed
        self.status_code = status_code
        self.envelope = envelope


class ReconciliationRequired(FiveArmError):
    """存在未决费用暴露，必须先对账再继续。"""
