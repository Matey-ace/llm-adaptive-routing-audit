"""离线场景运行器：把场景套件跑成带证据的可重复结果。

每个场景独立 run 目录（`runs/offline_<scenario>_<ts>`），并汇总成
`evidence/offline_scenario_receipt.json`。

这些结果**只**证明执行器的工程行为（门、账、恢复、止损），
不构成任何模型质量或费用结论。
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from .contracts import Contract, draft_contract, sha256_json, SCHEMA_VERSION, STUDY_ID
from .inputs import TaskPrompt
from .journal import Journal
from .providers import SyntheticAction, SyntheticProvider
from .runner import RunConfig, Runner


def ownerless_contract(**overrides) -> Contract:
    """构造一个**纯离线**合同（离线模拟不读凭证、不联网）。"""
    raw = draft_contract()
    raw.update({
        "execution_mode": "offline_simulation",
        "status": "OFFLINE_SIMULATION_ONLY",
        "phase_scope": ["preflight", "main"],
        "provider": {
            "name": "synthetic",
            "base_url": None,
            "model_id": "synthetic-model",
            "api_key_env": None,
            "thinking": {"enabled": None, "reasoning_effort": None},
            "sampling": {"temperature": 0.0, "top_p": 1.0, "seed": 42,
                         "temperature_or_omitted_reason": "offline_no_sampling"},
            "sdk_retries": 0,
            "timeout_seconds": 30,
            "stream": False,
            "response_cache_enabled": False,
        },
        "limits": {
            "per_call_output_token_ceiling": 16384,
            "per_trajectory_dispatch_cap": 8,
            "role_output_limits": {"default": 4096, "judge": 4096, "plan": 4096,
                                   "solve": 4096, "reflect": 4096, "replan": 4096,
                                   "baseline_solve": 4096, "tool": 4096},
            "input_token_upper_bound_method": "utf8_byte_upper_bound_v1",
            "trajectory_workers": 1,
            "max_dispatches_per_minute": None,
        },
        "tariff": {
            "currency": "CNY",
            "unit": "micro_CNY_per_million_tokens",
            "input_uncached_micro_per_million": 2_000_000,
            "output_micro_per_million": 8_000_000,
            "cached_input_micro_per_million": None,
            "reasoning_counting": "included_in_completion_single_count",
            "source": {"url": "offline_fixture", "checked_utc": "2026-11-11T00:00:00Z",
                       "sha256": None},
            "effective_window_utc": [None, None],
        },
        "budget": {
            "currency": "CNY",
            "total_micro": 100_000_000,
            "preflight_micro": 10_000_000,
            "main_micro": 90_000_000,
            "unknown_usage_policy": "retain_full_reservation_as_unresolved_exposure",
            "stop_before_dispatch_when_insufficient": True,
            "topup_without_approval": False,
        },
        "approval": {"approved": False, "approval_reference": None,
                     "approved_utc": None},
    })
    raw.update(overrides)
    # 离线合同不经过批准门；用内存对象避免写文件
    obj = Contract(path=Path("<offline>"), raw=raw, sha256=sha256_json(raw))
    obj._validate_shape()
    obj.problems = obj._collect_problems()
    return obj


def _fixture_bundle(tasks: List[TaskPrompt], rows: List[Dict[str, Any]]):
    """为离线场景组装最小 bundle（不读真实清单）。"""
    from .inputs import InputBundle, QueueRow

    class _Bundle(InputBundle):
        pass

    prompts = {t.task_id: t for t in tasks}
    queue = [QueueRow.from_dict(r) for r in rows]
    manifest = [{"task_id": t.task_id, "source": "gsm8k", "split": "preflight",
                 "prompt_sha256": t.prompt_sha256, "sampling_stratum": "fixture"}
                for t in tasks]
    return _Bundle(phase="preflight", prompts=prompts, queue=queue, manifest=manifest,
                   fingerprints={"fixture": "true"})


def _queue_rows(tasks: List[TaskPrompt], arms: List[str],
                run_id_prefix: str) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    seq = 0
    for block, task in enumerate(tasks, 1):
        block_id = f"{run_id_prefix}:{task.task_id}:r0"
        for pos, arm in enumerate(arms, 1):
            seq += 1
            rows.append({
                "sequence": seq, "block_number": block, "block_id": block_id,
                "run_id": f"{block_id}:{arm}", "phase": "preflight",
                "task_id": task.task_id, "source": "gsm8k",
                "sampling_stratum": "fixture", "prompt_sha256": task.prompt_sha256,
                "repeat_id": 0, "strategy": arm, "execution_position": pos,
            })
    return rows


def run_scenario_suite(*, suite_path: Optional[Path], out_dir: Path,
                       evidence_dir: Path) -> Dict[str, Any]:
    """内置场景 + 可选外部套件。"""
    from . import scenario_defs

    results: List[Dict[str, Any]] = []
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    for sc in scenario_defs.builtin_scenarios():
        results.append(_run_one(sc, out_dir=out_dir, stamp=stamp))
    if suite_path is not None and suite_path.is_file():
        results.append(_run_one_external(suite_path, out_dir=out_dir, stamp=stamp))

    failed = sum(1 for r in results if not r["passed"])
    summary = {
        "status": "PASS" if failed == 0 else "FAIL",
        "scenarios": len(results),
        "failed": failed,
        "live_calls": 0,
        "network_calls": 0,
        "stamp": stamp,
        "checks": results,
        "limitation": ("这些场景只用合成 provider 验证工程行为（派发门、预算门、"
                       "恢复、保全、止损），不构成模型质量、成功率或费用结论。"),
    }
    evidence_dir.mkdir(parents=True, exist_ok=True)
    out = evidence_dir / "offline_scenario_receipt.json"
    out.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


def _run_one(sc, *, out_dir: Path, stamp: str) -> Dict[str, Any]:
    from . import scenario_defs

    contract = ownerless_contract(**sc.contract_overrides)
    tasks = sc.tasks
    rows = _queue_rows(tasks, sc.arms, f"sim_{sc.scenario_id}")
    bundle = _fixture_bundle(tasks, rows)
    provider = sc.build_provider(rows)
    run_id = f"offline_{sc.scenario_id}_{stamp}"
    cfg = RunConfig(run_id=run_id, phase="preflight", contract=contract,
                    bundle=bundle, queue=bundle.queue, purpose="offline_simulation",
                    notes=sc.description)
    runner = Runner(config=cfg, provider=provider, runs_root=out_dir,
                    package_root=Path(__file__).resolve().parent)
    summary = runner.execute()
    checks = sc.check(run_id=run_id, run_dir=out_dir / run_id, summary=summary,
                      provider=provider)
    return {
        "scenario_id": sc.scenario_id,
        "description": sc.description,
        "run_id": run_id,
        "run_dir": str(out_dir / run_id),
        "summary": summary.as_dict(),
        "checks": checks,
        "passed": all(c["passed"] for c in checks),
    }


def _run_one_external(path: Path, *, out_dir: Path, stamp: str) -> Dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    from .inputs import TaskPrompt, sha256_text
    tasks = [TaskPrompt(task_id=str(t["task_id"]), prompt=str(t["prompt"]),
                        prompt_sha256=sha256_text(str(t["prompt"])))
             for t in data.get("tasks") or []]
    arms = list(data.get("arms") or ["direct", "planning", "plan_reflect",
                                     "adaptive_legacy", "asc_beta_8"])
    rows = _queue_rows(tasks, arms, f"sim_{data.get('scenario_id','ext')}")
    bundle = _fixture_bundle(tasks, rows)
    budget = data.get("budget") or {}
    overrides = {"budget": {**ownerless_contract().raw["budget"], **budget}} if budget else {}
    contract = ownerless_contract(**overrides)
    script: Dict[str, List[Any]] = {}
    actions = data.get("actions") or {}
    for row in rows:
        key = f"{row['task_id']}|{row['strategy']}"
        src = actions.get(key) or actions.get(row["strategy"]) or actions.get("default")
        if src is None:
            raise KeyError(f"外部场景缺少动作: {key}")
        script[row["run_id"]] = [_action(a) for a in src]
    provider = SyntheticProvider(script)
    run_id = f"offline_{data.get('scenario_id','ext')}_{stamp}"
    cfg = RunConfig(run_id=run_id, phase="preflight", contract=contract,
                    bundle=bundle, queue=bundle.queue, purpose="offline_simulation",
                    notes=str(data.get("description", "")))
    runner = Runner(config=cfg, provider=provider, runs_root=out_dir,
                    package_root=Path(__file__).resolve().parent)
    summary = runner.execute()
    return {"scenario_id": str(data.get("scenario_id", "external")),
            "description": str(data.get("description", "")),
            "run_id": run_id, "summary": summary.as_dict(),
            "checks": [], "passed": True}


def _action(d: Dict[str, Any]):
    from .simulation import action_from_dict
    return action_from_dict(d)
