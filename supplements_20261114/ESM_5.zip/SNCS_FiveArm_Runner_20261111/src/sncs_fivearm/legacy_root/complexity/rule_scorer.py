"""规则打分器（complexity 模块 B2）。

职责：把 prompt 表层特征映射为一个 [0,1] 复杂度分数，再用阈值切分为
easy / medium / hard 三级。**仅使用派生难度锚点（task.difficulty）作为离线标定目标**——
锚点是数据集原始标注的派生量（GSM8K 方程步数、MATH level），属于"离线标注与分层分析"
用途（实验协议第 5.3 节），不在线进入路由输入。

关键约束：
- 阈值 t_low / t_high **只在 calibration 集上拟合**（grid search + LOO-CV）。
- dev 只用于泛化检查，不参与调参。
- 打分纯表层、零 LLM 调用、零成本，可独立复现。
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

from complexity.features import (
    FeatureStats, compute_features, equal_weight_score,
    fit_feature_stats, select_v1_features,
)
from tasks.dataset import Task

LEVELS = ["easy", "medium", "hard"]


class RuleScorerNotFittedError(RuntimeError):
    """未调用 `fit` 就使用打分器时抛出。

    为什么必须抛错而不是"静默返回 0"：P3 修复的缺陷。
    旧实现在未拟合时返回 0.0，而 0.0 会被阈值判为 **easy**，等于把所有任务都走
    最省的路径——这是一种**静默的、方向性错误的降级**，在实际运行中很难被发现。
    现在的默认行为是大声失败；若确需降级，必须由调用方显式指定
    `unfitted_policy`（见 `complexity/router.py`），并在决策中留下可审计的标记。
    """


# ----------------------------------------------------------- 评估辅助（供 calibrate 复用）
def confusion_matrix(y_true: Sequence[str], y_pred: Sequence[str],
                     labels: Sequence[str] = LEVELS) -> Dict[str, Dict[str, int]]:
    cm: Dict[str, Dict[str, int]] = {t: {p: 0 for p in labels} for t in labels}
    for t, p in zip(y_true, y_pred):
        if t in cm and p in cm[t]:
            cm[t][p] += 1
    return cm


def macro_f1(cm: Dict[str, Dict[str, int]],
             labels: Sequence[str] = LEVELS) -> float:
    f1s = []
    for lab in labels:
        tp = cm[lab][lab]
        fp = sum(cm[t][lab] for t in labels) - tp
        fn = sum(cm[lab][p] for p in labels) - tp
        prec = tp / (tp + fp) if (tp + fp) else 0.0
        rec = tp / (tp + fn) if (tp + fn) else 0.0
        f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
        f1s.append(f1)
    return sum(f1s) / len(f1s) if f1s else 0.0


def accuracy(y_true: Sequence[str], y_pred: Sequence[str]) -> float:
    n = len(y_true)
    return sum(1 for t, p in zip(y_true, y_pred) if t == p) / n if n else 0.0


class RuleScorer:
    def __init__(self, selected: Optional[List[str]] = None,
                 use_extended: bool = False, override: Optional[List[str]] = None,
                 t_low: float = 0.33, t_high: float = 0.66) -> None:
        self.selected = select_v1_features(use_extended=use_extended, override=override)
        self.t_low = t_low
        self.t_high = t_high
        self.stats: Optional[FeatureStats] = None
        self._fitted = False

    # ------------------------------------------------------------------ 拟合
    def fit(self, tasks: Sequence[Task]) -> "RuleScorer":
        prompts = [t.prompt for t in tasks]
        sources = [t.source for t in tasks]
        self.stats = fit_feature_stats(prompts, self.selected, sources)
        self._fitted = True
        return self

    # ------------------------------------------------------------------ 打分
    @property
    def is_fitted(self) -> bool:
        return self.stats is not None and self._fitted

    def _require_fitted(self) -> None:
        if self.stats is None:
            raise RuleScorerNotFittedError(
                "RuleScorer 尚未 fit()。旧实现会静默返回 0.0 从而把任务全部判为 easy；"
                "现在改为显式报错。若确需降级，请在 C3Router 侧显式设置 "
                "unfitted_policy='all_gray'（会在决策中留下 rule_default 标记），"
                "或直接调用 fit() 完成标定。"
            )

    def score(self, task: Task) -> float:
        self._require_fitted()
        feats = compute_features(task.prompt, task.source)
        norm = self.stats.normalize(feats)
        return equal_weight_score(norm, self.selected)

    def score_from_prompt(self, prompt: str, source: Optional[str] = None) -> float:
        self._require_fitted()
        feats = compute_features(prompt, source)
        norm = self.stats.normalize(feats)
        return equal_weight_score(norm, self.selected)

    def predict(self, task: Task) -> str:
        s = self.score(task)
        if s < self.t_low:
            return "easy"
        if s > self.t_high:
            return "hard"
        return "medium"

    # ------------------------------------------------------------------ 阈值寻优
    def grid_search(self, tasks: Sequence[Task],
                    t_lows: Optional[Sequence[float]] = None,
                    t_highs: Optional[Sequence[float]] = None) -> Tuple[float, float]:
        """在 calibration 全量上网格搜索使 Macro-F1 最大的 (t_low, t_high)。

        选出的阈值随后用于 LOO-CV 与 dev 泛化检查；dev 不参与此处。
        """
        if not self._fitted:
            self.fit(tasks)
        t_lows = list(t_lows or [0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45])
        t_highs = list(t_highs or [0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85])
        y_true = [t.difficulty for t in tasks]
        best = (-1.0, self.t_low, self.t_high)
        for tl in t_lows:
            for th in t_highs:
                if th <= tl:
                    continue
                y_pred = [self._predict_with(t, tl, th) for t in tasks]
                f1 = macro_f1(confusion_matrix(y_true, y_pred))
                # 平局时偏好阈值间距更居中（t_low 偏小、t_high 偏大，灰区更宽更稳）
                if f1 > best[0]:
                    best = (f1, tl, th)
        self.t_low, self.t_high = best[1], best[2]
        return self.t_low, self.t_high

    def _predict_with(self, task: Task, t_low: float, t_high: float) -> str:
        s = self.score(task)
        if s < t_low:
            return "easy"
        if s > t_high:
            return "hard"
        return "medium"

    # ------------------------------------------ CV 与稳定性检查（P3：口径分家）
    def check_normalization_stability(self, tasks: Sequence[Task]) -> Dict[str, float]:
        """**归一化稳定性检查**（旧 `loo_cv` 改名而来，语义不变）。

        做法：逐个样本用"排除自身后"重算的特征 min/max 归一化来打分，
        但**阈值沿用全量 grid_search 选定的固定值**。

        它回答的问题：多大程度上结果依赖于某个极值样本撑开的归一化区间
        （即 min-max 归一化本身是否脆弱）。

        它**不能**用来宣称泛化性能——因为阈值是在包含全部样本（含当前被评估样本）
        的数据上选出来的，存在乐观偏差。真正的端到端估计见 `loo_cv`。
        """
        n = len(tasks)
        all_feats = [compute_features(t.prompt, t.source) for t in tasks]
        y_true = [t.difficulty for t in tasks]
        selected = self.selected
        y_pred: List[str] = []
        for i in range(n):
            # 排除 i 后重算每个选定特征的 min / max
            mins, maxs = {}, {}
            for name in selected:
                vals = [all_feats[j][name] for j in range(n) if j != i]
                mins[name] = min(vals) if vals else 0.0
                maxs[name] = max(vals) if vals else 0.0
            span = {name: maxs[name] - mins[name] for name in selected}
            norm = {}
            for name in selected:
                v = all_feats[i][name]
                norm[name] = 0.0 if span[name] <= 0 else min(1.0, max(0.0, (v - mins[name]) / span[name]))
            s = equal_weight_score(norm, selected)
            if s < self.t_low:
                y_pred.append("easy")
            elif s > self.t_high:
                y_pred.append("hard")
            else:
                y_pred.append("medium")
        return {
            "macro_f1": macro_f1(confusion_matrix(y_true, y_pred)),
            "accuracy": accuracy(y_true, y_pred),
            "confusion": confusion_matrix(y_true, y_pred),
            "note": "只反映归一化/阈值的稳定性，不是端到端泛化估计（阈值含全量信息）",
        }

    def loo_cv(self, tasks: Sequence[Task],
               t_lows: Optional[Sequence[float]] = None,
               t_highs: Optional[Sequence[float]] = None) -> Dict[str, object]:
        """**真正的留一交叉验证**（P3 新增）：每折都重新拟合归一化**并重选阈值**。

        与 `check_normalization_stability` 的区别（两者分别报告，不可互相顶替）：

        | | 归一化 | 阈值 |
        |---|---|---|
        | `check_normalization_stability` | 逐折重算 | 固定（全量选定） |
        | `loo_cv`（本方法） | 逐折重拟合 | **逐折重选** |

        因此只有本方法的结果可以拿来讨论"标定流程本身的泛化"；
        稳定性检查只用于说明是否有单样本极值在撑区间。
        """
        tasks = list(tasks)
        n = len(tasks)
        if n < 3:
            return {"n": n, "macro_f1": None, "accuracy": None,
                    "confusion": None, "note": "样本过少（<3），无法做留一验证"}
        t_lows = list(t_lows or [0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45])
        t_highs = list(t_highs or [0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85])
        y_true = [t.difficulty for t in tasks]
        y_pred: List[str] = []
        chosen_tl: List[float] = []
        chosen_th: List[float] = []
        for i in range(n):
            idx = [j for j in range(n) if j != i]
            stats = fit_feature_stats([tasks[j].prompt for j in idx],
                                      self.selected, [tasks[j].source for j in idx])
            train_scores = [
                equal_weight_score(stats.normalize(compute_features(tasks[j].prompt,
                                                                    tasks[j].source)),
                                   self.selected)
                for j in idx
            ]
            train_true = [y_true[j] for j in idx]
            best = (-1.0, t_lows[0], t_highs[-1])
            for tl in t_lows:
                for th in t_highs:
                    if th <= tl:
                        continue
                    preds = ["easy" if s < tl else ("hard" if s > th else "medium")
                             for s in train_scores]
                    f1 = macro_f1(confusion_matrix(train_true, preds))
                    if f1 > best[0]:
                        best = (f1, tl, th)
            tl, th = best[1], best[2]
            chosen_tl.append(tl)
            chosen_th.append(th)
            si = equal_weight_score(
                stats.normalize(compute_features(tasks[i].prompt, tasks[i].source)),
                self.selected)
            y_pred.append("easy" if si < tl else ("hard" if si > th else "medium"))

        def _mean(xs):
            return round(sum(xs) / len(xs), 4) if xs else None

        return {
            "n": n,
            "macro_f1": round(macro_f1(confusion_matrix(y_true, y_pred)), 4),
            "accuracy": round(accuracy(y_true, y_pred), 4),
            "confusion": confusion_matrix(y_true, y_pred),
            "thresholds_mean": {"t_low": _mean(chosen_tl), "t_high": _mean(chosen_th)},
            "thresholds_stable": (len(set(chosen_tl)) == 1 and len(set(chosen_th)) == 1),
            "note": "每折重拟合归一化并重新网格搜索阈值；可用于讨论标定流程的泛化",
        }

    # ------------------------------------------------------------------ 评估
    def eval_confusion(self, tasks: Sequence[Task]) -> Dict:
        y_true = [t.difficulty for t in tasks]
        y_pred = [self.predict(t) for t in tasks]
        return {
            "macro_f1": macro_f1(confusion_matrix(y_true, y_pred)),
            "accuracy": accuracy(y_true, y_pred),
            "confusion": confusion_matrix(y_true, y_pred),
        }

    def misestimation_rates(self, tasks: Sequence[Task]) -> Dict[str, float]:
        """低估 / 高估比率（相对派生锚点）。

        - 低估（under）：预测等级低于锚点（如在 hard 任务上判成 easy/medium）
          → 可能损失质量（用了更省但不足的策略）。
        - 高估（over）：预测等级高于锚点（如在 easy 任务上判成 hard）
          → 浪费成本（用了更贵但过度的策略）。
        绝对质量/成本影响需结合策略运行结果，本模块只报告比率（见 calibrate 报告）。
        """
        order = {"easy": 0, "medium": 1, "hard": 2}
        n = len(tasks)
        under = over = agree = 0
        for t in tasks:
            pred = self.predict(t)
            true = t.difficulty
            d = order[pred] - order[true]
            if d < 0:
                under += 1
            elif d > 0:
                over += 1
            else:
                agree += 1
        return {
            "n": n, "agree": agree, "under": under, "over": over,
            "under_rate": under / n if n else 0.0,
            "over_rate": over / n if n else 0.0,
        }
