"""complexity：复杂度判定模块。

组成：
- features：9 维候选特征池（prompt 表层，无隐藏信息）+ v1 等权子集。
- rule_scorer：阈值网格搜索 + LOO-CV 的规则打分器（calibration 拟合，零成本）。
- llm_judge：修复 hard→medium 缺陷的 LLM 判定器（计入 judge 成本）。
- router：C3 混合路由（规则低/高区免费，灰区调 judge，异常回退）。
- calibrate：拟合 → LOO-CV → dev 检查 → 报告。

所有在线判定只用 prompt 表层特征；派生难度锚点只用于离线标定目标，
绝不进入路由输入（见 paper/实验协议.md 第 4、5.3、5.5 节）。
"""

from __future__ import annotations

from complexity.features import (
    FEATURE_POOL, V1_DEFAULT_FEATURES, V1_EXTENDED_FEATURES,
    compute_features, fit_feature_stats, equal_weight_score, select_v1_features,
)
from complexity.rule_scorer import RuleScorer, confusion_matrix, macro_f1, accuracy
from complexity.llm_judge import LLMJudge
from complexity.router import C3Router, RouteDecision
from complexity.calibrate import run_calibration

__all__ = [
    "FEATURE_POOL", "V1_DEFAULT_FEATURES", "V1_EXTENDED_FEATURES",
    "compute_features", "fit_feature_stats", "equal_weight_score",
    "select_v1_features", "RuleScorer", "confusion_matrix", "macro_f1", "accuracy",
    "LLMJudge", "C3Router", "RouteDecision", "run_calibration",
]
