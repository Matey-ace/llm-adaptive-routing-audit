"""Versioned calibration-only router state, loaded independently for each task."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

from complexity.features import FeatureStats, FEATURE_POOL
from complexity.llm_judge import LLMJudge
from complexity.router import C3Router
from complexity.rule_scorer import RuleScorer
from tasks.dataset import Task


def load_artifact(path):
    raw = Path(path).read_bytes()
    data = json.loads(raw)
    if data.get("schema_version") != 1 or data.get("fit_split") != "calibration":
        raise ValueError("Invalid router schema or fit split")
    selected = data["selected_features"]
    if (not selected or len(set(selected)) != len(selected)
            or any(f not in FEATURE_POOL or f == "dataset_prior" for f in selected)):
        raise ValueError("Invalid prompt-only feature selection")
    lo, hi = data["thresholds"]["t_low"], data["thresholds"]["t_high"]
    if not 0 <= lo < hi <= 1:
        raise ValueError("Invalid router thresholds")
    for name in selected:
        a, b = data["mins"][name], data["maxs"][name]
        if not math.isfinite(a) or not math.isfinite(b) or a > b:
            raise ValueError("Invalid feature range")
    for example in data["judge_examples"]:
        if example["split"] != "calibration" or example["difficulty"] not in ("easy", "medium", "hard"):
            raise ValueError("Invalid judge example")
    return data, hashlib.sha256(raw).hexdigest()


def router_from_artifact(data, judge_max_tokens=None, mode='hybrid'):
    rs = RuleScorer(override=data["selected_features"], **data["thresholds"])
    rs.stats = FeatureStats(list(rs.selected), dict(data["mins"]), dict(data["maxs"]))
    rs._fitted = True
    examples = [Task(task_type="math", difficulty_anchor={}, gold=None,
                     metric="exact_match", **item) for item in data["judge_examples"]]
    return C3Router(rs, judge=LLMJudge(examples, per_level=data["judge_examples_per_level"],
                                     max_tokens=judge_max_tokens or data.get("judge_max_tokens", 160)), mode=mode)
