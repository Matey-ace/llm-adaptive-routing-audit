"""runner 侧的统一评分入口（P2：把隐藏评分从 Agent 里彻底移出）。

为什么要有这个文件：
- 评分需要 gold，而 gold **不能**出现在 Agent 的可见范围里（否则 Agent 可以
  用正确性反馈来决定何时停止、选哪个答案，这是必须堵住的公平性口子）。
- 因此评分只能发生在 **Agent 返回之后、runner 侧持有原始 Task 的地方**。
- 集中在这一个函数里，便于：① 版本化（`SCORER_VERSION` 写进每条 raw 日志）；
  ② 争议留存（`needs_review` 与原因码一并落盘）；③ 版本升级后离线重算。

输出字段：
    success          最终判定是否正确（needs_review 时也记为 False，但另有标记）
    needs_review     无法自动判定，需人工复核
    score_reason     原因码（见 eval/extractors.compare_answers）
    scorer_version   评分口径版本，用于事后溯源与跨版本比较
"""

from __future__ import annotations

from typing import Any, Dict

from eval.metrics import score_answer_detailed, SCORER_VERSION
from tasks.dataset import Task


def score_final_answer(task: Task, final_answer: str) -> Dict[str, Any]:
    """对 Agent 返回的最终答案评分。空答案为异常路径。"""
    if final_answer is None or str(final_answer).strip() == "":
        return {
            "success": False,
            "needs_review": True,
            "score_reason": "empty_answer",
            "scorer_version": SCORER_VERSION,
        }
    ok, needs_review, reason = score_answer_detailed(task, str(final_answer))
    return {
        "success": bool(ok),
        "needs_review": bool(needs_review),
        "score_reason": reason,
        "scorer_version": SCORER_VERSION,
    }


def apply_score(record: Dict[str, Any], task: Task) -> Dict[str, Any]:
    """把评分结果写进一条 raw 记录（就地修改并返回同一对象）。"""
    record.update(score_final_answer(task, record.get("final_answer", "")))
    return record


def error_score() -> Dict[str, Any]:
    """Agent 执行失败时的占位评分口径：算作异常，需复核，但不是"答案错误"。"""
    return {
        "success": False,
        "needs_review": True,
        "score_reason": "run_error",
        "scorer_version": SCORER_VERSION,
    }
