"""Agent 基类与轨迹结构。

核心约束（论文控制变量的基础）：
- 四种策略共用同一 Prompt 骨架与同一套解码参数，只切换 slot：
  {role}{task}{output_format}[plan_slot][exec_slot][reflection_slot]{budget_hint}
- 每次 LLM 调用都带 purpose 标记（judge/plan/execute/reflect/solve/tool），
  使论文中的"调用次数按用途分解"可以直接从 raw 日志统计。
- Trajectory 完整记录每一步，供后续审计与论文举例。
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

# agents.stoppers 不依赖本模块，无循环导入风险
from agents.stoppers import BudgetGuard, HardCapStopper
from llm_proxy.client import LLMClient
from llm_proxy.usage import UsageMeter
from tasks.agent_view import AgentView
from tasks.tools.builtin import MockToolBox

# 2026-10-13（S1）：反思协议新增 CONFIDENCE 行，供 S3 停止条件使用。
# 变更提示词必须递增版本号——提示词是实验的自变量之一，版本不可追踪就无法复现。
PROMPT_VERSION = "zh-v3"


@dataclass
class Step:
    kind: str                # judge / plan / solve / reflect / replan / tool / final
    prompt: str
    response: str
    latency_ms: float
    detail: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Trajectory:
    task_id: str
    strategy: str            # direct / planning / plan_reflect / adaptive
    final_answer: str
    success: Optional[bool] = None
    steps: List[Step] = field(default_factory=list)
    meter_summary: Dict[str, Any] = field(default_factory=dict)
    # 策略特定的过程计数，直接对应论文指标
    n_reflections: int = 0
    n_replans: int = 0
    n_tool_calls: int = 0
    n_llm_calls: int = 0
    selected_level: Optional[str] = None
    selected_path: Optional[str] = None
    stop_reason: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self, save_full_response: bool = True) -> Dict[str, Any]:
        steps_out = []
        for s in self.steps:
            item = {
                "kind": s.kind,
                "latency_ms": round(s.latency_ms, 2),
                "detail": s.detail,
            }
            # 原始 prompt 与 response 全量留存：这是论文可复现性与人工核查的基础，
            # 也是投稿时说明"实验数据真实可查"的依据。仅在显式关闭时才省略。
            if save_full_response:
                item["prompt"] = s.prompt
                item["response"] = s.response
            steps_out.append(item)
        return {
            "task_id": self.task_id,
            "strategy": self.strategy,
            "final_answer": self.final_answer,
            "success": self.success,
            "n_reflections": self.n_reflections,
            "n_replans": self.n_replans,
            "n_tool_calls": self.n_tool_calls,
            "n_llm_calls": self.n_llm_calls,
            "selected_level": self.selected_level,
            "selected_path": self.selected_path,
            "stop_reason": self.stop_reason,
            "meter_summary": self.meter_summary,
            "steps": steps_out,
            "extra": self.extra,
        }


class AgentBase:
    """四种策略的共同基类。"""

    strategy_name = "base"

    def __init__(self, client: LLMClient, toolbox: Optional[MockToolBox] = None,
                 max_reflections: int = 3,
                 hard_cap: Optional["HardCapStopper"] = None,
                 budget: Optional["BudgetGuard"] = None) -> None:
        self.client = client
        # 计量器必须与 client 共用同一个实例，否则 Trajectory 的 token/调用统计会为空。
        # runner 为每个任务单独构造 client + meter，因此不会出现跨任务累积。
        self.meter = client.meter
        self.toolbox = toolbox or MockToolBox()
        self.max_reflections = max_reflections
        # 全局硬兜底：默认总是存在（参数取得足够宽松，不改变既有行为），
        # 保证任何主停止策略配置下循环都能终止（实验协议 §6.4.3）。
        self.hard_cap = hard_cap if hard_cap is not None else HardCapStopper()
        # 严格预算门：默认 None（不限制）；由实验配置显式注入。
        self.budget = budget
        # 最近一次被预算门拦下的项目（"call" / "token"），供 Agent 写入轨迹。
        self.last_budget_block: Optional[str] = None

    # ------------------------------------------------------------------ Prompt
    def build_messages(self, av: AgentView, kind: str, history: str = "") -> List[dict]:
        """统一 Prompt 骨架。kind 决定填充哪个 slot。

        仅使用 AgentView 的 prompt / tools_allowed —— 评测元数据（gold 等）不在此暴露。
        """
        system = (
            "你是一个大语言模型智能体，需要按指定协议输出，不要输出协议之外的文字。\n"
            f"输出协议：\n"
            f"- 求解时输出一行：ANSWER: <答案>\n"
            f"- 制定计划时输出：PLAN: 之后跟编号步骤\n"
            f"- 反思时输出：REFLECT: 之后跟要点，"
            f"随后一行 CONFIDENCE: <0~1 的小数> 表示你对当前答案的信心，"
            f"最后一行 VERDICT: PASS 或 REVISE\n"
            f"- 需要调用工具时输出一行：ACTION: 工具名(参数)\n"
            f"- 工具流程结束时输出一行：FINAL: <答案>"
        )
        user_parts = [f"任务：{av.prompt}"]
        if kind == "plan":
            if history:
                user_parts.append(f"此前的计划、结果与反思意见：\n{history}")
                user_parts.append("请依据上述反思意见修订执行计划。")
            user_parts.append("请先给出完成该任务的执行计划，不超过 4 步，只输出 PLAN 部分。")
        elif kind == "reflect":
            user_parts.append(f"已执行的计划与结果：\n{history}")
            user_parts.append("请反思上述过程是否存在需要修正之处，"
                              "先输出一行 CONFIDENCE: <0~1 的小数> 表示你对当前答案的信心，"
                              "最后一行输出 VERDICT: PASS（无需修正）或 REVISE（需要修正）。")
        elif kind == "solve":
            if history:
                user_parts.append(f"已获得的中间信息：\n{history}")
            user_parts.append("请直接给出最终答案，只输出 ANSWER 行。")
        if av.tools_allowed:
            user_parts.append(f"可用工具：{self.toolbox.describe(av.tools_allowed)}")
            user_parts.append("需要时先输出 ACTION 调用工具，拿到执行结果后再输出 FINAL。")
        return [
            {"role": "system", "content": system},
            {"role": "user", "content": "\n".join(user_parts)},
        ]

    # ------------------------------------------------------------------ 预算门
    def calls_used(self) -> int:
        """Completed logical calls plus failed attempts consume the shared cap.

        Formal runs disable cache and SDK retries, so this includes failed
        judge requests even when the router handles them by falling back.
        """
        return self.meter.n_calls + len(getattr(self.client, 'failed_attempts', ()))

    def budget_ok(self) -> tuple[bool, str]:
        """严格预算门：在**发起调用之前**检查。

        返回 (是否允许, 被拦下的项目)。未配置 budget 时恒为 (True, "")。
        超限时不发起调用，并在 `self.last_budget_block` 记下触发项。
        """
        if self.calls_used() + 1 > self.hard_cap.max_calls:
            self.last_budget_block = "hard_call"
            return False, "hard_call"
        if self.budget is None:
            return True, ""
        ok, item = self.budget.check(self.calls_used(), self.meter.total_tokens)
        if not ok:
            self.last_budget_block = item
        return ok, item

    def mark_truncated(self, traj: "Trajectory", item: str) -> str:
        """把预算截断写入轨迹，并返回应使用的 stop_reason。"""
        if item == "hard_call":
            traj.extra["truncated_by_hard_cap"] = True
            traj.extra["hard_cap_trigger"] = "calls"
            return "hard_cap:calls"
        traj.extra["truncated_by_budget"] = True
        traj.extra["truncated_by"] = item
        return "call_budget" if item == "call" else "token_budget"

    # ------------------------------------------------------------------ 工具
    def run_tool_loop(self, av: AgentView, max_tool_steps: int = 4) -> tuple[str, int, str]:
        """执行工具调用循环，返回 (最终答案, 工具调用次数, 停止原因)。"""
        history = ""
        n_calls = 0
        for _ in range(max_tool_steps):
            ok, _item = self.budget_ok()
            if not ok:
                # 严格预算：不再发起新的工具轮次
                break
            messages = self.build_messages(av, "solve", history=history)
            reply = self.client.chat(messages, purpose="tool")
            content = reply.content.strip()
            if content.startswith("ACTION:"):
                call = content[len("ACTION:"):].strip()
                name = call.split("(")[0].strip()
                arg = call.split("(", 1)[1].rstrip(")") if "(" in call else ""
                obs, ok = self.toolbox.call(name, arg)
                n_calls += 1
                history += f"执行结果：{name}({arg}) -> {obs}\n"
                if not ok:
                    history += "该工具调用失败，请换一种方式或直接给出 FINAL。\n"
                continue
            if content.startswith("FINAL:"):
                return content[len("FINAL:"):].strip(), n_calls, "final_emitted"
            if content.startswith("ANSWER:"):
                return content[len("ANSWER:"):].strip(), n_calls, "answer_emitted"
            history += f"模型输出未遵循协议：{content}\n"
        return history.strip()[-200:] or "EMPTY", n_calls, "max_tool_steps_reached"

    # ------------------------------------------------------------------ 主入口
    def run(self, av: AgentView) -> Trajectory:
        raise NotImplementedError

    # ------------------------------------------------------------------ 工具方法
    def _finish(self, av: AgentView, answer: str, traj: Trajectory,
                started: float, meter: UsageMeter) -> Trajectory:
        """收尾：只补全工程量，不做评分。

        P2 变更：原先这里会调用 `av.grade(answer)` 得到 `success`，
        等于把"基于 gold 的正确性"暴露给了 Agent。现在评分统一由 runner 在
        Agent 返回后执行（`runner/scoring.py`），`traj.success` 保持 None 直到那时。
        这样"推理过程中不存在 gold 反馈"成为结构性事实，而不是代码约定。
        """
        traj.final_answer = answer
        if self.last_budget_block is not None:
            traj.stop_reason = self.mark_truncated(traj, self.last_budget_block)
        traj.meter_summary = meter.summary()
        traj.n_llm_calls = meter.n_calls
        traj.success = None  # 由 runner 事后填写，Agent 不得自评
        traj.extra["wall_time_ms"] = round((time.perf_counter() - started) * 1000, 2)
        return traj


def parse_verdict(text: str) -> str:
    """严格解析反思输出中的 VERDICT 行。

    返回 "PASS" / "REVISE" / "MALFORMED" 三者之一。

    2026-10-13（S1）修复：旧实现为
        `verdict = "REVISE" if "VERDICT: REVISE" in refl_text else "PASS"`
    这有两个问题：
      1. **缺失 VERDICT 时默认 PASS** —— 模型未遵循协议、输出被截断、或出现
         "VERDICT: REVISE（待确认）"一类变体都会被静默当作"无需修正"，
         使反思在第一轮就退出（历史日志 88 条反思记录全部因此只跑 1 轮）；
      2. 子串匹配会在正文里出现 "VERDICT: REVISE" 字样（例如模型复述协议）时误判。
    现只在**行首**匹配 `VERDICT:`，且未匹配到一律记 MALFORMED，由调用方按
    预先规定的策略处理（`实验协议.md` §7.4.3：不得默认 PASS）。
    """
    import re
    if not text:
        return "MALFORMED"
    for line in reversed(text.splitlines()):
        m = re.match(r"^\s*VERDICT\s*[:：]\s*(PASS|REVISE)\s*[\.。]?\s*$",
                     line.strip(), re.IGNORECASE)
        if m:
            return m.group(1).upper()
    return "MALFORMED"


def parse_confidence(text: str) -> tuple[float, bool]:
    """解析反思输出中的 CONFIDENCE 行，并做范围校验。

    返回 (置信度, 是否解析到合法值)。越界（<0 或 >1）或缺失均视为非法，
    返回 (0.0, False)，由调用方保留上一轮的值并单独计数——**不猜测、不夹取**。
    """
    import re
    if not text:
        return 0.0, False
    m = re.search(r"^\s*CONFIDENCE\s*[:：]\s*(-?\d+(?:\.\d+)?)\s*$",
                  text, re.IGNORECASE | re.MULTILINE)
    if not m:
        return 0.0, False
    try:
        v = float(m.group(1))
    except ValueError:
        return 0.0, False
    if not (0.0 <= v <= 1.0):
        return 0.0, False
    return v, True


def parse_json_loose(text: str) -> Dict[str, Any]:
    """容错解析 LLM 输出的 JSON。"""
    import json
    import re
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        return {}
    try:
        return json.loads(m.group(0))
    except Exception:  # noqa: BLE001
        return {}
