"""S1–S4：Reflection 的四种停止条件，以及全局硬兜底与严格预算门。

设计意图：把"何时停止反思"从经验设定变成可量化对比的对象。
所有 stopper 实现同一接口 `should_stop(state) -> (bool, reason)`，
因此可以在实验中只更换停止条件而不改动其他逻辑。

状态字段：
  rounds            已完成的反思轮数
  last_change       最近一轮反思导致的答案变化度量（0 = 无变化，1 = 完全不同）
  change_history    各轮答案变化率的历史（供 S2 做"连续两轮"判定）
  confidence        自评置信度（0~1）
  tokens_used       该任务累计 token
  calls_used        该任务累计 LLM 调用次数
  n_verdict_malformed  畸形 / 缺失 VERDICT 的次数（不得默认 PASS）

--------------------------------------------------------------------------
2026-10-13（S1）修复的缺陷，改动逐条对应 `论文进度总览与后续步骤_核查修订版.md` §4：

1. **答案变化率语义反向**：旧实现直接返回 `difflib.SequenceMatcher(...).ratio()`，
   那返回的是**相似度**——答案完全相同时为 1.0、完全不同时为 0.0，
   与"变化率"语义相反，会使 S2 在答案毫无变化时判定为"变化很大"从而永不停止。
   现统一由本模块的 `answer_change_rate()` 提供，返回 `1 - ratio()`。
2. **S2 的"连续两轮"从未实现**：旧代码只看单轮 `last_change < delta`。
   现改为基于 `change_history` 的连续 `streak` 轮判定。
3. **`made_revision` 是死分支**：旧代码在 `rounds > 0 and not made_revision` 时停止，
   但 `made_revision` 每次走到计数处都被置 True，该分支永不触发。已删除该字段。
4. **S3 恒不触发**：反思提示词原先未要求输出置信度字段，故 `confidence` 始终为 0。
   协议已改（见 `agents/base.py`），解析与范围校验在 agent 侧。
5. **无全局硬兜底**：S2 / S3 在某些输入分布下可能恒不触发，存在不终止风险。
   新增 `HardCapStopper`，由 Agent 在每轮结束后**强制叠加**检查，不依赖主 stopper。
6. **无严格预算门**：新增 `BudgetGuard`，在每次 LLM 调用**发起前**检查，超限不发起。
--------------------------------------------------------------------------
"""

from __future__ import annotations

import difflib
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


def answer_change_rate(old: str, new: str) -> float:
    """答案变化率：0 = 完全相同；1 = 完全不同。用归一化编辑距离近似。

    2026-10-13 修复：旧实现返回的是相似度（ratio），语义与函数名相反。
    """
    if old == new:
        return 0.0
    if not old or not new:
        return 1.0
    return 1.0 - difflib.SequenceMatcher(None, old, new).ratio()


@dataclass
class ReflectionState:
    rounds: int = 0
    last_change: float = 1.0
    change_history: List[float] = field(default_factory=list)
    confidence: float = 0.0
    tokens_used: int = 0
    calls_used: int = 0
    n_verdict_malformed: int = 0

    def record_change(self, change: float) -> None:
        """登记一轮反思后的答案变化率，供 S2 做连续判定。"""
        self.last_change = change
        self.change_history.append(change)


class Stopper:
    name = "base"

    def should_stop(self, state: ReflectionState) -> Tuple[bool, str]:
        raise NotImplementedError


class FixedRoundsStopper(Stopper):
    """S1：固定轮次，达 N 轮即停。

    口径说明（`实验协议.md` §7.4.2）：PASS 提前停止是**所有反思策略共享的机制**，
    不是本停止条件的专属特性。因此本条件的全称是「**固定上限 + PASS 提前停止**」，
    **不得**简称为"严格固定轮次"。D4 消融中另设 `ignore_pass=True` 的对照臂。
    """

    name = "S1_fixed_rounds"

    def __init__(self, max_rounds: int = 2) -> None:
        self.max_rounds = max_rounds

    def should_stop(self, state: ReflectionState) -> Tuple[bool, str]:
        if state.rounds >= self.max_rounds:
            return True, f"fixed_rounds:{self.max_rounds}"
        return False, "continue"


class GainStopper(Stopper):
    """S2：反思增益，连续 `streak` 轮答案变化率低于 delta 即停。

    2026-10-13 修复：旧实现 `if state.last_change < self.delta` 只看单轮，
    与 docstring 声称的"连续两轮"不符；且因变化率语义反向（旧 `_change_rate`
    返回相似度）而实际永不按预期触发。现改为基于 `change_history` 的连续判定。
    """

    name = "S2_gain_threshold"

    def __init__(self, delta: float = 0.05, streak: int = 2) -> None:
        self.delta = delta
        self.streak = max(1, int(streak))

    def should_stop(self, state: ReflectionState) -> Tuple[bool, str]:
        hist = state.change_history
        if len(hist) >= self.streak:
            tail = hist[-self.streak:]
            if all(c < self.delta for c in tail):
                return True, f"gain_below_delta:{self.delta}"
        return False, "continue"


class ConfidenceStopper(Stopper):
    """S3：自评置信度达到阈值即停。

    置信度来自**反思输出自身**的 CONFIDENCE 行，不额外发起模型调用；
    该行的输出 token 计入反思臂（见 `实验协议.md` §7.4.4）。

    2026-10-13（S1）说明：Agent 在**每轮反思结束后、PASS 判定之前**调用本条件。
    因此即使该轮 verdict 为 PASS，只要置信度已达阈值，stop_reason 记为
    `confidence>=tau`（优先级见 `agents/plan_reflect.py` 循环内注释）。
    若把本条件留到下一轮循环开头，则"PASS + 高置信"的轮次会先以 PASS 退出，
    S3 只有在"模型仍要求修订却自评高置信"的矛盾轮次上才可能触发。
    """

    name = "S3_confidence"

    def __init__(self, tau: float = 0.9) -> None:
        self.tau = tau

    def should_stop(self, state: ReflectionState) -> Tuple[bool, str]:
        if state.confidence >= self.tau:
            return True, f"confidence>=tau:{self.tau}"
        return False, "continue"


class BudgetStopper(Stopper):
    """S4：预算上限，token 或调用次数超限强制停（**轮间**检查）。

    与 `BudgetGuard` 的区别：S4 是"两轮之间看一眼累计量"，
    `BudgetGuard` 是"每次调用发起前看一眼"，后者在主停止策略为 S1/S2/S3 时也生效。
    """

    name = "S4_budget"

    def __init__(self, max_tokens: int = 4000, max_calls: int = 6) -> None:
        self.max_tokens = max_tokens
        self.max_calls = max_calls

    def should_stop(self, state: ReflectionState) -> Tuple[bool, str]:
        if state.tokens_used >= self.max_tokens:
            return True, f"token_budget:{self.max_tokens}"
        if state.calls_used >= self.max_calls:
            return True, f"call_budget:{self.max_calls}"
        return False, "continue"


class HardCapStopper(Stopper):
    """全局硬兜底：与任何主停止策略解耦，由 Agent 在每轮结束后强制叠加检查。

    存在理由：S2（增益）与 S3（置信）在某些输入分布下可能恒不触发，
    若没有兜底则循环不终止。**这不是贡献，是实现的终止性保证**
    （`实验协议.md` §6.4.3）。
    """

    name = "hard_cap"

    # 默认值取得足够宽松：现有实验的单任务调用量远低于此，不会改变既有行为，
    # 但能保证任何 stopper 配置下都存在终止保证。
    def __init__(self, max_rounds: int = 8, max_calls: int = 16,
                 max_tokens: Optional[int] = None) -> None:
        self.max_rounds = max_rounds
        self.max_calls = max_calls
        self.max_tokens = max_tokens

    def should_stop(self, state: ReflectionState) -> Tuple[bool, str]:
        if state.rounds >= self.max_rounds:
            return True, "hard_cap:rounds"
        if state.calls_used >= self.max_calls:
            return True, "hard_cap:calls"
        if self.max_tokens is not None and state.tokens_used >= self.max_tokens:
            return True, "hard_cap:tokens"
        return False, "continue"


@dataclass
class BudgetGuard:
    """严格预算门：每次 LLM 调用**发起前**检查，超限则不发起。

    2026-10-13 采用"严格预算"（已裁定，`实验协议.md` §6.4.2）：
    - `calls_used + 1 > max_calls` 或 `tokens_used + 预计输入 > max_tokens` 时，
      本次调用**不发起**，调用方标记 `truncated_by_budget` 并报告被截断比例。
    - 未配置（两项均为 None）时不做限制，等价于旧行为。
    """

    max_calls: Optional[int] = None
    max_tokens: Optional[int] = None

    def check(self, calls_used: int, tokens_used: int,
              est_input_tokens: int = 0) -> Tuple[bool, str]:
        if self.max_calls is not None and calls_used + 1 > self.max_calls:
            return False, "call"
        if self.max_tokens is not None and tokens_used + est_input_tokens > self.max_tokens:
            return False, "token"
        return True, ""


def build_stopper(name: str, params: Dict) -> Stopper:
    table = {
        "S1": FixedRoundsStopper,
        "S2": GainStopper,
        "S3": ConfidenceStopper,
        "S4": BudgetStopper,
        "hard_cap": HardCapStopper,
    }
    if name not in table:
        raise ValueError(f"未知停止条件: {name}；可选：{list(table)}")
    return table[name](**params)
