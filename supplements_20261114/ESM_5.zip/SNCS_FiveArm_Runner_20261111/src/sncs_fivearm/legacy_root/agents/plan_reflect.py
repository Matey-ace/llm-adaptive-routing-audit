"""Baseline 3：Fixed Planning + Reflection Agent —— 始终规划、始终反思。

反思轮数由注入的 Stopper 决定（默认 S1 固定 2 轮）。
对应"始终开启 Planning + Reflection"基线，是本文最主要的成本对照对象。

--------------------------------------------------------------------------
2026-10-13（S1）修复清单（对应核查版 §4 与 `实验协议.md` §6.4 / §7.3 / §7.4）：

1. `state.rounds += 1` 原本位于 PASS `break` **之后**，导致"首轮即 PASS"时
   轮次计数永远是 0，反思**实际恒为 1 轮**（历史 88 条反思记录全部如是）。
   现把轮次计数前移到 verdict 判定之前，无论 PASS / REVISE 都计数。
2. VERDICT 解析改为严格行匹配；缺失或畸形一律记 `verdict_malformed`，
   **不再默认 PASS**（§7.4.3）。
3. 反思协议新增 CONFIDENCE 行，解析后做 [0,1] 范围校验，S3 才可能真正生效。
4. 答案变化率改用 `answer_change_rate()`（旧实现返回相似度，语义反向）。
5. 变化率登记移出 if/else，**工具分支同样登记**（旧实现只在非工具分支更新）。
6. 删除 `made_revision` 死分支。
7. 新增全局硬兜底 `HardCapStopper`（每轮强制叠加，不依赖主 stopper）。
8. 新增严格预算门 `BudgetGuard`（每次调用发起前检查，超限不发起，
   标记 `truncated_by_budget`）。
9. 落盘 `extra.first_round_answer` 与 `extra.round_answers[]`，
   供 §7.3 的翻转率 / 纠错率计算（Agent 侧不接触 gold）。
--------------------------------------------------------------------------
"""

from __future__ import annotations

from agents.base import (AgentBase, Step, Trajectory, parse_confidence,
                         parse_verdict)
from agents.stoppers import ReflectionState, Stopper, answer_change_rate
from llm_proxy.usage import UsageMeter
from tasks.agent_view import AgentView


class PlanReflectAgent(AgentBase):
    strategy_name = "plan_reflect"

    def __init__(self, *args, stopper: Stopper | None = None,
                 ignore_pass: bool = False,
                 on_malformed: str = "stop", **kwargs) -> None:
        """ignore_pass：D4 消融臂用。True 时**不采信** PASS，继续到上限
        （由主 stopper 或硬兜底终止），用于把"PASS 提前停止"的独立贡献
        从"反思本身"中分离出来（`实验协议.md` §7.4.2）。

        on_malformed：畸形 / 缺失 VERDICT 的处理策略。
        - "stop"（默认，保守）：立即停止并记 `verdict_malformed`；
        - "continue"：当作 REVISE 继续，直到主 stopper 或硬兜底终止。
        """
        super().__init__(*args, **kwargs)
        from agents.stoppers import FixedRoundsStopper
        self.stopper = stopper or FixedRoundsStopper(max_rounds=self.max_reflections)
        self.ignore_pass = bool(ignore_pass)
        if on_malformed not in ("stop", "continue"):
            raise ValueError("on_malformed 只能是 'stop' 或 'continue'")
        self.on_malformed = on_malformed

    def run(self, av: AgentView) -> Trajectory:
        import time
        meter = self.meter
        started = time.perf_counter()
        traj = Trajectory(task_id=av.task_id, strategy=self.strategy_name,
                          final_answer="")
        traj.extra["ignore_pass"] = self.ignore_pass
        traj.extra["on_malformed"] = self.on_malformed
        traj.extra["round_answers"] = []
        # 预算拦截标记是 Agent 级状态，必须在每个任务开始时清零，
        # 否则上一个任务的截断会污染下一个任务的 stop_reason。
        self.last_budget_block = None

        def blocked() -> bool:
            """严格预算门。返回 True 表示本次调用不得发起、流程须中止。"""
            ok, item = self.budget_ok()
            if ok:
                return False
            traj.stop_reason = self.mark_truncated(traj, item)
            return True

        # 1) 计划
        if blocked():
            return self._finish(av, "", traj, started, meter)
        plan_msgs = self.build_messages(av, "plan")
        t0 = time.perf_counter()
        plan_reply = self.client.chat(plan_msgs, purpose="plan")
        plan_text = plan_reply.content.strip()
        traj.steps.append(Step(kind="plan", prompt=plan_msgs[1]["content"],
                               response=plan_text,
                               latency_ms=(time.perf_counter() - t0) * 1000))
        history = f"计划：\n{plan_text}"

        # 2) 首轮执行
        if av.tools_allowed:
            if blocked():
                return self._finish(av, "", traj, started, meter)
            answer, n_tools, _ = self.run_tool_loop(av)
            traj.n_tool_calls = n_tools
            if self.last_budget_block is not None:
                traj.stop_reason = self.mark_truncated(traj, self.last_budget_block)
                return self._finish(av, answer, traj, started, meter)
        else:
            if blocked():
                return self._finish(av, "", traj, started, meter)
            solve_msgs = self.build_messages(av, "solve", history=history)
            t0 = time.perf_counter()
            reply = self.client.chat(solve_msgs, purpose="solve")
            traj.steps.append(Step(kind="solve", prompt=solve_msgs[1]["content"],
                                   response=reply.content,
                                   latency_ms=(time.perf_counter() - t0) * 1000))
            answer = reply.content.strip()
            if answer.startswith("ANSWER:"):
                answer = answer[len("ANSWER:"):].strip()
        # 首轮答案：反思之前由首次 solve 产生的答案（§7.3 的分母基准）
        traj.extra["first_round_answer"] = answer
        traj.extra["round_answers"].append(answer)
        history += f"\n当前结果：{answer}"

        # 3) 反思循环
        state = ReflectionState(rounds=0, last_change=1.0, confidence=0.0,
                                tokens_used=meter.total_tokens, calls_used=self.calls_used())
        while True:
            # 每轮开始刷新累计量，保证 stopper 看到的是最新值
            state.tokens_used = meter.total_tokens
            state.calls_used = self.calls_used()

            stop, reason = self.stopper.should_stop(state)
            if stop:
                traj.stop_reason = reason
                break
            # 全局硬兜底：与主停止策略解耦，保证终止性
            hc_stop, hc_reason = self.hard_cap.should_stop(state)
            if hc_stop:
                traj.stop_reason = hc_reason
                break
            if blocked():
                break

            refl_msgs = self.build_messages(av, "reflect", history=history)
            t0 = time.perf_counter()
            refl_reply = self.client.chat(refl_msgs, purpose="reflect")
            refl_text = refl_reply.content.strip()
            traj.n_reflections += 1
            traj.steps.append(Step(kind="reflect", prompt=refl_msgs[1]["content"],
                                   response=refl_text,
                                   latency_ms=(time.perf_counter() - t0) * 1000))
            # 轮内停止判断必须包含刚完成的反思调用，避免 S4 看见旧用量。
            state.tokens_used = meter.total_tokens
            state.calls_used = self.calls_used()

            verdict = parse_verdict(refl_text)
            conf, conf_ok = parse_confidence(refl_text)
            if conf_ok:
                state.confidence = conf
            else:
                traj.extra["n_confidence_missing"] = \
                    traj.extra.get("n_confidence_missing", 0) + 1

            # 轮次计数必须在 verdict 判定之前完成：
            # 旧实现把它放在 PASS break 之后，使"首轮即 PASS"时 rounds 恒为 0，
            # 反思实际只跑 1 轮。现无论 PASS / REVISE / MALFORMED 都计入。
            state.rounds += 1

            if verdict == "MALFORMED":
                state.n_verdict_malformed += 1
                traj.extra["n_verdict_malformed"] = state.n_verdict_malformed
                if self.on_malformed == "stop":
                    traj.stop_reason = "verdict_malformed"
                    break
                verdict = "REVISE"   # 保守地当作需要修正，继续到上限/硬兜底

            # 轮内立即判定停止条件（S2/S3/S4 + 硬兜底）。
            # 必须在 PASS 判定**之前**：若放到下一轮循环开头，则"VERDICT: PASS 且
            # 置信度已达阈值"的轮次会先以 PASS 退出，S3 永远没有生效机会
            # （S3 只能停在"模型仍要求修订却自评高置信"的矛盾轮次上）。
            # 优先级：轮内停止条件 > PASS 提前停止；两者同时成立时取更具体的那一个。
            stop, reason = self.stopper.should_stop(state)
            if stop:
                traj.stop_reason = reason
                break
            hc_stop, hc_reason = self.hard_cap.should_stop(state)
            if hc_stop:
                traj.stop_reason = hc_reason
                break

            if verdict == "PASS" and not self.ignore_pass:
                traj.stop_reason = "reflection_verdict_pass"
                break
            # ignore_pass 臂：PASS 不予采信，继续往下走修订分支（等价于 REVISE）

            # 判定为需修正：重规划后重新执行
            if blocked():
                break
            traj.n_replans += 1
            replan_msgs = self.build_messages(
                av, "plan", history=history + f"\n反思意见：\n{refl_text}")
            t0 = time.perf_counter()
            replan_reply = self.client.chat(replan_msgs, purpose="replan")
            replan_text = replan_reply.content.strip()
            traj.steps.append(Step(kind="replan", prompt=replan_msgs[1]["content"],
                                   response=replan_text,
                                   latency_ms=(time.perf_counter() - t0) * 1000))
            history += f"\n反思意见：\n{refl_text}\n修订计划：\n{replan_text}"

            prev_answer = answer
            if av.tools_allowed:
                if blocked():
                    break
                answer, n_tools, _ = self.run_tool_loop(av)
                traj.n_tool_calls += n_tools
                if self.last_budget_block is not None:
                    traj.stop_reason = self.mark_truncated(traj, self.last_budget_block)
                    break
            else:
                if blocked():
                    break
                solve_msgs = self.build_messages(av, "solve", history=history)
                t0 = time.perf_counter()
                reply = self.client.chat(solve_msgs, purpose="solve")
                traj.steps.append(Step(kind="solve", prompt=solve_msgs[1]["content"],
                                       response=reply.content,
                                       latency_ms=(time.perf_counter() - t0) * 1000))
                answer = reply.content.strip()
                if answer.startswith("ANSWER:"):
                    answer = answer[len("ANSWER:"):].strip()

            # 变化率登记对所有分支生效（旧实现只在非工具分支更新，
            # 导致工具任务下 S2 永远看到初始值 1.0）
            state.record_change(answer_change_rate(prev_answer, answer))
            traj.extra["round_answers"].append(answer)
            history += f"\n当前结果：{answer}"

        if traj.stop_reason is None:
            traj.stop_reason = "stopper_default"
        return self._finish(av, answer, traj, started, meter)
