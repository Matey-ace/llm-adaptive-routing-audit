"""本文方法：Adaptive Planning + Reflection Agent。

流程：
  1. 复杂度路由（complexity.router.C3Router）→ easy / medium / hard
  2. 路由：easy → Direct 路径；medium → Planning 路径；hard → Planning + Reflection 路径
  3. escalation：Direct 路径输出格式不合规时升级到 Planning 路径

路由决策由 complexity 模块统一负责（规则低/高区免费，灰区调 LLM judge），
judge 调用与其他调用一样走 client.chat() 并带 purpose="judge"，成本计入总指标
——这是本文与"免费路由"类工作的关键区别之一，也是审稿人会核查的点。

router 通过构造参数注入；未注入时退化为"全部灰区→medium→planning"的保守默认，
不 crash（便于未配置标定的调试场景）。正式实验须注入已在 calibration 上冻结阈值的 router。
"""

from __future__ import annotations

import time

from agents.base import AgentBase, Step, Trajectory
from agents.plan_reflect import PlanReflectAgent
from agents.stoppers import Stopper
from llm_proxy.usage import UsageMeter
from tasks.agent_view import AgentView


class AdaptiveAgent(AgentBase):
    strategy_name = "adaptive"

    def __init__(self, *args, stopper: Stopper | None = None,
                 escalate_on_bad_format: bool = True, router=None,
                 ignore_pass: bool = False, on_malformed: str = "stop",
                 enable_reflection: bool = True,
                 **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.escalate_on_bad_format = escalate_on_bad_format
        self.router = router
        self.ignore_pass = bool(ignore_pass)
        self.on_malformed = on_malformed
        self.enable_reflection = bool(enable_reflection)
        self._inner_reflect = PlanReflectAgent(
            self.client, toolbox=self.toolbox, stopper=stopper,
            max_reflections=self.max_reflections, hard_cap=self.hard_cap,
            budget=self.budget, ignore_pass=ignore_pass,
            on_malformed=on_malformed)

    def run(self, av: AgentView) -> Trajectory:
        meter = self.meter
        started = time.perf_counter()
        traj = Trajectory(task_id=av.task_id, strategy=self.strategy_name,
                          final_answer="")
        self.last_budget_block = None
        if not self.budget_ok()[0]:
            return self._finish(av, "", traj, started, meter)

        # ---- 1) 复杂度路由（规则 + 可选 LLM judge）----
        if self.router is None:
            # 未注入 router 的保守默认：全部视为 medium → planning
            decision = None
            level = "medium"
            method = "no_router_default"
            score = 0.0
            judge_info = None
        else:
            decision = self.router.route(self.client, av.prompt)
            level = decision.level
            method = decision.method
            score = decision.score
            judge_info = decision.judge_info
            if judge_info is not None:
                # P3：judge 调用留痕——真实 prompt、延迟、本次调用增量用量、锚点示例 ID
                traj.steps.append(Step(
                    kind="judge",
                    prompt=judge_info.get("prompt", ""),
                    response=judge_info.get("raw", ""),
                    latency_ms=float(judge_info.get("latency_ms", 0.0) or 0.0),
                    detail={
                        "method": method,
                        "judge_examples": judge_info.get("example_ids", []),
                        "judge_usage": judge_info.get("usage"),
                        "judge_model": judge_info.get("model"),
                        "judge_level": judge_info.get("level"),
                        "judge_ok": judge_info.get("ok"),
                        "judge_confidence": judge_info.get("confidence"),
                        "judge_reasoning_steps": judge_info.get("reasoning_steps"),
                    }))

        traj.selected_level = level
        traj.extra["route_method"] = method
        traj.extra["rule_score"] = round(score, 4)
        # P3：走未拟合退路的样本必须能被检索出来（不应计入正常评测）
        if decision is not None and getattr(decision, "unfitted", False):
            traj.extra["router_unfitted"] = True
        if judge_info is not None:
            traj.extra["judge_ok"] = judge_info.get("ok")
            traj.extra["judge_confidence"] = judge_info.get("confidence")
            traj.extra["judge_reasoning_steps"] = judge_info.get("reasoning_steps")

        # ---- 2) 路由 ----
        if level == "easy":
            traj.selected_path = "direct"
            answer, stop_reason = self._run_direct_path(av, meter, traj)
        elif level == "medium":
            traj.selected_path = "planning"
            answer, stop_reason = self._run_planning_path(av, meter, traj)
        elif not self.enable_reflection:
            traj.selected_path = 'planning'
            traj.extra['reflection_disabled'] = True
            answer, stop_reason = self._run_planning_path(av, meter, traj)
        else:
            traj.selected_path = "plan_reflect"
            answer, stop_reason = self._run_reflect_path(av, meter, traj)
        traj.stop_reason = stop_reason

        return self._finish(av, answer, traj, started, meter)

    # ------------------------------------------------------------------ 各路径
    def _run_direct_path(self, av: AgentView, meter: UsageMeter, traj: Trajectory):
        if not self.budget_ok()[0]:
            return "", self.mark_truncated(traj, self.last_budget_block)
        if av.tools_allowed:
            answer, n_tools, reason = self.run_tool_loop(av)
            traj.n_tool_calls = n_tools
            return answer, reason

        msgs = self.build_messages(av, "solve")
        t0 = time.perf_counter()
        reply = self.client.chat(msgs, purpose="solve")
        traj.steps.append(Step(kind="solve", prompt=msgs[1]["content"],
                               response=reply.content,
                               latency_ms=(time.perf_counter() - t0) * 1000))
        content = reply.content.strip()

        # escalation：输出不合规则升级到 Planning 路径
        if self.escalate_on_bad_format and not (
                content.startswith("ANSWER:") or content.startswith("FINAL:")):
            traj.extra["escalated_from"] = "direct"
            answer, reason = self._run_planning_path(av, meter, traj)
            if reason in ("call_budget", "token_budget", "hard_cap:calls") and not answer:
                answer = content
            return answer, reason

        if content.startswith("ANSWER:"):
            content = content[len("ANSWER:"):].strip()
        elif content.startswith("FINAL:"):
            content = content[len("FINAL:"):].strip()
        return content, "direct_single_shot"

    def _run_planning_path(self, av: AgentView, meter: UsageMeter, traj: Trajectory):
        if not self.budget_ok()[0]:
            return "", self.mark_truncated(traj, self.last_budget_block)
        plan_msgs = self.build_messages(av, "plan")
        t0 = time.perf_counter()
        plan_reply = self.client.chat(plan_msgs, purpose="plan")
        plan_text = plan_reply.content.strip()
        traj.steps.append(Step(kind="plan", prompt=plan_msgs[1]["content"],
                               response=plan_text,
                               latency_ms=(time.perf_counter() - t0) * 1000))
        history = f"计划：\n{plan_text}"
        if not self.budget_ok()[0]:
            return "", self.mark_truncated(traj, self.last_budget_block)

        if av.tools_allowed:
            answer, n_tools, reason = self.run_tool_loop(av)
            traj.n_tool_calls = n_tools
            return answer, reason

        solve_msgs = self.build_messages(av, "solve", history=history)
        t0 = time.perf_counter()
        reply = self.client.chat(solve_msgs, purpose="solve")
        traj.steps.append(Step(kind="solve", prompt=solve_msgs[1]["content"],
                               response=reply.content,
                               latency_ms=(time.perf_counter() - t0) * 1000))
        answer = reply.content.strip()
        if answer.startswith("ANSWER:"):
            answer = answer[len("ANSWER:"):].strip()
        return answer, "planned_single_shot"

    def _run_reflect_path(self, av: AgentView, meter: UsageMeter, traj: Trajectory):
        """hard 路径复用 PlanReflectAgent 的完整循环，保证与基线 3 的实现一致。"""
        sub = self._inner_reflect.run(av)
        traj.n_reflections = sub.n_reflections
        traj.n_replans = sub.n_replans
        traj.n_tool_calls = sub.n_tool_calls
        # 将子轨迹的步骤并入，保留完整审计链
        traj.steps.extend(sub.steps)
        traj.extra["sub_strategy"] = sub.strategy
        traj.extra.update(sub.extra)
        return sub.final_answer, (sub.stop_reason or "reflect_path_done")


def build_agent(name: str, client: LLMClient, **kwargs):
    """按名称构造 Agent，供 runner 与实验配置使用。

    额外识别的 kwargs：
    - stopper / stopper_params：plan_reflect / adaptive 的停止条件
    - router：注入 adaptive 的复杂度路由（complexity.router.C3Router）
    - k：vote_k 的采样次数
    - hard_cap：全局硬兜底参数（dict，透传 HardCapStopper；缺省用宽松默认值）
    - budget：严格预算门参数（dict，透传 BudgetGuard；缺省 None = 不限制）
    - ignore_pass：D4 消融臂，不采信 PASS 提前停止（仅 plan_reflect / adaptive）
    - on_malformed：畸形 VERDICT 的处理策略 "stop" / "continue"（同上）
    其余 kwargs 透传给对应 Agent 构造器。
    """
    from agents.direct import DirectAgent
    from agents.planning import PlanningAgent
    from agents.plan_reflect import PlanReflectAgent
    from agents.majority_vote import MajorityVoteAgent
    from agents.stoppers import BudgetGuard, HardCapStopper, build_stopper

    stopper_name = kwargs.pop("stopper", "S1")
    stopper_params = kwargs.pop("stopper_params", {"max_rounds": 2})
    stopper = build_stopper(stopper_name, stopper_params)
    router = kwargs.pop("router", None)
    k = kwargs.pop("k", 3)

    hard_cap_cfg = kwargs.pop("hard_cap", None)
    hard_cap = HardCapStopper(**hard_cap_cfg) if hard_cap_cfg else None
    budget_cfg = kwargs.pop("budget", None)
    budget = BudgetGuard(**budget_cfg) if budget_cfg else None
    ignore_pass = bool(kwargs.pop("ignore_pass", False))
    on_malformed = kwargs.pop("on_malformed", "stop")
    enable_reflection = bool(kwargs.pop('enable_reflection', True))

    # stopper / hard_cap / budget 对所有策略生效（后两者是安全与可比性约束）
    common = {"hard_cap": hard_cap, "budget": budget}
    # 反思相关开关只对含反思的策略有意义
    refl = {"ignore_pass": ignore_pass, "on_malformed": on_malformed}

    table = {
        "direct": lambda: DirectAgent(client, **kwargs, **common),
        "planning": lambda: PlanningAgent(client, **kwargs, **common),
        "plan_reflect": lambda: PlanReflectAgent(client, stopper=stopper,
                                                 **kwargs, **common, **refl),
        "adaptive": lambda: AdaptiveAgent(client, stopper=stopper, router=router,
                                          enable_reflection=enable_reflection, **kwargs, **common, **refl),
        "vote_k": lambda: MajorityVoteAgent(client, k=k, **kwargs, **common),
    }
    if name not in table:
        raise ValueError(f"未知策略: {name}；可选：{list(table)}")
    return table[name]()
