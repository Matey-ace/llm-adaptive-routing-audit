"""本地可执行工具（mock 环境）。

真实实验中这些工具对应检索 API / 计算器 / 代码执行器；
此处用确定性实现替代，使工具调用链路（调用、观测、反馈、收尾）可以被完整执行与审计。

所有工具返回 (observation, ok)。observation 会进入后续 prompt，
因此必须简短、确定，且不含任何"答案提示"。
"""

from __future__ import annotations

import re
from typing import Dict, Tuple


class MockToolBox:
    def __init__(self) -> None:
        self._fact_db = {
            "光速": "真空中的光速约为 299792458 米/秒。",
            "水沸点": "在标准大气压下，水的沸点是 100 摄氏度。",
            "长城": "明长城的总长度约为 8850 千米。",
            "珠江": "珠江全长约 2214 千米，流域面积约 45 万平方千米。",
        }

    # 供 prompt 描述用
    def describe(self, allowed: Tuple[str, ...]) -> str:
        parts = []
        for name in allowed:
            fn = getattr(self, f"tool_{name}", None)
            if fn is not None:
                parts.append(f"{name}({getattr(fn, '__doc__', '').strip() or '参数见说明'})")
        return "；".join(parts) if parts else "无可用工具"

    def call(self, name: str, argument: str = "") -> Tuple[str, bool]:
        fn = getattr(self, f"tool_{name}", None)
        if fn is None:
            return f"未知工具: {name}", False
        try:
            return fn(argument), True
        except Exception as exc:  # noqa: BLE001
            return f"工具执行异常: {exc}", False

    # ---------------------------------------------------------------- 工具实现
    def tool_calculator(self, expression: str):
        """expression: 算术表达式，如 3*12+5"""
        if not re.fullmatch(r"[\d\s\.\+\-\*\/\(\)]+", expression or ""):
            return "表达式不合法，仅支持数字与 + - * / ( )"
        try:
            value = eval(expression, {"__builtins__": {}}, {})  # noqa: S307 - 已做字符白名单校验
        except ZeroDivisionError:
            return "除数不能为 0"
        return f"计算结果: {value}"

    def tool_search(self, query: str):
        """query: 检索关键词"""
        for key, val in self._fact_db.items():
            if key in (query or ""):
                return val
        return f"未检索到与『{query}』相关的条目"

    def tool_extract(self, text: str):
        """text: 待抽取数字的文本"""
        nums = re.findall(r"-?\d+(?:\.\d+)?", text or "")
        return "抽取到的数字: " + (", ".join(nums) if nums else "无")

    def tool_wordcount(self, text: str):
        """text: 待统计的文本"""
        return f"字符数: {len(text or '')}"


DEFAULT_TOOLBOX = MockToolBox()
