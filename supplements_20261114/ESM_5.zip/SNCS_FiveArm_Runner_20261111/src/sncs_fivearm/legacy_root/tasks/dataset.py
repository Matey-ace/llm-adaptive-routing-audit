"""任务数据结构。

关键设计：`difficulty_anchor` 记录该任务的**客观难度锚点**——
即来自数据集原始标注的难度依据（如 GSM8K 方程步数、HotpotQA supporting-facts 跳数、
MATH level、自建集的所需工具调用步数），而非模型表现。

这一字段是论文"三层数据隔离"与"避免用模型表现定义难度"的制度基础，
写作时必须在实验设计章节明确说明其来源。
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Optional


@dataclass
class Task:
    task_id: str
    task_type: str                 # fact_qa / text_processing / math / multihop / code / tool_use
    difficulty: str                # easy / medium / hard
    difficulty_anchor: Dict[str, Any]   # 客观难度锚点及其来源
    prompt: str                    # 送入 LLM 的任务正文
    gold: Any                      # 标准答案（程序可判定）
    metric: str                    # exact_match / numeric_match / contains / tool_trajectory
    split: str = "test"            # calibration / dev / test
    source: str = "mock"           # 数据来源：gsm8k / hotpotqa / humaneval / math / custom / mock
    tools_allowed: tuple = ()      # 该任务允许使用的本地工具名
    gold_trajectory: tuple = ()    # tool_use 任务的标准工具调用序列
    notes: str = ""
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["tools_allowed"] = list(self.tools_allowed)
        d["gold_trajectory"] = list(self.gold_trajectory)
        return d

    @classmethod
    def from_dict(cls, d: Dict) -> "Task":
        d = dict(d)
        d["tools_allowed"] = tuple(d.get("tools_allowed") or ())
        d["gold_trajectory"] = tuple(d.get("gold_trajectory") or ())
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in known})


def make_task(**kwargs) -> Task:
    """构造 Task 的便捷函数，必填字段缺失时给出清晰报错。"""
    required = ["task_id", "task_type", "difficulty", "prompt", "gold", "metric"]
    missing = [k for k in required if k not in kwargs]
    if missing:
        raise ValueError(f"缺少必填字段: {missing}")
    kwargs.setdefault("difficulty_anchor", {"rule": "未标注"})
    return Task(**kwargs)
