"""AgentView：Agent 在运行时看到的任务视图（信息隔离的结构性保证）。

设计目的（见 paper/实验协议.md 第 4 节"评测信息隔离"）：
Agent 在推理时**只应看到构造 prompt 所需的字段**（prompt / tools_allowed）。
刻意排除 gold / difficulty / difficulty_anchor / split / source / notes / extra /
gold_trajectory，使得这些评测元数据在结构上**不可能**进入任何 prompt——
即便有人误改 prompt 拼装逻辑，也拿不到这些字段。

------------------------------------------------------------------------------
P2 变更（2026-10-13）：移除评分闭包
------------------------------------------------------------------------------
本视图原先还带一个 `grade(answer) -> bool` 闭包，虽然当时只用于 `_finish` 的
收尾评分，但它在结构上意味着 **Agent 可以在推理过程中拿到基于 gold 的正确性反馈**
（例如用来自我判断何时停止、或在多个候选答案里挑答），这在论文的公平性论证里
是必须堵住的口子。

现在：
- `AgentView` 只有 {task_id, prompt, tools_allowed}；
- Agent **不再自评**，`Trajectory.success` 在 Agent 返回时保持 None；
- 评分统一由 runner 在 Agent 返回后执行（`runner/scoring.py`），
  且写入 `success` / `needs_review` / `score_reason` / `scorer_version` 四个字段。

另：一件事 cf. 计划 §1.8 的记录要求——judge 的 prompt 允许使用 calibration
锚点示例（这是它与自申请表icarity routing 的一部分），但**不得**泄漏目标任务标签；
每次 judge 调用使用的示例 ID 记录在 Step.detail["judge_examples"] 里备查。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

from tasks.dataset import Task

# 结构性白名单：AgentView 允许出现的字段。tests/test_isolation.py 以此为门禁，
# 任何新增字段都必须在此显式登记并说明理由。
AGENT_VIEW_FIELDS: Tuple[str, ...] = ("task_id", "prompt", "tools_allowed")


@dataclass(frozen=True)
class AgentView:
    """Agent 运行时可见的最小任务视图（**不含任何评分能力**）。

    字段说明：
    - task_id：仅用于轨迹记录与日志，不进入 prompt。
    - prompt：任务正文，唯一进入 prompt 的内容。
    - tools_allowed：允许使用的工具名元组，仅当非空时写入 prompt 的工具说明。

    `frozen=True` 使视图在运行中不可被改写（含不可被动态挂载 gold / grade），
    这比"约定不使用"更强：想偷偷加字段会在赋值时就报错。
    """

    task_id: str
    prompt: str
    tools_allowed: Tuple[str, ...] = ()


def to_agent_view(task: Task) -> AgentView:
    """从完整 Task 构造 AgentView。

    不再构造评分闭包：Task 对象在此函数返回后即不可通过视图触达，
    评分改由 runner 侧持有 Task 完成（见 `runner/scoring.py`）。
    """
    return AgentView(
        task_id=task.task_id,
        prompt=task.prompt,
        tools_allowed=tuple(task.tools_allowed or ()),
    )
