"""SQLite 响应缓存。

作用：同一 model + 同一 prompt + 同一解码参数的重复调用只计费一次。
这是控制实验预算的关键手段，同时在论文中作为"可复现性"的一个技术细节说明。

注意：缓存命中时不计 token、不计费，但会记录一条 cached=True 的 UsageRecord，
以便统计"实际发生的调用次数"与"真实计费调用次数"两个口径。

并发说明：runner 会为每个任务创建独立的 LLMClient，因此本类必须按 db_path
**共享同一实例**（类级注册表）。否则每个实例各持一把互斥锁，等于没有互斥，
多线程首次写入同一个新库时会触发 "attempt to write a readonly database"。
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import threading
from typing import Dict, Optional


class ResponseCache:
    _instances: Dict[str, "ResponseCache"] = {}
    _registry_lock = threading.Lock()

    def __init__(self, db_path: str, enabled: bool = True) -> None:
        self.db_path = db_path
        self.enabled = enabled
        self._local = threading.local()
        self._write_lock = threading.Lock()
        if self.enabled:
            os.makedirs(os.path.dirname(os.path.abspath(db_path)) or ".", exist_ok=True)
            # 注意：不要在这里获取 _registry_lock —— get_instance 已持有该锁并调用本构造函数，
            # 再次获取同一把非可重入锁会造成死锁。
            with self._conn() as conn:
                try:
                    conn.execute("PRAGMA journal_mode=WAL")
                    conn.execute("PRAGMA busy_timeout=30000")
                except sqlite3.Error:
                    pass  # WAL 转换失败时退化为普通日志模式，不影响可用性
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS responses (
                        cache_key TEXT PRIMARY KEY,
                        model TEXT NOT NULL,
                        content TEXT NOT NULL,
                        prompt_tokens INTEGER NOT NULL,
                        completion_tokens INTEGER NOT NULL
                    )
                    """
                )

    @classmethod
    def get_instance(cls, db_path: str, enabled: bool = True) -> "ResponseCache":
        """按 db_path 取得共享实例；同一路径在同一进程内只有一个实例与一把写锁。"""
        key = os.path.abspath(db_path)
        with cls._registry_lock:
            inst = cls._instances.get(key)
            if inst is None or inst.enabled != enabled:
                inst = cls(db_path, enabled=enabled)
                cls._instances[key] = inst
            return inst

    def _conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self.db_path, timeout=30, check_same_thread=False)
            try:
                conn.execute("PRAGMA busy_timeout=30000")
            except sqlite3.Error:
                pass
            self._local.conn = conn
        return conn

    @staticmethod
    def make_key(model: str, messages: list, decoding: dict, repeat_id: str = "") -> str:
        payload = json.dumps(
            {"model": model, "messages": messages, "decoding": decoding, "repeat_id": repeat_id},
            ensure_ascii=False,
            sort_keys=True,
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def get(self, cache_key: str) -> Optional[dict]:
        if not self.enabled:
            return None
        try:
            with self._conn() as conn:
                row = conn.execute(
                    "SELECT content, prompt_tokens, completion_tokens FROM responses WHERE cache_key = ?",
                    (cache_key,),
                ).fetchone()
        except sqlite3.Error:
            # 缓存是省钱手段，不是正确性依赖：读失败就当作未命中，重新调用。
            return None
        if row is None:
            return None
        return {"content": row[0], "prompt_tokens": row[1], "completion_tokens": row[2]}

    def put(self, cache_key: str, model: str, content: str,
            prompt_tokens: int, completion_tokens: int) -> None:
        if not self.enabled:
            return
        try:
            with self._write_lock, self._conn() as conn:
                conn.execute(
                    "INSERT OR REPLACE INTO responses VALUES (?,?,?,?,?)",
                    (cache_key, model, content, prompt_tokens, completion_tokens),
                )
        except sqlite3.Error:
            # 写失败不影响本次实验的正确性，只意味着这条响应无法被后续复用。
            pass

    def close(self) -> None:
        conn = getattr(self._local, "conn", None)
        if conn is not None:
            conn.close()
            self._local.conn = None
