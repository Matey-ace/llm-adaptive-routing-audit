"""Token / 调用 / 延迟 / 成本的计量与累计。

设计原则：
- 计量是论文的核心贡献之一，因此口径必须统一且可审计。
- 每次 LLM 调用都产生一条 UsageRecord，由 UsageMeter 汇总为 Trajectory 级指标。
- 成本按 configs/models.yaml 中登记的人民币单价计算，单价来源与日期须在论文中注明。
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, List


@dataclass
class UsageRecord:
    """单次 LLM 调用的计量记录。"""

    call_index: int
    purpose: str            # 本次调用的用途：judge / plan / execute / reflect / solve ...
    prompt_tokens: int
    completion_tokens: int
    latency_ms: float
    model: str
    cost_usd: float
    cost_cny: float
    cached: bool = False

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["total_tokens"] = self.total_tokens
        return d


@dataclass
class UsageMeter:
    """累计一个 Trajectory（一次任务执行）内的所有调用。"""

    model: str = ""
    records: List[UsageRecord] = field(default_factory=list)

    def add(self, record: UsageRecord) -> None:
        self.records.append(record)

    # ---- 汇总指标 ----
    @property
    def n_calls(self) -> int:
        return len(self.records)

    @property
    def n_uncached_calls(self) -> int:
        return sum(1 for r in self.records if not r.cached)

    @property
    def prompt_tokens(self) -> int:
        return sum(r.prompt_tokens for r in self.records)

    @property
    def completion_tokens(self) -> int:
        return sum(r.completion_tokens for r in self.records)

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens

    @property
    def total_latency_ms(self) -> float:
        return sum(r.latency_ms for r in self.records)

    @property
    def total_cost_usd(self) -> float:
        return sum(r.cost_usd for r in self.records)

    @property
    def total_cost_cny(self) -> float:
        return sum(r.cost_cny for r in self.records)

    def calls_by_purpose(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for r in self.records:
            out[r.purpose] = out.get(r.purpose, 0) + 1
        return out

    def summary(self) -> Dict:
        return {
            "model": self.model,
            "n_calls": self.n_calls,
            "n_uncached_calls": self.n_uncached_calls,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
            "total_latency_ms": round(self.total_latency_ms, 3),
            "total_cost_usd": round(self.total_cost_usd, 8),
            "total_cost_cny": round(self.total_cost_cny, 6),
            "calls_by_purpose": self.calls_by_purpose(),
        }
