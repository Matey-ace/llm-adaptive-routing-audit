"""统一 LLM 调用层。

- 真实模式：通过 openai SDK 调用 OpenAI 兼容端点（DeepSeek / 通义 / OpenAI 均支持）。
- mock 模式：不发起网络请求，按 prompt 内容生成符合输出协议的结构化响应，
  用于在拿到 API Key 前把整条实验流水线打通。

mock 模式的定位：**只验证工程链路，不产生任何可引用的实验结论**。
所有论文结论必须来自真实模式下的 results/raw/*.jsonl。

输出协议（Agent 与 mock 共同遵守，定义于 agents/prompts.py）：
    ANSWER:  <最终答案>
    PLAN:\n1. ...\n2. ...
    REFLECT:\n- ...\nVERDICT: PASS | REVISE
    ACTION: <tool_name>(<args>)     # 需要调用工具时
    FINAL:  <最终答案>              # 工具流程结束时
"""

from __future__ import annotations

import os
import random
import re
import time
import threading
from dataclasses import dataclass
from typing import Dict, List, Optional

import yaml

from .cache import ResponseCache
from .usage import UsageMeter, UsageRecord

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_REQUEST_LOCK = threading.Lock()
_NEXT_REQUEST = 0.0


def pace_request(interval):
    global _NEXT_REQUEST
    if interval <= 0:
        return
    with _REQUEST_LOCK:
        now = time.monotonic()
        delay = max(0.0, _NEXT_REQUEST - now)
        _NEXT_REQUEST = max(now, _NEXT_REQUEST) + interval
    if delay:
        time.sleep(delay)


@dataclass
class LLMReply:
    content: str
    prompt_tokens: int
    completion_tokens: int
    latency_ms: float
    cached: bool
    model: str
    finish_reason: str = "stop"


class LLMClient:
    """所有 LLM 调用的唯一出口。每次调用都会向 UsageMeter 登记一条记录。"""

    def __init__(self, provider: str, model: str, meter: UsageMeter,
                 models_config: Optional[dict] = None, base_config: Optional[dict] = None,
                 mock_seed: int = 1234) -> None:
        self.provider_name = provider
        self.model = model
        self.meter = meter
        meter.model = model

        models_config = models_config or {}
        base_config = base_config or {}

        if provider not in models_config:
            raise ValueError(f"未登记的 provider: {provider}；可选：{list(models_config)}")
        prov = models_config[provider]
        self.prov_type = prov["type"]
        # 单价统一以美元 / 1M tokens 计；人民币成本按 base.yaml 的汇率换算
        self.price_in_usd = float(prov.get("price_per_m_input_usd", 0.0))
        self.price_out_usd = float(prov.get("price_per_m_output_usd", 0.0))
        self.usd_to_cny = float(base_config.get("cost", {}).get("usd_to_cny", 7.10))

        # 模型级单价优先于 provider 级
        model_cfg = (prov.get("models") or {}).get(model)
        if model_cfg:
            self.price_in_usd = float(model_cfg.get("price_per_m_input_usd", self.price_in_usd))
            self.price_out_usd = float(model_cfg.get("price_per_m_output_usd", self.price_out_usd))

        self.max_output_tokens = int((model_cfg or {}).get("max_output_tokens", 8192))
        # 部分平台的 supported_parameters 不含 seed，传入可能报错，故做成开关
        self.supports_seed = bool(prov.get("supports_seed", True))

        dec = base_config.get("decoding", {})
        self.temperature = float(dec.get("temperature", 0.0))
        self.top_p = float(dec.get("top_p", 1.0))
        self.seed = dec.get("seed", 42)
        self.default_max_tokens = int(dec.get("max_tokens", 1024))

        rt = base_config.get("runtime", {})
        self.mock_failure_rate = float(rt.get("mock_failure_rate", 0.0))
        self.mock_latency_ms = float(rt.get("mock_latency_ms", 0))

        retry = base_config.get("retry", {})
        self.max_attempts = int(retry.get("max_attempts", 4))
        self.initial_backoff_s = float(retry.get("initial_backoff_s", 1.0))
        self.max_backoff_s = float(retry.get("max_backoff_s", 20.0))

        cache_cfg = base_config.get("cache", {})
        self.cache = ResponseCache.get_instance(
            db_path=cache_cfg.get("db_path", "results/cache.db"),
            enabled=bool(cache_cfg.get("enabled", True)),
        )

        self._call_counter = 0
        self.request_attempts = 0
        self.max_request_attempts = None
        self._rng = random.Random(mock_seed)
        # 重复实验标识：runner 在每次 run_one 时按 repeat 设为不同值（如 "r0"/"r1"），
        # 使 majority vote 等多次独立作答不会因命中同一条缓存而彼此污染。
        self.repeat_id = ""
        self.failed_attempts = []
        self.call_audit = []
        self._response_envelope = None
        self.request_interval = float(os.environ.get("INTERN_AI_REQUEST_INTERVAL_S", "0")) if provider == "intern_ai" else 0

        self._client = None
        if self.prov_type == "openai_compatible":
            key_env = prov.get("api_key_env")
            api_key = os.environ.get(key_env) if key_env else None
            if not api_key:
                raise RuntimeError(
                    f"provider={provider} 需要环境变量 {key_env}；未设置时请改用 mock provider"
                )
            from openai import OpenAI
            # max_retries=0：重试由本类的指数退避循环统一负责，避免两层重试叠加
            self._client = OpenAI(
                api_key=api_key,
                base_url=prov.get("base_url"),
                timeout=float(rt.get("request_timeout_s", 120)),
                max_retries=0,
            )
        elif self.prov_type != "mock":
            raise ValueError(f"不支持的 provider 类型: {self.prov_type}")

    # ------------------------------------------------------------------ 公共接口
    def chat(self, messages: List[dict], purpose: str = "solve",
             max_tokens: Optional[int] = None, decoding_override: Optional[dict] = None,
             repeat_id: Optional[str] = None) -> LLMReply:
        """发起一次调用。带指数退避重试与 SQLite 缓存。

        repeat_id：重复实验标识。未显式传入时回退到 `self.repeat_id`（由 runner
        按 repeat 设定）。同一 (model, messages, decoding) 在重复采样（如 majority
        vote 的多次独立作答、温度/种子扰动）时必须使用不同的 repeat_id，否则会全部
        命中同一条缓存，使"重复实验"形同虚设。
        """
        decoding = {
            "temperature": self.temperature,
            "top_p": self.top_p,
            "seed": self.seed,
            "max_tokens": max_tokens or self.default_max_tokens,
        }
        if decoding_override:
            decoding.update(decoding_override)

        rid = repeat_id if repeat_id is not None else self.repeat_id
        self._call_counter += 1
        call_index = self._call_counter
        key = ResponseCache.make_key(self.model, messages, decoding, rid)

        cached = self.cache.get(key)
        if cached is not None:
            reply = LLMReply(
                content=cached["content"],
                prompt_tokens=cached["prompt_tokens"],
                completion_tokens=cached["completion_tokens"],
                latency_ms=0.0,
                cached=True,
                model=self.model,
                finish_reason="unknown_cached",
            )
            self.call_audit.append({"purpose": purpose, "cached": True,
                "messages": messages, "decoding": decoding,
                "finish_reason": "unknown_cached", "response_envelope": None})
            self._record(reply, purpose, call_index)
            return reply

        last_err: Optional[Exception] = None
        for attempt in range(self.max_attempts):
            if self.max_request_attempts is not None and self.request_attempts >= self.max_request_attempts:
                raise RuntimeError('Shared request-attempt ceiling reached before request')
            started = time.perf_counter()
            try:
                if self.prov_type != "mock":
                    pace_request(self.request_interval)
                    started = time.perf_counter()
                self._response_envelope = None
                self.request_attempts += 1
                content, p_tok, c_tok, finish = self._raw_chat(messages, decoding)
                latency = (time.perf_counter() - started) * 1000.0
                reply = LLMReply(content=content, prompt_tokens=p_tok,
                                 completion_tokens=c_tok, latency_ms=latency,
                                 cached=False, model=self.model, finish_reason=finish)
                self.cache.put(key, self.model, content, p_tok, c_tok)
                self._record(reply, purpose, call_index)
                self.call_audit.append({"purpose": purpose, "cached": False,
                    "messages": messages, "decoding": decoding,
                    "finish_reason": finish, "content": content,
                    "response_envelope": self._response_envelope})
                return reply
            except Exception as exc:  # noqa: BLE001 - 重试需要兜住所有异常
                last_err = exc
                self.failed_attempts.append({"purpose": purpose, "attempt": attempt + 1,
                    "messages": messages, "decoding": decoding,
                    "api_elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
                    "error": str(exc), "status_code": getattr(exc, "status_code", None)})
                if attempt < self.max_attempts - 1:
                    backoff = min(self.initial_backoff_s * (2 ** attempt), self.max_backoff_s)
                    if getattr(exc, "status_code", None) == 429:
                        backoff = max(backoff, 65.0)
                    time.sleep(backoff)
        raise RuntimeError(f"LLM 调用在 {self.max_attempts} 次尝试后仍失败: {last_err}")

    # ------------------------------------------------------------------ 内部实现
    def _record(self, reply: LLMReply, purpose: str, call_index: int) -> None:
        cost_usd = (reply.prompt_tokens / 1e6) * self.price_in_usd + \
                   (reply.completion_tokens / 1e6) * self.price_out_usd
        cost_cny = cost_usd * self.usd_to_cny
        self.meter.add(UsageRecord(
            call_index=call_index,
            purpose=purpose,
            prompt_tokens=reply.prompt_tokens,
            completion_tokens=reply.completion_tokens,
            latency_ms=reply.latency_ms,
            model=self.model,
            cost_usd=cost_usd,
            cost_cny=cost_cny,
            cached=reply.cached,
        ))

    def _raw_chat(self, messages: List[dict], decoding: dict):
        if self.prov_type == "mock":
            return self._mock_chat(messages, decoding)
        return self._openai_chat(messages, decoding)

    def _openai_chat(self, messages: List[dict], decoding: dict):
        kwargs = dict(
            model=self.model,
            messages=messages,
            temperature=decoding["temperature"],
            top_p=decoding["top_p"],
            max_tokens=decoding["max_tokens"],
        )
        # 仅当 provider 声明支持 seed 时才传入，避免部分平台因未知参数报错
        if self.supports_seed and decoding.get("seed") is not None:
            kwargs["seed"] = decoding["seed"]
        resp = self._client.chat.completions.create(**kwargs)
        self._response_envelope = resp.model_dump()
        choice = resp.choices[0]
        usage = resp.usage
        return (
            choice.message.content or "",
            int(usage.prompt_tokens),
            int(usage.completion_tokens),
            choice.finish_reason or "stop",
        )

    # ------------------------------------------------------------------ mock 模式
    def _mock_chat(self, messages: List[dict], decoding: dict):
        """确定性 mock：同一输入必然得到同一输出，保证流程可复现。"""
        if self.mock_latency_ms > 0:
            time.sleep(self.mock_latency_ms / 1000.0)
        if self.mock_failure_rate > 0 and self._rng.random() < self.mock_failure_rate:
            raise RuntimeError("mock 模拟的瞬时调用失败")

        user_text = self._last_user_text(messages)
        system_text = self._system_text(messages)
        content = self._mock_generate(user_text, system_text)
        p_tok = self._estimate_tokens(system_text + user_text)
        c_tok = self._estimate_tokens(content)
        return content, p_tok, c_tok, "stop"

    @staticmethod
    def _last_user_text(messages: List[dict]) -> str:
        for m in reversed(messages):
            if m.get("role") == "user":
                return m.get("content", "")
        return ""

    @staticmethod
    def _system_text(messages: List[dict]) -> str:
        return "\n".join(m.get("content", "") for m in messages if m.get("role") == "system")

    @staticmethod
    def _estimate_tokens(text: str) -> int:
        """粗略 token 估算：中日韩字符约 1 字 1 token，其余约 4 字符 1 token。"""
        if not text:
            return 1
        cjk = sum(1 for ch in text if ord(ch) > 0x2E80)
        other = len(text) - cjk
        return max(1, cjk + other // 4)

    def _mock_generate(self, user_text: str, system_text: str) -> str:
        """按 prompt 意图生成符合输出协议的响应。

        注意：意图识别只看 **user 消息**。system 消息中包含完整的输出协议说明
        （其中必然出现 PLAN / REFLECT / VERDICT 等字样），若参与匹配会导致
        所有请求都被误判为"反思"请求。
        """
        # 1) 复杂度判定：识别"输出 level 字段" + "判定语义"两个信号
        if ("level" in user_text or "难度" in user_text) and \
                ("复杂度" in user_text or "判定" in user_text):
            level = self._mock_judge_difficulty(user_text)
            return (
                '{"level": "%s", "confidence": 0.9, '
                '"reason": "mock: 基于输入长度与关键词的启发式判定"}' % level
            )

        # 2) 反思
        # 2026-10-13（S1）：协议新增 CONFIDENCE 行（S3 自评置信度停止条件依赖它），
        # mock 输出必须同步遵循，否则 S3 在 mock 下仍恒不触发。
        if "反思" in user_text and "VERDICT" in user_text:
            return (
                "REFLECT:\n- mock：检查了计划执行情况与中间结果的一致性。\n"
                "- mock：未发现需要修正的步骤。\n"
                "CONFIDENCE: 0.85\nVERDICT: PASS"
            )

        # 3) 计划
        if "执行计划" in user_text and "PLAN" in user_text:
            return (
                "PLAN:\n1. mock：明确任务目标与已知条件。\n"
                "2. mock：按依赖关系分解为可执行步骤。\n"
                "3. mock：汇总各步骤结果并给出最终答案。"
            )

        # 4) 工具调用流程
        if "可用工具" in user_text and "ACTION" in user_text:
            return self._mock_tool_step(user_text)

        # 5) 求解
        return "ANSWER: " + self._mock_solve(user_text)

    def _mock_judge_difficulty(self, user_text: str) -> str:
        """启发式难度判定：长度 + 数字个数 + 句数 + 关键词。

        只评估"待判定任务"之后的原文——judge prompt 中附带的判定标准说明文本很长，
        若一并参与打分会把所有任务都推到 hard。

        仅用于 mock 模式下让三条执行路径（easy/medium/hard）都能被触发，
        从而端到端验证路由逻辑。它**不是**真实的复杂度判定方法，
        论文中的判定器是 agents/adaptive.py 的 judge prompt 与 complexity/ 模块。
        """
        m = re.search(r"待判定任务[:：]\s*(.+)$", user_text, re.S)
        text = m.group(1).strip() if m else user_text

        score = 0
        nums = re.findall(r"-?\d+(?:\.\d+)?", text)
        if len(text) > 80:
            score += 1
        if len(text) > 150:
            score += 1
        if len(nums) >= 3:
            score += 1
        if len(nums) >= 5:
            score += 1
        if text.count("。") + text.count("；") >= 3:
            score += 1
        for kw in ("并且", "同时", "多步", "调试", "比较", "整合", "调用", "代码", "证明", "其中"):
            if kw in text:
                score += 1
        if score <= 0:
            return "easy"
        if score == 1:
            return "medium"
        return "hard"

    def _mock_tool_step(self, user_text: str) -> str:
        """工具流程：第一步发一个 ACTION，之后（已见执行结果）给 FINAL。"""
        m = re.search(r"可用工具[:：]\s*(.+)", user_text)
        tool_line = m.group(1) if m else ""
        tool_name = tool_line.split("(")[0].split("；")[0].split(";")[0].strip() or "calculator"

        # 若历史里已有执行结果，说明已调用过工具，直接收尾
        if "执行结果" in user_text or "Observation" in user_text:
            return "FINAL: " + self._mock_solve(user_text)
        if "calculator" in tool_name:
            nums = re.findall(r"-?\d+(?:\.\d+)?", user_text)
            expr = "+".join(nums[:3]) if len(nums) >= 2 else (nums[0] if nums else "0")
            return f"ACTION: calculator({expr})"
        return f"ACTION: {tool_name}(query)"

    @staticmethod
    def _mock_solve(user_text: str) -> str:
        """mock 求解：优先做数字运算；无数字时回退到词表中的关键词。

        注意：这仍然只是 mock 行为，不构成对模型能力的任何判断。
        真实实验中的答案完全由 LLM 生成，此处仅为让 contains 类指标的
        评分链路也能被端到端验证。
        """
        nums = re.findall(r"-?\d+(?:\.\d+)?", user_text)
        if nums:
            vals = [float(x) for x in nums[:6]]
            if any(k in user_text for k in ("每", "倍", "×", "*")):
                out = 1.0
                for v in vals:
                    out *= v
            else:
                out = sum(vals)
            if abs(out - round(out)) < 1e-9:
                return str(int(round(out)))
            return f"{out:.2f}"
        for kw in ("广州", "深圳", "佛山", "东莞", "珠海",
                   "小明", "小红", "小华", "小刚", "小丽",
                   "苹果", "香蕉", "橙子", "葡萄", "西瓜"):
            if kw in user_text:
                return kw
        return "0"


def load_configs() -> tuple[dict, dict]:
    """读取 configs/models.yaml 与 configs/base.yaml。

    返回的 models 配置已解包到 provider 级别（即 YAML 中 providers 键下的内容），
    调用方拿到的 key 就是 provider 名，如 mock / deepseek / qwen / openai。
    """
    with open(os.path.join(PROJECT_ROOT, "configs", "models.yaml"), encoding="utf-8") as f:
        models_cfg = yaml.safe_load(f)["providers"]
    with open(os.path.join(PROJECT_ROOT, "configs", "base.yaml"), encoding="utf-8") as f:
        base_cfg = yaml.safe_load(f)
    return models_cfg, base_cfg
