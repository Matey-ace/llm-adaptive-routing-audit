"""答案抽取与归一化工具（P1 修复版）。

集中实现 GSM8K / MATH 答案的稳健提取与规范化，供 `eval/metrics.py` 的评分器、
`agents/majority_vote.py` 的投票键、以及 `tasks/loaders/math.py` 的 gold 派生共用。
所有函数均为纯函数、可单测、无网络与无状态。

版本管理（plan P1 要求"对评分器/抽取器/投票键做版本化"）：
    SCORER_VERSION = "2026-10-13.2"
每次修改比较语义都必须递增此常量，并同步更新 `paper/实验协议.md` 的评分口径小节。
raw 日志会记录该版本，使得事后重算与跨版本比较可追溯。

------------------------------------------------------------------------------
本版修复的缺陷（2026-10-13 只读核查复现的三个假阳性）
------------------------------------------------------------------------------
旧 `_math_equiv` 的第二条规则是"任一方能用 `extract_final_number` 抽出数值就比数值"，
而 `extract_final_number` 取的是**最后一个数**，于是：

    gold="2"      vs ans="x+2"       -> 抽出 2 与 2   -> 判 True（错）
    gold="2/3"    vs ans="5/3"       -> 抽出 3 与 3   -> 判 True（错）
    gold="2"      vs ans=r"\\sqrt{2}" -> 抽出 2 与 2   -> 判 True（错）

根因：**把"含有某个数字"当成了"答案的值"**。表达式并不是数值。
本版的做法是先把答案转换为**带结构的规范化表示**（字符串范式 / sympy 表达式 / 集合 / 元组），
再做比较；只有双方都是**纯数值标量**时才启用数值比较。这样：

- 自由度不同（一个含变量、一个不含）-> 直接判不等；
- 分数、根式、小数 -> 交给 sympy 精确/容差比较，不再用"最后一个数"；
- 集合 -> 无序多重集比较；元组 / 列表 / 区间 -> 有序逐元素比较；
- 百分号 -> 视为独立单位符号 Percent，**不与裸数字等价**（事前声明口径）。

------------------------------------------------------------------------------
事前声明的口径（写入 `paper/实验协议.md`，评测前冻结，不得事后调整）
------------------------------------------------------------------------------
1. 25% 与 25、0.25 与 25% **互不自动等价**（Percent 作为独立符号参与比较）。
2. 形如 `x = 5` 且 x 未在右侧出现时，视为"给变量赋值的书写习惯"，约简为 `5`；
   但 `x + 2` 不约简（变量仍在表达式内）。
3. 集合 `\\{a,b\\}` 无序比较；元组/列表 `(a,b)`、`[a,b]` 有序比较。
4. 无法解析且与 gold 字符串范式也不等者，不猜！标记为 needs_review 交人工复核。
5. sympy 调用前有白名单过滤，且表达式长度受限，避免将任意模型输出交给解析器。
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

# 评分口径版本：修改比较语义必须递增
SCORER_VERSION = "2026-10-13.2"


# ----------------------------------------------------------------- 通用归一化
def normalize(text) -> str:
    """宽口径归一化：去空白、去中英文标点，小写。用于 exact_match / contains。"""
    if text is None:
        return ""
    s = str(text).strip().lower()
    s = re.sub(r"[\s,，。.；;：:、]+", "", s)
    return s


# --------------------------------------------------------------- LaTeX 处理
_LATEX_NOISE = re.compile(r"\\[a-zA-Z]+\s*|\$|\\!|\\,|\\;|\\:|\\quad|\\qquad|\\left|\\right|\\%")
_FRAC_RE = re.compile(r"\\frac\s*\{\s*(-?\d+(?:\.\d+)?)\s*\}\s*\{\s*(-?\d+(?:\.\d+)?)\s*\}")


def latex_normalize(text: str) -> str:
    """把 LaTeX 噪声（命令、定界符、占位空格）剥掉，保留数字与字母变量名。

    例："\\frac{1}{2}" -> "1/2"；"$x = 5$" -> "x=5"。
    该口径较粗（会把 \\sqrt{2} 变成 "{2}"），仅用于向后兼容；
    **真正的等价判定请用 `canonical_text` / `compare_answers`**。
    """
    s = str(text)
    s = _FRAC_RE.sub(lambda m: f"({float(m.group(1)) / float(m.group(2))})", s)
    s = _LATEX_NOISE.sub("", s)
    s = re.sub(r"\s+", "", s)
    return s.lower()


# ------------------------------------------------------------- 数值抽取
def extract_final_number(text: str) -> Optional[float]:
    """从文本中抽取**最后一个**数值（GSM8K 无显式标记时的兜底启发式）。

    处理：千分位逗号、百分号/单位后缀、LaTeX 分数、负号。
    返回 None 表示无法判定。

    注意：这不是"答案的值"，只是兜底。MATH 判定不得使用它（见模块文档串）。
    """
    if text is None:
        return None
    s = str(text)
    s = _replace_frac(s)
    s = re.sub(r"(?<=\d),(?=\d{3}\b)", "", s)
    s = re.sub(r"[%$€£¥()\[\]]", "", s)
    nums = re.findall(r"-?\d+(?:\.\d+)?", s)
    if not nums:
        return None
    try:
        return float(nums[-1])
    except ValueError:
        return None


def _replace_frac(s: str) -> str:
    return _FRAC_RE.sub(lambda m: str(float(m.group(1)) / float(m.group(2))), s)


def extract_boxed(text: str) -> Optional[str]:
    """抽取最后一个 \\boxed{...} 的内容（支持嵌套花括号）。返回 None 表示无。"""
    if text is None:
        return None
    idx = str(text).rfind("\\boxed{")
    if idx == -1:
        return None
    start = idx + len("\\boxed{")
    depth = 0
    for i in range(start, len(text)):
        ch = text[i]
        if ch == "{":
            depth += 1
        elif ch == "}":
            if depth == 0:
                return text[start:i]
            depth -= 1
    return None


# =================================================================================
# 以下为 P1 新增：答案位置定位 / 规范化范式 / 结构化比较
# =================================================================================

# ------------------------------------------------- 最终答案位置定位（优先级）
# 约定：先找显式标记，再退回整串。顺序即优先级，不得在评测后调整。
_BOXED_RE = re.compile(r"\\boxed\s*")
_MARK_RE = re.compile(
    r"(?:ANSWER|FINAL|ANS)\s*[:：]|"          # 本框架的输出协议
    r"(?:the\s+)?answer\s+is\s*[:：]?|"        # 英文习惯写法
    r"答案是\s*[:：]?|最终答案(?:是|为)\s*[:：]?|"  # 中文习惯写法
    r"####\s*",                                # GSM8K 官方标记
    re.IGNORECASE,
)


_BRACE_PAIRS = {"{": "}", "(": ")", "[": "]"}


def _brace_balanced(s: str) -> bool:
    """简单括号配平检查（用于判断答案片段是否被行切碎）。"""
    depth = 0
    for ch in s:
        if ch in "({[":
            depth += 1
        elif ch in ")}]":
            depth -= 1
            if depth < 0:
                return False
    return depth == 0


def extract_answer_span(text: str) -> Tuple[str, str]:
    """定位最终答案所在的片段，返回 (片段, 来源标记)。

    来源标记（source）：
      "boxed"            最后一个 \\boxed{} 的内容 —— MATH 最可信位置
      "marker"           显式标记（ANSWER:/答案是/answer is/####）之后的内容
      "last_line"        无标记时取最后一个非空行的全部内容
      "whole"            以上皆无，取整串（调用方应记 needs_review）
      "empty"            输入为空

    注意：行切分**不得**把跨行的 LaTeX 结构（如 `\\text{ square\\nunits}`）切断，
    因此切分后会做括号配平检查，不配平就退回更完整的片段。这是真实数据里
    遇到 gold 内含换行时暴露出来的问题。
    """
    if text is None:
        return "", "empty"
    s = str(text).strip()
    if not s:
        return "", "empty"

    boxed = extract_boxed(s)
    if boxed is not None and boxed.strip():
        return boxed.strip(), "boxed"

    hits = list(_MARK_RE.finditer(s))
    if hits:
        m = hits[-1]
        tail = s[m.end():].strip()
        tail_lines = [ln.strip() for ln in tail.splitlines() if ln.strip()]
        if tail_lines:
            first = tail_lines[0]
            first = first.strip().strip("$").strip()
            first = re.sub(r"[。.．]+$", "", first).strip()
            if first and _brace_balanced(first):
                return first, "marker"
            # 首行括号不配平：说明答案跨行，取标记后的全部内容
            whole_tail = " ".join(tail_lines)
            whole_tail = whole_tail.strip().strip("$").strip()
            if whole_tail:
                return whole_tail, "marker"

    lines = [ln.strip() for ln in s.splitlines() if ln.strip()]
    if lines:
        span = lines[-1].strip().strip("$").strip()
        span = re.sub(r"[。.．]+$", "", span).strip()
        if span and _brace_balanced(span):
            return span, "last_line"
    return s, "whole"


# ------------------------------------------------------- 字符串范式规范化
_DROP_NOISE_RE = re.compile(r"\\[,;:!]|\\quad|\\qquad|\\displaystyle|\\limits|\\left|\\right|\\ ")
_FRAC_ALIAS_RE = re.compile(r"\\(d|t)frac(?=\s*\{)")


def _canon_frac_braceless(s: str) -> str:
    """把无花括号的 \\frac 写法统一成 "\\frac{A}{B}"（真实 MATH gold 里有这种写法）。

    例："\\frac 32" -> "\\frac{3}{2}"；"\\frac12" -> "\\frac{1}{2}"；
    已带花括号的写法不受影响。
    """
    # 情况 1：两个参数都是单个字符/记号（\frac 3 2 / \frac12 / \frac{1}2 / \frac1{2}）
    def _one(tok: str) -> str:
        tok = tok.strip()
        return tok if (tok.startswith("{") and tok.endswith("}")) else "{" + tok + "}"

    pat = re.compile(r"\\frac\s*(\{[^{}]*\}|[^\s{}\\])\s*(\{[^{}]*\}|[^\s{}\\])")
    prev = None
    while prev != s:
        prev = s
        s = pat.sub(lambda m: r"\frac" + _one(m.group(1)) + _one(m.group(2)), s, count=1)
    return s


def canonical_text(text: str) -> str:
    """轻量、确定的字符串范式：只做"书写差异"归一化，不改变数学含义。

    用途：作为严格相等的第一道闸门，以及 sympy 解析失败时的兜底比较。
    归一化项：去空白 / `$` / 占位空格命令；\\dfrac,\\tfrac -> \\frac；
    无花括号 \\frac 补齐花括号；去首尾句点；统一全角括号与乘号为 ascii。
    """
    if text is None:
        return ""
    s = str(text).strip()
    s = s.replace("\u00a0", " ")
    s = s.replace("−", "-").replace("π", r"\pi")
    s = s.replace("×", "*").replace("·", "*").replace("÷", "/")
    s = s.replace("（", "(").replace("）", ")").replace("，", ",")
    s = re.sub(r"\\[dt]frac", r"\\frac", s)
    s = _canon_frac_braceless(s)
    s = _DROP_NOISE_RE.sub("", s)
    s = s.replace("$", "")
    # 裸 % 与 \% 统一为 \%（便于下游一致地把百分数当作独立单位符号处理）
    s = re.sub(r"(?<!\\)%", r"\\%", s)
    s = s.replace("\\{", "{").replace("\\}", "}").replace("\\|", "|")
    s = re.sub(r"\s+", "", s)
    # A numeric Unicode radicand has a known endpoint. Leave √2x and √2^2
    # unresolved instead of guessing the extent of the radical.
    s = re.sub(r"√(\d+(?:\.\d+)?)(?=$|[)/,+\-*])",
               lambda m: r"\sqrt{" + m.group(1) + "}", s)
    s = re.sub(r"^[。.．]+|[。.．]+$", "", s)
    return s


_ASSIGN_RE = re.compile(r"^([A-Za-z][A-Za-z0-9_\\\{\}]*)\s*=\s*(.+)$")


def strip_assignment(s: str, max_rounds: int = 2) -> Tuple[str, List[str]]:
    """把 "x = 5" 这类"给出单个未知量的值"的写法约简为 "5"（口径 2）。

    返回 (约简后的串, 被剥掉的变量名列表)，供调用方核对两侧剥掉的变量是否一致。

    约束（真实数据驱动的两条收紧条件，缺一不可）：
      1. 左侧必须是单个符号式记号；
      2. **右侧不得含任何自由变量**（必须是一个"值"）。
        这条防止把 "y = x+2" 这类函数式答案误当成赋值约简成 "x+2"，
        否则会凭空丢掉 y 这个答案成分。
      3. 左侧符号不得再出现在右侧。
    """
    cur = str(s).strip()
    lhs_list: List[str] = []
    for _ in range(max_rounds):
        m = _ASSIGN_RE.match(cur)
        if not m:
            break
        lhs, rhs = m.group(1), m.group(2).strip()
        rhs_clean = rhs.strip("()")
        if re.search(rf"\b{re.escape(lhs)}\b", rhs_clean):
            break
        e = to_sympy(rhs_clean)
        if e is None or set(getattr(e, "free_symbols", set())):
            break  # 右侧不是纯值 -> 视为方程，不约简
        lhs_list.append(lhs)
        cur = rhs_clean
    return cur, lhs_list


# --------------------------------------------------- LaTeX -> ascii 表达式
_SIMPLE_MAP: Dict[str, str] = {
    "times": "*", "cdot": "*", "ast": "*", "div": "/", "pm": "±",
    "pi": "pi", "tau": "pi*2", "circ": "deg",
    "alpha": "alpha", "beta": "beta", "gamma": "gamma", "delta": "delta",
    "theta": "theta", "lambda": "lambda", "mu": "mu", "sigma": "sigma",
    "phi": "phi", "omega": "omega", "epsilon": "epsilon",
    "infty": "oo", "ldots": "...", "dots": "...",
    "%": "*Percent", "$": "",
    ",": "", ";": "", ":": "", "!": "", "#": "",
    "{": "{", "}": "}",
}
_DROP_CMDS = {"displaystyle", "limits", "nolimits", "huge", "large", "small",
              "textstyle", "boldsymbol", "mathrm", "mathbf", "mathit", "displaystyle"}
_ARG1_MAP: Dict[str, str] = {
    "sqrt": "sqrt", "text": "KEEP", "textrm": "KEEP", "textbf": "KEEP",
    "mbox": "KEEP", "mathbb": "mathbb", "mathcal": "mathcal",
    "overline": "conjugate", "vec": "vec", "hat": "hat",
}
_ARG2_CMDS = {"frac", "dfrac", "tfrac", "binom", "cfrac"}

def _read_arg(s: str, i: int) -> Tuple[Optional[str], int]:
    """读取一个 LaTeX 参数：优先 {...} 组，否则取单个非空格记号。"""
    n = len(s)
    while i < n and s[i] in " \t":
        i += 1
    if i >= n:
        return None, i
    if s[i] == "{":
        return _read_group(s, i)
    if s[i] == "\\":
        m = re.match(r"\\[a-zA-Z]+|\\.", s[i:])
        if m:
            return m.group(0), i + len(m.group(0))
    return s[i], i + 1


_MAX_LEN = 240


def _read_group(s: str, i: int) -> Tuple[Optional[str], int]:
    """从位置 i 读取一个 {...} 组，返回 (内容, 结束位置)。失败返回 (None, i)。"""
    n = len(s)
    while i < n and s[i] in " \t":
        i += 1
    if i >= n or s[i] != "{":
        return None, i
    depth = 0
    start = i + 1
    while i < n:
        if s[i] == "{":
            depth += 1
        elif s[i] == "}":
            depth -= 1
            if depth == 0:
                return s[start:i], i + 1
        i += 1
    return None, i  # 括号不闭合


def latex_to_ascii(text: str) -> str:
    """把 LaTeX 数学片段转成可被 sympy 解析的 ascii 表达式字符串。

    不保证一定可解析；不可解析时由调用方退回字符串范式比较。
    未识别的 LaTeX 命令按"去掉反斜杠的字面名"保留，避免静默丢弃语义。
    """
    if text is None:
        return ""
    s = canonical_text(text)
    if len(s) > _MAX_LEN:
        return ""  # 过长的串几乎必不是纯数学表达式，放弃符号化

    out: List[str] = []
    i, n = 0, len(s)
    while i < n:
        c = s[i]
        if c == "\\":
            m = re.match(r"\\([a-zA-Z]+|.)", s[i:])
            if not m:
                i += 1
                continue
            name = m.group(1)
            i += len(m.group(0))
            if name in _SIMPLE_MAP:
                out.append(_SIMPLE_MAP[name])
                continue
            if name in _DROP_CMDS:
                continue
            if name in _ARG2_CMDS:
                a, i = _read_arg(s, i)
                b, i = _read_arg(s, i)
                if a is None or b is None:
                    out.append(f"\\{name}")
                    continue
                if name == "binom":
                    out.append(f"binomial({latex_to_ascii(a)},{latex_to_ascii(b)})")
                else:
                    out.append(f"(({latex_to_ascii(a)})/({latex_to_ascii(b)}))")
                continue
            if name in _ARG1_MAP:
                # \sqrt[3]{8} 的可选参数
                if name == "sqrt" and i < n and s[i] == "[":
                    j = s.find("]", i)
                    if j != -1:
                        root_txt = s[i + 1:j]
                        a, k = _read_group(s, j + 1)
                        if a is not None:
                            out.append(f"root({latex_to_ascii(a)},{latex_to_ascii(root_txt)})")
                            i = k
                            continue
                    a, i = _read_arg(s, i)  # \sqrt3 这类无花括号写法
                    if a is None:
                        out.append("\\sqrt")
                        continue
                    out.append(f"sqrt({latex_to_ascii(a)})")
                    continue
                # 其余单参数命令（\text / \mathbb / \overline ...）
                a, i = _read_arg(s, i)
                if a is None:
                    out.append(f"\\{name}")
                    continue
                if _ARG1_MAP[name] == "KEEP":
                    out.append("(" + latex_to_ascii(a) + ")")
                elif name == "mathbb" or name == "mathcal":
                    out.append(latex_to_ascii(a))
                else:
                    out.append(f"{_ARG1_MAP[name]}({latex_to_ascii(a)})")
                continue
            out.append(name)  # 未知命令：保留字面名
            continue
        if c == "^":
            j = i + 1
            if j < n and s[j] == "{":
                a, k = _read_group(s, j)
                if a is not None:
                    out.append(f"**({latex_to_ascii(a)})")
                    i = k
                    continue
            if j < n and s[j] not in "+-*/) ":
                out.append(f"**{s[j]}")
                i = j + 1
                continue
            i = j
            continue
        if c == "_":
            # 下标并入符号名，避免 sympy 语法错误
            j = i + 1
            if j < n and s[j] == "{":
                a, k = _read_group(s, j)
                if a is not None:
                    out.append("_" + latex_to_ascii(a).strip("()"))
                    i = k
                    continue
            if j < n and s[j].isalnum():
                out.append("_" + s[j])
                i = j + 1
                continue
            i = j
            continue
        out.append(c)
        i += 1

    expr = "".join(out)
    # 隐性乘号："2x" -> "2*x"，"2(3)" -> "2*(3)"，")(" -> ")*("
    expr = re.sub(r"(\d)\s*([A-Za-z_])", r"\1*\2", expr)
    expr = re.sub(r"(\d)\s*\(", r"\1*(", expr)
    expr = re.sub(r"\)\s*\(", r")*(", expr)
    expr = re.sub(r"\)\s*(\d)", r")*\1", expr)
    expr = re.sub(r"\s+", "", expr)
    return expr


_SAFE_CHARS = re.compile(r"^[A-Za-z0-9_+\-*/^().,±\s]+$")
_SYMPY_FUNCS = {"sqrt": "sqrt", "root": None, "binomial": None, "conjugate": None}


def _sympy_module():
    import sympy  # 延迟导入：评测路径才需要，单测与 CLI 不强制
    return sympy


def to_sympy(text: str):
    """安全地把答案片段转成 sympy 表达式，失败返回 None。

    安全策略：字符白名单 + 长度上限 + 固定 locals 命名空间，
    避免把任意模型输出交给解析器执行。
    """
    expr_s = latex_to_ascii(text)
    if not expr_s or len(expr_s) > _MAX_LEN or not _SAFE_CHARS.match(expr_s):
        return None
    sp = _sympy_module()
    try:
        expr = sp.sympify(expr_s, rational=True)
    except Exception:  # noqa: BLE001
        return None
    try:
        # 拒收非标量数学对象的意外类型（如把字符串 sympify 成 Symbol 的组合）
        if expr.is_Number or getattr(expr, "free_symbols", None) is not None:
            return expr
        return None
    except Exception:  # noqa: BLE001
        return None


NUM_ABS_TOL = 1e-6


def _num_close(a, b, abs_: float = NUM_ABS_TOL) -> bool:
    """数值容差：**只设绝对容差，不设相对容差**。

    原因（负例控检发现）：相对容差在大数上过宽——gold=3750000 与 3750001
    的差值仅 2.7e-7（相对），会被误判为相等。整数答案本身就应精确到个位，
    小数答案则要求写出足够位数，这与 MATH/GSM8K 的答题习惯一致。
    """
    try:
        fa, fb = float(a), float(b)
    except Exception:  # noqa: BLE001
        return False
    if fa != fa or fb != fb:  # NaN
        return False
    if fa in (float("inf"), float("-inf")) or fb in (float("inf"), float("-inf")):
        return fa == fb
    return abs(fa - fb) <= abs_


_PLAIN_FLOAT_RE = re.compile(r"^[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?$")


def sym_equal(a_text: str, b_text: str) -> Tuple[Optional[bool], str]:
    """对两个答案片段做符号/数值层比较。

    返回 (结果, 原因)；结果为 None 表示**无法判定**（应 needs_review）。
    """
    # 0) 纯十进制字面量（含科学计数法）先直接比数值，避免把 "1.2e1" 的 e 当成变量
    if _PLAIN_FLOAT_RE.match(a_text) and _PLAIN_FLOAT_RE.match(b_text):
        return (_num_close(float(a_text), float(b_text)),
                "numeric_equal" if _num_close(float(a_text), float(b_text)) else "numeric_diff")

    a = to_sympy(a_text)
    b = to_sympy(b_text)
    if a is None or b is None:
        if a is None and b is None:
            return None, "both_unparseable"
        return None, "one_unparseable"
    sp = _sympy_module()
    try:
        sa, sb = set(a.free_symbols), set(b.free_symbols)
    except Exception:  # noqa: BLE001
        sa = sb = set()
    if sa != sb:
        # 一方含变量、一方不含 -> 不是同一个数学对象（如 x+2 与 2）
        return False, "different_variables"
    try:
        if sp.simplify(a - b) == 0:
            return True, "symbolic_equal"
    except Exception:  # noqa: BLE001
        pass
    # 都是纯数值时才做容差比较；含变量的表达式不做（避免失真判定）
    if not sa and not sb:
        try:
            if _num_close(a.evalf(30), b.evalf(30)):
                return True, "numeric_equal"
        except Exception:  # noqa: BLE001
            pass
        return False, "numeric_diff"
    try:
        if str(sp.simplify(a)) == str(sp.simplify(b)):
            return True, "symbolic_equal"
    except Exception:  # noqa: BLE001
        pass
    return False, "symbolic_diff"


# ------------------------------------------------------------- 结构化比较
def _split_top_level(s: str, sep: str = ",") -> List[str]:
    """按顶层分隔符切分（忽略括号内的分隔符）。"""
    items, depth, buf = [], 0, []
    for ch in s:
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
        if ch == sep and depth == 0:
            items.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    items.append("".join(buf))
    return [x.strip() for x in items]


def _is_wrapped(s: str, open_ch: str, close_ch: str) -> bool:
    return len(s) >= 2 and s[0] == open_ch and s[-1] == close_ch


def _inner(s: str) -> str:
    return s[1:-1]


def _has_perfect_matching(gi: List[str], pi: List[str], max_n: int = 6) -> bool:
    """判断两个多重集能否一一匹配（双向包含），n 较小时用精确排列。"""
    n = len(gi)
    if n != len(pi) or n == 0:
        return False
    if n <= max_n:
        from itertools import permutations
        for perm in permutations(range(n)):
            if all(compare_answers(x, pi[j])[0] for x, j in zip(gi, perm)):
                return True
        return False
    # 元素过多时退化为"每个元素都能在对方集合中找到匹配"（够用且线性）
    return all(any(compare_answers(x, y)[0] for y in pi) for x in gi)


def _variants(s: str) -> List[str]:
    """书写变体：原串 + 剥掉一层**冗余外层括号**后的串。

    只剥 '(' / '[' 的完整包裹（集合 '{...}' 不剥，避免把集合与序列混为一谈），
    要求该左括号的配对右括号正好是最后一个字符。这样 `\\left(73^\\circ\\right)`
    能与 `73^\\circ` 判等，而 `(-\\infty,-20)\\cup(-20,\\infty)` 这种本身
    就不是整体包裹的表达式不会被误剥。
    """
    outs = [s]
    if len(s) > 3:
        for oc, cc in (("(", ")"), ("[", "]")):
            if s[0] == oc and s[-1] == cc:
                depth = 0
                ok = True
                for idx, ch in enumerate(s):
                    if ch in "([{":
                        depth += 1
                    elif ch in ")]}":
                        depth -= 1
                    if depth == 0 and idx != len(s) - 1:
                        ok = False
                        break
                if ok and depth == 0:
                    outs.append(s[1:-1])
    seen, res = set(), []
    for x in outs:
        if x and x not in seen:
            seen.add(x)
            res.append(x)
    return res or [s]


def _parts_and_wrapper(s: str) -> Tuple[List[str], str]:
    """返回 (顶层逗号切分出的部分, 外层包裹类型)。包裹类型 ∈ {"", "{", "(", "["}"""
    for oc, cc in (("{", "}"), ("(", ")"), ("[", "]")):
        if _is_wrapped(s, oc, cc):
            return _split_top_level(_inner(s)), oc
    return _split_top_level(s), ""


def _compare_core(g: str, p: str) -> Tuple[bool, bool, str]:
    """单组变体的比较。返回 True / False / None(无法判定) + 原因。"""
    if g == "" or p == "":
        return None, True, "empty_answer"

    # 赋值写法约简（口径 2）。放在这里而不是变体生成之前，保证先剥括号再判赋值，
    # 否则 "(a=-30.5)" 这种带装饰的写法无法与 "a=-30.5" / "-30.5" 对齐。
    gc, glhs = strip_assignment(g)
    pc, plhs = strip_assignment(p)
    if glhs and plhs and set(glhs) != set(plhs):
        return False, False, "different_variables"
    g, p = gc, pc

    if g == p:
        return True, False, "norm_equal"

    # 双方都是纯数值 -> 只做数值比较（"最后一个数"式的近似不再参与）
    gn, pn = to_number(g), to_number(p)
    if gn is not None and pn is not None:
        ok = _num_close(gn, pn)
        return ok, False, "numeric_equal" if ok else "numeric_diff"

    gi, gw = _parts_and_wrapper(g)
    pi, pw = _parts_and_wrapper(p)

    # 集合：无序多重集比较
    if gw == "{" and pw == "{" and len(gi) == len(pi) and len(gi) > 1:
        pairs = [compare_answers(x, y) for x in gi for y in pi]
        if all(not nr for _c, nr, _r in pairs):
            if _has_perfect_matching(gi, pi):
                return True, False, "set_equal"
            return False, False, "set_diff"

    # 有序多答案：元组 / 列表 / 区间 / 裸写的逗号序列，要求包裹类型与元素数一致
    if gw == pw and len(gi) == len(pi) and len(gi) > 1:
        pairs = [compare_answers(x, y) for x, y in zip(gi, pi)]
        if all(c for c, _nr, _r in pairs):
            return True, False, "ordered_equal"
        if all(not nr for _c, nr, _r in pairs):
            return False, False, "ordered_diff"

    res, reason = sym_equal(g, p)
    if res is None:
        return None, True, reason
    return bool(res), False, reason


def compare_answers(gold: str, pred: str) -> Tuple[bool, bool, str]:
    """比较两个答案片段是否等价。返回 (correct, needs_review, reason)。

    reason 取值：
      norm_equal        字符串范式完全相等
      numeric_equal     纯数值且相等
      set_equal         集合（无序多重集）相等
      ordered_equal     元组/列表/区间/逗号序列 逐元素相等
      symbolic_equal    sympy 符号化简后相等
      numeric_diff      纯数值但不相等
      symbolic_diff     符号表达式不相等
      set_diff / ordered_diff  结构化答案不等
      different_variables  变量集合不同（明确不等）
      empty_answer      答案为空（提取失败）
      both_unparseable / one_unparseable  无法自动判定 -> needs_review

    比较前会为每个候选生成**书写变体**（剥一层冗余外括号），使
    `\\left(x\\right)` 与 `x` 这类装饰差异不影响判定。
    """
    if pred is None or str(pred).strip() == "":
        return False, True, "empty_answer"

    # 统一先定位"最终答案片段"，使 \boxed{...} / ANSWER: ... 与裸写形式可比
    _gs, _ = extract_answer_span(str(gold) if gold is not None else "")
    _ps, _ = extract_answer_span(str(pred) if pred is not None else "")
    g2 = canonical_text(_gs)
    p2 = canonical_text(_ps)

    if g2 == "" and p2 == "":
        return False, True, "empty_answer"

    gvs, pvs = _variants(g2), _variants(p2)
    best: Optional[Tuple[bool, bool, str]] = None
    for gv in gvs:
        for pv in pvs:
            res = _compare_core(gv, pv)
            if res[0]:
                return res
            # 优先保留"可判定"的结论（None 表示只能 needs_review）
            if best is None or (res[2] != best[2] and not res[1] and best[1]):
                best = res
    if best is None:
        return False, True, "empty_answer"
    return (False, best[1], best[2]) if not best[0] else (True, False, best[2])


# ------------------------------------------------------------- 对外便捷接口
def to_number(text: str) -> Optional[float]:
    """仅当该片段是**纯数值**时返回数值，否则 None（供 GSM8K 严格化使用）。

    不会像旧的 `extract_final_number` 那样从 "x+2"、\\sqrt{2} 里掏出某个数字。
    """
    e = to_sympy(text)
    if e is None:
        # 千分位写法 "1,234" 不是 sympy 可解析的单个数，去掉分隔符后再试一次
        if re.fullmatch(r"-?\d{1,3}(?:,\d{3})+(?:\.\d+)?", str(text).strip()):
            e = to_sympy(str(text).replace(",", ""))
        if e is None:
            return None
    try:
        if not getattr(e, "is_number", False) or not getattr(e, "is_real", True):
            return None
        return float(e.evalf(30))
    except Exception:  # noqa: BLE001
        return None


def vote_key(answer: str, fallback_index: Optional[int] = None) -> str:
    """投票键：无 gold 参与、保留候选语义的规范化键。

    规则（事前声明）：
      1. 先用 `extract_answer_span` 定位最终答案片段；
      2. 纯数值 -> "num:<30 位精度的数值>"，使 0.5 与 1/2 归为一票；
      3. 含变量的表达式 -> "sym:<sympy 规范打印>"，使 2*x 与 x*2 归为一票，
         但与纯数值绝不同票（这是修复"x+2 与 2 混为一票"的关键）；
      4. 结构化答案 -> "struct:<集合/元组规范化串>"；
      5. 无法解析 -> 不合并！返回 "raw#<i>:<原串>"（i 为采样序号），
         平票时按首次出现取胜。
    """
    span, _src = extract_answer_span(answer)
    if not span:
        raw = canonical_text(answer)
        return f"raw#{fallback_index if fallback_index is not None else 0}:{raw}"
    e = to_sympy(span)
    if e is not None:
        try:
            if set(e.free_symbols) == set():
                return "num:" + format(float(e.evalf(30)), ".12g")
            return "sym:" + str(e)
        except Exception:  # noqa: BLE001
            pass
    return "struct:" + canonical_text(span)


# --------------------------------------------------- 统一答案解析（旧接口保留）
def parse_answer(text: str) -> Tuple[Optional[float], str]:
    """把任意模型/参考答案解析为 (数值, 归一化串)。保留旧接口以便兼容。

    新代码应优先使用 `extract_answer_span` + `compare_answers`。
    """
    s = str(text)
    span, _src = extract_answer_span(s)
    num = to_number(span)
    if num is None:
        num = extract_final_number(span)
    return num, canonical_text(span)


def parse_gsm8k_gold(answer: str) -> str:
    """从 GSM8K 参考解答中抽取官方最终答案（#### 之后）。"""
    if "####" in answer:
        return answer.split("####")[-1].strip()
    return answer.strip()
