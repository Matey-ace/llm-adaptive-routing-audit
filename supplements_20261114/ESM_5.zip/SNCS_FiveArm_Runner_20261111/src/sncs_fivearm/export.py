"""导出：把一个 run 变成可交付、可审计的资料包。

导出内容：

    <run>_ledger.json          精确账本（micro CNY）+ 逐 purpose 明细
    <run>_status.json          计划轨迹的完整状态表与分母
    <run>_calls.jsonl          逐次派发记录（脱敏 envelope）
    <run>_summary.md           人能读懂的汇总

不导出：gold、评分映射、任何凭证。
"""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List

from .budget import micro_to_cny
from .journal import Journal, derive_trajectory_states


def _purpose_table(calls: List[Dict[str, Any]]) -> Dict[str, Dict[str, int]]:
    out: Dict[str, Dict[str, int]] = {}
    for c in calls:
        p = str(c.get("purpose", "unknown"))
        slot = out.setdefault(p, {"dispatches": 0, "prompt_tokens": 0,
                                  "completion_tokens": 0, "cost_micro": 0,
                                  "failed": 0, "unresolved": 0})
        slot["dispatches"] += 1
        slot["prompt_tokens"] += int(c.get("prompt_tokens") or 0)
        slot["completion_tokens"] += int(c.get("completion_tokens") or 0)
        slot["cost_micro"] += int(c.get("actual_micro") or 0)
        if c.get("error"):
            slot["failed"] += 1
        if c.get("settled") == "reconciliation_required":
            slot["unresolved"] += int(c.get("bound_micro") or 0)
    return out


def export_run(*, run_id: str, runs_root: Path, reports_dir: Path,
               evidence_dir: Path) -> Dict[str, Any]:
    run_dir = runs_root / run_id
    journal = Journal(run_dir / "journal.jsonl")
    events = journal.read_all()
    verify = journal.verify()
    tail = journal.tail_status()

    ledger_state = {}
    for ev in reversed(events):
        if ev["event"] == "run_finished":
            ledger_state = ev.get("ledger") or {}
            break
    if not ledger_state:
        # 未落 run_finished（例如中断）：从事件重放
        from .contracts import Contract
        from .budget import Ledger  # 延迟导入避免循环
        ledger_state = {"note": "run 未正常结束；账本状态需由 status 命令的项目重放"}

    calls: List[Dict[str, Any]] = []
    for ev in events:
        if ev["event"] == "response_received":
            calls.append({
                "request_id": ev.get("request_id"),
                "run_id": ev.get("run_id"),
                "purpose": ev.get("purpose"),
                "finish_reason": ev.get("finish_reason"),
                "model_reported": ev.get("model_reported"),
                "prompt_tokens": ev.get("prompt_tokens"),
                "completion_tokens": ev.get("completion_tokens"),
                "usage_missing_reason": ev.get("usage_missing_reason"),
                "latency_ms": ev.get("latency_ms"),
                "content": ev.get("content"),
                "envelope": ev.get("envelope"),
                "settled": "settled",
                "error": None,
                "bound_micro": None,
                "actual_micro": None,
            })
        elif ev["event"] == "failed":
            calls.append({
                "request_id": ev.get("request_id"),
                "run_id": ev.get("run_id"),
                "purpose": ev.get("purpose"),
                "error": ev.get("error"),
                "may_have_billed": ev.get("may_have_billed"),
                "settled": "reconciliation_required" if ev.get("may_have_billed") else "released",
                "bound_micro": None,
                "actual_micro": None,
            })
    # 用 usage_settled 回填实际费用
    settled = {ev.get("request_id"): ev for ev in events
               if ev["event"] == "usage_settled"}
    reserved = {ev.get("request_id"): ev for ev in events
                if ev["event"] == "reservation_created"}
    for c in calls:
        rid = c.get("request_id")
        if rid in settled:
            c["actual_micro"] = settled[rid].get("actual_micro")
        if rid in reserved:
            c["bound_micro"] = reserved[rid].get("bound_micro")
            c["input_tokens_upper"] = reserved[rid].get("input_tokens_upper")
            c["output_tokens_upper"] = reserved[rid].get("output_tokens_upper")

    states = derive_trajectory_states(events)
    by_state = Counter(s.state for s in states.values())

    reports_dir.mkdir(parents=True, exist_ok=True)
    ledger_path = reports_dir / f"{run_id}_ledger.json"
    status_path = reports_dir / f"{run_id}_status.json"
    calls_path = reports_dir / f"{run_id}_calls.jsonl"
    md_path = reports_dir / f"{run_id}_summary.md"

    ledger_payload = {
        "run_id": run_id,
        "currency": "CNY",
        "unit": "micro_CNY",
        "ledger": ledger_state,
        "by_purpose": _purpose_table(calls),
        "journal_verify": verify,
        "tail": tail.as_dict(),
        "dispatches_total": len(calls),
        "note": "费用以 usage_settled 事件为准；未决暴露不清零。",
    }
    ledger_path.write_text(json.dumps(ledger_payload, ensure_ascii=False, indent=2),
                           encoding="utf-8")

    status_payload = {
        "run_id": run_id,
        "trajectory_states": dict(by_state),
        "trajectories": [s.as_dict() for s in states.values()],
        "journal_verify": verify,
        "tail": tail.as_dict(),
    }
    status_path.write_text(json.dumps(status_payload, ensure_ascii=False, indent=2),
                           encoding="utf-8")

    with calls_path.open("w", encoding="utf-8", newline="\n") as fh:
        for c in calls:
            fh.write(json.dumps(c, ensure_ascii=False, sort_keys=True) + "\n")

    md = [
        f"# run {run_id} 汇总\n",
        f"- 派发次数：{len(calls)}",
        f"- 轨迹状态：{dict(by_state)}",
        f"- 日志校验：{verify}",
        f"- 尾行：{tail.as_dict()}",
    ]
    if isinstance(ledger_state, dict) and "known_charge_micro" in ledger_state:
        md.append(f"- 已核费用：{micro_to_cny(int(ledger_state['known_charge_micro']))} 元")
        md.append(f"- 未决暴露：{micro_to_cny(int(ledger_state.get('unresolved_exposure_micro', 0)))} 元")
    md.append("\n## 逐用途\n")
    md.append("| purpose | 派发 | 输入 tokens | 输出 tokens | 费用(micro) | 失败 | 未决 |")
    md.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: |")
    for p, row in sorted(_purpose_table(calls).items()):
        md.append(f"| {p} | {row['dispatches']} | {row['prompt_tokens']} | "
                  f"{row['completion_tokens']} | {row['cost_micro']} | {row['failed']} | "
                  f"{row['unresolved']} |")
    md_path.write_text("\n".join(md) + "\n", encoding="utf-8")

    return {"run_id": run_id, "ledger": str(ledger_path), "status": str(status_path),
            "calls": str(calls_path), "summary_md": str(md_path),
            "dispatches": len(calls), "states": dict(by_state)}
