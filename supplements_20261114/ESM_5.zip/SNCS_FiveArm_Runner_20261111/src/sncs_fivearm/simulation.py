"""离线模拟场景套件：为每个离线用例构造确定性的合成 provider 脚本。

每个场景都是"一道题 × 一个臂 × 一组预设动作"，可用于验证：
派发门、预算门、ASC 早停、截断、缺 usage、HTTP 错误、全部无效、平票等。

场景文件格式（JSON）：

    {
      "scenario_id": "...",
      "description": "...",
      "tasks": [{"task_id": "...", "prompt": "...", "source": "gsm8k"}],
      "actions": {"<task_id>:<strategy>": [ <action>, ... ]},
      "budget": {"total_micro": ..., "preflight_micro": ...},
      "expect": {...}
    }

action 的 kind：
    text          正常返回（可指定 finish / pt / ct）
    truncated     被截断（finish_reason=length）
    missing_usage 有正文但缺 usage
    error         传输失败（可指定 may_have_billed）
    empty         空 content
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from .providers import SyntheticAction, SyntheticProvider


def action_from_dict(d: Dict[str, Any]) -> SyntheticAction:
    kind = str(d.get("kind", "text"))
    if kind == "error":
        return SyntheticAction.error(str(d.get("message", "synthetic error")),
                                     may_have_billed=bool(d.get("may_have_billed", True)),
                                     status_code=d.get("status_code"))
    if kind == "missing_usage":
        return SyntheticAction.missing_usage(
            str(d.get("content", "ANSWER: 1")),
            reason=str(d.get("reason", "provider_omitted_usage")),
            finish=str(d.get("finish", "stop")))
    if kind == "truncated":
        return SyntheticAction.truncated(str(d.get("content", "")),
                                         pt=int(d.get("pt", 100)),
                                         ct=int(d.get("ct", 4096)))
    if kind == "empty":
        return SyntheticAction.empty()
    return SyntheticAction.text(str(d.get("content", "ANSWER: 1")),
                                finish=str(d.get("finish", "stop")),
                                pt=int(d.get("pt", 100)),
                                ct=int(d.get("ct", 50)))


def script_key(task_id: str, strategy: str) -> str:
    """provider 脚本按 run_id 索引；此处用 task|strategy 前缀供上层拼接。"""
    return f"{task_id}|{strategy}"


class ScenarioSuite:
    """一组离线场景；可产出 provider、任务与期望。"""

    def __init__(self, data: Dict[str, Any]) -> None:
        self.data = data
        self.scenario_id = str(data.get("scenario_id", "unnamed"))

    @classmethod
    def load(cls, path: Path | str) -> "ScenarioSuite":
        return cls(json.loads(Path(path).read_text(encoding="utf-8-sig")))

    # ------------------------------------------------------------------ 构造
    def provider(self) -> SyntheticProvider:
        """把 `actions` 从 `task|strategy` 前缀展开成按 request_id 索引的脚本。

        request_id 形如 `<run_id>#d<n>`；因此脚本按 (run_id) 索引，并由
        `run_plan` 提供的映射解析 run_id → (task_id, strategy)。
        """
        raise NotImplementedError(
            "请使用 build_provider(plan)，因为脚本需要 run_id → (task, strategy) 的映射")

    def build_provider(self, plan: List[Dict[str, Any]]) -> SyntheticProvider:
        """plan: [{"run_id","task_id","strategy"}...]"""
        raw = self.data.get("actions") or {}
        script: Dict[str, List[SyntheticAction]] = {}
        for item in plan:
            key_task = script_key(item["task_id"], item["strategy"])
            fallback = raw.get(key_task)
            if fallback is None:
                base = raw.get(item["strategy"])
                default = raw.get("default")
                src = base or default
                if src is None:
                    raise KeyError(f"场景缺少脚本：{key_task} 且无臂级或默认动作")
                fallback = src
            script[item["run_id"]] = [action_from_dict(a) for a in fallback]
        return SyntheticProvider(script)
