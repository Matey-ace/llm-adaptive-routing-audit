# Online Resource 5

Resource Accounting and Evaluation Sensitivity in Adaptive LLM Mathematical Reasoning

Mai Ye, School of Artificial Intelligence, Guangdong Industry Polytechnic University, Foshan, China
Correspondence: 2025233201343@stumail.gdipu.edu.cn

## Reproduce the new numeric results

Extract this ZIP, keep its relative directory layout, and run:

    python SNCS_Final_Revision_20261114/analysis/rebuild_supplementary_analysis.py

Dependencies: Python 3.11 or later, NumPy and SciPy. The original verification used NumPy 2.5.1 and SciPy 1.18.0. No gateway, model access or network connection is needed. The script includes a network tripwire and writes new analysis outputs beside itself. The required numeric inputs and original maintained code files are included. Local paths, timestamps and the scope of the historical file search vary after extraction; numeric outcomes should not.

## De-identification and provenance

Reviewer names are replaced by A/B/C labels, the local gateway address is masked, private identity/method-mapping files are excluded, and credential-shaped structured fields are redacted. These are distributed derivatives, not byte-identical raw journals. TRANSFORM_MANIFEST.json records source and derivative hashes. Original source-code bytes are preserved for the four-file provenance comparison. Regenerated analysis hashes refer to the distributed inputs. Do not treat changed derivative hashes as evidence of changes to the original experiment.

The numeric results, question identities, submitted answers, paired scores and usage values are retained. New doorbell and shelter concerns are AI-raised audits, not new human adjudications. The source search cannot recover the four unavailable run-start files; the supplied current original executor and post-run repaired executor remain distinct.

## Repaired executor

repaired_executor/src and tests include the local repairs and regression cases. The complete 233-test result was obtained in the original workspace with historical preparation, configuration, reports and run fixtures. This ZIP does not claim to contain all fixtures required by that full suite. The portable synthetic repair tests can be run with pytest against tests/test_review_repairs.py; their separate smoke-test result is reported in the final verification materials. All tests must remain offline; do not use live provider credentials.

## Rights

Benchmark questions, model outputs and third-party code retain their source-specific conditions. The ASC source Apache-2.0 notice is preserved in repaired_executor/LICENSES. Historical author-owned code and annotation licences are described in Online Resource 2 and the manuscript; this packaging operation assigns no blanket licence to mixed-source material. This archive is supplied for transparent peer-review reproduction.

Portable regression command: python -m pytest repaired_executor/tests/test_review_repairs.py (pytest and the executor dependencies in pyproject.toml are required). The supplied public-bundle run passed all eight synthetic cases. Other manuscript-verification helpers retain author-workspace/historical-archive dependencies; only the numeric reconstruction command above is claimed self-contained for this new screen.
