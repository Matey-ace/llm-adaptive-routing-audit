"""Post-test per-anchor-stratum quality intervals, distinct from main tests."""
from pathlib import Path
import json,csv
import independent_statistical_audit as audit
root=Path(__file__).resolve().parents[1]
rr=json.loads((root/'evidence/independent_statistics_v2/followup_labels_independent.json').read_text(encoding='utf-8'))
out=[]
for source in ['gsm8k','math']:
    for difficulty in ['easy','medium','hard']:
        sub=[r for r in rr if r['source']==source and r['difficulty']==difficulty and r['repeat']==0]
        pp=audit.pair(sub)
        for version in ['baseline','audit_original_gold','audit_gold_sensitivity']:
            r=audit.interval(pp,version)
            out.append({'source':source,'difficulty':difficulty,'version':version,'status':'post_test_anchor_stratum_not_validated_policy','n_pairs':r['n'],'diff_low_pp':100*r['difference_bounds'][0],'diff_high_pp':100*r['difference_bounds'][1],'ci_low_pp':100*r['confidence_interval'][0],'ci_high_pp':100*r['confidence_interval'][1],'unknown_pairs':r['unknown_pairs'],'strict_lower_gt_minus_003':r['passes_strict_lower_gt_minus_003'],'alpha':.05,'H_within_comparison':1,'multiplicity_control':'none across source/difficulty/version comparisons'})
audit.dump(root/'evidence/difficulty_quality_sensitivity.json',out)
with (root/'evidence/difficulty_quality_sensitivity.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
print(json.dumps([r for r in out if r['version']=='audit_original_gold'],indent=2))
