"""Execute original agent code with a deterministic local client; no API or cache."""
from pathlib import Path
import hashlib
import json
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parents[1] / 'evidence'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
from agents.adaptive import build_agent
from complexity.artifact import load_artifact, router_from_artifact
from llm_proxy.usage import UsageMeter, UsageRecord
from tasks.agent_view import AgentView


class LocalClient:
    def __init__(self):
        self.meter = UsageMeter('local-deterministic-fixture')
        self.failed_attempts = []
        self.repeat_id = 'mock'
        self.model = 'local-deterministic-fixture'
        self.purposes = []

    def chat(self, messages, purpose='solve', **kwargs):
        self.purposes.append(purpose)
        content = {'judge': '{"level":"hard","confidence":1.0,"reasoning_steps":4}',
                   'plan': 'PLAN: 1. Calculate.', 'replan': 'PLAN: 1. Recalculate.',
                   'solve': 'ANSWER: 7',
                   'reflect': 'CONFIDENCE: 0.5\nVERDICT: REVISE'}[purpose]
        self.meter.add(UsageRecord(len(self.purposes), purpose, 1, 1, 0.0,
                                   self.model, 0.0, 0.0, False))
        return SimpleNamespace(content=content)


def run(cap, judged, use_s2):
    data, digest = load_artifact(ROOT / 'results/complexity/router_candidate_s5_20261014.json')
    client = LocalClient()
    router = router_from_artifact(data, judge_max_tokens=4096)
    agent = build_agent('adaptive', client, router=router,
                        stopper='S2' if use_s2 else 'S1',
                        stopper_params={'delta': 0.05, 'streak': 2} if use_s2 else {'max_rounds': 99},
                        hard_cap={'max_calls': cap, 'max_rounds': 4}, budget={'max_calls': cap})
    prompt = 'x' * (300 if judged else 1000)
    av = AgentView(task_id='offline_s2_fixture', prompt=prompt, tools_allowed=[])
    trajectory = agent.run(av)
    return dict(cap=cap, judged=judged, use_s2=use_s2, route=trajectory.extra['route_method'],
                attempts=len(client.purposes), purposes=client.purposes,
                stop=trajectory.stop_reason, reflections=trajectory.n_reflections,
                replans=trajectory.n_replans, final_answer=trajectory.final_answer,
                round_answers=trajectory.extra['round_answers'], router_sha256=digest)


def main():
    rows = [run(cap, judged, s2) for cap in (8, 9, 10) for judged in (False, True) for s2 in (True, False)]
    for judged in (False, True):
        at8 = [r for r in rows if r['cap'] == 8 and r['judged'] == judged]
        assert all(r['attempts'] == 8 for r in at8)
        assert at8[0]['final_answer'] == at8[1]['final_answer'] == '7'
    assert next(r for r in rows if r['cap'] == 8 and not r['judged'] and r['use_s2'])['stop'] == 'gain_below_delta:0.05'
    assert next(r for r in rows if r['cap'] == 8 and r['judged'] and r['use_s2'])['stop'] == 'hard_cap:calls'
    payload = dict(status='OFFLINE_LOCAL_FIXTURE_ONLY', model_api_calls=0, cases=rows,
                   source_sha256={str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                                  for p in [ROOT/'agents/adaptive.py', ROOT/'agents/plan_reflect.py',
                                            ROOT/'agents/stoppers.py', ROOT/'agents/base.py',
                                            ROOT/'complexity/router.py']})
    (OUT/'s2_budget_mock.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(rows, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
