"""Offline, read-only reconstruction of recorded workflow resource consumption.

No project collector is imported. Outputs are restricted to this audit directory.
All analyses in this file are post-test descriptive analyses, not new experiments.
"""
from pathlib import Path
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
import statistics

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parents[1] / 'evidence'
OUT.mkdir(exist_ok=True)
INPUTS = {}


def read_json(path):
    path = ROOT / path
    INPUTS[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return json.loads(path.read_text(encoding='utf-8-sig'))


def read_rows(path):
    path = ROOT / path
    raw = path.read_bytes()
    INPUTS[str(path.relative_to(ROOT))] = hashlib.sha256(raw).hexdigest()
    assert not raw or raw.endswith(b'\n'), path
    return [dict(json.loads(line), _path=str(path.relative_to(ROOT)), _line=i)
            for i, line in enumerate(raw.splitlines(), 1) if line.strip()]


def key(row):
    return row['strategy'], row['task_id'], str(row['repeat_id'])


def original_populations():
    contract = read_json('results/verify/intern_return_program_contract_20261014.json')
    qwen = read_json('results/verify/qwen_maas_resume_contract_20261018.json')
    correction = read_json('results/verify/qwen_misroute_replacement_20261019.json')
    replacement = {key(r): r for r in read_rows(correction['replacement']['path'])}
    populations = {}
    for case, spec in contract['cases'].items():
        paths = [c['path'] for c in spec['previous_components']]
        paths.append(f"results/raw/{spec['output_run_id']}.jsonl")
        secondary = spec['parent_case']['kind'] == 'secondary_backbone'
        source = spec['parent_case']['source']
        if secondary:
            for group in ('local_components', 'previous_hosted_components'):
                if source in qwen[group]:
                    paths.append(qwen[group][source]['path'])
            paths.append(f'results/raw/formal_{source}_qwen_maas_resume_20261018.jsonl')
        rows = [r for p in paths if (ROOT / p).exists() for r in read_rows(p)]
        if secondary and source == 'gsm8k':
            originals = read_rows(correction['original']['path'])
            keys = set(replacement)
            assert len(keys) == len(originals) == 7
            found = {key(r): r for r in rows}
            for r in originals:
                assert key(r) in found
                assert {k: v for k, v in found[key(r)].items() if not k.startswith('_')} == {
                    k: v for k, v in r.items() if not k.startswith('_')}
            rows = [replacement.get(key(r), r) for r in rows]
        assert len(rows) == len({key(r) for r in rows}) == spec['planned_rows'], case
        assert all(r['split'] == 'test' and r['source'] == source for r in rows)
        populations[case] = rows
    assert sum(map(len, populations.values())) == 51000
    return populations


def call_role(purpose, seen_solve, has_replan, escalated):
    if purpose == 'judge':
        return 'judge'
    if purpose == 'plan':
        return 'plan_escalation' if escalated else 'plan_initial'
    if purpose == 'replan':
        return 'replan'
    if purpose == 'reflect':
        return 'reflect'
    if purpose in ('solve', 'execute'):
        return 'solve_regenerated' if has_replan else 'solve_escalation' if seen_solve else 'solve_initial'
    return purpose


def original_calls(row):
    calls = row.get('usage_records', [])
    assert sum(c['prompt_tokens'] + c['completion_tokens'] for c in calls) == row['meter_summary']['total_tokens']
    return calls


def follow_calls(row):
    calls = []
    for c in row.get('call_audit', []):
        u = (c.get('response_envelope') or {}).get('usage')
        assert u is not None
        calls.append(dict(purpose=c['purpose'], prompt_tokens=u['prompt_tokens'],
                          completion_tokens=u['completion_tokens'],
                          reasoning_tokens=(u.get('completion_tokens_details') or {}).get('reasoning_tokens'),
                          total_tokens=u['total_tokens']))
    assert sum(c['prompt_tokens'] + c['completion_tokens'] for c in calls) == row['meter_summary']['total_tokens']
    assert len(calls) == row['meter_summary']['n_calls']
    return calls


def summarize_case(case, rows, follow=False):
    roles = defaultdict(Counter)
    trajectory_rows = []
    strata = defaultdict(Counter)
    for r in rows:
        calls = follow_calls(r) if follow else original_calls(r)
        strategy = r['strategy']
        seen_solve = has_replan = False
        for c in calls:
            role = call_role(c['purpose'], seen_solve, has_replan,
                             r.get('extra', {}).get('escalated_from') == 'direct')
            seen_solve = seen_solve or c['purpose'] in ('solve', 'execute')
            has_replan = has_replan or c['purpose'] == 'replan'
            cell = roles[(strategy, role)]
            cell['calls'] += 1
            cell['prompt_tokens'] += c['prompt_tokens']
            cell['completion_tokens'] += c['completion_tokens']
            cell['total_tokens'] += c['prompt_tokens'] + c['completion_tokens']
            if c.get('reasoning_tokens') is not None:
                cell['reasoning_tokens'] += c['reasoning_tokens']
                cell['reasoning_usage_calls'] += 1
        failed = r.get('failed_attempts', 0)
        failed = len(failed) if isinstance(failed, list) else failed
        attempts = r.get('request_attempts') if follow else r['request_audit_summary']['recorded_request_attempts']
        assert attempts == len(calls) + failed, (case, key(r), attempts, len(calls), failed)
        met = r['meter_summary']
        record = dict(case=case, source=r['source'], strategy=strategy, task_id=r['task_id'],
                      repeat_id=r['repeat_id'], difficulty=r['difficulty'], attempts=attempts,
                      successful_calls=len(calls), failed_attempts=failed,
                      prompt_tokens=met['prompt_tokens'], completion_tokens=met['completion_tokens'],
                      known_tokens=met['total_tokens'], usage_complete=not failed and not bool(r.get('error')),
                      stop_reason=r.get('stop_reason'), level=r.get('selected_level'),
                      route=r.get('extra', {}).get('route_method'),
                      escalated=r.get('extra', {}).get('escalated_from') == 'direct',
                      n_reflections=r.get('n_reflections', 0), n_replans=r.get('n_replans', 0),
                      error=bool(r.get('error')), empty=not bool(str(r.get('final_answer') or '').strip()),
                      raw_path=r['_path'], raw_line=r['_line'])
        trajectory_rows.append(record)
        for difficulty in ('ALL', r['difficulty']):
            cell = strata[(strategy, difficulty)]
            cell['n'] += 1
            for field in ('attempts', 'successful_calls', 'failed_attempts', 'prompt_tokens', 'completion_tokens',
                          'known_tokens', 'usage_complete', 'escalated', 'n_reflections', 'n_replans', 'error', 'empty'):
                cell[field] += record[field]
    role_rows = [dict(case=case, strategy=s, role=role, **values) for (s, role), values in sorted(roles.items())]
    summary_rows = [dict(case=case, strategy=s, difficulty=d, **values) for (s, d), values in sorted(strata.items())]
    return trajectory_rows, role_rows, summary_rows


def paired(rows, a='adaptive', b='plan_reflect'):
    left = {(r['task_id'], str(r['repeat_id'])): r for r in rows if r['strategy'] == a}
    right = {(r['task_id'], str(r['repeat_id'])): r for r in rows if r['strategy'] == b}
    if not left or not right:
        return []
    assert left.keys() == right.keys()
    out = []
    for difficulty in ('ALL', 'easy', 'medium', 'hard'):
        pairs = [(left[k], right[k]) for k in left if difficulty == 'ALL' or left[k]['difficulty'] == difficulty]
        if not pairs:
            continue
        result = Counter(n=len(pairs))
        for x, y in pairs:
            assert x['difficulty'] == y['difficulty']
            result['delta_attempts_sum'] += x['attempts'] - y['attempts']
            result['delta_prompt_tokens_sum'] += x['prompt_tokens'] - y['prompt_tokens']
            result['delta_completion_tokens_sum'] += x['completion_tokens'] - y['completion_tokens']
            result['delta_known_tokens_sum'] += x['known_tokens'] - y['known_tokens']
            complete = x['usage_complete'] and y['usage_complete']
            result['complete_usage_pairs'] += complete
            if complete:
                result['delta_complete_tokens_sum'] += x['known_tokens'] - y['known_tokens']
                result['fewer_requests_more_tokens_complete'] += x['attempts'] < y['attempts'] and x['known_tokens'] > y['known_tokens']
                result['fewer_requests_fewer_tokens_complete'] += x['attempts'] < y['attempts'] and x['known_tokens'] < y['known_tokens']
            result['fewer_requests_more_known_tokens'] += x['attempts'] < y['attempts'] and x['known_tokens'] > y['known_tokens']
        out.append(dict(case=pairs[0][0]['case'], a=a, b=b, difficulty=difficulty, **result))
    return out


def write_csv(name, rows):
    fields = sorted({field for row in rows for field in row})
    with (OUT / name).open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def main():
    populations = original_populations()
    trajectories, roles, summaries, comparisons = [], [], [], []
    for case, rows in populations.items():
        tr, ro, su = summarize_case(case, rows)
        trajectories.extend(tr); roles.extend(ro); summaries.extend(su)
        comparisons.extend(paired(tr, b='vote_k' if '_budget' in case else 'plan_reflect'))
    for phase, path in [('main', 'main_16384'), ('repeats', 'repeats_16384')]:
        rows = read_rows(f'results/validation20261020_dsh/{path}/trajectories.jsonl')
        assert len(rows) == (4000 if phase == 'main' else 2400)
        for source in ('gsm8k', 'math'):
            case = f'followup_{phase}_{source}'
            tr, ro, su = summarize_case(case, [r for r in rows if r['source'] == source], follow=True)
            trajectories.extend(tr); roles.extend(ro); summaries.extend(su)
            comparisons.extend(paired(tr))
    assert len(trajectories) == 57400
    write_csv('resource_trajectory_index.csv', trajectories)
    write_csv('resource_roles.csv', roles)
    write_csv('resource_summary_by_difficulty.csv', summaries)
    write_csv('resource_paired_differences.csv', comparisons)
    payload = dict(status='OFFLINE_POST_TEST_DESCRIPTIVE', original_n=51000, followup_n=6400,
                   calls=sum(r['calls'] for r in roles), known_tokens=sum(r['total_tokens'] for r in roles),
                   input_sha256=INPUTS, paired_differences=comparisons,
                   limitations=['Known successful usage is not full failed-request billing.',
                                'Difficulty is the dataset-derived anchor, not randomized difficulty.',
                                'Role labels describe observed sequential calls; they do not identify causal component effects.',
                                'Reasoning tokens are a subset of completion tokens and are not added twice.',
                                'No quality re-scoring or model execution was performed.'])
    (OUT / 'resource_role_audit.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: payload[k] for k in ('status', 'original_n', 'followup_n', 'calls', 'known_tokens')}, ensure_ascii=False))
    print(json.dumps([r for r in comparisons if r['difficulty'] == 'ALL' and ('primary' in r['case'] or 'qwen' in r['case'] or 'followup_main' in r['case'])], ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
