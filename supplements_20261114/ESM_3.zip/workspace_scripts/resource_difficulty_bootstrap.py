"""Post-test paired stratified bootstrap of complete follow-up resource measures."""
from pathlib import Path
import csv
import hashlib
import json
import numpy as np

OUT = Path(__file__).resolve().parents[1] / 'evidence'
SOURCE = OUT / 'resource_trajectory_index.csv'
SEED = 20261109
B = 2000


def main():
    rows = list(csv.DictReader(SOURCE.open(encoding='utf-8-sig')))
    rng = np.random.default_rng(SEED)
    summaries = []
    for source in ('gsm8k', 'math'):
        case = 'followup_main_' + source
        group = [r for r in rows if r['case'] == case]
        left = {r['task_id']: r for r in group if r['strategy'] == 'adaptive'}
        right = {r['task_id']: r for r in group if r['strategy'] == 'plan_reflect'}
        assert left.keys() == right.keys() and len(left) == 1000
        strata = {}
        for difficulty in ('easy', 'medium', 'hard'):
            ids = sorted(k for k in left if left[k]['difficulty'] == difficulty)
            diffs = np.array([[int(left[k][f]) - int(right[k][f]) for f in ('attempts', 'known_tokens')]
                              for k in ids], dtype=float)
            assert all(left[k]['usage_complete'] == right[k]['usage_complete'] == 'True' for k in ids)
            sampled = diffs[rng.integers(0, len(ids), size=(B, len(ids)))].mean(axis=1)
            strata[difficulty] = (diffs, sampled)
            lo, hi = np.quantile(sampled, [.025, .975], axis=0)
            summaries.append(dict(source=source, difficulty=difficulty, n=len(ids),
                                  delta_requests=float(diffs[:, 0].mean()), requests_low=float(lo[0]), requests_high=float(hi[0]),
                                  delta_tokens=float(diffs[:, 1].mean()), tokens_low=float(lo[1]), tokens_high=float(hi[1])))
        sampled = sum(len(d) / 1000 * s for d, s in strata.values())
        diffs = np.concatenate([d for d, s in strata.values()])
        lo, hi = np.quantile(sampled, [.025, .975], axis=0)
        summaries.append(dict(source=source, difficulty='ALL_stratified', n=1000,
                              delta_requests=float(diffs[:, 0].mean()), requests_low=float(lo[0]), requests_high=float(hi[0]),
                              delta_tokens=float(diffs[:, 1].mean()), tokens_low=float(lo[1]), tokens_high=float(hi[1])))
    payload = dict(status='POST_TEST_DESCRIPTIVE', seed=SEED, draws=B, numpy=np.__version__,
                   source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(), results=summaries,
                   scope='Observed benchmark-anchor strata. Pointwise 95% percentile intervals, not multiplicity-adjusted or quality non-inferiority tests. No new model calls.')
    (OUT / 'resource_difficulty_bootstrap.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    with (OUT / 'resource_difficulty_bootstrap.csv').open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=list(summaries[0])); w.writeheader(); w.writerows(summaries)
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
