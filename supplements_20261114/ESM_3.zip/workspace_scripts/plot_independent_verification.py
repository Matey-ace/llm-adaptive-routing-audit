"""Standalone scientific plots from independently reconstructed numerical files."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parents[1]
ev=root/'evidence/independent_statistics_v2'
def read(n):return json.loads((ev/n).read_text(encoding='utf-8'))
main=read('original_primary_intervals.json');follow=read('followup_main_intervals.json')
fig,ax=plt.subplots(figsize=(10.5,7));yy=[];labs=[];y=0
colors={'frozen':'#6d7480','historical_author':'#487fa5','baseline':'#6d7480','audit_original_gold':'#cc6529','audit_gold_sensitivity':'#207e6a'}
for case,vv in list(main.items())+[(f'followup_{s}',v) for s,v in follow.items()]:
    if case.startswith('followup'):name='Follow-up '+case.split('_')[-1].upper()
    else:name=('Qwen ' if 'qwen' in case else 'DS ')+('GSM8K' if 'gsm8k' in case else 'MATH')
    for v,s in vv.items():
        lo,hi=[100*x for x in s['confidence_interval']];l,u=[100*x for x in s['difference_bounds']]
        ax.plot([lo,hi],[y,y],color=colors[v],lw=1.4)
        ax.plot([l,u],[y,y],color=colors[v],lw=5)
        ax.plot([(l+u)/2],[y],marker='o',color=colors[v],ms=3)
        labs.append(name+' | '+v.replace('audit_','').replace('_',' '));yy.append(y);y-=1
    y-=.5
ax.axvline(-3,color='#222',ls='--',lw=1);ax.axvline(0,color='#ccc',lw=.6)
ax.set_yticks(yy,labs,fontsize=8);ax.set_xlabel('Adaptive minus Plan+Reflect (percentage points)')
ax.set_title('Reconstructed quality intervals by score version\nThin: stratified CP outer interval; thick: unknown-label bounds',fontsize=11)
ax.grid(axis='x',alpha=.15);fig.tight_layout();fig.savefig(root/'evidence/reconstructed_quality_intervals.png',dpi=200);fig.savefig(root/'evidence/reconstructed_quality_intervals.pdf');plt.close(fig)
resources=read('followup_resources.json');fig,aa=plt.subplots(1,2,figsize=(8,3.5))
for ax,metric,title,unit in zip(aa,['n_calls','total_tokens'],['Recorded requests','Recorded tokens'],['requests per task','tokens per task']):
    for y,source in enumerate(['gsm8k','math']):
        r=resources[source][metric];m=r['mean_difference'];l,u=r['bootstrap95'];ax.errorbar(m,y,xerr=[[m-l],[u-m]],fmt='o',color='#207e6a',capsize=4)
    ax.axvline(0,color='#666',ls='--',lw=1);ax.set_yticks([0,1],['GSM8K','MATH']);ax.set_title(title);ax.set_xlabel('Adaptive minus reference\n'+unit);ax.set_ylim(-.5,1.5);ax.grid(axis='x',alpha=.15)
fig.suptitle('Follow-up main comparisons: paired means and descriptive 95% intervals',fontsize=10);fig.tight_layout();fig.savefig(root/'evidence/reconstructed_request_token_tradeoff.png',dpi=200);fig.savefig(root/'evidence/reconstructed_request_token_tradeoff.pdf');plt.close(fig)
print('Saved four scientific plot files; figures use independent reconstruction outputs.')
