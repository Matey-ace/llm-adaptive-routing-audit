"""Post-test hypothetical one-label sensitivity; not a new correction or rating."""
from pathlib import Path
from collections import defaultdict
from copy import deepcopy
import json
import independent_statistical_audit as audit

root=Path(__file__).resolve().parents[1]
src=root/'evidence/independent_statistics_v2/followup_labels_independent.json'
rr=json.loads(src.read_text(encoding='utf-8'));out={}
for source in ['gsm8k','math']:
    r=[dict(x,repeat=x['repeat']) for x in rr if x['source']==source and x['repeat']==0]
    pp=audit.pair(r);out[source]={}
    for version in ['audit_original_gold','audit_gold_sensitivity']:
        groups=defaultdict(list)
        for i,(a,b) in enumerate(pp):
            for arm,x in enumerate((a,b)):
                if x['labels'][version]==(1 if arm==0 else 0):
                    groups[(a['difficulty'],a['labels'][version],b['labels'][version],arm)].append(i)
        conditions=[]
        for (difficulty,a_value,b_value,arm),indices in groups.items():
            i=indices[0];changed=pp.copy();ab=list(changed[i]);ab[arm]=deepcopy(ab[arm]);ab[arm]['labels'][version]=0 if arm==0 else 1;changed[i]=tuple(ab)
            result=audit.interval(changed,version)
            conditions.append({'difficulty':difficulty,'adaptive_before':a_value,'reference_before':b_value,'changed_arm':'adaptive' if arm==0 else 'plan_reflect','changed_to':0 if arm==0 else 1,'eligible_single_label_edits':len(indices),'ci_lower_after_pp':100*result['confidence_interval'][0],'passes_after':result['passes_strict_lower_gt_minus_003']})
        out[source][version]={'status':'post_test_hypothetical_only','baseline':audit.interval(pp,version),'one_label_edits_evaluated':sum(c['eligible_single_label_edits'] for c in conditions),'edits_that_change_pass_to_nonpass':sum(c['eligible_single_label_edits'] for c in conditions if not c['passes_after']),'conditions':conditions}
audit.dump(root/'evidence/one_label_perturbation_sensitivity.json',out)
print(json.dumps({s:{v:{k:x[k] for k in ['one_label_edits_evaluated','edits_that_change_pass_to_nonpass']} for v,x in ss.items()} for s,ss in out.items()},indent=2))
