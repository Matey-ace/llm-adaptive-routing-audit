from pathlib import Path
from collections import defaultdict,Counter
from hashlib import sha256
from urllib.request import Request,urlopen
from scipy.special import betaincinv
import json,csv
ROOT=Path('E:/论文相关');OUT=ROOT/'SNCS_Autonomous_Audit_20261109/evidence'
data=ROOT/'results/validation20261020_dsh/main_16384/trajectories.jsonl'
records=[json.loads(s) for s in data.read_text(encoding='utf-8-sig').splitlines() if s]
totals=defaultdict(Counter);tasks=defaultdict(dict)
for r in records:
    key=(r['source'],r['strategy']);v=totals[key];v['n']+=1
    calls=r['call_audit'];v['calls']+=len(calls)
    for c in calls:
        u=c['response_envelope']['usage'];assert u['total_tokens']==u['prompt_tokens']+u['completion_tokens']
        v['tokens']+=u['total_tokens'];v['input']+=u['prompt_tokens'];v['output']+=u['completion_tokens']
        v[c['purpose']+'_tokens']+=u['total_tokens'];v[c['purpose']+'_calls']+=1
    tasks[(r['source'],r['task_id'])][r['strategy']]=(len(calls),sum(c['response_envelope']['usage']['total_tokens'] for c in calls))
rs={}
for src in ['gsm8k','math']:
    a=totals[(src,'adaptive')];b=totals[(src,'plan_reflect')]
    rs[src]={'adaptive':dict(a),'reference':dict(b),'delta_requests_mean':(a['calls']-b['calls'])/1000,'delta_tokens_mean':(a['tokens']-b['tokens'])/1000,'judge_share_adaptive':a['judge_tokens']/a['tokens'],'fewer_requests_more_tokens_tasks':sum(x['adaptive'][0]<x['plan_reflect'][0] and x['adaptive'][1]>x['plan_reflect'][1] for (s,t),x in tasks.items() if s==src)}
# Independently calculate outer CP endpoints with inverse incomplete beta,
# given the independently reconstructed discordance counts as sufficient statistics.
stats=json.loads((OUT/'independent_statistics_v2/followup_main_intervals.json').read_text())
def bounds(q,alpha):
    lows=[];ups=[];H=len(q['strata']);tail=alpha/(4*H);n=q['n']
    for entries in q['strata'].values():
        a,b=entries;ns=a['n']
        lo=lambda k:0. if k==0 else float(betaincinv(k,ns-k+1,tail))
        up=lambda k:1. if k==ns else float(betaincinv(k+1,ns-k,1-tail))
        lows.append(ns/n*(lo(a['positive'])-up(a['negative'])))
        ups.append(ns/n*(up(b['positive'])-lo(b['negative'])))
    return [sum(lows),sum(ups)]
cpchecks=[]
def walk(o,path=''):
    if isinstance(o,dict):
        if 'strata'in o and 'confidence_interval'in o:
            actual=bounds(o,.05);assert max(abs(x-y) for x,y in zip(actual,o['confidence_interval']))<1e-12
            cpchecks.append({'path':path,'alpha_005':actual,'alpha_0025':bounds(o,.025)})
        else:
            for k,v in o.items():walk(v,path+'/'+k)
walk(stats)
s2={'permitted_attempts':8,'initial_plan_and_solve':2,'calls_per_completed_revision':3,'required_low_change_revisions':2,'earliest_without_judge':2+3*2,'earliest_with_one_judge':1+2+3*2,'interpretation':'S2 cannot stop before the 8-attempt cap in the no-tool frozen workflow. At 8 it can take priority as a reason label; with one judge it cannot collect two changes. Static control-flow verification independently read by root.'}
report={'source':str(data.relative_to(ROOT)),'source_sha256':sha256(data.read_bytes()).hexdigest(),'n':len(records),'resources':rs,'independent_cp_special_function_checks':cpchecks,'S2_static_bound':s2}
(OUT/'root_independent_crosscheck.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))

external=[]
for url in ['https://github.com/Matey-ace/sncs-adaptive-routing-audit/tree/audit-20261105-v1','https://api.github.com/repos/Matey-ace/sncs-adaptive-routing-audit/git/ref/tags/audit-20261105-v1','https://link.springer.com/brands/springer/journal-policies']:
    try:
        with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=20) as r:
            b=r.read();rec={'requested_url':url,'final_url':r.url,'status':r.status,'sha256':sha256(b).hexdigest()}
        if 'api.github'in url:rec['response']=json.loads(b)
        external.append(rec)
        if 'journal-policies'in url:(OUT/'journal/publisher_journal_policies.html').write_bytes(b)
    except Exception as e:external.append({'requested_url':url,'error':str(e)})
(OUT/'external_access_check.json').write_text(json.dumps(external,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(external,ensure_ascii=False))
