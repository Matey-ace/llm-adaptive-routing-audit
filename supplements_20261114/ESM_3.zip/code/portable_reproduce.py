"""Portable offline reconstruction of Tables 15--17 from ESM_3 numeric inputs.

No project production module is imported. Requires NumPy/SciPy, installed before
offline execution. Source snapshots are verified and read, never imported.
"""
from pathlib import Path
from collections import Counter, defaultdict
from copy import deepcopy
import argparse, csv, hashlib, importlib.util, json, math, socket, sys
sys.dont_write_bytecode=True
def deny(*a,**k):raise RuntimeError('ESM_3 portable reproduction blocks network connections.')
socket.socket.connect=deny;socket.socket.connect_ex=deny
socket.create_connection=deny;socket.getaddrinfo=deny
import numpy as np
import scipy

def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def csvread(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def compare(a,b,path=''):
    if isinstance(b,dict):
        assert set(a)==set(b),(path,set(a)^set(b))
        for k in b:compare(a[k],b[k],path+'/'+str(k))
    elif isinstance(b,list):
        assert len(a)==len(b),(path,len(a),len(b))
        for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'/'+str(i))
    elif isinstance(b,float):assert math.isclose(a,b,rel_tol=0,abs_tol=1e-8),(path,a,b)
    else:assert a==b,(path,a,b)
def select_stat(r):
    return {k:r[k] for k in ['n','difference_bounds','confidence_interval','passes_strict_lower_gt_minus_003','unknown_pairs']}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--input',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    root=a.input.resolve();out=a.output.resolve();assert not out.exists() and root not in out.parents and out!=root
    manifest=read(root/'MANIFEST.json');listed={e['path'] for e in manifest['files']}
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()};assert actual==listed|{'MANIFEST.json'}
    for entry in manifest['files']:
        p=root/entry['path'];assert p.stat().st_size==entry['bytes'] and digest(p)==entry['sha256'],entry['path']
    out.mkdir(parents=True)
    spec=importlib.util.spec_from_file_location('independent_numeric_audit',root/'code/independent_statistical_audit.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
    # Numeric/hashes-only label inputs omit all answers, rater identities and prose.
    labels=read(root/'data/followup_labels.json');assert len(labels)==6400
    original=read(root/'data/original_labels.json');assert len(original)==51000
    label_counts={}
    for family,rows in [('original',original),('followup',labels)]:
        label_counts[family]={v:dict(Counter(str(r['labels'][v]) for r in rows)) for v in rows[0]['labels']}
    main_quality={};simultaneous={};difficulty=[];edits={}
    for source in ['gsm8k','math']:
        pp=audit.pair([r for r in labels if r['source']==source and r['repeat']==0]);assert len(pp)==1000
        main_quality[source]={v:select_stat(audit.interval(pp,v)) for v in ['baseline','audit_original_gold','audit_gold_sensitivity']}
        simultaneous[source]={v:select_stat(audit.interval(pp,v,alpha=.025)) for v in ['baseline','audit_original_gold','audit_gold_sensitivity']}
        edits[source]={}
        for d in ['easy','medium','hard']:
            sub=[p for p in pp if p[0]['difficulty']==d]
            for v in ['baseline','audit_original_gold','audit_gold_sensitivity']:
                q=audit.interval(sub,v)
                difficulty.append({'source':source,'difficulty':d,'version':v,'n_pairs':q['n'],'diff_low_pp':100*q['difference_bounds'][0],'diff_high_pp':100*q['difference_bounds'][1],'ci_low_pp':100*q['confidence_interval'][0],'ci_high_pp':100*q['confidence_interval'][1],'unknown_pairs':q['unknown_pairs'],'strict_lower_gt_minus_003':q['passes_strict_lower_gt_minus_003']})
        for v in ['audit_original_gold','audit_gold_sensitivity']:
            groups=defaultdict(list)
            for i,(x,y) in enumerate(pp):
                for arm,r in enumerate((x,y)):
                    if r['labels'][v]==(1 if arm==0 else 0):groups[(x['difficulty'],x['labels'][v],y['labels'][v],arm)].append(i)
            eligible=reversed_=0;conditions=[]
            for (d,xv,yv,arm),indices in groups.items():
                changed=pp.copy();i=indices[0];ab=list(changed[i]);ab[arm]=deepcopy(ab[arm]);ab[arm]['labels'][v]=0 if arm==0 else 1;changed[i]=tuple(ab)
                q=audit.interval(changed,v);eligible+=len(indices)
                if not q['passes_strict_lower_gt_minus_003']:reversed_+=len(indices)
                conditions.append({'difficulty':d,'adaptive_before':xv,'reference_before':yv,'changed_arm':'adaptive' if arm==0 else 'plan_reflect','changed_to':0 if arm==0 else 1,'eligible_single_label_edits':len(indices),'ci_lower_after_pp':100*q['confidence_interval'][0],'passes_after':q['passes_strict_lower_gt_minus_003']})
            edits[source][v]={'eligible':eligible,'reversed':reversed_,'conditions':conditions}
    # Table 15: per-call numeric usage, not input aggregate role totals.
    calls=csvread(root/'data/followup_main_calls.csv');assert len(calls)==11537
    roles=defaultdict(Counter)
    for c in calls:
        p=c['purpose'];role='Judge' if p=='judge' else 'Initial plan' if p=='plan' else 'Reflection' if p=='reflect' else 'Solve and replan' if p in ['solve','execute','replan'] else p
        assert int(c['total_tokens'])==int(c['prompt_tokens'])+int(c['completion_tokens'])
        roles[(c['source'],c['strategy'])][role]+=int(c['total_tokens'])
    table15=[{'source':s,'strategy':st,**{k:roles[(s,st)][k] for k in ['Judge','Initial plan','Reflection','Solve and replan']}} for s in ['gsm8k','math'] for st in ['adaptive','plan_reflect']]
    # Table 16: preserve original source/stratum ordering, joint two-metric draws,
    # seed 20261109 and 2,000 percentile draws exactly.
    index=csvread(root/'data/resource_trajectory_index.csv');assert len(index)==57400
    resources=[];rng=np.random.default_rng(20261109)
    for source in ['gsm8k','math']:
        rr=[r for r in index if r['case']=='followup_main_'+source];left={r['task_id']:r for r in rr if r['strategy']=='adaptive'};right={r['task_id']:r for r in rr if r['strategy']=='plan_reflect'};assert left.keys()==right.keys() and len(left)==1000
        strata={}
        for d in ['easy','medium','hard']:
            ids=sorted(k for k in left if left[k]['difficulty']==d)
            assert all(left[k]['usage_complete']==right[k]['usage_complete']=='True' for k in ids)
            diffs=np.array([[int(left[k][f])-int(right[k][f]) for f in ['attempts','known_tokens']] for k in ids],dtype=float)
            sampled=diffs[rng.integers(0,len(ids),size=(2000,len(ids)))].mean(axis=1);strata[d]=(diffs,sampled);lo,hi=np.quantile(sampled,[.025,.975],axis=0)
            resources.append({'source':source,'difficulty':d,'n':len(ids),'delta_requests':float(diffs[:,0].mean()),'requests_low':float(lo[0]),'requests_high':float(hi[0]),'delta_tokens':float(diffs[:,1].mean()),'tokens_low':float(lo[1]),'tokens_high':float(hi[1])})
        sampled=sum(len(d)/1000*s for d,s in strata.values());diffs=np.concatenate([d for d,s in strata.values()]);lo,hi=np.quantile(sampled,[.025,.975],axis=0)
        resources.append({'source':source,'difficulty':'ALL_stratified','n':1000,'delta_requests':float(diffs[:,0].mean()),'requests_low':float(lo[0]),'requests_high':float(hi[0]),'delta_tokens':float(diffs[:,1].mean()),'tokens_low':float(lo[1]),'tokens_high':float(hi[1])})
    # Independent finite schedule for the archived deterministic S2 fixture.
    # Source snapshots are verified, not imported as project production code.
    expected_s2=read(root/'evidence/s2_budget_mock.json');s2=[]
    for cap in [8,9,10]:
        for judged in [False,True]:
            for use_s2 in [True,False]:
                schedule=(['judge'] if judged else [])+['plan','solve'];rounds=1;changes=0;stop='hard_cap:calls'
                while len(schedule)<cap:
                    for p in ['reflect','replan','solve']:
                        if len(schedule)==cap:break
                        schedule.append(p)
                        if p=='solve':
                            rounds+=1;changes+=1
                            if use_s2 and changes>=2:stop='gain_below_delta:0.05';break
                    if stop.startswith('gain_'):break
                s2.append({'cap':cap,'judged':judged,'use_s2':use_s2,'attempts':len(schedule),'purposes':schedule,'stop':stop,'reflections':schedule.count('reflect'),'replans':schedule.count('replan'),'round_answers':['7']*rounds,'final_answer':'7'})
    for got,expected in zip(s2,expected_s2['cases']):compare(got,{k:expected[k] for k in got})
    for rel,h in expected_s2['source_sha256'].items():assert digest(root/'source_snapshots'/Path(rel.replace('\\','/')))==h
    totals={'trajectories':len(index),'successful_calls':sum(int(r['successful_calls']) for r in index),'known_tokens':sum(int(r['known_tokens']) for r in index)}
    result={'table15':table15,'difficulty_resources':resources,'difficulty_quality':difficulty,'main_quality':main_quality,'simultaneous_quality':simultaneous,'single_label_edits':edits,'label_counts':label_counts,'totals':totals}
    compare(result,read(root/'expected/reconstructed_results.json'))
    for name,obj in [('table15_roles.json',table15),('table16_resources_full_intervals.json',resources),('table16_quality_full_intervals.json',difficulty),('table17_simultaneous_intervals.json',simultaneous),('table17_single_label_edits.json',edits),('s2_independent_schedule.json',s2)]:write(out/name,obj)
    report={'passed':True,'manifest_files_verified':len(listed),'tables_recomputed':[15,16,17],'followup_main_calls_read':len(calls),'all_resource_trajectory_rows':len(index),'label_rows':{'original':len(original),'followup':len(labels)},'bootstrap_draws':2000,'bootstrap_seed':20261109,'network_blocked':True,'model_api_calls':0,'production_code_imports':0,'s2_scope':'Independent schedule reconstruction plus stored original-Agent fixture and source hash verification; not a fresh import/execution of the Agent.','runtime':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__},'manifest_sha256':digest(root/'MANIFEST.json'),'numeric_comparison_absolute_tolerance':1e-8}
    write(out/'RUN_REPORT.json',report);print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
