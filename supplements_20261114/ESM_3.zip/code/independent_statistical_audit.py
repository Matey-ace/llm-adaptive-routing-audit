"""Independent 2026-11-09 source-to-label/CP/resource audit. No production imports.

Reads stored outputs and explicit review crosswalks; reconstructs labels before
reading any expected statistics. Network use is blocked. All writes are in --out.
"""
from pathlib import Path
from collections import Counter, defaultdict
from functools import lru_cache
import argparse, csv, hashlib, json, math, random, socket, sys, time
import numpy as np
from scipy.stats import beta

def deny(*a, **k): raise RuntimeError('Offline audit: network disabled')
socket.socket.connect=deny; socket.socket.connect_ex=deny
socket.create_connection=deny; socket.getaddrinfo=deny
INPUTS={}
def fingerprint(p):
    p=Path(p); h=hashlib.sha256(p.read_bytes()).hexdigest(); INPUTS[str(p.resolve())]=h; return h
def read(p):
    fingerprint(p); return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def rows(p):
    fingerprint(p)
    with Path(p).open(encoding='utf-8-sig') as f:
        for s in f:
            if s.strip(): yield json.loads(s)
def dump(p,obj):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def ah(s): return hashlib.sha256(str(s or '').encode()).hexdigest()
def outcome(r):
    if r.get('error') or not str(r.get('final_answer') or '').strip(): return 0
    if r.get('needs_review') or r.get('success') is None: return None
    return int(bool(r['success']))
@lru_cache(None)
def cp(k,n,tail):
    return (0. if k==0 else float(beta.ppf(tail,k,n-k+1)),1. if k==n else float(beta.ppf(1-tail,k+1,n-k)))
def interval(pairs,version,alpha=.05,unknown_zero=False):
    strata=defaultdict(list)
    for a,b in pairs:
        assert (a['task'],a['repeat'],a['difficulty'])==(b['task'],b['repeat'],b['difficulty'])
        strata[a['difficulty']].append((a['labels'][version],b['labels'][version]))
    n=len(pairs);tail=alpha/(4*len(strata));points=[0.,0.];limits=[0.,0.];counts={}
    for d,vs in strata.items():
        ns=len(vs); ss=[]
        for j in (0,1):
            xx=[((0 if unknown_zero else j) if x is None else x,(0 if unknown_zero else 1-j) if y is None else y) for x,y in vs]
            pos=sum(x>y for x,y in xx);neg=sum(x<y for x,y in xx)
            lp,up=cp(pos,ns,tail);lm,um=cp(neg,ns,tail)
            points[j]+=(pos-neg)/n; limits[j]+=ns/n*((lp-um) if j==0 else (up-lm))
            ss.append({'n':ns,'positive':pos,'negative':neg})
        counts[str(d)]=ss
    return {'n':n,'independent_tasks':len({a['task'] for a,b in pairs}),'difference_bounds':points,'confidence_interval':limits,'passes_strict_lower_gt_minus_003':limits[0]>-.03,'unknown_pairs':sum(a['labels'][version] is None or b['labels'][version] is None for a,b in pairs),'alpha':alpha,'strata':counts}
def pair(rr,arm='plan_reflect'):
    a={(r['task'],r['repeat']):r for r in rr if r['strategy']=='adaptive'}
    b={(r['task'],r['repeat']):r for r in rr if r['strategy']==arm}
    assert a.keys()==b.keys() and a
    return [(a[k],b[k]) for k in sorted(a)]
def counts(v):
    return {'n':len(v),'correct':v.count(1),'incorrect':v.count(0),'unknown':v.count(None),'accuracy_bounds':[v.count(1)/len(v),(v.count(1)+v.count(None))/len(v)]}
def cluster_repeat(pp,version,kind):
    groups=defaultdict(list)
    for a,b in pp: groups[(a['difficulty'],a['task'])].append((a['labels'][version],b['labels'][version]))
    assert all(len(v)==3 for v in groups.values())
    by=defaultdict(list)
    for (d,t),vs in groups.items():
        by[d].append([sum((j if x is None else x)-(1-j if y is None else y) for x,y in vs)/3 for j in (0,1)])
    n=len(groups); low=[];high=[]
    if kind=='original':
        # Frozen Python PRNG, strata and task ordering, quantile rule.
        bounds=[]
        for j in (0,1):
            rng=random.Random(20261014); draw=[]
            for _ in range(2000): draw.append(sum(sum(rng.choice(v)[j] for __ in range(len(v))) for v in by.values())/n)
            draw.sort();bounds.append(draw[int((.025 if j==0 else .975)*1999)])
    else:
        # Follow-up repeats use a single task-cluster draw shared by the bounds.
        bytask={t:vs for (d,t),vs in groups.items()};tasks=sorted(bytask)
        vals=np.array([[sum((j if x is None else x)-(1-j if y is None else y) for x,y in bytask[t])/3 for j in (0,1)] for t in tasks])
        idx=np.random.default_rng(20261020).integers(0,n,size=(2000,n))
        draw=vals[idx].mean(axis=1);bounds=[float(np.percentile(draw[:,0],2.5)),float(np.percentile(draw[:,1],97.5))]
    mean=[sum(sum(v[j] for v in vs) for vs in by.values())/n for j in (0,1)]
    consistency={}
    for arm,pos in [('adaptive',0),('plan_reflect',1)]:
        seq=[[v[pos] for v in vv] for vv in groups.values()];known=[s for s in seq if None not in s]
        consistency[arm]={'fixed_tasks':n,'three_known':len(known),'identical':sum(len(set(s))==1 for s in known),'rate':sum(len(set(s))==1 for s in known)/len(known) if known else None}
    return {'n_tasks':n,'n_paired_runs':len(pp),'difference_bounds':mean,'descriptive_cluster_bootstrap_95':bounds,'draws':2000,'consistency':consistency}
def resource(pp):
    # Match the follow-up's recorded metric order; one draw stream continues.
    rng=np.random.default_rng(20261020);out={}
    for metric in ['total_tokens','n_calls']:
        by=defaultdict(list);coverage=0
        for a,b in pp:
            x=a['meter'].get(metric);y=b['meter'].get(metric)
            coverage+=int(isinstance(x,(int,float)))+int(isinstance(y,(int,float)))
            if isinstance(x,(int,float)) and isinstance(y,(int,float)):by[a['difficulty']].append(x-y)
        nn=sum(map(len,by.values()));boot=[]
        for _ in range(2000):
            total=0.
            for vs in by.values():
                vv=np.array(vs);total+=float(vv[rng.integers(0,len(vs),len(vs))].sum())
            boot.append(total/nn)
        out[metric]={'n_pairs':nn,'coverage':coverage/(2*len(pp)),'mean_difference':sum(sum(v) for v in by.values())/nn,'bootstrap95':list(np.percentile(boot,[2.5,97.5]))}
    return out
def compare(x,y,tol=1e-10):
    assert len(x)==len(y)
    assert all(abs(a-b)<tol for a,b in zip(x,y)),(x,y)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args();root=args.source;out=args.out
    assert not out.exists();out.mkdir(parents=True)
    pop=read(root/'data/population.json');hum=root/'data/human_review'
    mats=read(hum/'paired_records_internal.json');material={(r['task_id'],r['answer_sha256']):r for r in mats};assert len(material)==len(mats)==1216
    adj=read(hum/'normalized_decisions_87.json');adj={r['review_id']:r for r in adj};assert len(adj)==87
    targets={f:{} for f in ('original','followup')};overlaps=Counter()
    for fam,filenames in [('original',['original_audit300.json','original_unknown_mapping.json']),('followup',['followup_audit300.json','followup_unknown_mapping.json'])]:
        for fn in filenames:
            for item in read(hum/fn):
                m=(item['task_id'],item['answer_sha256']);assert m in material
                for member in item['members']:
                    key=(member['run_id'],member['strategy'],item['task_id'],str(member['repeat_id'])) if fam=='original' else member['run_id']
                    if key in targets[fam]:assert targets[fam][key]==m;overlaps[fam]+=1
                    targets[fam][key]=m
    gold={'math_precalculus_test_0039','math_precalculus_test_0343'}
    versions=['audit_original_gold','audit_gold_sensitivity']
    def revised(fam,key,task,hash_,base,failure):
        rec=material[targets[fam][key]] if key in targets[fam] else None
        if rec:assert (task,hash_)==(rec['task_id'],rec['answer_sha256'])
        ans={}
        for v in versions:
            val=base
            if rec and not(task in gold and v==versions[0]):
                if rec['review_id'] in adj:decision=adj[rec['review_id']]['adjudication_decision']
                else:
                    assert not rec['full_review_required'] and rec['A']['semantic_decision']==rec['B']['semantic_decision'];decision=rec['A']['semantic_decision']
                val={'correct':1,'incorrect':0,'unresolved':None}[decision]
            ans[v]=0 if failure else val
        return ans,rec['review_id'] if rec else None
    overlay={(r['run_id'],r['strategy'],r['task_id'],str(r['repeat_id'])):r for r in read(root/'data/scoring/author_overlay.json')['entries']}
    replacement={(r['strategy'],r['task_id'],str(r['repeat_id'])):r for r in rows(root/'data/original/replacement7.jsonl')}
    allcounts=defaultdict(Counter);casereports={};mainreports={};repeatreports={};resource_original={};ledger=[];allcase={};used=set();mapped=Counter();seen=set();change=defaultdict(Counter);errors=empty=0
    for case in pop['cases']:
        rr=[];caseid=case['run_id']
        for rel in case['components']:
            for raw in rows(root/rel):
                key=(raw['strategy'],raw['task_id'],str(raw['repeat_id']))
                if case['kind']=='secondary_backbone' and case['source']=='gsm8k' and key in replacement:raw=replacement[key];used.add(key)
                full=(caseid,*key);assert full not in seen;seen.add(full)
                frozen=outcome(raw);hist=frozen
                if full in overlay:
                    assert ah(str(raw.get('final_answer') or '').strip())==overlay[full]['answer_sha256'];hist=int(bool(overlay[full]['author_outcome']))
                labels,rid=revised('original',full,raw['task_id'],ah(raw.get('final_answer')),hist,bool(raw.get('error') or not str(raw.get('final_answer') or '').strip()))
                labels.update(frozen=frozen,historical_author=hist);mapped['original']+=int(rid is not None)
                r={'key':list(full),'task':raw['task_id'],'strategy':raw['strategy'],'repeat':str(raw['repeat_id']),'difficulty':raw['difficulty'],'labels':labels,'meter':raw.get('meter_summary') or {},'attempts':(raw.get('request_audit_summary') or {}).get('recorded_request_attempts'),'usage_tokens':sum(u.get('total_tokens',0) for u in raw.get('usage_records',[])),'error':bool(raw.get('error')),'empty':not str(raw.get('final_answer') or '').strip(),'stop':raw.get('stop_reason'),'answer_sha256':ah(raw.get('final_answer')),'review_id':rid}
                rr.append(r);ledger.append({k:v for k,v in r.items() if k not in ('meter',)})
                for v,val in labels.items():allcounts[v][str(val)]+=1
                for v in versions:change[v]['original']+=int(labels[v]!=hist)
                errors+=r['error'];empty+=r['empty']
        assert len(rr)==case['planned_rows'];allcase[caseid]=rr
        casereports[caseid]={v:{s:counts([r['labels'][v] for r in rr if r['strategy']==s]) for s in sorted({r['strategy'] for r in rr})} for v in ['frozen','historical_author',*versions]}
        resource_original[caseid]={s:{'n':len(v),'mean_recorded_attempts':sum(r['attempts'] for r in v if r['attempts'] is not None)/sum(r['attempts'] is not None for r in v),'known_usage_tokens':sum(r['usage_tokens'] for r in v),'execution_errors':sum(r['error'] for r in v),'empty_answers':sum(r['empty'] for r in v)} for s in sorted({r['strategy'] for r in rr}) for v in [[r for r in rr if r['strategy']==s]]}
        if case['kind'] in ['primary','secondary_backbone']:mainreports[caseid]={v:interval(pair(rr),v) for v in ['frozen','historical_author',*versions]}
        if case['kind']=='repeats':repeatreports[caseid]={v:cluster_repeat(pair(rr),v,'original') for v in ['frozen','historical_author',*versions]}
        print('independently read and counted '+caseid,flush=True)
    assert len(seen)==51000 and len(used)==7 and mapped['original']==len(targets['original'])
    dump(out/'original_labels_independent.json',ledger);dump(out/'original_case_counts.json',casereports);dump(out/'original_resources.json',resource_original);dump(out/'original_primary_intervals.json',mainreports);dump(out/'original_repeats.json',repeatreports)
    ff=[];followledger=[];hashes={r['run_id']:(r['task_id'],ah(r.get('final_answer'))) for phase in ['main','repeats'] for r in rows(root/f'data/followup/{phase}/trajectories.jsonl')};assert len(hashes)==6400
    fcounts=defaultdict(Counter)
    for phase in ['main','repeats']:
        for raw in rows(root/f'data/followup/{phase}/scored.jsonl'):
            assert hashes[raw['run_id']]==(raw['task_id'],raw['answer_sha256'])
            labels,rid=revised('followup',raw['run_id'],raw['task_id'],raw['answer_sha256'],raw['value'],raw['bucket']=='zero_by_policy');labels['baseline']=raw['value'];mapped['followup']+=int(rid is not None)
            r={'key':raw['run_id'],'pairid':raw['pair_id'],'task':raw['task_id'],'strategy':raw['strategy'],'repeat':int(raw['repeat_id']),'difficulty':raw['difficulty'],'source':raw['source'],'labels':labels,'meter':raw.get('meter_summary') or {},'review_id':rid};ff.append(r);followledger.append({k:v for k,v in r.items() if k!='meter'})
            for v,val in labels.items():fcounts[v][str(val)]+=1
            for v in versions:change[v]['followup']+=int(labels[v]!=raw['value'])
    assert len(ff)==6400 and mapped['followup']==len(targets['followup'])
    freports={};fresources={};frepeats={};additional={};multiplicity={};fcountsby={}
    manifest=read(root/'data/followup/task_manifest.json')
    for source in ['gsm8k','math']:
        pp=pair([r for r in ff if r['source']==source and r['repeat']==0]);assert len(pp)==1000
        freports[source]={v:interval(pp,v) for v in ['baseline',*versions]}
        # Preserve pairing.py's difficulty/key ordering for frozen RNG reproducibility.
        ppres=sorted(pp,key=lambda ab:(ab[0]['difficulty'],ab[0]['pairid']));fresources[source]=resource(ppres)
        additional[source]={str(rep):{v:interval(pair([r for r in ff if r['source']==source and r['repeat']==rep]),v) for v in ['baseline',*versions]} for rep in [1,2]}
        tasks={r['task_id'] for r in manifest if r['source']==source and r['matched_repeat_subset']};assert len(tasks)==300
        repeatpp=pair([r for r in ff if r['source']==source and r['task'] in tasks]);frepeats[source]={v:cluster_repeat(repeatpp,v,'followup') for v in ['baseline',*versions]}
        multiplicity[source]={v:interval(pp,v,alpha=.025) for v in ['baseline',*versions]}
        fcountsby[source]={v:{s:counts([r['labels'][v] for r in ff if r['source']==source and r['repeat']==0 and r['strategy']==s]) for s in ['adaptive','plan_reflect']} for v in ['baseline',*versions]}
    dump(out/'followup_labels_independent.json',followledger);dump(out/'followup_main_intervals.json',freports);dump(out/'followup_main_counts.json',fcountsby);dump(out/'followup_resources.json',fresources);dump(out/'followup_additional_repeats.json',additional);dump(out/'followup_repeats.json',frepeats);dump(out/'multiplicity_sensitivity_two_comparisons.json',multiplicity)
    # Agreement is reconstructed from votes, before consulting expected files.
    agreement={}
    for part in sorted({r['source_part'] for r in mats}):
        mm=[r for r in mats if r['source_part']==part];ct=Counter((r['A']['semantic_decision'],r['B']['semantic_decision']) for r in mm);n=len(mm);ca=Counter(r['A']['semantic_decision'] for r in mm);cb=Counter(r['B']['semantic_decision'] for r in mm);po=sum(x==y for x,y in [(r['A']['semantic_decision'],r['B']['semantic_decision']) for r in mm])/n;pe=sum(ca[k]*cb[k] for k in set(ca)|set(cb))/n**2
        agreement[part]={'n':n,'agreement_count':round(po*n),'agreement':po,'kappa':(po-pe)/(1-pe),'table':{f'{a}/{b}':v for (a,b),v in ct.items()},'distinct_tasks':len({r['task_id'] for r in mm})}
    dump(out/'pre_adjudication_agreement.json',agreement)
    # Only now read existing aggregates and compare, so expected outputs are not inputs to calculations.
    expected=read(root/'expected/human_audit/original_primary_statistics.json');checks=0
    for case,vv in mainreports.items():
        for v,stat in vv.items():
            e=expected[case][v]['primary_stratified_cp'];compare(stat['confidence_interval'],e['confidence_interval']);compare(stat['difference_bounds'],e['difference_bounds']);assert stat['unknown_pairs']==e['uncertain_pairs'];checks+=1
    expected=read(root/'expected/human_audit/followup_statistics.json')
    for source,vv in freports.items():
        for v,stat in vv.items():
            e=expected[v]['sources'][source]['primary_stratified_cp'];compare(stat['confidence_interval'],e['confidence_interval']);compare(stat['difference_bounds'],e['difference_bounds']);assert stat['unknown_pairs']==e['unknown_pairs'];checks+=1
        for rep,vv2 in additional[source].items():
            for v,stat in vv2.items():
                e=expected[v]['per_repeat_paired_cp'][source][rep];compare(stat['confidence_interval'],e['confidence_interval']);compare(stat['difference_bounds'],e['difference_bounds']);checks+=1
        for metric,r in fresources[source].items():
            e=expected['baseline']['sources'][source]['resources'][metric];compare(r['bootstrap95'],e['cluster_bootstrap_95']);assert r['mean_difference']==e['observed_mean_adaptive_minus_plan_reflect']
    expected=read(root/'expected/human_audit/original_case_summaries.json');countchecks=0;resourcechecks=0
    for case,vv in casereports.items():
        for v,ss in vv.items():
            for strategy,c in ss.items():
                e=expected[case][v][strategy];assert c=={k:e[k] for k in c};countchecks+=1
        for s,c in resource_original[case].items():
            e=expected[case]['frozen'][s];assert c=={k:e[k] for k in c};resourcechecks+=1
    expected=read(root/'expected/human_audit/original_repeat_statistics.json');repeatchecks=0
    for case,vv in repeatreports.items():
        for v,ss in vv.items():
            e=expected[case][v];compare(ss['difference_bounds'],[e['low_assignment']['difference_a_minus_b'],e['high_assignment']['difference_a_minus_b']]);compare(ss['descriptive_cluster_bootstrap_95'],[e['low_assignment']['descriptive_percentile95'][0],e['high_assignment']['descriptive_percentile95'][1]]);repeatchecks+=1
    expected=read(root/'expected/human_audit/followup_statistics.json')
    for source,vv in frepeats.items():
        for v,ss in vv.items():
            e=expected[v]['repeat_consistency'][source]['clustered_task_level_difference'];compare(ss['difference_bounds'],e['difference_bounds']);compare(ss['descriptive_cluster_bootstrap_95'],e['cluster_bootstrap_outer95']);repeatchecks+=1
    summary={'status':'PASS','source':str(root.resolve()),'original_formal_rows':len(seen),'original_physical_rows':pop['original_physical_records'],'followup_rows':len(ff),'original_cases':len(allcase),'replacement_records':len(used),'material_count':len(mats),'adjudication_count':len(adj),'adjudication_decisions':dict(Counter(r['adjudication_decision'] for r in adj.values())),'mapped_trajectories':dict(mapped),'duplicate_crosswalk_memberships':dict(overlaps),'original_label_counts':{v:dict(c) for v,c in allcounts.items()},'followup_label_counts':{v:dict(c) for v,c in fcounts.items()},'label_changes':{v:dict(c) for v,c in change.items()},'original_execution_errors':errors,'original_empty_answers':empty,'cp_comparisons_matching':checks,'case_count_comparisons_matching':countchecks,'original_strategy_resource_comparisons_matching':resourcechecks,'cluster_repeat_comparisons_matching':repeatchecks,'followup_resource_intervals_matching':4,'network_blocked':True,'new_model_calls':0,'scientific_scope':'computational reconstruction of archived labels, not an independent mathematical re-rating or new experiment'}
    dump(out/'independent_summary.json',summary);dump(out/'input_sha256.json',INPUTS)
    with (out/'primary_traceability.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['family','comparison','version','n','difference_lower_pp','difference_upper_pp','ci_lower_pp','ci_upper_pp','unknown_pairs','strict_pass'])
        for family,reports in [('original',mainreports),('followup',freports)]:
            for case,vv in reports.items():
                for v,s in vv.items():w.writerow([family,case,v,s['n'],*[100*x for x in s['difference_bounds']],*[100*x for x in s['confidence_interval']],s['unknown_pairs'],s['passes_strict_lower_gt_minus_003']])
    print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
