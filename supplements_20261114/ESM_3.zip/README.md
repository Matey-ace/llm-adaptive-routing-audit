# Online Resource 3 — retrospective workflow and evaluation analyses

Article: **Resource Accounting and Evaluation Sensitivity in Adaptive LLM Mathematical Reasoning**

Author: Mai Ye. Correspondence: 2025233201343@stumail.gdipu.edu.cn.
Target journal: SN Computer Science. Archive version: 2026-11-09, author-review candidate; no journal submission or acceptance is asserted.

## Portable offline mode (recommended)

Unzip into a new directory, install requirements before going offline, and run:

    python -B code/portable_reproduce.py --input /path/to/ESM_3 --output /path/to/NEW_RESULTS

The output must be new and outside the extracted input directory. The entry point blocks socket connections. It imports only standard libraries, NumPy, SciPy and the adjacent **independent audit** module. It never imports the project's production agents, collector or service client, and performs zero model calls.

It verifies every package file, independently rebuilds Table 15 from 11,537 call-level numeric usage rows; reproduces Table 16 request/token bootstrap means and full intervals (2,000 draws, seed 20261109); reconstructs the full one-anchor CP intervals under all three score versions; and reconstructs Table 17 nominal and two-dataset simultaneous intervals and all eligible one-label adverse-edit classes. Numeric comparisons use an absolute tolerance of 1e-8, much smaller than displayed precision. Outputs include full request and quality intervals, not only the main paper's abbreviated columns. NumPy PRNG and percentile conventions are retained. Reference runtime: Python 3.13, NumPy 2.5.1, SciPy 1.18.0; Python 3.10+ syntax is used, but exact cross-version results should be checked rather than assumed.

The package contains 51,000 original and 6,400 follow-up numeric/versioned label records. The portable entry verifies their counts and label distributions. **It does not independently re-rate mathematics, re-link all raw answers, replay the original scoring engine, or re-create all original Tables 1–14 from raw texts.** Those operations require Online Resource 2. Exact answer hashes are retained where present, but answer texts and rating identities/prose are absent.

## S2 boundary: what this portable mode proves

The actual frozen Agent was executed previously with a deterministic local client; its 12 stored cap/judge/S2 cases are in evidence/s2_budget_mock.json. Five source snapshots are hash-matched to that execution. The portable entry independently reconstructs the finite call schedule and verifies those 12 cases; it reads/verifies source snapshots but does not execute them. Earliest two-change stopping is 8+g calls, where g is the number of preceding judge calls. At cap eight this does not save requests before the cap. This is a control-flow fixture, not a model-performance experiment. Running the original Agent fixture itself needs the complete original project dependency tree; it is not claimed as portable execution of production code.

## Workspace-dependent provenance scripts

workspace_scripts/ preserves the exact 9 November scripts. They document original paths and are **not the portable entry points**:

- independent_statistical_audit.py accepts --source pointing to a separately extracted ESM_2 and --out pointing to a new directory. It can reconstruct all versioned label mappings and the 34 paired-CP checks without the original project tree; NumPy/SciPy are required. Original full input/output answer text stays in ESM_2, not this package.
- independent_label_perturbation.py and independent_difficulty_quality.py import that adjacent independent module but expect the audit's original evidence/independent_statistics_v2 layout. Their portable equivalents are in code/portable_reproduce.py.
- resource_difficulty_bootstrap.py expects evidence/resource_trajectory_index.csv. Its complete self-contained equivalent is in the portable entry.
- resource_role_audit.py and s2_budget_mock.py use original workspace-relative paths and project source/dependencies. They are archived for provenance; use the portable numeric/schedule reconstructions here, or restore the documented original tree before executing them.
- root_crosscheck.py is evidence of a separate check and includes historical network-capable source. **Do not run it as the offline entry point.** Its numerical result is included as root_independent_crosscheck.json. The portable entry performs no network action.
- plot_independent_verification.py requires optional Matplotlib and the original evidence layout; the already rendered numeric plots are supplied.

## Relation to Online Resource 2

ESM_2 contains the original stored trajectories, benchmark/scoring evidence and review mappings. Use its reproduce.py with --mode verify, analysis or rescore and a new output directory. ESM_3 is an additional retrospective evidence package, not a replacement or edited ESM_2. The 9 November scripts and results are not represented as present in the older public Git tag. Reused benchmark problems, post-test labels, nominal single-comparison intervals, conditional IID assumptions and incomplete historical failed-request billing retain the limitations described in the article.

## Interpretation and licences

Table 16's anchor strata are defined retrospectively from benchmark information, not a deployable online policy. Intervals are pointwise; Table 17's simultaneous family is the two follow-up datasets for one fixed score version, not all versions/analyses. Hypothetical label edits are not independent experiments, proposed label corrections or error probabilities. Usage roles are additive observations, not causal removal experiments; missing failed-call tokens remain unknown.

Author-owned code/documentation: MIT, LICENSE_CODE_MIT.txt. Author-owned annotation compilation/versioned labels: GPL-3.0-only, data/LICENSE and LICENSES/GPL-3.0-only.txt. Factual numeric measurements and labels are not asserted to be exclusive property. Source-specific conditions remain; no blanket relicensing of third-party evidence is claimed. No rater identities, rationale prose, private return packets, benchmark problem/answer texts or literature full texts are included. MANIFEST.json lists every included file with byte count and SHA256.
